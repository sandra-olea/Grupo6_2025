<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('woo_sync_states', function (Blueprint $table) {
            $table->string('current_batch_id')->nullable()->after('last_stock_sync_at');
            $table->unsignedInteger('current_batch_total')->nullable()->after('current_batch_id');
            $table->unsignedInteger('current_batch_processed')->nullable()->after('current_batch_total');
            $table->string('current_batch_status')->nullable()->after('current_batch_processed');
            $table->timestamp('current_batch_started_at')->nullable()->after('current_batch_status');
            $table->timestamp('current_batch_finished_at')->nullable()->after('current_batch_started_at');
            $table->unsignedBigInteger('orders_imported_count')->default(0)->after('current_batch_finished_at');
            $table->unsignedBigInteger('orders_updated_count')->default(0)->after('orders_imported_count');
        });
    }

    public function down(): void
    {
        Schema::table('woo_sync_states', function (Blueprint $table) {
            $table->dropColumn([
                'current_batch_id',
                'current_batch_total',
                'current_batch_processed',
                'current_batch_status',
                'current_batch_started_at',
                'current_batch_finished_at',
                'orders_imported_count',
                'orders_updated_count',
            ]);
        });
    }
};
