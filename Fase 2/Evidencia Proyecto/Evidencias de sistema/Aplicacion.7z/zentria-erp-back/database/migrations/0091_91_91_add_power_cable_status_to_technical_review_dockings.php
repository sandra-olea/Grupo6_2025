<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('technical_review_dockings', function (Blueprint $table) {
            if (!Schema::hasColumn('technical_review_dockings', 'power_cable_status')) {
                $table->enum('power_cable_status', [
                    'good_condition',
                    'damaged_cable',
                    'not_matching_equipment',
                    'not_included',
                ])->nullable()->after('includes_power_adapter');
            }
        });
    }

    public function down(): void
    {
        Schema::table('technical_review_dockings', function (Blueprint $table) {
            if (Schema::hasColumn('technical_review_dockings', 'power_cable_status')) {
                $table->dropColumn('power_cable_status');
            }
        });
    }
};

