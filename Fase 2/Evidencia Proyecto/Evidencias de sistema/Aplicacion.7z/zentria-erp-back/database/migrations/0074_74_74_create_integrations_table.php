<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('integrations', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignId('subsidiary_id')->constrained('subsidiaries')->onDelete('cascade');
            $table->string('name');
            // Ej: 'woocommerce', 'falabella', 'shopify', etc.
            $table->string('provider', 50);
            $table->text('base_url');

            // Credenciales de acceso
            $table->text('consumer_key')->nullable();
            $table->text('consumer_secret')->nullable();
            $table->text('api_token')->nullable();

            // Webhooks + API key de enrutamiento por subsidiary
            $table->string('webhook_secret')->nullable(); // Para validar X-WC-Webhook-Signature
            $table->string('api_key_prefix', 24)->nullable(); // Prefijo visible del token entrante
            $table->string('api_key_hash')->nullable(); // Hash del token completo (argon/bcrypt)

            // Modo: read, write, read_write
            $table->string('mode', 20)->default('read');
            $table->boolean('is_active')->default(true);

            // Alcances y restricciones
            $table->json('scopes')->nullable(); // p.ej. ["orders","refunds"]
            $table->json('allowed_ips')->nullable();
            $table->json('params')->default(DB::raw("'{}'::json"));

            $table->timestampTz('last_success_at')->nullable();
            $table->timestampTz('last_error_at')->nullable();
            $table->text('last_error_msg')->nullable();

            $table->timestampsTz();

            // Índices útiles
            $table->index(['subsidiary_id', 'provider']);
            $table->index('is_active');
            $table->unique(['subsidiary_id', 'provider', 'name'], 'integrations_sub_provider_name_unique');
            $table->unique('api_key_prefix');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('integrations');
    }
};
