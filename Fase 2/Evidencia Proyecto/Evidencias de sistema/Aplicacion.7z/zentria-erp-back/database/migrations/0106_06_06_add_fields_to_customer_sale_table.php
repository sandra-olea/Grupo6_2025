<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('customer_sale', function (Blueprint $table) {
            if (!Schema::hasColumn('customer_sale', 'customer_code')) {
                $table->string('customer_code', 100)->nullable()->after('subsidiary_id');
            }
            if (!Schema::hasColumn('customer_sale', 'document_type')) {
                $table->string('document_type', 20)->nullable()->default('rut')->after('customer_code');
            }
            if (!Schema::hasColumn('customer_sale', 'primary_contact_name')) {
                $table->string('primary_contact_name', 255)->nullable()->after('contact_name');
            }
            if (!Schema::hasColumn('customer_sale', 'primary_contact_email')) {
                $table->string('primary_contact_email', 255)->nullable()->after('primary_contact_name');
            }
            if (!Schema::hasColumn('customer_sale', 'primary_contact_phone')) {
                $table->string('primary_contact_phone', 50)->nullable()->after('primary_contact_email');
            }
        });
    }

    public function down(): void
    {
        Schema::table('customer_sale', function (Blueprint $table) {
            if (Schema::hasColumn('customer_sale', 'primary_contact_phone')) {
                $table->dropColumn('primary_contact_phone');
            }
            if (Schema::hasColumn('customer_sale', 'primary_contact_email')) {
                $table->dropColumn('primary_contact_email');
            }
            if (Schema::hasColumn('customer_sale', 'primary_contact_name')) {
                $table->dropColumn('primary_contact_name');
            }
            if (Schema::hasColumn('customer_sale', 'document_type')) {
                $table->dropColumn('document_type');
            }
            if (Schema::hasColumn('customer_sale', 'customer_code')) {
                $table->dropColumn('customer_code');
            }
        });
    }
};

