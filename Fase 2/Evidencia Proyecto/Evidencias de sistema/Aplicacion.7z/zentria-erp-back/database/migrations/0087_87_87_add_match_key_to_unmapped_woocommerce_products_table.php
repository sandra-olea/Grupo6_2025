<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('unmapped_woocommerce_products', function (Blueprint $table) {
            $table->string('match_key', 128)->nullable()->after('sku');
            $table->index(['integration_id', 'match_key', 'resolution_status'], 'idx_uwoo_matchkey');
        });

        // Backfill existing rows: prefer SKU when present, else normalized name
        // Normalize: lowercase, trim, collapse spaces
        DB::statement(<<<SQL
            UPDATE unmapped_woocommerce_products
            SET match_key = CASE
                WHEN COALESCE(NULLIF(TRIM(sku), ''), '') <> '' THEN 'sku:' || LOWER(REPLACE(sku, ' ', ''))
                WHEN COALESCE(NULLIF(TRIM(name), ''), '') <> '' THEN 'name:' || LOWER(REGEXP_REPLACE(name, '\\s+', ' ', 'g'))
                ELSE NULL
            END
            WHERE match_key IS NULL;
        SQL);
    }

    public function down(): void
    {
        Schema::table('unmapped_woocommerce_products', function (Blueprint $table) {
            $table->dropIndex('idx_uwoo_matchkey');
            $table->dropColumn('match_key');
        });
    }
};

