<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Cambiar tipo de columna a TEXT para soportar el string encriptado (Crypt::encryptString)
        DB::statement('ALTER TABLE integrations ALTER COLUMN webhook_secret TYPE TEXT');
    }

    public function down(): void
    {
        // Volver a VARCHAR(255) si fuese necesario
        DB::statement('ALTER TABLE integrations ALTER COLUMN webhook_secret TYPE VARCHAR(255)');
    }
};

