<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Un webhook activo por subsidiaria para WooCommerce
        DB::statement(<<<SQL
            CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_woo_webhook_active_per_subsidiary
            ON integrations (subsidiary_id)
            WHERE provider = 'woocommerce' AND mode = 'webhook' AND is_active = true
        SQL);

        // Un REST (read|read_write) activo por subsidiaria para WooCommerce
        DB::statement(<<<SQL
            CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_woo_rest_active_per_subsidiary
            ON integrations (subsidiary_id)
            WHERE provider = 'woocommerce' AND mode IN ('read','read_write') AND is_active = true
        SQL);
    }

    public function down(): void
    {
        DB::statement('DROP INDEX IF EXISTS idx_unique_woo_webhook_active_per_subsidiary');
        DB::statement('DROP INDEX IF EXISTS idx_unique_woo_rest_active_per_subsidiary');
    }
};

