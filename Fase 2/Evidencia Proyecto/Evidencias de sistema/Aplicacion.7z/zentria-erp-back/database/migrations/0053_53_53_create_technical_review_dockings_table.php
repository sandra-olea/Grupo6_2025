<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_dockings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('review_item_id')->constrained('technical_review_items')->onDelete('cascade');
            
            // Identificación
            $table->string('brand')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable();
            
            // Accesorios incluidos
            $table->boolean('includes_power_adapter')->default(false);
            $table->text('other_includes')->nullable();
            
            // Condición general
            $table->enum('general_condition', ['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'])->nullable();
            
            // Puertos y conectividad (presencia)
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_usb_c')->default(false);
            $table->boolean('has_sd_reader')->default(false);
            $table->boolean('has_wifi')->default(false);
            $table->boolean('has_rj45')->default(false);
            
            // Puertos (cantidad)
            $table->unsignedTinyInteger('usb_ports_count')->default(0);
            
            // Estado físico
            $table->enum('cover_condition', ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'])->nullable();
            
            // Observaciones
            $table->text('observations')->nullable();
            
            // Campos flexibles
            $table->json('extra_attributes')->nullable();
            
            $table->timestamps();
            
            $table->index('review_item_id');
            $table->index('brand');
            $table->index('model');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_dockings');
    }
};
