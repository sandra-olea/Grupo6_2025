<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_aios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('review_item_id')->constrained('technical_review_items')->onDelete('cascade');
            
            // Identificación
            $table->string('brand')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable();
            
            // Hardware
            $table->string('processor')->nullable();
            $table->string('ram_size')->nullable();
            $table->string('ram_slots')->nullable();
            $table->enum('ram_type', ['DDR3', 'DDR4', 'DDR5'])->nullable();
            $table->string('storage_size')->nullable();
            $table->enum('storage_technology', ['HDD', 'SSD', 'M2', 'NVME', 'HYBRID'])->nullable();
            
            // Accesorios incluidos
            $table->boolean('includes_power_adapter')->default(false);
            $table->enum('charger_status', ['good_condition','damaged_cable','not_matching_equipment','not_included'])->nullable();
            $table->boolean('includes_keyboard')->default(false);
            $table->boolean('includes_mouse')->default(false);
            $table->text('other_includes')->nullable();
            
            // Condición general
            $table->enum('general_condition', ['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'])->nullable();
            
            // Conectividad (presencia)
            $table->boolean('has_wifi')->default(false);
            $table->boolean('has_bluetooth')->default(false);
            $table->boolean('has_cd_drive')->default(false);
            
            // Puertos (cantidad)
            $table->unsignedTinyInteger('vga_ports')->default(0);
            $table->unsignedTinyInteger('hdmi_ports')->default(0);
            $table->unsignedTinyInteger('displayport_ports')->default(0);
            $table->unsignedTinyInteger('usb_a_ports')->default(0);
            $table->unsignedTinyInteger('usb_c_ports')->default(0);
            $table->unsignedTinyInteger('sd_readers')->default(0);
            $table->unsignedTinyInteger('rj45_ports')->default(0);
            
            // Pantalla
            $table->string('screen_inches')->nullable();
            $table->enum('screen_condition', ['ok', 'worn', 'missing_pieces', 'dead_pixels', 'broken'])->nullable();
            $table->boolean('is_touchscreen')->default(false);
            
            // Estado físico
            $table->enum('cover_condition', ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'])->nullable();
            
            // Sistema operativo
            $table->string('operating_system')->nullable();
            
            // Características adicionales
            $table->text('other_features')->nullable();
            
            // Observaciones
            $table->text('observations')->nullable();
            
            // Campos flexibles
            $table->json('extra_attributes')->nullable();
            
            $table->timestamps();
            
            $table->index('review_item_id');
            $table->index('brand');
            $table->index('model');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_aios');
    }
};
