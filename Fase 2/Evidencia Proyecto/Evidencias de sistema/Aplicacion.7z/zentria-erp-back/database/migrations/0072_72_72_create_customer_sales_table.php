<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('customer_sale', function (Blueprint $table) {
            $table->id();

            $table->foreignId('subsidiary_id')->constrained('subsidiaries')->onDelete('cascade');

            $table->string('type', 20)->default('company'); // natural | company
            $table->string('rut', 20);
            $table->string('billing_company', 255)->nullable();
            $table->string('trade_activity', 255)->nullable();

            $table->string('contact_name', 255)->nullable();
            $table->string('email', 255)->nullable();
            $table->string('phone', 50)->nullable();

            // Billing address (optional)
            $table->string('billing_address_1', 255)->nullable();
            $table->string('billing_address_2', 255)->nullable();
            $table->string('billing_city', 255)->nullable();
            $table->foreignId('commune_id')->nullable()->constrained('communes');
            $table->string('billing_state_code', 10)->nullable();
            $table->string('billing_postcode', 20)->nullable();
            $table->char('billing_country_code', 2)->default('CL');

            // Shipping address (optional)
            $table->string('shipping_address_1', 255)->nullable();
            $table->string('shipping_address_2', 255)->nullable();
            $table->string('shipping_city', 255)->nullable();
            $table->foreignId('shipping_commune_id')->nullable()->constrained('communes');
            $table->string('shipping_state_code', 10)->nullable();
            $table->string('shipping_postcode', 20)->nullable();
            $table->char('shipping_country_code', 2)->nullable();

            // Preferences/commercial
            $table->string('default_document_type', 20)->nullable(); // factura | boleta
            $table->string('preferred_payment_method', 50)->nullable();
            $table->string('purchase_order_number', 100)->nullable();
            $table->json('commercial_data')->nullable();

            $table->text('notes')->nullable();
            $table->boolean('is_active')->default(true);

            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
        });

        // Useful indexes
        Schema::table('customer_sale', function (Blueprint $table) {
            // Índices varios
            $table->index('email', 'idx_customer_sale_email');
            $table->index('phone', 'idx_customer_sale_phone');
            $table->index('commune_id', 'idx_customer_sale_commune');
            $table->index('shipping_commune_id', 'idx_customer_sale_shipping_commune');

            // Unicidad por subsidiary + rut (permite mismo RUT en distintas subsidiarias)
            $table->unique(['subsidiary_id', 'rut'], 'customer_sale_subsidiary_rut_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('customer_sale');
    }
};
