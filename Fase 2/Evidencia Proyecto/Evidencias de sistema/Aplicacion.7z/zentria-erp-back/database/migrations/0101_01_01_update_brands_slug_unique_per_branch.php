<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('brands', function (Blueprint $table) {
            // Drop global unique on slug if exists
            try { $table->dropUnique('brands_slug_unique'); } catch (\Throwable $e) {}
        });

        // Create composite uniqueness per branch for slug
        // Note: Laravel's unique() cannot express partial indexes; using composite is OK here
        Schema::table('brands', function (Blueprint $table) {
            $table->unique(['branch_id', 'slug'], 'brands_branch_slug_unique');
        });
    }

    public function down(): void
    {
        Schema::table('brands', function (Blueprint $table) {
            try { $table->dropUnique('brands_branch_slug_unique'); } catch (\Throwable $e) {}
            // Restore global unique on slug
            $table->unique('slug', 'brands_slug_unique');
        });
    }
};

