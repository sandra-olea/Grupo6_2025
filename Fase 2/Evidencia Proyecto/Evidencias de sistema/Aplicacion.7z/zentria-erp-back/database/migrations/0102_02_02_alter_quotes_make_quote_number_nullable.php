<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $driver = DB::getDriverName();

        if ($driver === 'pgsql') {
            DB::statement('ALTER TABLE quotes ALTER COLUMN quote_number DROP NOT NULL');
        } elseif ($driver === 'mysql') {
            DB::statement('ALTER TABLE quotes MODIFY quote_number VARCHAR(255) NULL');
        } else {
            // Fallback genérico: intentar vía SQL estándar
            try {
                DB::statement('ALTER TABLE quotes ALTER COLUMN quote_number DROP NOT NULL');
            } catch (\Throwable $e) {
                // No soportado en este driver; dejar trazado en logs para intervención manual
                \Log::warning('No se pudo alterar nullability de quotes.quote_number automáticamente', [
                    'driver' => $driver,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }

    public function down(): void
    {
        $driver = DB::getDriverName();

        if ($driver === 'pgsql') {
            DB::statement('ALTER TABLE quotes ALTER COLUMN quote_number SET NOT NULL');
        } elseif ($driver === 'mysql') {
            DB::statement('ALTER TABLE quotes MODIFY quote_number VARCHAR(255) NOT NULL');
        } else {
            try {
                DB::statement('ALTER TABLE quotes ALTER COLUMN quote_number SET NOT NULL');
            } catch (\Throwable $e) {
                \Log::warning('No se pudo revertir nullability de quotes.quote_number', [
                    'driver' => $driver,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }
};

