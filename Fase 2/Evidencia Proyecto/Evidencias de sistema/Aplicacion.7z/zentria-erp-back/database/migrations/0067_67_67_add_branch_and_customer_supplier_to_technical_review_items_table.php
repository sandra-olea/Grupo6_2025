<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('technical_review_items', function (Blueprint $table) {
            $table->foreignId('branch_id')
                ->nullable()
                ->after('batch_id')
                ->constrained('branches')
                ->cascadeOnUpdate()
                ->restrictOnDelete();

            $table->foreignId('customer_supplier_id')
                ->nullable()
                ->after('branch_id')
                ->constrained('customer_suppliers')
                ->cascadeOnUpdate()
                ->nullOnDelete();
        });

        DB::table('technical_review_items')
            ->orderBy('id')
            ->chunkById(200, function ($items) {
                $batchIds = $items->pluck('batch_id')->filter()->unique();

                if ($batchIds->isEmpty()) {
                    return true;
                }

                $batches = DB::table('technical_review_batches')
                    ->whereIn('id', $batchIds)
                    ->get(['id', 'branch_id', 'customer_supplier_id'])
                    ->keyBy('id');

                foreach ($items as $item) {
                    $batch = $batches->get($item->batch_id);

                    if (!$batch) {
                        continue;
                    }

                    DB::table('technical_review_items')
                        ->where('id', $item->id)
                        ->update([
                            'branch_id' => $batch->branch_id,
                            'customer_supplier_id' => $batch->customer_supplier_id,
                        ]);
                }

                return true;
            });

        $driver = DB::getDriverName();
        if (in_array($driver, ['pgsql', 'mysql'])) {
            $constraint = $driver === 'pgsql'
                ? 'ALTER TABLE technical_review_items ALTER COLUMN branch_id SET NOT NULL'
                : 'ALTER TABLE technical_review_items MODIFY branch_id BIGINT UNSIGNED NOT NULL';

            DB::statement($constraint);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('technical_review_items', function (Blueprint $table) {
            $table->dropForeign(['customer_supplier_id']);
            $table->dropForeign(['branch_id']);
            $table->dropColumn(['customer_supplier_id', 'branch_id']);
        });
    }
};
