<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_validation_rules', function (Blueprint $table) {
            $table->id();
            $table->enum('equipment_type', ['notebook', 'desktop', 'docking', 'aio', 'monitor']);
            $table->string('field_name')->comment('Campo a validar');
            $table->enum('validation_type', ['required', 'format', 'range', 'dependency', 'suggestion']);
            $table->json('rule_config')->comment('Configuración dinámica de la regla');
            $table->string('error_message');
            $table->string('help_text')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('priority')->default(0)->comment('Mayor prioridad se ejecuta primero');
            $table->timestamps();

            $table->index(['equipment_type', 'field_name']);
            $table->index('is_active');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_validation_rules');
    }
};
