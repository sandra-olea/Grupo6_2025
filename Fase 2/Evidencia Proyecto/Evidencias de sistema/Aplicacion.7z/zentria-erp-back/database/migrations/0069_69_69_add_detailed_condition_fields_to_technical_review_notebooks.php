<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            // Modificar screen_condition para incluir nuevo valor 'minor_wear'
            $table->dropColumn('screen_condition');
        });
        
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->enum('screen_condition', ['ok', 'minor_wear', 'worn', 'missing_pieces', 'dead_pixels', 'broken'])->nullable()->after('screen_inches');
        });
        
        // Modificar cover_condition para incluir nuevo valor 'minor_wear'
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->dropColumn('cover_condition');
        });
        
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->enum('cover_condition', ['ok', 'minor_wear', 'worn', 'missing_pieces', 'scratched', 'broken'])->nullable()->after('touchpad_condition');
        });
        
        // Agregar campos para puertos detallados (cantidades individuales)
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            // Solo agregar el contador de puertos defectuosos, los demás ya existen
            $table->unsignedTinyInteger('defective_ports_count')->default(0)->after('all_ports_functional');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->dropColumn('defective_ports_count');
        });
        
        // Revertir screen_condition al estado original
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->dropColumn('screen_condition');
        });
        
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->enum('screen_condition', ['ok', 'worn', 'missing_pieces', 'dead_pixels', 'broken'])->nullable();
        });
        
        // Revertir cover_condition al estado original
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->dropColumn('cover_condition');
        });
        
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->enum('cover_condition', ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'])->nullable();
        });
    }
};
