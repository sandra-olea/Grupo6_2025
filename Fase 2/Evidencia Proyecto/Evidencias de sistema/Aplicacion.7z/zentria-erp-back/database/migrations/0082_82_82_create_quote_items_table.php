<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('quote_items', function (Blueprint $table) {
            $table->id();

            $table->foreignId('quote_id')->constrained('quotes')->onDelete('cascade');
            $table->foreignId('product_id')->constrained('products');

            $table->integer('quantity')->default(1);
            $table->decimal('unit_price', 15, 2)->nullable();
            $table->decimal('discount_rate', 5, 4)->default(0);
            $table->decimal('discount_amount', 15, 2)->default(0);
            $table->decimal('subtotal', 15, 2);
            $table->decimal('total', 15, 2);

            $table->string('customer_sku', 255)->nullable();
            $table->string('customer_name', 255)->nullable();
            $table->text('description')->nullable();
            $table->text('notes')->nullable();
            $table->json('product_attributes')->nullable();

            $table->timestamps();

            $table->index('quote_id', 'idx_quote_items_quote');
            $table->index('product_id', 'idx_quote_items_product');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('quote_items');
    }
};

