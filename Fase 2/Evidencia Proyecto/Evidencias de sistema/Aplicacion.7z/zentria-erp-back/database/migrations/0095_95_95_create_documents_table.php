<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('subsidiary_id')->nullable()->constrained('subsidiaries')->nullOnDelete();
            $table->foreignId('document_type_id')->nullable()->constrained('document_types')->nullOnDelete();
            $table->string('name', 255);
            $table->text('description')->nullable();
            $table->string('output_format', 16)->default('pdf');
            $table->string('related_module', 64)->nullable();
            $table->text('template_body')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index('subsidiary_id', 'idx_documents_subsidiary');
            $table->index('document_type_id', 'idx_documents_document_type');
            $table->index('related_module', 'idx_documents_related_module');
        });

        // Check constraint for related_module values (PostgreSQL)
        DB::statement(
            "ALTER TABLE documents ADD CONSTRAINT documents_related_module_check " .
            "CHECK (related_module IS NULL OR related_module IN ('CLIENTE','CLIENTE-PROVEEDOR','VENTAS','REVISIONES TÉCNICAS','PRODUCTO'))"
        );
    }

    public function down(): void
    {
        Schema::dropIfExists('documents');
    }
};

