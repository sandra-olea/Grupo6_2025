<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('woo_sync_states', function (Blueprint $table) {
            $table->uuid('integration_id')->primary();
            $table->unsignedBigInteger('subsidiary_id');
            $table->timestamp('last_order_created_at')->nullable();
            $table->unsignedBigInteger('last_order_id')->nullable();
            $table->timestamp('last_stock_sync_at')->nullable();
            $table->timestamps();

            $table->index('subsidiary_id', 'idx_woo_sync_states_subsidiary');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('woo_sync_states');
    }
};

