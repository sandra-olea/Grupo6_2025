<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_notebooks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('review_item_id')->constrained('technical_review_items')->onDelete('cascade');
            
            // Identificación
            $table->string('brand')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable();
            
            // Hardware
            $table->string('processor')->nullable();
            $table->string('ram_size')->nullable(); // "8GB", "16GB"
            $table->string('ram_slots')->nullable(); // "4x2", "8x1"
            $table->enum('ram_type', ['DDR3', 'DDR4', 'DDR5', 'LPDDR3', 'LPDDR4', 'LPDDR5'])->nullable();
            $table->string('storage_size')->nullable(); // "512GB", "1TB"
            $table->enum('storage_technology', ['HDD', 'SSD', 'M2', 'NVME', 'HYBRID'])->nullable();
            
            // Accesorios incluidos
            $table->boolean('includes_charger')->default(false);
            $table->string('charger_watts')->nullable(); // "65W", "90W"
            $table->text('other_includes')->nullable();
            
            // Condición general
            $table->enum('general_condition', ['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'])->nullable();
            
            // Puertos y conectividad (presencia)
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_usb_c')->default(false);
            $table->boolean('has_biometric')->default(false);
            $table->boolean('has_sd_reader')->default(false);
            $table->boolean('has_wifi')->default(false);
            $table->boolean('has_rj45')->default(false);
            $table->boolean('has_bluetooth')->default(false);
            
            // Puertos (cantidad)
            $table->unsignedTinyInteger('usb_ports_count')->default(0);
            
            // Pantalla
            $table->string('screen_inches')->nullable(); // "14\"", "15.6\""
            $table->enum('screen_condition', ['ok', 'worn', 'missing_pieces', 'dead_pixels', 'broken'])->nullable();
            $table->boolean('is_touchscreen')->default(false);
            
            // Teclado
            $table->enum('keyboard_condition', ['ok', 'worn', 'missing_pieces', 'broken'])->nullable();
            $table->enum('keyboard_layout', ['es', 'us', 'latam'])->nullable();
            $table->boolean('has_numeric_keypad')->default(false);
            $table->boolean('has_backlit_keyboard')->default(false);
            
            // Touchpad
            $table->enum('touchpad_condition', ['ok', 'worn', 'missing_pieces', 'broken'])->nullable();
            
            // Estado físico
            $table->enum('cover_condition', ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'])->nullable();
            $table->enum('hinge_condition', ['ok', 'worn', 'missing_pieces', 'broken'])->nullable();
            $table->enum('bottom_condition', ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'])->nullable();
            
            // Batería (formato dual)
            $table->string('battery_health')->nullable(); // "81%", "GOOD", "FAIR", "EXCELLENT"
            $table->enum('battery_status', ['excellent', 'good', 'fair', 'poor', 'no_battery'])->nullable();
            $table->integer('battery_percentage')->nullable(); // Valor numérico extraído
            $table->boolean('battery_holds_charge')->default(true);
            // Permitir también los valores 'fair' y 'poor' en battery_condition para compatibilidad
            $table->enum('battery_condition', ['excellent', 'good', 'fair', 'regular', 'poor', 'bad', 'no_battery'])->nullable();
            
            // Sistema operativo
            $table->string('operating_system')->nullable();
            
            // Observaciones
            $table->text('observations')->nullable();
            
            // Campos flexibles para datos adicionales
            $table->json('extra_attributes')->nullable();
            
            $table->timestamps();
            
            $table->index('review_item_id');
            $table->index('brand');
            $table->index('model');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_notebooks');
    }
};
