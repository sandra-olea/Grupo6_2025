<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_monitors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('review_item_id')->constrained('technical_review_items')->onDelete('cascade');
            
            // Identificación
            $table->string('brand')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable();
            
            // Accesorios incluidos
            $table->boolean('includes_power_cable')->default(false);
            $table->boolean('includes_video_cable')->default(false);
            $table->boolean('includes_stand')->default(false);
            $table->text('other_includes')->nullable();
            
            // Condición general
            $table->enum('general_condition', ['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'])->nullable();
            
            // Puertos y conectividad (presencia)
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_dvi')->default(false);
            $table->boolean('has_usb_hub')->default(false);
            
            // Puertos (cantidad)
            $table->unsignedTinyInteger('usb_ports_count')->default(0);
            
            // Pantalla
            $table->string('screen_inches')->nullable();
            $table->string('screen_resolution')->nullable(); // "1920x1080", "2560x1440"
            $table->enum('screen_condition', ['ok', 'worn', 'missing_pieces', 'dead_pixels', 'broken'])->nullable();
            $table->boolean('is_touchscreen')->default(false);
            
            // Estado físico
            $table->enum('frame_condition', ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'])->nullable();
            $table->enum('stand_condition', ['ok', 'worn', 'missing_pieces', 'broken', 'no_stand'])->nullable();
            
            // Observaciones
            $table->text('observations')->nullable();
            
            // Campos flexibles
            $table->json('extra_attributes')->nullable();
            
            $table->timestamps();
            
            $table->index('review_item_id');
            $table->index('brand');
            $table->index('model');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_monitors');
    }
};
