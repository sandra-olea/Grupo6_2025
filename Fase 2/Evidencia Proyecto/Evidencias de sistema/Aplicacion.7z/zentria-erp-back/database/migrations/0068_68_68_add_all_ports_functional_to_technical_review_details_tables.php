<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Notebooks
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->boolean('all_ports_functional')->default(true)->after('has_bluetooth');
        });

        // Desktops
        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->boolean('all_ports_functional')->default(true)->after('has_bluetooth');
        });

        // Dockings
        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->boolean('all_ports_functional')->default(true)->after('has_wifi');
        });

        // AIOs
        Schema::table('technical_review_aios', function (Blueprint $table) {
            $table->boolean('all_ports_functional')->default(true)->after('has_bluetooth');
        });

        // Monitors
        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->boolean('all_ports_functional')->default(true)->after('has_usb_hub');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->dropColumn('all_ports_functional');
        });

        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->dropColumn('all_ports_functional');
        });

        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->dropColumn('all_ports_functional');
        });

        Schema::table('technical_review_aios', function (Blueprint $table) {
            $table->dropColumn('all_ports_functional');
        });

        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->dropColumn('all_ports_functional');
        });
    }
};

