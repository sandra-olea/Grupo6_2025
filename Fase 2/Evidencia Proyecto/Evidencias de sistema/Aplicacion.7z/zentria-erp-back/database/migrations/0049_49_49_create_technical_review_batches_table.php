<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_batches', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique()->comment('Código único del lote');
            $table->foreignId('branch_id')->constrained('branches')->onDelete('restrict');
            $table->foreignId('warehouse_id')->constrained('warehouses')->onDelete('restrict');
            $table->foreignId('customer_supplier_id')
                ->nullable()
                ->constrained('customer_suppliers')
                ->nullOnDelete()
                ->comment('Cliente o proveedor origen');
            $table->date('entry_date')->comment('Fecha de ingreso de los equipos');
            $table->unsignedInteger('expected_quantity')->default(0)->comment('Cantidad esperada de equipos');
            $table->unsignedInteger('completed_quantity')->default(0)->comment('Cantidad completada');
            $table->enum('status', ['draft', 'in_progress', 'completed', 'cancelled'])->default('draft');
            $table->text('notes')->nullable();
            $table->foreignId('created_by')->constrained('users')->onDelete('restrict');
            $table->foreignId('updated_by')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamps();
            $table->softDeletes();

            $table->index('code');
            $table->index('status');
            $table->index(['branch_id', 'warehouse_id']);
            $table->index('entry_date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_batches');
    }
};
