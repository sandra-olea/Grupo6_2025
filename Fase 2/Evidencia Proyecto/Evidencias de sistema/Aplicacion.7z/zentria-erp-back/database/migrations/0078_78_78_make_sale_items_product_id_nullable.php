<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Drop existing foreign key if present, then make column nullable and re-add FK with SET NULL
        Schema::table('sale_items', function (Blueprint $table) {
            try { $table->dropForeign(['product_id']); } catch (\Throwable $e) {}
        });

        DB::statement('ALTER TABLE sale_items ALTER COLUMN product_id DROP NOT NULL');

        Schema::table('sale_items', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('products')->nullOnDelete();
        });
    }

    public function down(): void
    {
        // Revert to NOT NULL and standard FK (may fail if nulls exist)
        Schema::table('sale_items', function (Blueprint $table) {
            try { $table->dropForeign(['product_id']); } catch (\Throwable $e) {}
        });
        DB::statement('UPDATE sale_items SET product_id = 0 WHERE product_id IS NULL');
        DB::statement('ALTER TABLE sale_items ALTER COLUMN product_id SET NOT NULL');
        Schema::table('sale_items', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('products');
        });
    }
};

