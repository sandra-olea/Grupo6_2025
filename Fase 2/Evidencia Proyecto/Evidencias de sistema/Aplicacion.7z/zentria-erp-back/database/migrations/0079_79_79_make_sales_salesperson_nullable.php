<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // salesperson_id nullable para permitir ingesta automática sin asignación de vendedor
        DB::statement('ALTER TABLE sales ALTER COLUMN salesperson_id DROP NOT NULL');
    }

    public function down(): void
    {
        // Revertir (puede fallar si existen nulls)
        DB::statement('UPDATE sales SET salesperson_id = 0 WHERE salesperson_id IS NULL');
        DB::statement('ALTER TABLE sales ALTER COLUMN salesperson_id SET NOT NULL');
    }
};

