<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Desktops
        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->unsignedTinyInteger('defective_ports_count')->default(0)->after('all_ports_functional');
        });

        // Docking Stations
        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->unsignedTinyInteger('defective_ports_count')->default(0)->after('all_ports_functional');
        });

        // AIOs
        Schema::table('technical_review_aios', function (Blueprint $table) {
            $table->unsignedTinyInteger('defective_ports_count')->default(0)->after('all_ports_functional');
        });

        // Monitors
        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->unsignedTinyInteger('defective_ports_count')->default(0)->after('all_ports_functional');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->dropColumn('defective_ports_count');
        });

        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->dropColumn('defective_ports_count');
        });

        Schema::table('technical_review_aios', function (Blueprint $table) {
            $table->dropColumn('defective_ports_count');
        });

        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->dropColumn('defective_ports_count');
        });
    }
};
