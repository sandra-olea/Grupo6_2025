<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_scoring_rules', function (Blueprint $table) {
            $table->id();
            $table->enum('equipment_type', ['notebook', 'desktop', 'docking', 'aio', 'monitor']);
            $table->string('field_name');
            $table->json('condition')->comment('Condición que se evalúa');
            $table->integer('points')->comment('Puntos positivos o negativos');
            $table->enum('affects_grade', ['A', 'B', 'C', 'M'])->nullable();
            $table->text('reasoning')->nullable()->comment('Explicación del puntaje');
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index(['equipment_type', 'field_name']);
            $table->index('is_active');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_scoring_rules');
    }
};
