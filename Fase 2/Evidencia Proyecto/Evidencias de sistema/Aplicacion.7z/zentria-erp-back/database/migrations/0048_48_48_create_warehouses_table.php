<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('warehouses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('branch_id')->constrained()->cascadeOnDelete();
            $table->string('name', 255);
            $table->string('code', 255);
            $table->text('description')->nullable();
            $table->string('address', 255)->nullable();
            // Ubicación general dentro de la bodega (opcional)
            $table->string('storage_location', 255)->nullable();
            // Número de pallet o lugar específico (opcional)
            $table->string('pallet_spot', 255)->nullable();
            $table->foreignId('commune_id')->nullable()->constrained('communes');
            $table->integer('maximum_capacity')->nullable();
            $table->text('schedule')->nullable();
            $table->integer('capacity')->nullable();
            $table->string('warehouse_type', 255);
            $table->foreignId('manager_id')->nullable()->constrained('users');
            $table->boolean('is_active')->default(true);
            $table->boolean('requires_serial_tracking')->default(false);
            $table->timestamps();
            $table->softDeletes();

            $table->index(['branch_id', 'name']);
         });
    }

    public function down(): void
    {
        Schema::dropIfExists('warehouses');
    }
};
