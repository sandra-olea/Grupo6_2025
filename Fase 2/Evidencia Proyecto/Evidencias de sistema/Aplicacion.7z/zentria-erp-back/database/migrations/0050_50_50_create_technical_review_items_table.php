<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('batch_id')->constrained('technical_review_batches')->onDelete('cascade');
            $table->foreignId('warehouse_id')->constrained('warehouses')->onDelete('restrict');
            $table->string('serial_number')->index()->comment('Número de serie del equipo');
            $table->foreignId('product_id')->nullable()->constrained('products')->onDelete('set null');
            
            // Tipo de equipo
            $table->enum('equipment_type', ['notebook', 'desktop', 'docking', 'aio', 'monitor'])->nullable();
            
            // Estados
            $table->enum('review_status', ['pending', 'in_review', 'reviewed', 'approved'])->default('pending');
            $table->enum('current_status', [
                'received',
                'in_review',
                'reviewed',
                'available_for_sale',
                'in_quotation',
                'reserved',
                'sold',
                'returned',
                'scrapped'
            ])->default('received');
            
            // Calificación
            $table->enum('grade', ['A', 'B', 'C', 'M'])->nullable();
            $table->string('suggested_grade', 1)->nullable();
            $table->unsignedTinyInteger('scoring_confidence')->nullable()->comment('Confianza del scoring automático 0-100');
            $table->json('scoring_breakdown')->nullable()->comment('Desglose de puntuación');
            $table->boolean('override_suggestion')->default(false)->comment('Permite forzar un grado diferente al sugerido');
            $table->string('override_reason', 500)->nullable()->comment('Motivo del override del grado sugerido');
            
            // Destino
            $table->enum('destination', ['stock', 'sold_to_supplier', 'sold_to_final_customer', 'unknown'])->nullable();
            
            // Referencias (sin FK por ahora - se agregará cuando exista la tabla sales)
            $table->unsignedBigInteger('sale_id')->nullable()->index();
            
            // Fechas importantes
            $table->timestamp('review_started_at')->nullable()->comment('Fecha de inicio de revisión');
            $table->timestamp('reviewed_at')->nullable()->comment('Fecha de finalización de revisión');
            $table->timestamp('approved_at')->nullable()->comment('Fecha de aprobación final');
            
            // Auditoría y responsables
            $table->foreignId('created_by')->constrained('users')->onDelete('restrict');
            $table->foreignId('reviewed_by')->nullable()->constrained('users')->onDelete('set null')->comment('Técnico que realizó la revisión');
            $table->foreignId('approved_by')->nullable()->constrained('users')->onDelete('set null')->comment('Usuario que aprobó el equipo');
            $table->foreignId('updated_by')->nullable()->constrained('users')->onDelete('set null');
            
            $table->timestamps();
            $table->softDeletes();
            
            // Índices
            $table->unique(['serial_number', 'deleted_at'], 'technical_review_items_serial_deleted_unique');
            $table->index('equipment_type');
            $table->index('review_status');
            $table->index('current_status');
            $table->index('grade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_items');
    }
};
