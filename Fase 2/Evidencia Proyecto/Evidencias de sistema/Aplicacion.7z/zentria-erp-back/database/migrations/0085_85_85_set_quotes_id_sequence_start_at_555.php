<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Ajusta la secuencia de IDs de la tabla quotes para que comience en 555.
     * Los números de cotización serán incrementales: 555, 556, 557, etc.
     */
    public function up(): void
    {
        // Obtener el máximo ID actual de quotes
        $maxId = DB::table('quotes')->max('id') ?? 0;
        
        // Si el máximo ID es menor a 555, ajustamos la secuencia a 555
        // Si ya hay registros con ID >= 555, respetamos el valor actual
        $nextId = max(555, $maxId + 1);
        
        // Ajustar la secuencia de PostgreSQL
        DB::statement("SELECT setval('quotes_id_seq', ?, false)", [$nextId]);
        
        // Log para confirmar
        \Log::info("Quotes sequence adjusted", [
            'max_existing_id' => $maxId,
            'next_id_will_be' => $nextId
        ]);
    }

    /**
     * Reverse the migrations.
     * 
     * No es necesario revertir porque no queremos perder la numeración.
     */
    public function down(): void
    {
        // No revertimos la secuencia para mantener la integridad de los números
    }
};
