<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_error_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('review_item_id')->nullable()->constrained('technical_review_items')->onDelete('set null');
            $table->string('field_name');
            $table->string('error_type');
            $table->json('invalid_value');
            $table->json('suggested_value')->nullable();
            $table->boolean('was_corrected')->default(false);
            $table->timestamps();

            $table->index(['user_id', 'field_name']);
            $table->index('error_type');
            $table->index('was_corrected');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_error_logs');
    }
};
