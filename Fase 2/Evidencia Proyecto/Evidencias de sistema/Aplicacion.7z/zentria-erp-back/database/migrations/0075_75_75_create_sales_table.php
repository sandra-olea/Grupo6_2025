<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->id();

            // Contexto
            $table->foreignId('subsidiary_id')->constrained('subsidiaries')->onDelete('cascade');
            $table->unsignedBigInteger('customer_id'); // Ref a customer_sale.id

            // Sincronización WooCommerce (opcional)
            $table->unsignedBigInteger('wc_order_id')->nullable();
            $table->string('wc_order_number', 255)->nullable();

            // Datos clave
            $table->string('sale_number', 255);
            $table->string('status', 50)->default('draft');

            $table->unsignedBigInteger('quote_id')->nullable();
            $table->unsignedBigInteger('salesperson_id');

            // Fechas relevantes
            $table->date('sale_date');
            $table->date('delivery_date')->nullable();
            $table->timestamp('completed_at')->nullable();

            // Montos
            $table->decimal('subtotal', 15, 2)->default(0);
            $table->decimal('tax_amount', 15, 2)->default(0);
            $table->decimal('discount_amount', 15, 2)->default(0);
            $table->decimal('shipping_amount', 15, 2)->default(0);
            $table->decimal('total_amount', 15, 2)->default(0);
            $table->decimal('paid_amount', 15, 2)->default(0);
            $table->decimal('pending_amount', 15, 2)->default(0);

            $table->decimal('tax_rate', 5, 4)->default(0.19);
            $table->decimal('discount_rate', 5, 4)->default(0);

            $table->string('currency', 10)->default('CLP');
            $table->decimal('exchange_rate', 12, 6)->nullable();

            // Inventario
            $table->boolean('inventory_reserved')->default(false);
            $table->boolean('inventory_delivered')->default(false);
            $table->timestamp('inventory_reserved_at')->nullable();
            $table->timestamp('inventory_delivered_at')->nullable();

            // Snapshots y metadatos
            $table->json('billing_snapshot')->nullable();
            $table->json('shipping_snapshot')->nullable();
            $table->json('delivery_address')->nullable();

            $table->string('payment_method', 100)->nullable();
            $table->string('payment_method_title', 255)->nullable();

            $table->json('woo_metadata')->nullable();
            $table->json('documents_metadata')->nullable();

            $table->text('notes')->nullable();
            $table->text('internal_notes')->nullable();

            $table->timestamps();

            // Índices
            $table->index('customer_id', 'idx_sales_customer');
            $table->index('subsidiary_id', 'idx_sales_subsidiary');
            $table->index('wc_order_id', 'idx_sales_wc_order');

            // Unicidad útil
            $table->unique(['subsidiary_id', 'sale_number'], 'sales_subsidiary_sale_number_unique');
            $table->unique(['subsidiary_id', 'wc_order_id'], 'sales_subsidiary_wc_order_unique');
        });

        // Check constraint de estado (PostgreSQL)
        DB::statement("ALTER TABLE sales ADD CONSTRAINT sales_status_check CHECK (status IN ('draft','confirmed','partially_paid','paid','delivered','cancelled','refunded'))");

        // FK a customer_sale (clientes de venta)
        Schema::table('sales', function (Blueprint $table) {
            $table->foreign('customer_id')->references('id')->on('customer_sale')->onDelete('restrict');
        });
    }

    public function down(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            $table->dropForeign(['customer_id']);
        });
        Schema::dropIfExists('sales');
    }
};

