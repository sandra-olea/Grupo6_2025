<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Agrega índices únicos compuestos para prevenir duplicados
     * dentro de la misma subsidiary.
     */
    public function up(): void
    {
        // Prevenir duplicados de proveedores en la misma subsidiary
        Schema::table('suppliers', function (Blueprint $table) {
            $table->unique(['subsidiary_id', 'name'], 'suppliers_subsidiary_name_unique');
        });

        // Prevenir duplicados de clientes-proveedores en la misma subsidiary
        Schema::table('customer_suppliers', function (Blueprint $table) {
            $table->unique(['subsidiary_id', 'name'], 'customer_suppliers_subsidiary_name_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('suppliers', function (Blueprint $table) {
            $table->dropUnique('suppliers_subsidiary_name_unique');
        });

        Schema::table('customer_suppliers', function (Blueprint $table) {
            $table->dropUnique('customer_suppliers_subsidiary_name_unique');
        });
    }
};
