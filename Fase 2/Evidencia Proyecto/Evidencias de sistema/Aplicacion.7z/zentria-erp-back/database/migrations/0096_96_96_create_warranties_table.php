<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('warranties', function (Blueprint $table) {
            $table->id();

            // Contexto (por arquitectura del sistema)
            $table->foreignId('subsidiary_id')->constrained('subsidiaries')->onDelete('cascade');

            // Datos asociados
            $table->string('serial_number', 255)->nullable();
            $table->foreignId('product_id')->nullable()->constrained('products');
            $table->unsignedBigInteger('customer_id')->nullable(); // Ref a customer_sale.id
            $table->foreignId('sale_id')->nullable()->constrained('sales');

            // Fechas de la garantía
            $table->date('start_date');
            $table->date('end_date');

            // Estado: Activa, Expirada, Usada, Anulada
            $table->string('status', 50);

            $table->text('notes')->nullable();
            $table->timestamps();

            // Índices útiles
            $table->index('serial_number', 'idx_warranties_serial');
            $table->index('customer_id', 'idx_warranties_customer');
            $table->index('subsidiary_id', 'idx_warranties_subsidiary');
            $table->unique(['serial_number', 'subsidiary_id'], 'warranties_serial_sub_unique');
        });

        // FK a customer_sale (clientes de venta)
        Schema::table('warranties', function (Blueprint $table) {
            $table->foreign('customer_id')->references('id')->on('customer_sale')->onDelete('restrict');
        });

        // Check constraint para estado (PostgreSQL)
        DB::statement("ALTER TABLE warranties ADD CONSTRAINT warranties_status_check CHECK (status IN ('Activa','Expirada','Usada','Anulada'))");
    }

    public function down(): void
    {
        Schema::table('warranties', function (Blueprint $table) {
            $table->dropForeign(['customer_id']);
        });
        Schema::dropIfExists('warranties');
    }
};

