<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('unmapped_woocommerce_products', function (Blueprint $table) {
            $table->id();
            $table->uuid('integration_id');
            $table->unsignedBigInteger('sale_id')->nullable();
            $table->unsignedBigInteger('external_line_id')->nullable();
            $table->bigInteger('external_product_id')->nullable();
            $table->bigInteger('external_variation_id')->nullable();
            $table->string('sku')->nullable();
            $table->string('name')->nullable();
            $table->decimal('price', 15, 2)->default(0);
            $table->integer('quantity')->default(1);
            $table->jsonb('line_item_data')->nullable();
            $table->bigInteger('wc_order_id')->nullable();
            $table->string('resolution_status')->default('pending'); // pending, mapped, ignored
            $table->unsignedBigInteger('mapped_product_id')->nullable();
            $table->timestamp('mapped_at')->nullable();
            $table->timestamps();

            // Indexes
            $table->index('integration_id');
            $table->index('sale_id');
            $table->index('sku');
            $table->index('external_product_id');
            $table->index('resolution_status');
            $table->index(['integration_id', 'resolution_status']);

            // Foreign keys
            $table->foreign('integration_id')->references('id')->on('integrations')->onDelete('cascade');
            $table->foreign('sale_id')->references('id')->on('sales')->onDelete('cascade');
            $table->foreign('mapped_product_id')->references('id')->on('products')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('unmapped_woocommerce_products');
    }
};
