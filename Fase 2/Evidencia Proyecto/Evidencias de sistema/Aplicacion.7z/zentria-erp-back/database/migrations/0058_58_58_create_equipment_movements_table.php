<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('equipment_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('traceability_id')->constrained('equipment_traceability')->onDelete('cascade');
            $table->string('serial_number')->index();
            
            // Origen y destino
            $table->foreignId('from_warehouse_id')->nullable()->constrained('warehouses')->onDelete('set null');
            $table->foreignId('to_warehouse_id')->nullable()->constrained('warehouses')->onDelete('set null');
            
            // Cambio de estado
            $table->string('previous_status')->nullable();
            $table->string('new_status');
            
            // Contexto del movimiento
            $table->enum('movement_type', [
                'entry',
                'status_change',
                'warehouse_transfer',
                'reservation',
                'sale',
                'return',
                'adjustment'
            ]);
            
            // Referencias polimórficas
            $table->unsignedBigInteger('related_document_id')->nullable();
            $table->string('related_document_type')->nullable();
            
            // Auditoría
            $table->foreignId('performed_by')->constrained('users')->onDelete('restrict');
            $table->text('reason')->nullable();
            $table->json('metadata')->nullable()->comment('Datos adicionales del movimiento');
            
            $table->timestamp('movement_date')->useCurrent();
            $table->timestamps();
            
            // Índices
            $table->index(['serial_number', 'movement_date']);
            $table->index('movement_type');
            $table->index(['related_document_type', 'related_document_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('equipment_movements');
    }
};
