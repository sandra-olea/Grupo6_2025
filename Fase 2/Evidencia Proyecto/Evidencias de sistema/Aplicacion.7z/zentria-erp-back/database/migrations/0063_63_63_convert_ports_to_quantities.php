<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Convierte los campos de puertos de boolean a unsignedTinyInteger
     * para permitir almacenar la cantidad de cada tipo de puerto.
     */
    public function up(): void
    {
        // Notebooks
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            // Eliminar los campos booleanos y recrearlos como enteros
            $table->dropColumn([
                'has_vga',
                'has_hdmi', 
                'has_displayport',
                'has_usb_c',
                'has_sd_reader',
                'has_rj45',
            ]);
        });

        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            // Agregar como unsignedTinyInteger con default 0
            $table->unsignedTinyInteger('vga_ports')->default(0)->after('general_condition');
            $table->unsignedTinyInteger('hdmi_ports')->default(0)->after('vga_ports');
            $table->unsignedTinyInteger('displayport_ports')->default(0)->after('hdmi_ports');
            $table->unsignedTinyInteger('usb_c_ports')->default(0)->after('displayport_ports');
            $table->unsignedTinyInteger('sd_readers')->default(0)->after('usb_c_ports');
            $table->unsignedTinyInteger('rj45_ports')->default(0)->after('sd_readers');
            
            // Renombrar usb_ports_count a usb_a_ports para consistencia
            $table->renameColumn('usb_ports_count', 'usb_a_ports');
        });

        // Desktops
        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->dropColumn([
                'has_vga',
                'has_hdmi',
                'has_displayport', 
                'has_usb_c',
                'has_sd_reader',
                'has_rj45',
            ]);
        });

        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->unsignedTinyInteger('vga_ports')->default(0)->after('general_condition');
            $table->unsignedTinyInteger('hdmi_ports')->default(0)->after('vga_ports');
            $table->unsignedTinyInteger('displayport_ports')->default(0)->after('hdmi_ports');
            $table->unsignedTinyInteger('usb_c_ports')->default(0)->after('displayport_ports');
            $table->unsignedTinyInteger('sd_readers')->default(0)->after('usb_c_ports');
            $table->unsignedTinyInteger('rj45_ports')->default(0)->after('sd_readers');
            
            $table->renameColumn('usb_ports_count', 'usb_a_ports');
        });

        // Docking Stations
        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->dropColumn([
                'has_vga',
                'has_hdmi',
                'has_displayport',
                'has_usb_c',
                'has_sd_reader',
                'has_rj45',
            ]);
        });

        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->unsignedTinyInteger('vga_ports')->default(0)->after('general_condition');
            $table->unsignedTinyInteger('hdmi_ports')->default(0)->after('vga_ports');
            $table->unsignedTinyInteger('displayport_ports')->default(0)->after('hdmi_ports');
            $table->unsignedTinyInteger('usb_c_ports')->default(0)->after('displayport_ports');
            $table->unsignedTinyInteger('sd_readers')->default(0)->after('usb_c_ports');
            $table->unsignedTinyInteger('rj45_ports')->default(0)->after('sd_readers');
            
            $table->renameColumn('usb_ports_count', 'usb_a_ports');
        });

        // Monitors
        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->dropColumn([
                'has_vga',
                'has_hdmi',
                'has_displayport',
                'has_dvi',
            ]);
        });

        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->unsignedTinyInteger('vga_ports')->default(0)->after('general_condition');
            $table->unsignedTinyInteger('hdmi_ports')->default(0)->after('vga_ports');
            $table->unsignedTinyInteger('displayport_ports')->default(0)->after('hdmi_ports');
            $table->unsignedTinyInteger('dvi_ports')->default(0)->after('displayport_ports');
            
            $table->renameColumn('usb_ports_count', 'usb_hub_ports');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Notebooks - revertir a booleanos
        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->dropColumn([
                'vga_ports',
                'hdmi_ports',
                'displayport_ports',
                'usb_c_ports',
                'sd_readers',
                'rj45_ports',
            ]);
            $table->renameColumn('usb_a_ports', 'usb_ports_count');
        });

        Schema::table('technical_review_notebooks', function (Blueprint $table) {
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_usb_c')->default(false);
            $table->boolean('has_sd_reader')->default(false);
            $table->boolean('has_rj45')->default(false);
        });

        // Desktops - revertir a booleanos
        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->dropColumn([
                'vga_ports',
                'hdmi_ports',
                'displayport_ports',
                'usb_c_ports',
                'sd_readers',
                'rj45_ports',
            ]);
            $table->renameColumn('usb_a_ports', 'usb_ports_count');
        });

        Schema::table('technical_review_desktops', function (Blueprint $table) {
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_usb_c')->default(false);
            $table->boolean('has_sd_reader')->default(false);
            $table->boolean('has_rj45')->default(false);
        });

        // Docking Stations - revertir a booleanos
        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->dropColumn([
                'vga_ports',
                'hdmi_ports',
                'displayport_ports',
                'usb_c_ports',
                'sd_readers',
                'rj45_ports',
            ]);
            $table->renameColumn('usb_a_ports', 'usb_ports_count');
        });

        Schema::table('technical_review_dockings', function (Blueprint $table) {
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_usb_c')->default(false);
            $table->boolean('has_sd_reader')->default(false);
            $table->boolean('has_rj45')->default(false);
        });

        // Monitors - revertir a booleanos
        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->dropColumn([
                'vga_ports',
                'hdmi_ports',
                'displayport_ports',
                'dvi_ports',
            ]);
            $table->renameColumn('usb_hub_ports', 'usb_ports_count');
        });

        Schema::table('technical_review_monitors', function (Blueprint $table) {
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_dvi')->default(false);
        });
    }
};
