<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Create function to propagate mapping to related pending rows
        DB::unprepared(<<<SQL
        CREATE OR REPLACE FUNCTION propagate_unmapped_mapping() RETURNS trigger AS $$
        BEGIN
            -- Only act when moving to mapped
            IF NEW.resolution_status = 'mapped' AND (OLD.resolution_status IS DISTINCT FROM 'mapped') THEN
                -- Update related rows to mapped depending on available identifiers
                IF NEW.external_product_id IS NOT NULL OR NEW.external_variation_id IS NOT NULL THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'mapped',
                        mapped_product_id = NEW.mapped_product_id,
                        mapped_at = now(),
                        updated_at = now()
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND (NEW.external_product_id IS NULL OR u.external_product_id = NEW.external_product_id)
                      AND (NEW.external_variation_id IS NULL OR u.external_variation_id = NEW.external_variation_id);

                    -- Update sale_items for those rows
                    UPDATE sale_items si
                    SET product_id = NEW.mapped_product_id
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND (NEW.external_product_id IS NULL OR u.external_product_id = NEW.external_product_id)
                      AND (NEW.external_variation_id IS NULL OR u.external_variation_id = NEW.external_variation_id)
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id;
                ELSIF NEW.sku IS NOT NULL AND trim(NEW.sku) <> '' THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'mapped',
                        mapped_product_id = NEW.mapped_product_id,
                        mapped_at = now(),
                        updated_at = now()
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND u.sku = NEW.sku;

                    UPDATE sale_items si
                    SET product_id = NEW.mapped_product_id
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND u.sku = NEW.sku
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id;
                ELSIF NEW.match_key IS NOT NULL AND trim(NEW.match_key) <> '' THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'mapped',
                        mapped_product_id = NEW.mapped_product_id,
                        mapped_at = now(),
                        updated_at = now()
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND u.match_key = NEW.match_key;

                    UPDATE sale_items si
                    SET product_id = NEW.mapped_product_id
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND u.match_key = NEW.match_key
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id;
                END IF;
            END IF;

            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS trg_propagate_unmapped_mapping ON unmapped_woocommerce_products;
        CREATE TRIGGER trg_propagate_unmapped_mapping
        AFTER UPDATE ON unmapped_woocommerce_products
        FOR EACH ROW
        EXECUTE FUNCTION propagate_unmapped_mapping();
        SQL);
    }

    public function down(): void
    {
        DB::unprepared(<<<SQL
        DROP TRIGGER IF EXISTS trg_propagate_unmapped_mapping ON unmapped_woocommerce_products;
        DROP FUNCTION IF EXISTS propagate_unmapped_mapping();
        SQL);
    }
};

