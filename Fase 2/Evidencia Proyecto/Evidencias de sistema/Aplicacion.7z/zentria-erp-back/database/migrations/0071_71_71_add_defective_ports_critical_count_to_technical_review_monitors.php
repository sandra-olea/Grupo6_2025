<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('technical_review_monitors', function (Blueprint $table) {
            if (!Schema::hasColumn('technical_review_monitors', 'defective_ports_critical_count')) {
                $table->unsignedTinyInteger('defective_ports_critical_count')
                    ->default(0)
                    ->after('defective_ports_count');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('technical_review_monitors', function (Blueprint $table) {
            if (Schema::hasColumn('technical_review_monitors', 'defective_ports_critical_count')) {
                $table->dropColumn('defective_ports_critical_count');
            }
        });
    }
};
