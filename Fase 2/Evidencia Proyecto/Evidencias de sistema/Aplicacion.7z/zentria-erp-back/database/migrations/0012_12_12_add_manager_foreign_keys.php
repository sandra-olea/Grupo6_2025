<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Agrega las foreign keys para los managers después de que la tabla users exista.
     */
    public function up(): void
    {
        Schema::table('subsidiaries', function (Blueprint $table) {
            $table->foreign('subsidiary_manager_id')
                ->references('id')
                ->on('users')
                ->onDelete('set null');
        });

        Schema::table('branches', function (Blueprint $table) {
            $table->foreign('manager_id')
                ->references('id')
                ->on('users')
                ->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('subsidiaries', function (Blueprint $table) {
            $table->dropForeign(['subsidiary_manager_id']);
        });

        Schema::table('branches', function (Blueprint $table) {
            $table->dropForeign(['manager_id']);
        });
    }
};
