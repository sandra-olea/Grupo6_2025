<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::unprepared(<<<SQL
        CREATE OR REPLACE FUNCTION propagate_unmapped_mapping() RETURNS trigger AS $$
        BEGIN
            -- Cascade mapping
            IF NEW.resolution_status = 'mapped' AND (OLD.resolution_status IS DISTINCT FROM 'mapped') THEN
                IF NEW.external_product_id IS NOT NULL OR NEW.external_variation_id IS NOT NULL THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'mapped',
                        mapped_product_id = NEW.mapped_product_id,
                        mapped_at = now(),
                        updated_at = now()
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND (NEW.external_product_id IS NULL OR u.external_product_id = NEW.external_product_id)
                      AND (NEW.external_variation_id IS NULL OR u.external_variation_id = NEW.external_variation_id);

                    UPDATE sale_items si
                    SET product_id = NEW.mapped_product_id
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND (NEW.external_product_id IS NULL OR u.external_product_id = NEW.external_product_id)
                      AND (NEW.external_variation_id IS NULL OR u.external_variation_id = NEW.external_variation_id)
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id;
                ELSIF NEW.sku IS NOT NULL AND trim(NEW.sku) <> '' THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'mapped',
                        mapped_product_id = NEW.mapped_product_id,
                        mapped_at = now(),
                        updated_at = now()
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND u.sku = NEW.sku;

                    UPDATE sale_items si
                    SET product_id = NEW.mapped_product_id
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND u.sku = NEW.sku
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id;
                ELSIF NEW.match_key IS NOT NULL AND trim(NEW.match_key) <> '' THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'mapped',
                        mapped_product_id = NEW.mapped_product_id,
                        mapped_at = now(),
                        updated_at = now()
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND u.match_key = NEW.match_key;

                    UPDATE sale_items si
                    SET product_id = NEW.mapped_product_id
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = NEW.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND u.match_key = NEW.match_key
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id;
                END IF;

            -- Cascade unmapping
            ELSIF NEW.resolution_status = 'pending' AND OLD.resolution_status = 'mapped' THEN
                IF OLD.external_product_id IS NOT NULL OR OLD.external_variation_id IS NOT NULL THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'pending',
                        mapped_product_id = NULL,
                        mapped_at = NULL,
                        updated_at = now()
                    WHERE u.integration_id = OLD.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND (OLD.external_product_id IS NULL OR u.external_product_id = OLD.external_product_id)
                      AND (OLD.external_variation_id IS NULL OR u.external_variation_id = OLD.external_variation_id);

                    UPDATE sale_items si
                    SET product_id = NULL
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = OLD.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND (OLD.external_product_id IS NULL OR u.external_product_id = OLD.external_product_id)
                      AND (OLD.external_variation_id IS NULL OR u.external_variation_id = OLD.external_variation_id)
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id
                      AND si.product_id = OLD.mapped_product_id;
                ELSIF OLD.sku IS NOT NULL AND trim(OLD.sku) <> '' THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'pending',
                        mapped_product_id = NULL,
                        mapped_at = NULL,
                        updated_at = now()
                    WHERE u.integration_id = OLD.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND u.sku = OLD.sku;

                    UPDATE sale_items si
                    SET product_id = NULL
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = OLD.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND u.sku = OLD.sku
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id
                      AND si.product_id = OLD.mapped_product_id;
                ELSIF OLD.match_key IS NOT NULL AND trim(OLD.match_key) <> '' THEN
                    UPDATE unmapped_woocommerce_products u
                    SET resolution_status = 'pending',
                        mapped_product_id = NULL,
                        mapped_at = NULL,
                        updated_at = now()
                    WHERE u.integration_id = OLD.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'mapped'
                      AND u.match_key = OLD.match_key;

                    UPDATE sale_items si
                    SET product_id = NULL
                    FROM unmapped_woocommerce_products u
                    WHERE u.integration_id = OLD.integration_id
                      AND u.id <> NEW.id
                      AND u.resolution_status = 'pending'
                      AND u.match_key = OLD.match_key
                      AND si.sale_id = u.sale_id
                      AND si.external_line_id = u.external_line_id
                      AND si.product_id = OLD.mapped_product_id;
                END IF;
            END IF;

            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        SQL);
    }

    public function down(): void
    {
        // No-op: function definition will be replaced by previous migration if needed.
    }
};

