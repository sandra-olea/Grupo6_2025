<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * Hace product_id nullable para permitir quote_items manuales
     * sin producto asociado (ej: productos de WooCommerce no mapeados)
     */
    public function up(): void
    {
        Schema::table('quote_items', function (Blueprint $table) {
            // Primero eliminar la foreign key constraint
            $table->dropForeign(['product_id']);
            
            // Hacer la columna nullable
            $table->foreignId('product_id')->nullable()->change();
            
            // Recrear la foreign key con nullable
            $table->foreign('product_id')
                  ->references('id')
                  ->on('products')
                  ->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('quote_items', function (Blueprint $table) {
            // Eliminar la foreign key nullable
            $table->dropForeign(['product_id']);
            
            // Volver a NOT NULL (eliminar registros con product_id null primero)
            \DB::statement('DELETE FROM quote_items WHERE product_id IS NULL');
            
            $table->foreignId('product_id')->nullable(false)->change();
            
            // Recrear constraint original
            $table->foreign('product_id')
                  ->references('id')
                  ->on('products');
        });
    }
};
