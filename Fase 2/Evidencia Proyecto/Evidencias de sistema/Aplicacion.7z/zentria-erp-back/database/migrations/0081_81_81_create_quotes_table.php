<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('quotes', function (Blueprint $table) {
            $table->id();

            // Contexto
            $table->foreignId('subsidiary_id')->constrained('subsidiaries')->onDelete('cascade');
            $table->unsignedBigInteger('customer_id'); // Ref a customer_sale.id

            // Datos clave
            $table->string('quote_number', 255);
            $table->string('status', 50)->default('draft');

            $table->unsignedBigInteger('salesperson_id')->nullable();

            // Fechas
            $table->date('quote_date');
            $table->date('expiry_date');

            // Montos
            $table->decimal('subtotal', 15, 2)->default(0);
            $table->decimal('tax_amount', 15, 2)->default(0);
            $table->decimal('discount_amount', 15, 2)->default(0);
            $table->decimal('total_amount', 15, 2)->default(0);
            $table->decimal('tax_rate', 5, 4)->default(0.19);
            $table->decimal('discount_rate', 5, 4)->default(0);

            $table->json('terms_conditions')->nullable();
            $table->text('notes')->nullable();
            $table->text('internal_notes')->nullable();

            $table->boolean('is_converted_to_sale')->default(false);
            $table->timestamp('converted_at')->nullable();

            $table->timestamps();

            // Índices
            $table->index('customer_id', 'idx_quotes_customer');
            $table->index('subsidiary_id', 'idx_quotes_subsidiary');
            $table->unique(['subsidiary_id', 'quote_number'], 'quotes_subsidiary_quote_number_unique');
        });

        // Check constraint de estado (PostgreSQL)
        DB::statement("ALTER TABLE quotes ADD CONSTRAINT quotes_status_check CHECK (status IN ('draft','sent','approved','converted','rejected','expired'))");

        // FK a customer_sale (clientes de venta)
        Schema::table('quotes', function (Blueprint $table) {
            $table->foreign('customer_id')->references('id')->on('customer_sale')->onDelete('restrict');
        });
    }

    public function down(): void
    {
        Schema::table('quotes', function (Blueprint $table) {
            $table->dropForeign(['customer_id']);
        });
        Schema::dropIfExists('quotes');
    }
};

