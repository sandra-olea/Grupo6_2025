<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * NOTA: Esta migración debe ejecutarse DESPUÉS de que existan las tablas:
     * - sales
     * - quotations  
     * - customers
     * 
     * Para ejecutarla manualmente:
     * php artisan migrate --path=database/migrations/2025_11_01_000014_add_foreign_keys_to_technical_reviews.php
     */
    public function up(): void
    {
        // Verificar si las tablas existen antes de agregar las foreign keys
        $hasSales = Schema::hasTable('sales');
        $hasQuotations = Schema::hasTable('quotations');
        $hasCustomers = Schema::hasTable('customers');

        if ($hasSales) {
            // Agregar FK a technical_review_items
            Schema::table('technical_review_items', function (Blueprint $table) {
                $table->foreign('sale_id')
                    ->references('id')
                    ->on('sales')
                    ->onDelete('set null');
            });

            // Agregar FK a equipment_traceability
            Schema::table('equipment_traceability', function (Blueprint $table) {
                $table->foreign('sale_id')
                    ->references('id')
                    ->on('sales')
                    ->onDelete('set null');
            });
        }

        if ($hasQuotations) {
            Schema::table('equipment_traceability', function (Blueprint $table) {
                $table->foreign('quotation_id')
                    ->references('id')
                    ->on('quotations')
                    ->onDelete('set null');
            });
        }

        if ($hasCustomers) {
            Schema::table('equipment_traceability', function (Blueprint $table) {
                $table->foreign('customer_id')
                    ->references('id')
                    ->on('customers')
                    ->onDelete('set null');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('technical_review_items', function (Blueprint $table) {
            $table->dropForeign(['sale_id']);
        });

        Schema::table('equipment_traceability', function (Blueprint $table) {
            if (Schema::hasColumn('equipment_traceability', 'sale_id')) {
                $table->dropForeign(['sale_id']);
            }
            if (Schema::hasColumn('equipment_traceability', 'quotation_id')) {
                $table->dropForeign(['quotation_id']);
            }
            if (Schema::hasColumn('equipment_traceability', 'customer_id')) {
                $table->dropForeign(['customer_id']);
            }
        });
    }
};
