<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // No modificar notebooks; se mantiene lógica existente basada en extra_attributes

        Schema::table('technical_review_aios', function (Blueprint $table) {
            if (!Schema::hasColumn('technical_review_aios', 'charger_status')) {
                $table->enum('charger_status', [
                    'good_condition',
                    'damaged_cable',
                    'not_matching_equipment',
                    'not_included',
                ])->nullable()->after('includes_power_adapter');
            }
            // No existe includes_charger en AIO; se usa includes_power_adapter (alias por controlador)
        });
    }

    public function down(): void
    {
        // Sin cambios para notebooks

        Schema::table('technical_review_aios', function (Blueprint $table) {
            if (Schema::hasColumn('technical_review_aios', 'charger_status')) {
                $table->dropColumn('charger_status');
            }
        });
    }
};
