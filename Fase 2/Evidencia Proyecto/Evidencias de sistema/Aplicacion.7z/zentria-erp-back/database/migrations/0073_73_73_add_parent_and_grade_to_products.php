<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->unsignedBigInteger('parent_product_id')->nullable()->after('branch_id');
            $table->string('grade', 1)->nullable()->after('serial_tracking');

            $table->foreign('parent_product_id')->references('id')->on('products')->onDelete('cascade');
            $table->unique(['parent_product_id', 'grade'], 'products_parent_grade_unique');
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropUnique('products_parent_grade_unique');
            $table->dropForeign(['parent_product_id']);
            $table->dropColumn(['parent_product_id', 'grade']);
        });
    }
};

