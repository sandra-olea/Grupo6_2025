<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_personalizations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id'); // FK correcta
            $table->unsignedInteger('tema')->nullable();
            $table->unsignedInteger('font_size')->nullable();

            $table->unsignedBigInteger('sucursal_principal')->nullable();
            // Subsidiary asociada a la sucursal_principal (se sincroniza vía trigger)
            $table->unsignedBigInteger('subsidiary_id')->nullable();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->timestamps();

            // Foreign keys
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('sucursal_principal')->references('id')->on('branches')->onDelete('set null');
            $table->foreign('subsidiary_id')->references('id')->on('subsidiaries')->onDelete('set null');
            $table->foreign('company_id')->references('id')->on('companies')->onDelete('set null');
        });

        // Backfill y triggers (PostgreSQL) para mantener subsidiary_id sincronizado con sucursal_principal
        // Backfill inicial usando sintaxis PostgreSQL
        DB::unprepared(<<<'SQL'
        UPDATE user_personalizations up
        SET subsidiary_id = b.subsidiary_id
        FROM branches b
        WHERE b.id = up.sucursal_principal;
        SQL);

        // Función y trigger BEFORE INSERT
        DB::unprepared(<<<'SQL'
        CREATE OR REPLACE FUNCTION set_subsidiary_from_branch_insert()
        RETURNS trigger AS $$
        BEGIN
            IF NEW.sucursal_principal IS NOT NULL THEN
                NEW.subsidiary_id = (
                    SELECT b.subsidiary_id FROM branches b WHERE b.id = NEW.sucursal_principal LIMIT 1
                );
            END IF;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        CREATE TRIGGER trg_user_pers_bi
        BEFORE INSERT ON user_personalizations
        FOR EACH ROW
        EXECUTE FUNCTION set_subsidiary_from_branch_insert();
        SQL);

        // Función y trigger BEFORE UPDATE (recalcula siempre que haya sucursal_principal)
        DB::unprepared(<<<'SQL'
        CREATE OR REPLACE FUNCTION set_subsidiary_from_branch_update()
        RETURNS trigger AS $$
        BEGIN
            IF NEW.sucursal_principal IS NOT NULL THEN
                NEW.subsidiary_id = (
                    SELECT b.subsidiary_id FROM branches b WHERE b.id = NEW.sucursal_principal LIMIT 1
                );
            ELSE
                NEW.subsidiary_id = NULL;
            END IF;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        CREATE TRIGGER trg_user_pers_bu
        BEFORE UPDATE ON user_personalizations
        FOR EACH ROW
        EXECUTE FUNCTION set_subsidiary_from_branch_update();
        SQL);

        // Trigger en branches para propagar cambios de subsidiary_id hacia user_personalizations
        DB::unprepared(<<<'SQL'
        CREATE OR REPLACE FUNCTION sync_user_pers_on_branch_subsidiary_update()
        RETURNS trigger AS $$
        BEGIN
            IF NEW.subsidiary_id IS DISTINCT FROM OLD.subsidiary_id THEN
                UPDATE user_personalizations up
                SET subsidiary_id = NEW.subsidiary_id
                WHERE up.sucursal_principal = NEW.id;
            END IF;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        CREATE TRIGGER trg_branch_subsidiary_au
        AFTER UPDATE OF subsidiary_id ON branches
        FOR EACH ROW
        EXECUTE FUNCTION sync_user_pers_on_branch_subsidiary_update();
        SQL);
    }

    public function down(): void
    {
        // Eliminar triggers y funciones si existen (PostgreSQL)
        DB::unprepared('DROP TRIGGER IF EXISTS trg_user_pers_bi ON user_personalizations;');
        DB::unprepared('DROP TRIGGER IF EXISTS trg_user_pers_bu ON user_personalizations;');
        DB::unprepared('DROP FUNCTION IF EXISTS set_subsidiary_from_branch_insert();');
        DB::unprepared('DROP FUNCTION IF EXISTS set_subsidiary_from_branch_update();');
        DB::unprepared('DROP TRIGGER IF EXISTS trg_branch_subsidiary_au ON branches;');
        DB::unprepared('DROP FUNCTION IF EXISTS sync_user_pers_on_branch_subsidiary_update();');

        Schema::dropIfExists('user_personalizations');
    }
};
