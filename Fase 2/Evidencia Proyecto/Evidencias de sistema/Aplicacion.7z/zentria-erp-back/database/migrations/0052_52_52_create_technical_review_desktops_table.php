<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technical_review_desktops', function (Blueprint $table) {
            $table->id();
            $table->foreignId('review_item_id')->constrained('technical_review_items')->onDelete('cascade');
            
            // Identificación
            $table->string('brand')->nullable();
            $table->string('model')->nullable();
            $table->string('line')->nullable(); // SFF, MicroPC, Tower, etc.
            
            // Hardware
            $table->string('processor')->nullable();
            $table->string('ram_size')->nullable();
            $table->string('ram_slots')->nullable();
            $table->enum('ram_type', ['DDR3', 'DDR4', 'DDR5'])->nullable();
            $table->string('storage_size')->nullable();
            $table->enum('storage_technology', ['HDD', 'SSD', 'M2', 'NVME', 'HYBRID'])->nullable();
            // Accesorios
            $table->boolean('includes_charger')->default(false);
            $table->enum('charger_status', ['good_condition','damaged_cable','not_matching_equipment','not_included'])->nullable();
            
            // Condición general
            $table->enum('general_condition', ['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'])->nullable();
            
            // Puertos y conectividad (presencia)
            $table->boolean('has_vga')->default(false);
            $table->boolean('has_hdmi')->default(false);
            $table->boolean('has_displayport')->default(false);
            $table->boolean('has_usb_c')->default(false);
            $table->boolean('has_sd_reader')->default(false);
            $table->boolean('has_rj45')->default(false);
            $table->boolean('has_wifi')->default(false);
            $table->boolean('has_bluetooth')->default(false);
            $table->boolean('has_cd_drive')->default(false);
            
            // Puertos (cantidad)
            $table->unsignedTinyInteger('usb_ports_count')->default(0);
            
            // Estado físico (tokens EN más representativos)
            $table->enum('cover_condition', ['ok', 'good_condition', 'light_scratches', 'noticeable_wear', 'broken'])->nullable();
            
            // Sistema operativo
            $table->string('operating_system')->nullable();
            
            // Observaciones
            $table->text('observations')->nullable();
            
            // Campos flexibles
            $table->json('extra_attributes')->nullable();
            
            $table->timestamps();
            
            $table->index('review_item_id');
            $table->index('brand');
            $table->index('model');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technical_review_desktops');
    }
};
