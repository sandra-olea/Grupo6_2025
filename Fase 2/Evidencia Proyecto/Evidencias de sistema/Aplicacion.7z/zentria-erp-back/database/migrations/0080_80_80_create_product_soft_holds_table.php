<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_soft_holds', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->onDelete('cascade');
            $table->foreignId('sale_id')->constrained('sales')->onDelete('cascade');
            $table->foreignId('sale_item_id')->constrained('sale_items')->onDelete('cascade');
            $table->integer('quantity')->default(0);
            $table->string('status', 20)->default('active'); // active | released
            $table->timestamps();

            $table->unique(['sale_item_id'], 'product_soft_holds_sale_item_unique');
            $table->index(['product_id','status'], 'product_soft_holds_product_status_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_soft_holds');
    }
};

