<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sale_items', function (Blueprint $table) {
            $table->id();

            $table->foreignId('sale_id')->constrained('sales')->onDelete('cascade');
            $table->foreignId('product_id')->constrained('products');

            $table->integer('quantity')->default(1);
            $table->decimal('unit_price', 15, 2);
            $table->decimal('discount_amount', 15, 2)->default(0);
            $table->decimal('subtotal', 15, 2)->default(0);
            $table->decimal('total', 15, 2)->default(0);

            // Id externo de Woo (line_items[].id) para idempotencia
            $table->unsignedBigInteger('external_line_id')->nullable();

            // Metadatos adicionales del ítem (ej: meta_data de Woo)
            $table->json('meta_json')->nullable();

            $table->timestamps();

            // Índices útiles
            $table->index('sale_id', 'idx_sale_items_sale');
            $table->index('product_id', 'idx_sale_items_product');
            $table->index('external_line_id', 'idx_sale_items_external_line');
            // Evitar duplicados del mismo ítem externo dentro de una misma venta
            $table->unique(['sale_id', 'external_line_id'], 'sale_items_sale_external_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sale_items');
    }
};

