<?php

namespace Database\Seeders;

use App\Models\Branch;
use App\Models\Warehouse;
use App\Models\Product;
use Illuminate\Database\Seeder;

class WarehousesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * Crea bodegas de ejemplo para las sucursales existentes y asocia productos.
     */
    public function run(): void
    {
        $this->command->info('🔄 Creando bodegas de ejemplo...');

        $created = 0;
        $productsAttached = 0;
        $branches = Branch::all();

        foreach ($branches as $branch) {
            // Crear una bodega principal para cada sucursal
            $warehouse = Warehouse::firstOrCreate(
                [
                    'branch_id' => $branch->id,
                    'name' => 'Bodega Principal ' . $branch->name,
                ],
                [
                    'code' => 'BDP-' . str_pad($branch->id, 3, '0', STR_PAD_LEFT),
                    'description' => 'Bodega principal de la sucursal ' . $branch->name,
                    'address' => $branch->address ?? 'Dirección no especificada',
                    'warehouse_type' => 'general',
                    'capacity' => 1000,
                    'maximum_capacity' => 1500,
                    'is_active' => true,
                    'requires_serial_tracking' => true,
                ]
            );

            if ($warehouse->wasRecentlyCreated) {
                $created++;
            }

            // Asociar productos existentes de la misma branch a la bodega
            $products = Product::where('branch_id', $branch->id)
                ->take(5) // Tomar hasta 5 productos
                ->get();

            foreach ($products as $product) {
                // Verificar si ya está asociado
                if (!$warehouse->products()->where('product_id', $product->id)->exists()) {
                    $warehouse->products()->attach($product->id, [
                        'quantity' => rand(5, 50) // Cantidad aleatoria entre 5 y 50
                    ]);
                    $productsAttached++;
                }
            }
        }

        $this->command->info("✅ Bodegas: {$created} creadas, " . ($branches->count() - $created) . " ya existían");
        $this->command->info("✅ Productos asociados a bodegas: {$productsAttached}");
    }
}
