<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Notifications\NotificationType;

class RoleNotificationDefaultsSeeder extends Seeder
{
    public function run(): void
    {
        $roles = DB::table('roles')->pluck('id','name');
        $types = NotificationType::all()->keyBy('key');

        $plans = [
            'company-admin' => [
                'transfer.sent' => ['allowed' => true],
                'transfer.receipt-discrepancy' => ['allowed' => true, 'priority_override' => 'P1'],
                'system.sequence-threshold' => ['allowed' => true, 'priority_override' => 'P1'],
                'system.sync-failed' => ['allowed' => true, 'priority_override' => 'P1'],
                // Empresa/Subempresa/Sucursal
                'company.updated' => ['allowed' => true],
                'subsidiary.created' => ['allowed' => true],
                'subsidiary.updated' => ['allowed' => true],
                'branch.created' => ['allowed' => true],
                'branch.updated' => ['allowed' => true],
                // Catálogo
                'product.created' => ['allowed' => true],
                'product.updated' => ['allowed' => true],
                'product.stock-zero' => ['allowed' => true],
                'brand.created' => ['allowed' => true],
                'brand.updated' => ['allowed' => true],
                'category.created' => ['allowed' => true],
                'category.updated' => ['allowed' => true],
                // Eliminaciones
                'company.deleted' => ['allowed' => true],
                'subsidiary.deleted' => ['allowed' => true],
                'branch.deleted' => ['allowed' => true],
                'product.deleted' => ['allowed' => true],
                'brand.deleted' => ['allowed' => true],
                'category.deleted' => ['allowed' => true],
                // Suppliers, Customer Sales y Customer Suppliers
                'supplier.created' => ['allowed' => true],
                'supplier.updated' => ['allowed' => true],
                'supplier.deleted' => ['allowed' => true],
                'customer-sale.created' => ['allowed' => true],
                'customer-sale.updated' => ['allowed' => true],
                'customer-sale.deleted' => ['allowed' => true],
                'customer-supplier.created' => ['allowed' => true],
                'customer-supplier.updated' => ['allowed' => true],
                'customer-supplier.deleted' => ['allowed' => true],
                // Invitaciones
                'invitation.sent' => ['allowed' => true],
                'invitation.activated' => ['allowed' => true],
                // Recordatorios y vencimientos
                'reminder.general' => ['allowed' => true],
                'deadline.expiring-soon' => ['allowed' => true],
                'sale.stock-shortage' => ['allowed' => true],
            ],
            'subsidiary-admin' => [
                'transfer.sent' => ['allowed' => true],
                'transfer.receipt-discrepancy' => ['allowed' => true, 'priority_override' => 'P1'],
                // Subempresa/Sucursal dentro de su empresa
                'subsidiary.created' => ['allowed' => true],
                'subsidiary.updated' => ['allowed' => true],
                'branch.created' => ['allowed' => true],
                'branch.updated' => ['allowed' => true],
                // Catálogo
                'product.created' => ['allowed' => true],
                'product.updated' => ['allowed' => true],
                'product.stock-zero' => ['allowed' => true],
                'brand.created' => ['allowed' => true],
                'brand.updated' => ['allowed' => true],
                'category.created' => ['allowed' => true],
                'category.updated' => ['allowed' => true],
                'subsidiary.deleted' => ['allowed' => true],
                'branch.deleted' => ['allowed' => true],
                'product.deleted' => ['allowed' => true],
                'brand.deleted' => ['allowed' => true],
                'category.deleted' => ['allowed' => true],
                // Suppliers, Customer Sales y Customer Suppliers
                'supplier.created' => ['allowed' => true],
                'supplier.updated' => ['allowed' => true],
                'supplier.deleted' => ['allowed' => true],
                'customer-sale.created' => ['allowed' => true],
                'customer-sale.updated' => ['allowed' => true],
                'customer-sale.deleted' => ['allowed' => true],
                'customer-supplier.created' => ['allowed' => true],
                'customer-supplier.updated' => ['allowed' => true],
                'customer-supplier.deleted' => ['allowed' => true],
                // Invitaciones
                'invitation.sent' => ['allowed' => true],
                'invitation.activated' => ['allowed' => true],
                'deadline.expiring-soon' => ['allowed' => true],
                'sale.stock-shortage' => ['allowed' => true],
            ],
            'branch-admin' => [
                'sale.delivery-due-today' => ['allowed' => true],
                'payment.confirmed' => ['allowed' => true],
                'sale.stock-shortage' => ['allowed' => true],
                // Catálogo en su sucursal
                'product.created' => ['allowed' => true],
                'product.updated' => ['allowed' => true],
                'product.stock-zero' => ['allowed' => true],
                'brand.created' => ['allowed' => true],
                'brand.updated' => ['allowed' => true],
                'category.created' => ['allowed' => true],
                'category.updated' => ['allowed' => true],
                'branch.deleted' => ['allowed' => true],
                'product.deleted' => ['allowed' => true],
                'brand.deleted' => ['allowed' => true],
                'category.deleted' => ['allowed' => true],
                // Suppliers, Customer Sales y Customer Suppliers
                'supplier.created' => ['allowed' => true],
                'supplier.updated' => ['allowed' => true],
                'supplier.deleted' => ['allowed' => true],
                'customer-sale.created' => ['allowed' => true],
                'customer-sale.updated' => ['allowed' => true],
                'customer-sale.deleted' => ['allowed' => true],
                'customer-supplier.created' => ['allowed' => true],
                'customer-supplier.updated' => ['allowed' => true],
                'customer-supplier.deleted' => ['allowed' => true],
                // Invitaciones
                'invitation.sent' => ['allowed' => true],
                'invitation.activated' => ['allowed' => true],
                'deadline.expiring-soon' => ['allowed' => true],
            ],
            'catalog-admin' => [
                // Administrador de catálogo: notificaciones de productos, categorías y marcas
                'product.created' => ['allowed' => true],
                'product.updated' => ['allowed' => true],
                'product.deleted' => ['allowed' => true],
                'brand.created' => ['allowed' => true],
                'brand.updated' => ['allowed' => true],
                'brand.deleted' => ['allowed' => true],
                'category.created' => ['allowed' => true],
                'category.updated' => ['allowed' => true],
                'category.deleted' => ['allowed' => true],
            ],
            'company-member' => [
                'quote.expiring-soon' => ['allowed' => true],
                'quote.converted' => ['allowed' => true],
                'reminder.general' => ['allowed' => true],
            ],
            'subsidiary-member' => [
                'quote.expiring-soon' => ['allowed' => true],
                'reminder.general' => ['allowed' => true],
            ],
            // Operativos
            'warehouse-manager' => [
                // Encargado de bodega: productos, marcas y bodegas
                'warehouse.created' => ['allowed' => true],
                'warehouse.updated' => ['allowed' => true],
                'warehouse.deleted' => ['allowed' => true],
                'warehouse.product.attached' => ['allowed' => true],
                'warehouse.product.detached' => ['allowed' => true],
                'product.created' => ['allowed' => true],
                'product.updated' => ['allowed' => true],
                'product.deleted' => ['allowed' => true],
                'brand.created' => ['allowed' => true],
                'brand.updated' => ['allowed' => true],
                'brand.deleted' => ['allowed' => true],
                'category.updated' => ['allowed' => true],
                'deadline.expiring-soon' => ['allowed' => true],
            ],
            'warehouse-employee' => [
                'warehouse.product.attached' => ['allowed' => true],
                'warehouse.product.detached' => ['allowed' => true],
                'product.created' => ['allowed' => true],
                'product.updated' => ['allowed' => true],
                'brand.updated' => ['allowed' => true],
                'product.deleted' => ['allowed' => true],
                'brand.deleted' => ['allowed' => true],
                'deadline.expiring-soon' => ['allowed' => true],
            ],
            'technician' => [
                // Técnico: notificaciones de revisiones técnicas
                'technical-review.batch-created' => ['allowed' => true],
                'technical-review.batch-completed' => ['allowed' => true],
                'technical-review.item-pending-review' => ['allowed' => true],
                'technical-review.item-completed' => ['allowed' => true],
                'technical-review.item-approved' => ['allowed' => true],
                'technical-review.item-rejected' => ['allowed' => true],
                'technical-review.validation-error' => ['allowed' => true],
                'technical-review.equipment-available' => ['allowed' => true],
                'reminder.general' => ['allowed' => true],
                'deadline.expiring-soon' => ['allowed' => true],
            ],
        ];

        $created = 0; $updated = 0; $skippedRoles = [];
        foreach ($plans as $roleName => $map) {
            if (!isset($roles[$roleName])) { $skippedRoles[] = $roleName; continue; }
            $roleId = $roles[$roleName];
            foreach ($map as $key => $cfg) {
                if (!isset($types[$key])) continue;
                $exists = DB::table('role_notification_defaults')
                    ->where('role_id', $roleId)
                    ->where('notification_type_id', $types[$key]->id)
                    ->exists();

                DB::table('role_notification_defaults')->updateOrInsert(
                    ['role_id' => $roleId, 'notification_type_id' => $types[$key]->id],
                    [
                        'allowed' => $cfg['allowed'] ?? true,
                        'channels' => $cfg['channels'] ?? null,
                        'priority_override' => $cfg['priority_override'] ?? null,
                        'updated_at' => now(),
                        'created_at' => now(),
                    ]
                );

                $exists ? $updated++ : $created++;
            }
        }

        if (isset($this->command)) {
            $this->command->info(sprintf(
                'RoleNotificationDefaults: %d creados, %d actualizados',
                $created,
                $updated
            ));
            if (!empty($skippedRoles)) {
                $this->command->warn('Roles inexistentes omitidos: '.implode(', ', $skippedRoles));
            }
        }
    }
}
