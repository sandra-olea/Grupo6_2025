<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use App\Models\Branch;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;

class ExtraCatalogSeeder extends Seeder
{
    public function run(): void
    {
        $out = $this->command?->getOutput();

        DB::transaction(function () use ($out) {
            // Branch objetivo (igual a DemoCatalogSeeder)
            $branchName = 'Casa Matriz EcoPC';
            /** @var Branch $branch */
            $branch = Branch::where('branch_name', $branchName)->firstOrFail();

            // Asegurar marca Dell
            $brandSlugCol = Schema::hasColumn('brands', 'slug');
            $dell = Brand::firstOrCreate(
                ['branch_id' => $branch->id] + ($brandSlugCol ? ['slug' => 'dell'] : ['name' => 'Dell']),
                ['name' => 'Dell'] + ($brandSlugCol ? [] : [])
            );

            // Categorías requeridas
            $catSlugCol = Schema::hasColumn('categories', 'slug');
            $categories = collect([
                'monitor' => 'Monitor',
                'docking' => 'Docking',
                'desktop' => 'Desktop',
                'aio' => 'AIO',
                'notebook' => 'Notebook',
            ])->map(function ($name, $slug) use ($catSlugCol) {
                return Category::firstOrCreate(
                    $catSlugCol ? ['slug' => $slug] : ['name' => $name, 'parent_id' => null],
                    ['name' => $name, 'parent_id' => null] + ($catSlugCol ? ['slug' => $slug] : [])
                );
            });

            // Productos a crear/actualizar
            $products = [
                [
                    'sku' => 'LATITUDE-5420-I7',
                    'name' => 'LATITUDE 5420 / I7 1165G7',
                    'product_type' => 'notebook',
                    'serial_tracking' => true,
                    'attributes_json' => [
                        'packaging' => ['charger_included' => false],
                        'product_kind' => 'notebook',
                    ],
                    'categories' => ['notebook'],
                ],
                [
                    'sku' => 'OPTIPLEX-7090',
                    'name' => 'OPTIPLEX 7090 / I7-10700',
                    'product_type' => 'desktop_pc',
                    'serial_tracking' => true,
                    'attributes_json' => [
                        'packaging' => ['charger_included' => false],
                        'product_kind' => 'desktop_pc',
                    ],
                    'categories' => ['desktop'],
                ],
                [
                    'sku' => 'OPTIPLEX-5270',
                    'name' => 'Optiplex 5270 / i5 8500',
                    'product_type' => 'aio',
                    'serial_tracking' => true,
                    'attributes_json' => [
                        'packaging' => ['charger_included' => false],
                        'product_kind' => 'aio',
                    ],
                    'categories' => ['aio'],
                ],
                [
                    'sku' => 'P2222H',
                    'name' => 'Monitor Dell P2222H 21.5" FHD',
                    'product_type' => 'monitor',
                    'serial_tracking' => true,
                    'attributes_json' => json_decode('{"product_kind": "monitor"}', true),
                    'categories' => ['monitor'],
                ],
                [
                    'sku' => 'DOCKING',
                    'name' => 'WD19S',
                    'product_type' => 'docking',
                    'serial_tracking' => true,
                    'attributes_json' => json_decode('{"product_kind": "docking"}', true),
                    'categories' => ['docking'],
                ],
            ];

            foreach ($products as $p) {
                $payload = [
                    'branch_id' => $branch->id,
                    'sku' => $p['sku'],
                    'name' => $p['name'],
                    'brand_id' => $dell->id,
                    'product_type' => $p['product_type'],
                    'warranty_months' => 0,
                    'serial_tracking' => $p['serial_tracking'],
                    'short_description' => null,
                    'long_description' => null,
                    'snippet_description' => null,
                    'cost' => '0.00',
                    'price' => '0.00',
                    'offer_price' => null,
                    'product_status' => null,
                    'attributes_json' => $p['attributes_json'],
                    'marketplace_external_ids' => null,
                    'is_active' => true,
                    // Para productos sin tracking, se podría setear stock. Para serial_tracking true, el accessor lo calcula.
                    'stock' => 0,
                ];

                $existing = Product::fromBranch($branch->id)
                    ->whereRaw('LOWER(sku)=LOWER(?)', [$p['sku']])
                    ->first();

                if ($existing) {
                    $existing->update($payload);
                    $product = $existing;
                } else {
                    $product = Product::create($payload);
                }

                // Sincronizar categorías por slug
                $pivot = [];
                foreach ($p['categories'] as $slug) {
                    $cat = $categories->get($slug);
                    if ($cat) {
                        $pivot[$cat->id] = ['assigned_at' => now()];
                    }
                }
                if (!empty($pivot)) {
                    $product->categories()->syncWithoutDetaching($pivot);
                }
            }

            if ($out) {
                $out->writeln('');
                $out->writeln('✅ ExtraCatalogSeeder: categorías (Monitor, Docking, Desktop, AIO) y 4 productos Dell listos.');
            }
        });
    }
}

