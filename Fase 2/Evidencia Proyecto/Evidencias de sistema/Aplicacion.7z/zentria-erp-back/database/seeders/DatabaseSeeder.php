<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            // Migraciones de todas las comunas y regiones de chile -> esto no debería cambiar. Pero si se necesitan cambios aplicar al seeder para mantener
            // persistencia de datos
            RegionSeeder::class,
            ProvinceSeeder::class,
            CommuneSeeder::class,

            // Orden importante: primero roles y permisos
            RolesAndPermissionsSeeder::class,
            FixPermissionGuardSeeder::class,
            
            // Permisos de módulos específicos
            TechnicalReviewsPermissionsSeeder::class,
            
            // Tipos y defaults de notificaciones (antes de crear datos)
            NotificationTypesSeeder::class,
            RoleNotificationDefaultsSeeder::class,

            // Tipos de documentos conocidos (globales)
            DocumentTypesSeeder::class,

            // Luego estructura empresarial
            EmpresaSeeder::class,
            
            // Usuarios principales -> se debe aplicar cambios de contraseñas inmediatos
            // o eliminarlos eventualmente
            SuperAdminSeeder::class,
            UsuarioBasicoSeeder::class,
            
            // Datos de ejemplo multi-empresa
            MultiCompanyExampleSeeder::class,
            
            // Datos de ejemplo catálogo - productos, marcas, categorías
            DemoCatalogSeeder::class,
            ExtraCatalogSeeder::class,
            
            // Productos de prueba de carga (60 productos) - desactivado temporalmente
            // LoadTestProductsSeeder::class,
            
            // Datos de ejemplo - proveedores y clientes-proveedores
            SuppliersSeeder::class,
            CustomerSalesSeeder::class,
            
            // Bodegas (necesarias para revisiones técnicas)
            WarehousesSeeder::class,
            
            // Reglas de validación y puntuación para revisiones técnicas
            TechnicalReviewValidationRulesSeeder::class,
            TechnicalReviewScoringRulesSeeder::class,
            
            // Datos de ejemplo - revisiones técnicas
            TechnicalReviewDemoSeeder::class,

            // Asignaciones de acceso para pruebas de jerarquía + granularidad
            AccessContextDemoSeeder::class,

            // Asegurar que los roles contextuales queden reflejados como roles Spatie
            FixContextRolesToSpatieSeeder::class,

            // Generar notificaciones iniciales derivadas de lo sembrado
            InitialNotificationsFromSeedsSeeder::class,

            // Demo integration for WooCommerce webhooks (fixed keys for local testing)
            IntegrationWebhookDemoSeeder::class,

            // Ventas y cotizaciones de ejemplo (estilo Woo)
            SalesDemoSeeder::class,
            QuotesDemoSeeder::class,

            // Garantías demo a partir de series vendidas
            WarrantiesDemoSeeder::class,

            // Semillas adicionales y robustas para Documentos y Garantías
            DocumentsSeeder::class,
            WarrantiesSeeder::class,
        ]);
    }

}
