<?php

namespace Database\Seeders;

use App\Models\CustomerSale;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\Subsidiary;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class SalesDemoSeeder extends Seeder
{
    public function run(): void
    {
        $subsidiary = Subsidiary::query()->find(1) ?: Subsidiary::query()->first();
        if (!$subsidiary) {
            $this->command?->warn('No subsidiaries found. Skipping SalesDemoSeeder.');
            return;
        }

        $customer = CustomerSale::query()->where('subsidiary_id', $subsidiary->id)->first();
        if (!$customer) {
            $this->command?->warn('No CustomerSale found. Run CustomerSalesSeeder first.');
            return;
        }

        // Pick a child product with grade if possible, else any product
        $product = Product::query()
            ->whereNotNull('parent_product_id')
            ->orderBy('id')
            ->first();
        if (!$product) {
            $product = Product::query()->orderBy('id')->first();
        }
        if (!$product) {
            $this->command?->warn('No products found. Run DemoCatalogSeeder first.');
            return;
        }

        $wcOrderId = 8458;
        $saleNumber = 'W'.$wcOrderId;
        $sale = Sale::query()->firstOrCreate(
            [
                'subsidiary_id' => $subsidiary->id,
                'wc_order_id' => $wcOrderId,
            ],
            [
                'customer_id' => $customer->id,
                'wc_order_number' => (string)$wcOrderId,
                'sale_number' => $saleNumber,
                'status' => 'confirmed',
                'salesperson_id' => 0,
                'sale_date' => now()->toDateString(),
                'delivery_date' => null,
                'subtotal' => 0,
                'tax_amount' => 0,
                'discount_amount' => 0,
                'shipping_amount' => 0,
                'total_amount' => 0,
                'paid_amount' => 0,
                'pending_amount' => 0,
                'billing_snapshot' => [
                    'first_name' => 'Tikilillo',
                    'last_name' => '30clavos',
                    'address_1' => 'Dirección demo',
                    'city' => 'Santiago',
                    'state' => 'CL-RM',
                    'country' => 'CL',
                    'email' => 'cliente.demo@example.com',
                    'phone' => '+56911111111',
                ],
                'shipping_snapshot' => [
                    'first_name' => 'Tikilillo',
                    'last_name' => '30clavos',
                    'address_1' => 'Dirección demo',
                    'city' => 'Santiago',
                    'state' => 'CL-RM',
                    'country' => 'CL',
                ],
                'payment_method' => 'bacs',
                'payment_method_title' => 'Transferencia bancaria directa',
                'woo_metadata' => ['channel' => 'WooCommerce', 'version' => '10.3.4'],
                'documents_metadata' => null,
                'notes' => 'Venta demo estilo Woo',
                'internal_notes' => 'Generado por SalesDemoSeeder',
            ]
        );

        // Item (idempotente por external_line_id)
        $lineId = 31;
        $item = SaleItem::query()->firstOrCreate(
            [
                'sale_id' => $sale->id,
                'external_line_id' => $lineId,
            ],
            [
                'product_id' => $product->id,
                'quantity' => 1,
                'unit_price' => (string) ($product->price ?? 0),
                'discount_amount' => 0,
                'subtotal' => (string) ($product->price ?? 0),
                'total' => (string) ($product->price ?? 0),
                'meta_json' => [
                    'sku_original' => $product->sku,
                    'reservation' => [
                        'requested_qty' => 1,
                        'hold_qty' => 0,
                        'shortage_qty' => 1,
                    ],
                ],
            ]
        );

        if (isset($this->command)) {
            $this->command->info(sprintf(
                '✅ SalesDemoSeeder: venta demo %s (id=%s) con 1 ítem (product_id=%s) para customer_id=%s',
                $saleNumber,
                (string)$sale->id,
                (string)$product->id,
                (string)$customer->id
            ));
        }
    }
}

