<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\TechnicalReviewValidationRule;

class TechnicalReviewValidationRulesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * Crea reglas de validación en tiempo real para los campos técnicos
     * de los equipos en revisión.
     */
    public function run(): void
    {
        $this->command->info('🔄 Creando reglas de validación para revisiones técnicas...');

        $rules = $this->getValidationRules();

        $createdCount = 0;
        $updatedCount = 0;

        foreach ($rules as $rule) {
            $exists = TechnicalReviewValidationRule::where('equipment_type', $rule['equipment_type'])
                ->where('field_name', $rule['field_name'])
                ->exists();

            TechnicalReviewValidationRule::updateOrCreate(
                [
                    'equipment_type' => $rule['equipment_type'],
                    'field_name' => $rule['field_name'],
                ],
                $rule
            );

            if ($exists) {
                $updatedCount++;
            } else {
                $createdCount++;
            }
        }

        $this->command->info("✅ Reglas de validación: {$createdCount} creadas, {$updatedCount} actualizadas");
    }

    /**
     * Define las reglas de validación
     */
    private function getValidationRules(): array
    {
        return [
            // ===== NOTEBOOK =====
            [
                'equipment_type' => 'notebook',
                'field_name' => 'ram_size',
                'validation_type' => 'format',
                'rule_config' => [
                    'pattern' => '/^\d+(GB|MB)$/',
                    'suggested_value' => '8GB',
                ],
                'help_text' => 'Formato: 8GB, 16GB, etc.',
                'error_message' => 'Debe usar formato: número + GB o MB',
                'is_active' => true,
                'priority' => 10,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'storage_size',
                'validation_type' => 'format',
                'rule_config' => [
                    'pattern' => '/^\d+(\.\d+)?(GB|TB)$/',
                    'suggested_value' => '256GB',
                ],
                'help_text' => 'Formato: 256GB, 512GB, 1TB, etc.',
                'error_message' => 'Debe usar formato: número + GB o TB',
                'is_active' => true,
                'priority' => 10,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'processor',
                'validation_type' => 'format',
                'rule_config' => [
                    'pattern' => '/^.+\d\.\d+GHz$/',
                    'suggested_value' => 'i5-8250U 1.60GHz',
                ],
                'help_text' => 'Incluya modelo y velocidad. Ejemplo: i5-8250U 1.60GHz',
                'error_message' => 'Debe incluir modelo completo y velocidad',
                'is_active' => true,
                'priority' => 10,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'screen_inches',
                'validation_type' => 'suggestion',
                'rule_config' => [
                    'allowed_values' => ['13"', '14"', '15"', '15.6"', '17"'],
                ],
                'help_text' => 'Tamaños comunes: 13", 14", 15", 15.6", 17"',
                'error_message' => 'Use formato con comillas: 14", 15.6", etc.',
                'is_active' => true,
                'priority' => 5,
            ],

            // ===== DESKTOP =====
            [
                'equipment_type' => 'desktop',
                'field_name' => 'ram_size',
                'validation_type' => 'format',
                'rule_config' => [
                    'pattern' => '/^\d+(GB|MB)$/',
                    'suggested_value' => '8GB',
                ],
                'help_text' => 'Formato: 8GB, 16GB, etc.',
                'error_message' => 'Debe usar formato: número + GB o MB',
                'is_active' => true,
                'priority' => 10,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'storage_size',
                'validation_type' => 'format',
                'rule_config' => [
                    'pattern' => '/^\d+(\.\d+)?(GB|TB)$/',
                    'suggested_value' => '500GB',
                ],
                'help_text' => 'Formato: 256GB, 512GB, 1TB, etc.',
                'error_message' => 'Debe usar formato: número + GB o TB',
                'is_active' => true,
                'priority' => 10,
            ],

            // ===== MONITOR =====
            [
                'equipment_type' => 'monitor',
                'field_name' => 'screen_inches',
                'validation_type' => 'suggestion',
                'rule_config' => [
                    'allowed_values' => ['19"', '21"', '22"', '23"', '24"', '27"', '32"'],
                ],
                'help_text' => 'Tamaños comunes: 19", 21", 22", 23", 24", 27", 32"',
                'error_message' => 'Use formato con comillas',
                'is_active' => true,
                'priority' => 5,
            ],
            // Sin regla de power_cable_status en monitores

            // ===== AIO =====
            [
                'equipment_type' => 'aio',
                'field_name' => 'screen_inches',
                'validation_type' => 'suggestion',
                'rule_config' => [
                    'allowed_values' => ['21"', '23"', '24"', '27"'],
                ],
                'help_text' => 'Tamaños comunes: 21", 23", 24", 27"',
                'error_message' => 'Use formato con comillas',
                'is_active' => true,
                'priority' => 5,
            ],
            [
                'equipment_type' => 'aio',
                'field_name' => 'power_cable_status',
                'validation_type' => 'suggestion',
                'rule_config' => [
                    'allowed_values' => ['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'],
                ],
                'help_text' => 'Estado del cable de alimentación si se incluye',
                'error_message' => 'Valor no permitido para el estado del cable de poder',
                'is_active' => true,
                'priority' => 5,
            ],

            // ===== DOCKING =====
            // Sin regla de power_cable_status en docking

            // ===== DOCKING =====
            [
                'equipment_type' => 'docking',
                'field_name' => 'compatible_models',
                'validation_type' => 'required',
                'rule_config' => [
                    'min_length' => 3,
                ],
                'help_text' => 'Liste los modelos de notebooks compatibles',
                'error_message' => 'Debe especificar al menos un modelo compatible',
                'is_active' => true,
                'priority' => 10,
            ],
        ];
    }
}
