<?php

namespace Database\Seeders;

use App\Models\CustomerSale;
use App\Models\Subsidiary;
use Illuminate\Database\Seeder;

class CustomerSalesSeeder extends Seeder
{
    public function run(): void
    {
        $subsidiary = Subsidiary::query()->first();
        if (!$subsidiary) {
            $this->command?->warn('No subsidiaries found. Skipping CustomerSalesSeeder.');
            return;
        }

        $customer = CustomerSale::firstOrCreate(
            [
                'subsidiary_id' => $subsidiary->id,
                'rut' => '76.543.210-1',
            ],
            [
                'type' => 'company',
                'billing_company' => 'Cliente Demo SPA',
                'trade_activity' => 'Servicios TI',
                'contact_name' => 'María López',
                'email' => 'cliente.demo@example.com',
                'phone' => '+56 2 2345 6789',
                'billing_address_1' => 'Av. Principal 123',
                'billing_address_2' => 'Piso 4',
                'billing_city' => 'Santiago',
                'billing_state_code' => 'RM',
                'billing_postcode' => '8320000',
                'billing_country_code' => 'CL',
                'default_document_type' => 'factura',
                'preferred_payment_method' => 'transferencia',
                'purchase_order_number' => null,
                'commercial_data' => ['nota' => 'Cliente de ejemplo para pruebas'],
                'notes' => 'No llamar en horario de almuerzo',
                'is_active' => true,
            ]
        );

        if (isset($this->command)) {
            $this->command->info(sprintf(
                '✅ CustomerSalesSeeder: asegurado cliente demo (id=%s, rut=%s, subsidiary_id=%s)'
                , (string)($customer->id)
                , '76.543.210-1'
                , (string)$subsidiary->id
            ));
        }
    }
}
