<?php

namespace Database\Seeders;

use App\Models\Document;
use App\Models\DocumentType;
use App\Models\Product;
use App\Models\Sale;
use App\Models\Subsidiary;
use Illuminate\Database\Seeder;

class DocumentsSeeder extends Seeder
{
    public function run(): void
    {
        $this->command?->info('Sembrando documentos de demostración...');

        $subsidiaries = Subsidiary::query()->orderBy('id')->get();
        if ($subsidiaries->isEmpty()) {
            $this->command?->warn('No hay subsidiarias disponibles. Omitiendo documentos.');
            return;
        }

        // Tipos básicos esperados
        $typeByCode = DocumentType::query()->get()->keyBy('code');
        if ($typeByCode->isEmpty()) {
            $this->command?->warn('No hay tipos de documento. Ejecuta DocumentTypesSeeder primero.');
        }

        $created = 0; $updated = 0; $rows = [];

        foreach ($subsidiaries as $subsidiary) {
            // Elegir referencias opcionales
            $sale = Sale::where('subsidiary_id', $subsidiary->id)->latest('id')->first();
            $product = Product::query()->whereHas('branch', function ($q) use ($subsidiary) {
                $q->where('subsidiary_id', $subsidiary->id);
            })->first();

            // Documento 1: PDF de ventas
            $doc1 = Document::firstOrNew([
                'subsidiary_id' => $subsidiary->id,
                'name' => 'Informe de Ventas (Demo)',
            ]);
            $doc1->fill([
                'document_type_id' => optional($typeByCode->get('guia_despacho') ?: $typeByCode->get('cotizacion') ?: $typeByCode->first())->id,
                'description' => 'Documento de demostración para el módulo de ventas.',
                'output_format' => 'pdf',
                'related_module' => 'VENTAS',
                'related_id' => $sale?->id,
                'is_active' => true,
                'metadata' => ['tags' => ['demo','ventas']],
            ]);
            $isNew = !$doc1->exists;
            $doc1->save();
            $isNew ? $created++ : $updated++;
            $rows[] = sprintf(' - %s (subsidiary:%d)%s', $doc1->name, $subsidiary->id, $isNew ? ' [CREADO]' : ' [ACTUALIZADO]');

            // Adjuntar un archivo de demostración (texto) si no tiene
            if ($doc1->getMedia()->isEmpty()) {
                $tmp = tempnam(sys_get_temp_dir(), 'doc_demo_');
                file_put_contents($tmp, "Documento de demostración para ventas (PDF simulado).\n");
                $doc1->addMedia($tmp)
                    ->usingFileName('informe_ventas_demo.pdf')
                    ->withCustomProperties(['original_name' => 'informe_ventas_demo.pdf'])
                    ->toMediaCollection('files');
                @unlink($tmp);
            }

            // Documento 2: Ficha de producto
            $doc2 = Document::firstOrNew([
                'subsidiary_id' => $subsidiary->id,
                'name' => 'Ficha de Producto (Demo)',
            ]);
            $doc2->fill([
                'document_type_id' => optional($typeByCode->get('orden_compra') ?: $typeByCode->get('boleta') ?: $typeByCode->first())->id,
                'description' => 'Ficha técnica o manual de producto de demostración.',
                'output_format' => 'docx',
                'related_module' => 'PRODUCTO',
                'related_id' => $product?->id,
                'is_active' => true,
                'metadata' => ['tags' => ['demo','producto']],
            ]);
            $isNew = !$doc2->exists;
            $doc2->save();
            $isNew ? $created++ : $updated++;
            $rows[] = sprintf(' - %s (subsidiary:%d)%s', $doc2->name, $subsidiary->id, $isNew ? ' [CREADO]' : ' [ACTUALIZADO]');

            if ($doc2->getMedia()->isEmpty()) {
                $tmp = tempnam(sys_get_temp_dir(), 'doc_demo_');
                file_put_contents($tmp, "Documento de demostración (docx simulado).\n");
                $doc2->addMedia($tmp)
                    ->usingFileName('ficha_producto_demo.docx')
                    ->withCustomProperties(['original_name' => 'ficha_producto_demo.docx'])
                    ->toMediaCollection('files');
                @unlink($tmp);
            }
        }

        foreach ($rows as $line) { $this->command?->info($line); }
        $this->command?->info(sprintf('Documentos → creados: %d, actualizados: %d', $created, $updated));
    }
}

