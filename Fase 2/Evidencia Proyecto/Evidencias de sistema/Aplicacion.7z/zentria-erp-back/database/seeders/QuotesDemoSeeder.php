<?php

namespace Database\Seeders;

use App\Models\CustomerSale;
use App\Models\Product;
use App\Models\Quote;
use App\Models\QuoteItem;
use App\Models\Sale;
use App\Models\Subsidiary;
use Illuminate\Database\Seeder;

class QuotesDemoSeeder extends Seeder
{
    public function run(): void
    {
        $subsidiary = Subsidiary::query()->find(1) ?: Subsidiary::query()->first();
        if (!$subsidiary) {
            $this->command?->warn('No subsidiaries found. Skipping QuotesDemoSeeder.');
            return;
        }

        $customer = CustomerSale::query()->where('subsidiary_id', $subsidiary->id)->first();
        if (!$customer) {
            $this->command?->warn('No CustomerSale found. Run CustomerSalesSeeder first.');
            return;
        }

        // Intenta tomar el mismo producto de la venta demo si existe
        $sale = Sale::query()->where('subsidiary_id', $subsidiary->id)->orderByDesc('id')->with('items')->first();
        $productId = $sale?->items?->first()?->product_id;
        $product = $productId ? Product::find($productId) : null;
        if (!$product) {
            $product = Product::query()->orderBy('id')->first();
        }
        if (!$product) {
            $this->command?->warn('No products found. Run DemoCatalogSeeder first.');
            return;
        }

        $quote = Quote::query()->firstOrCreate(
            [
                'subsidiary_id' => $subsidiary->id,
                'quote_number' => 'Q-0001',
            ],
            [
                'customer_id' => $customer->id,
                'status' => 'draft',
                'salesperson_id' => null,
                'quote_date' => now()->toDateString(),
                'expiry_date' => now()->addDays(15)->toDateString(),
                'subtotal' => 0,
                'tax_amount' => 0,
                'discount_amount' => 0,
                'total_amount' => 0,
                'terms_conditions' => ['validez' => '15 días'],
                'notes' => 'Cotización demo ligada a la venta demo',
                'internal_notes' => 'Generado por QuotesDemoSeeder',
            ]
        );

        QuoteItem::query()->firstOrCreate(
            [
                'quote_id' => $quote->id,
                'product_id' => $product->id,
            ],
            [
                'quantity' => 1,
                'unit_price' => (string) ($product->price ?? 0),
                'discount_rate' => 0,
                'discount_amount' => 0,
                'subtotal' => (string) ($product->price ?? 0),
                'total' => (string) ($product->price ?? 0),
                'customer_sku' => $product->sku,
                'customer_name' => $customer->billing_company ?: $customer->contact_name,
                'product_attributes' => $product->attributes_json,
            ]
        );

        if (isset($this->command)) {
            $this->command->info(sprintf(
                '✅ QuotesDemoSeeder: cotización demo %s (id=%s) con 1 ítem (product_id=%s) para customer_id=%s',
                'Q-0001',
                (string)$quote->id,
                (string)$product->id,
                (string)$customer->id
            ));
        }
    }
}

