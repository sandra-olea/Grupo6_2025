<?php

namespace Database\Seeders;

use App\Enums\EquipmentGrade;
use App\Enums\EquipmentStatus;
use App\Enums\EquipmentType;
use App\Enums\ReviewStatus;
use App\Models\Branch;
use App\Models\CustomerSupplier;
use App\Models\TechnicalReviewBatch;
use App\Models\TechnicalReviewItem;
use App\Models\TechnicalReviewNotebook;
use App\Models\TechnicalReviewDesktop;
use App\Models\TechnicalReviewMonitor;
use App\Models\EquipmentTraceability;
use App\Models\User;
use App\Models\Warehouse;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TechnicalReviewDemoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * Crea un lote completo de revisiones técnicas con equipos en diferentes estados
     * para demostrar el flujo completo del sistema.
     */
    public function run(): void
    {
        $this->command->info('🔄 Creando lote de demostración de revisiones técnicas...');

        DB::beginTransaction();

        try {
            // 1. Obtener datos base
            $branch = Branch::with('subsidiary')->first();
            $warehouse = Warehouse::where('branch_id', $branch?->id)->first();
            $technician = User::whereHas('roles', function ($q) {
                $q->where('name', 'technician')->where('guard_name', 'api');
            })->first();

            if (!$branch || !$warehouse || !$technician) {
                $this->command->error('❌ Faltan datos base (branch, warehouse o technician)');
                return;
            }

            $customer = CustomerSupplier::firstOrCreate([
                'subsidiary_id' => $branch->subsidiary_id,
                'name' => 'Cliente Demo Revisiones Técnicas',
            ]);

            // 2. Crear el lote
            $batch = TechnicalReviewBatch::create([
                'code' => 'RT-DEMO-001',
                'branch_id' => $branch->id,
                'warehouse_id' => $warehouse->id,
                'customer_supplier_id' => $customer->id,
                'expected_quantity' => 5,
                'completed_quantity' => 2, // 2 equipos ya completados
                'status' => 'in_progress',
                'entry_date' => now(),
                'notes' => 'Lote de demostración con equipos en diferentes estados del flujo',
                'created_by' => $technician->id,
            ]);

            // 3. Crear equipos en diferentes estados
            
            // EQUIPO 1: Notebook completamente aprobado (Grado A)
            $item1 = $this->createNotebookItem($batch, $technician, 'NB-001-APPROVED', ReviewStatus::APPROVED);
            $this->completeNotebookReview($item1->fresh(), $technician, 95, 95, 95, 'good');
            $item1->update([
                'grade' => EquipmentGrade::A,
                'suggested_grade' => 'A',
                'scoring_confidence' => 95,
            ]);
            EquipmentTraceability::create([
                'review_item_id' => $item1->id,
                'serial_number' => $item1->serial_number,
                'warehouse_id' => $warehouse->id,
                'status' => 'available_for_sale',
            ]);

            // EQUIPO 2: Notebook completado pendiente de aprobación (Grado B)
            $item2 = $this->createNotebookItem($batch, $technician, 'NB-002-PENDING-APPROVAL', ReviewStatus::REVIEWED);
            $this->completeNotebookReview($item2->fresh(), $technician, 80, 85, 75, 'fair');
            $item2->update([
                'suggested_grade' => 'B',
                'scoring_confidence' => 80,
            ]);

            // EQUIPO 3: Desktop en revisión (parcialmente completado)
            $item3 = $this->createDesktopItem($batch, $technician, 'DT-003-IN-REVIEW', ReviewStatus::IN_REVIEW);
            $this->partialDesktopReview($item3->fresh(), $technician);

            // EQUIPO 4: Monitor pendiente de revisión
            $item4 = $this->createMonitorItem($batch, $technician, 'MN-004-PENDING', ReviewStatus::PENDING);

            // EQUIPO 5: Notebook rechazado (Grado M - Para repuestos)
            $item5 = $this->createNotebookItem($batch, $technician, 'NB-005-REJECTED', ReviewStatus::APPROVED);
            $this->completeNotebookReview($item5->fresh(), $technician, 30, 40, 20, 'poor');
            $item5->update([
                'grade' => EquipmentGrade::M,
                'suggested_grade' => 'M',
                'scoring_confidence' => 30,
            ]);
            EquipmentTraceability::create([
                'review_item_id' => $item5->id,
                'serial_number' => $item5->serial_number,
                'warehouse_id' => $warehouse->id,
                'status' => 'scrapped',
            ]);

            DB::commit();

            $this->command->newLine();
            $this->command->info('✅ Lote de demostración creado exitosamente:');
            $this->command->line("   📦 Lote: {$batch->code}");
            $this->command->line("   📍 Sucursal: {$branch->branch_name}");
            $this->command->line("   🏢 Bodega: {$warehouse->name}");
            $this->command->line("   👤 Técnico: {$technician->email}");
            $this->command->newLine();
            $this->command->info('   Equipos creados:');
            $this->command->line("   ✅ NB-001-APPROVED: Notebook aprobado (Grado A) - Disponible");
            $this->command->line("   ⏳ NB-002-PENDING-APPROVAL: Notebook pendiente aprobación (sugerido B)");
            $this->command->line("   🔧 DT-003-IN-REVIEW: Desktop en revisión");
            $this->command->line("   📋 MN-004-PENDING: Monitor pendiente revisión");
            $this->command->line("   ❌ NB-005-REJECTED: Notebook rechazado (Grado M) - Para repuestos");
            $this->command->newLine();

        } catch (\Exception $e) {
            DB::rollBack();
            $this->command->error("❌ Error al crear lote de demostración: {$e->getMessage()}");
            throw $e;
        }
    }

    private function createNotebookItem(TechnicalReviewBatch $batch, User $technician, string $serial, ReviewStatus $status): TechnicalReviewItem
    {
        $item = TechnicalReviewItem::create([
            'batch_id' => $batch->id,
            'branch_id' => $batch->branch_id,
            'warehouse_id' => $batch->warehouse_id,
            'customer_supplier_id' => $batch->customer_supplier_id,
            'serial_number' => $serial,
            'equipment_type' => EquipmentType::NOTEBOOK,
            'review_status' => $status,
            'review_started_at' => $status !== ReviewStatus::PENDING ? now()->subHours(2) : null,
            'reviewed_at' => in_array($status, [ReviewStatus::REVIEWED, ReviewStatus::APPROVED]) ? now()->subHour() : null,
            'approved_at' => $status === ReviewStatus::APPROVED ? now() : null,
            'created_by' => $technician->id,
            'reviewed_by' => $status !== ReviewStatus::PENDING ? $technician->id : null,
            'approved_by' => $status === ReviewStatus::APPROVED ? $technician->id : null,
        ]);

        TechnicalReviewNotebook::create([
            'review_item_id' => $item->id,
        ]);

        return $item;
    }

    private function createDesktopItem(TechnicalReviewBatch $batch, User $technician, string $serial, ReviewStatus $status): TechnicalReviewItem
    {
        $item = TechnicalReviewItem::create([
            'batch_id' => $batch->id,
            'branch_id' => $batch->branch_id,
            'warehouse_id' => $batch->warehouse_id,
            'customer_supplier_id' => $batch->customer_supplier_id,
            'serial_number' => $serial,
            'equipment_type' => EquipmentType::DESKTOP,
            'review_status' => $status,
            'review_started_at' => now()->subHour(),
            'created_by' => $technician->id,
            'reviewed_by' => $technician->id,
        ]);

        TechnicalReviewDesktop::create([
            'review_item_id' => $item->id,
        ]);

        return $item;
    }

    private function createMonitorItem(TechnicalReviewBatch $batch, User $technician, string $serial, ReviewStatus $status): TechnicalReviewItem
    {
        return TechnicalReviewItem::create([
            'batch_id' => $batch->id,
            'branch_id' => $batch->branch_id,
            'warehouse_id' => $batch->warehouse_id,
            'customer_supplier_id' => $batch->customer_supplier_id,
            'serial_number' => $serial,
            'equipment_type' => EquipmentType::MONITOR,
            'review_status' => $status,
            'created_by' => $technician->id,
        ]);
    }

    private function completeNotebookReview(
        TechnicalReviewItem $item,
        User $technician,
        int $aestheticScore,
        int $functionalScore,
        int $batteryScore,
        string $batteryStatus
    ): void {
        $notebook = TechnicalReviewNotebook::where('review_item_id', $item->id)->first();
        $componentCondition = $aestheticScore >= 90 ? 'ok' : ($aestheticScore >= 70 ? 'worn' : 'missing_pieces');
        $generalCondition = match (true) {
            $aestheticScore >= 90 => 'like_new',
            $aestheticScore >= 70 => 'good_shape',
            $aestheticScore >= 50 => 'visible_wear',
            $aestheticScore >= 30 => 'needs_repair',
            default => 'scrap',
        };

        $notebook->update([
            // Estética
            'screen_condition' => $aestheticScore >= 90 ? 'ok' : ($aestheticScore >= 70 ? 'worn' : 'dead_pixels'),
            'keyboard_condition' => $componentCondition,
            'touchpad_condition' => $componentCondition,
            'cover_condition' => $componentCondition,
            'hinge_condition' => $aestheticScore >= 90 ? 'ok' : ($aestheticScore >= 70 ? 'worn' : 'broken'),
            'bottom_condition' => $componentCondition,
            // Puertos (cantidades)
            'usb_a_ports' => $functionalScore >= 80 ? 3 : 2,
            'usb_c_ports' => $functionalScore >= 80 ? 1 : 0,
            'hdmi_ports' => 1,
            'displayport_ports' => 0,
            'rj45_ports' => 1,
            'sd_readers' => $functionalScore >= 70 ? 1 : 0,
            // Conectividad inalámbrica (booleanos se mantienen)
            'has_wifi' => $functionalScore >= 70,
            'has_bluetooth' => $functionalScore >= 70,
            // Batería
            'battery_health' => $batteryScore . '%',
            'battery_status' => $batteryStatus,
            'battery_percentage' => $batteryScore,
            'battery_holds_charge' => $batteryScore >= 50,
            'battery_condition' => $batteryStatus,
            // General
            'general_condition' => $generalCondition,
        ]);
    }

    private function partialDesktopReview(TechnicalReviewItem $item, User $technician): void
    {
        $desktop = TechnicalReviewDesktop::where('review_item_id', $item->id)->first();
        $desktop->update([
            // Desktop usa tokens: ok, good_condition, light_scratches, noticeable_wear, broken
            // Mapear "worn" (desgaste leve) al token permitido más cercano
            'cover_condition' => 'noticeable_wear',
            'general_condition' => 'good_shape',
            // Puertos (cantidades) - parcialmente completado
            'usb_a_ports' => 4,
            'usb_c_ports' => 1,
            'hdmi_ports' => 1,
            'displayport_ports' => 2,
            'rj45_ports' => 1,
            // Conectividad inalámbrica
            'has_wifi' => true,
            'has_bluetooth' => false,
            // Dejamos algunos campos sin completar para simular revisión en progreso
        ]);
    }
}
