<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class TechnicalReviewsPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * Crea los permisos del módulo de Revisiones Técnicas y los asigna a los roles correspondientes.
     */
    public function run(): void
    {
        $this->command->info('🔄 Creando permisos para el módulo de Revisiones Técnicas...');

        // Obtener permisos desde permission_groups.php
        $permissionGroups = config('permission_groups');
        
        $technicalReviewsPermissions = array_merge(
            $permissionGroups['technical-reviews-batches'] ?? [],
            $permissionGroups['technical-reviews-items'] ?? [],
            $permissionGroups['technical-reviews-reports'] ?? []
        );

        $createdCount = 0;
        $existingCount = 0;

        foreach ($technicalReviewsPermissions as $permissionName) {
            $permission = Permission::firstOrCreate(
                ['name' => $permissionName, 'guard_name' => 'api']
            );

            if ($permission->wasRecentlyCreated) {
                $createdCount++;
            } else {
                $existingCount++;
            }
        }

        $this->command->info("✅ Permisos de Revisiones Técnicas: {$createdCount} creados, {$existingCount} ya existían");

        // Asignar permisos a roles
        $this->assignPermissionsToRoles($technicalReviewsPermissions);
    }

    /**
     * Asigna los permisos de revisiones técnicas a los roles del sistema
     */
    private function assignPermissionsToRoles(array $permissions): void
    {
        $this->command->info('🔄 Asignando permisos a roles...');

        // Admin: todos los permisos del módulo
        $admin = Role::where('name', 'admin')->where('guard_name', 'api')->first();
        if ($admin) {
            $admin->givePermissionTo($permissions);
            $this->command->info("   ✓ Rol 'admin' → " . count($permissions) . " permisos");
        }

        // Super Admin: todos los permisos del módulo
        $superAdmin = Role::where('name', 'super-admin')->where('guard_name', 'api')->first();
        if ($superAdmin) {
            $superAdmin->givePermissionTo($permissions);
            $this->command->info("   ✓ Rol 'super-admin' → " . count($permissions) . " permisos");
        }

        // Supervisor: todos excepto eliminar
        $supervisor = Role::where('name', 'supervisor')->where('guard_name', 'api')->first();
        if ($supervisor) {
            $supervisorPermissions = array_filter($permissions, function($perm) {
                return !str_contains($perm, 'delete');
            });
            $supervisor->givePermissionTo($supervisorPermissions);
            $this->command->info("   ✓ Rol 'supervisor' → " . count($supervisorPermissions) . " permisos");
        }

        // Technician: solo operaciones básicas (view, create, review, edit)
        $technician = Role::where('name', 'technician')->where('guard_name', 'api')->first();
        if ($technician) {
            $technicianPermissions = array_filter($permissions, function($perm) {
                return str_contains($perm, 'view') 
                    || str_contains($perm, 'create') 
                    || str_contains($perm, 'review') 
                    || str_contains($perm, 'edit');
            });
            // Excluir reportes para técnicos
            $technicianPermissions = array_filter($technicianPermissions, function($perm) {
                return !str_contains($perm, 'reports');
            });
            $technician->givePermissionTo($technicianPermissions);
            $this->command->info("   ✓ Rol 'technician' → " . count($technicianPermissions) . " permisos");
        }

        $this->command->info('✅ Permisos asignados correctamente a los roles');
    }
}
