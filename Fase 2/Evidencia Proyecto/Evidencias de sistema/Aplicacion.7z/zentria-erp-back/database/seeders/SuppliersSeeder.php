<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Subsidiary;
use App\Models\Supplier;
use App\Models\CustomerSupplier;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\NotificationEvent;
use App\Services\Notifications\NotificationRouter;

class SuppliersSeeder extends Seeder
{
    /**
     * Seed suppliers y customer_suppliers con datos de ejemplo.
     * Crea 2 proveedores y 2 clientes en 2 subsidiaries diferentes.
     */
    public function run(): void
    {
        $out = $this->command?->getOutput();

        DB::transaction(function () use ($out) {
            // Obtener las primeras 2 subsidiaries
            $subsidiaries = Subsidiary::take(2)->get();

            if ($subsidiaries->count() < 2) {
                if ($out) {
                    $out->writeln('');
                    $out->writeln('⚠️  <comment>Se necesitan al menos 2 subsidiaries en la base de datos.</comment>');
                    $out->writeln('   Ejecuta primero: <info>php artisan db:seed --class=EmpresaSeeder</info>');
                    $out->writeln('');
                }
                return;
            }

            $subsidiary1 = $subsidiaries[0];
            $subsidiary2 = $subsidiaries[1];

            // ===================================================================
            // SUBSIDIARY 1: 1 proveedor y 1 cliente con 1 relación
            // ===================================================================
            
            $supplier1 = Supplier::firstOrCreate(
                [
                    'subsidiary_id' => $subsidiary1->id,
                    'name' => 'Proveedor Global SA',
                ],
                ['name' => 'Proveedor Global SA']
            );

            $customer1 = CustomerSupplier::firstOrCreate(
                [
                    'subsidiary_id' => $subsidiary1->id,
                    'name' => 'Cliente Xinerlink',
                ],
                ['name' => 'Cliente Xinerlink']
            );

            // Cliente 1 → 1 proveedor (mismo subsidiary)
            $customer1->suppliers()->syncWithoutDetaching([$supplier1->id]);
            
            // Crear notificación de attach
            $this->createAttachNotification($customer1, [$supplier1->id], $subsidiary1);

            // ===================================================================
            // SUBSIDIARY 2: 1 proveedor y 1 cliente con 2 relaciones
            // ===================================================================
            
            $supplier2 = Supplier::firstOrCreate(
                [
                    'subsidiary_id' => $subsidiary2->id,
                    'name' => 'Distribuidora NC Ltda',
                ],
                ['name' => 'Distribuidora NC Ltda']
            );
            
            $supplier3 = Supplier::firstOrCreate(
                [
                    'subsidiary_id' => $subsidiary2->id,
                    'name' => 'Mayorista Express SA',
                ],
                ['name' => 'Mayorista Express SA']
            );

            $customer2 = CustomerSupplier::firstOrCreate(
                [
                    'subsidiary_id' => $subsidiary2->id,
                    'name' => 'Cliente Retail Mayor',
                ],
                ['name' => 'Cliente Retail Mayor']
            );

            // Cliente 2 → 2 proveedores (mismo subsidiary)
            $customer2->suppliers()->syncWithoutDetaching([$supplier2->id, $supplier3->id]);
            
            // Crear notificación de attach
            $this->createAttachNotification($customer2, [$supplier2->id, $supplier3->id], $subsidiary2);

            // Output estilo "checklist"
            if ($out) {
                $out->writeln('');
                $out->writeln('✅ <info>Seeder de Suppliers y Customer Suppliers completado:</info>');
                $out->writeln('');
                $out->writeln('  <comment>Subsidiary 1:</comment> <info>' . $subsidiary1->subsidiary_name . '</info>');
                $out->writeln('    • Proveedor: <info>' . $supplier1->name . '</info>');
                $out->writeln('    • Cliente: <info>' . $customer1->name . '</info>');
                $out->writeln('    • Relación: <comment>1 cliente ↔ 1 proveedor</comment>');
                $out->writeln('');
                $out->writeln('  <comment>Subsidiary 2:</comment> <info>' . $subsidiary2->subsidiary_name . '</info>');
                $out->writeln('    • Proveedor 1: <info>' . $supplier2->name . '</info>');
                $out->writeln('    • Proveedor 2: <info>' . $supplier3->name . '</info>');
                $out->writeln('    • Cliente: <info>' . $customer2->name . '</info>');
                $out->writeln('    • Relación: <comment>1 cliente ↔ 2 proveedores</comment>');
                $out->writeln('');
                $out->writeln('  <comment>Resumen:</comment>');
                $out->writeln('    • Total proveedores: <info>3</info>');
                $out->writeln('    • Total clientes: <info>2</info>');
                $out->writeln('    • Total relaciones: <info>3</info>');
                $out->writeln('    • <comment>✓ Aislamiento por subsidiary respetado</comment>');
                $out->writeln('');
            }
        });
    }

    /**
     * Crear notificación de attach suppliers a customer
     */
    private function createAttachNotification(CustomerSupplier $customer, array $supplierIds, Subsidiary $subsidiary): void
    {
        try {
            $type = NotificationType::where('key', 'customer-supplier.suppliers-attached')->first();
            if (!$type) return;

            $suppliers = Supplier::whereIn('id', $supplierIds)->get();
            $supplierNames = $suppliers->pluck('name')->join(', ');

            $event = NotificationEvent::create([
                'type_id' => $type->id,
                'entity_type' => 'customer_supplier',
                'entity_id' => $customer->id,
                'company_id' => $subsidiary->company_id,
                'subsidiary_id' => $subsidiary->id,
                'branch_id' => null,
                'priority' => $type->default_priority,
                'payload' => [
                    'customer_supplier_name' => $customer->name,
                    'supplier_names' => $supplierNames,
                    'suppliers_count' => count($suppliers),
                    'subsidiary_name' => $subsidiary->subsidiary_name,
                    'action' => 'proveedores_asociados_seeder',
                ],
                'dedup_key' => 'seeder.customer-supplier.attach:'.$customer->id.':'.now()->timestamp,
                'occurred_at' => now(),
            ]);

            app(NotificationRouter::class)->route($event);
        } catch (\Throwable $e) {
            // Silently fail para no romper el seeder
        }
    }
}
