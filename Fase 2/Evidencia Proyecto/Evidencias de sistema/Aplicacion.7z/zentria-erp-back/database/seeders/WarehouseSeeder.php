<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Branch;
use App\Models\Warehouse;

class WarehouseSeeder extends Seeder
{
    public function run(): void
    {
        $branch = Branch::first();
        if (!$branch) {
            $this->command?->warn('No branches found. Skipping WarehouseSeeder.');
            return;
        }

        Warehouse::firstOrCreate([
            'branch_id' => $branch->id,
            'code' => 'MAIN',
        ], [
            'name' => 'Bodega Principal',
            'description' => 'Bodega por defecto para la sucursal',
            'warehouse_type' => 'main',
            'is_active' => true,
            'requires_serial_tracking' => true,
        ]);

        $this->command?->info('WarehouseSeeder: Bodega creada/actualizada.');
    }
}

