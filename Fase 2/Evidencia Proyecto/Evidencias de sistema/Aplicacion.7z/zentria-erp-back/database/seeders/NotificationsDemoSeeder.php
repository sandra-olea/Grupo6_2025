<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Company;
use App\Models\Subsidiary;
use App\Models\Branch;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\NotificationEvent;
use App\Services\Notifications\NotificationRouter;

class NotificationsDemoSeeder extends Seeder
{
    public function run(): void
    {
        $typeP1 = NotificationType::where('key', 'system.sync-failed')->first();
        $typeP2 = NotificationType::where('key', 'payment.confirmed')->first();
        $typeP3 = NotificationType::where('key', 'quote.expiring-soon')->first();

        $company = Company::first();
        $subsidiary = Subsidiary::first();
        $branch = Branch::first();

        if (! $typeP1 || ! $typeP2 || ! $typeP3 || ! $company || ! $subsidiary || ! $branch) {
            if (isset($this->command)) {
                $this->command->warn('NotificationsDemoSeeder: faltan tipos o datos base (company/subsidiary/branch).');
            }
            return;
        }

        $router = app(NotificationRouter::class);

        // Autor por defecto para demo
        $author = \App\Models\User::role('super-admin')->first() ?: \App\Models\User::first();
        $authorName = $author ? (trim(($author->first_name ?? '').' '.($author->last_name ?? '')) ?: ($author->email ?? 'Sistema')) : 'Sistema';
        $authorId = $author->id ?? null;

        $examples = [
            [
                'type' => $typeP1,
                'scope' => ['company_id' => $company->id],
                'entity' => ['type' => 'system', 'id' => 0],
                'payload' => ['component' => 'syncer', 'error' => 'Timeout contacting upstream', 'created_by' => $authorName, 'created_by_id' => $authorId],
            ],
            [
                'type' => $typeP2,
                'scope' => ['subsidiary_id' => $subsidiary->id],
                'entity' => ['type' => 'payment', 'id' => rand(1000,9999)],
                'payload' => ['amount' => 123450, 'currency' => 'CLP', 'created_by' => $authorName, 'created_by_id' => $authorId],
            ],
            [
                'type' => $typeP3,
                'scope' => ['branch_id' => $branch->id],
                'entity' => ['type' => 'quote', 'id' => rand(1000,9999)],
                'payload' => ['days_left' => 2, 'created_by' => $authorName, 'created_by_id' => $authorId],
            ],
        ];

        $created = 0;
        foreach ($examples as $ex) {
            $event = NotificationEvent::create([
                'type_id' => $ex['type']->id,
                'entity_type' => $ex['entity']['type'],
                'entity_id' => $ex['entity']['id'],
                'company_id' => $ex['scope']['company_id'] ?? null,
                'subsidiary_id' => $ex['scope']['subsidiary_id'] ?? null,
                'branch_id' => $ex['scope']['branch_id'] ?? null,
                'priority' => $ex['type']->default_priority,
                'payload' => $ex['payload'],
                'dedup_key' => $ex['type']->key.':'.$ex['entity']['type'].':'.$ex['entity']['id'],
                'occurred_at' => now(),
            ]);
            $router->route($event);
            $created++;
        }

        if (isset($this->command)) {
            $this->command->info("NotificationsDemoSeeder: {$created} eventos creados y enrutados.");
        }
    }
}
