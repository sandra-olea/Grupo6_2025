<?php

namespace Database\Seeders;

use App\Enums\EquipmentStatus;
use App\Models\EquipmentTraceability;
use App\Models\Product;
use App\Models\Warranty;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class WarrantiesDemoSeeder extends Seeder
{
    public function run(): void
    {
        $this->command?->info('Sembrando garantías de demostración desde series VENDIDAS...');

        // Crear algunas garantías a partir de series vendidas recientes
        $sold = EquipmentTraceability::query()
            ->where('status', EquipmentStatus::SOLD)
            ->orderByDesc('sold_at')
            ->limit(20)
            ->get();

        $created = 0; $updated = 0; $rows = [];
        foreach ($sold as $trace) {
            $sale = $trace->sale;
            if (!$sale) continue;
            $subsidiaryId = $sale->subsidiary_id;

            $productId = optional($trace->reviewItem)->product_id;
            $months = 12;
            if ($productId) {
                $prod = Product::find($productId);
                if ($prod && is_numeric($prod->warranty_months)) {
                    $months = max(0, (int) $prod->warranty_months);
                }
            }

            $start = ($trace->sold_at ?? now())->toDateString();
            $end = ($trace->sold_at ?? now())->copy()->addMonths($months)->toDateString();

            $model = Warranty::firstOrNew([
                'serial_number' => $trace->serial_number,
                'subsidiary_id' => $subsidiaryId,
            ]);
            $isNew = !$model->exists;
            $model->fill([
                'product_id' => $productId,
                'customer_id' => $trace->customer_id,
                'sale_id' => $trace->sale_id,
                'start_date' => $start,
                'end_date' => $end,
                'status' => now()->gt($end) ? 'Expirada' : 'Activa',
                'notes' => 'Generada automáticamente desde series vendidas (seeder demo).',
            ]);
            $model->save();
            $isNew ? $created++ : $updated++;
            $rows[] = sprintf(' - %s | venta:%s | cliente:%s | %s → %s%s',
                $trace->serial_number,
                (string) $trace->sale_id,
                (string) $trace->customer_id,
                $start,
                $end,
                $isNew ? ' [CREADA]' : ' [ACTUALIZADA]'
            );
        }

        foreach ($rows as $line) { $this->command?->info($line); }
        $this->command?->info(sprintf('Garantías → creadas: %d, actualizadas: %d', $created, $updated));
    }
}
