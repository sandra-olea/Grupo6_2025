<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Notifications\NotificationType;
use Illuminate\Support\Str;

class NotificationTypesSeeder extends Seeder
{
    public function run(): void
    {
        $types = [
            ['key' => 'transfer.sent', 'module' => 'transfer', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'transfer.receipt-discrepancy', 'module' => 'transfer', 'default_priority' => 'P1', 'default_channels' => ['inapp','email'], 'critical' => true, 'enabled_global' => true],
            ['key' => 'quote.expiring-soon', 'module' => 'quote', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'quote.converted', 'module' => 'quote', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'sale.delivery-due-today', 'module' => 'sales', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'payment.confirmed', 'module' => 'finance', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'system.sequence-threshold', 'module' => 'system', 'default_priority' => 'P1', 'default_channels' => ['inapp','email'], 'critical' => true, 'enabled_global' => true],
            ['key' => 'system.sync-failed', 'module' => 'system', 'default_priority' => 'P1', 'default_channels' => ['inapp','email'], 'critical' => true, 'enabled_global' => true],
            // Operacionales base para ERP
            ['key' => 'branch.created', 'module' => 'branch', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'branch.updated', 'module' => 'branch', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'company.updated', 'module' => 'company', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            // Nuevas: subsidiarias
            ['key' => 'subsidiary.created', 'module' => 'subsidiary', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'subsidiary.updated', 'module' => 'subsidiary', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'subsidiary.deleted', 'module' => 'subsidiary', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            // Nuevas: productos/marcas/categorías
            ['key' => 'product.created', 'module' => 'catalog', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'product.updated', 'module' => 'catalog', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'product.deleted', 'module' => 'catalog', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'brand.created', 'module' => 'catalog', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'brand.updated', 'module' => 'catalog', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'brand.deleted', 'module' => 'catalog', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            // Warehouses
            ['key' => 'warehouse.created', 'module' => 'warehouse', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'warehouse.updated', 'module' => 'warehouse', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'warehouse.deleted', 'module' => 'warehouse', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'warehouse.product.attached', 'module' => 'warehouse', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'warehouse.product.detached', 'module' => 'warehouse', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'category.created', 'module' => 'catalog', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            // Ventas
            ['key' => 'sale.created', 'module' => 'sales', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'sale.status-changed', 'module' => 'sales', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'sale.stock-shortage', 'module' => 'sales', 'default_priority' => 'P1', 'default_channels' => ['inapp'], 'critical' => true, 'enabled_global' => true],
            ['key' => 'product.stock-zero', 'module' => 'catalog', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            // Customer Sales
            ['key' => 'customer-sale.created', 'module' => 'customer', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'customer-sale.updated', 'module' => 'customer', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'customer-sale.deleted', 'module' => 'customer', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'category.updated', 'module' => 'catalog', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'category.deleted', 'module' => 'catalog', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            // Suppliers y Customer Suppliers
            ['key' => 'supplier.created', 'module' => 'supplier', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'supplier.updated', 'module' => 'supplier', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'supplier.deleted', 'module' => 'supplier', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'customer-supplier.created', 'module' => 'supplier', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'customer-supplier.updated', 'module' => 'supplier', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'customer-supplier.deleted', 'module' => 'supplier', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            // Relaciones attach/detach
            ['key' => 'supplier.customers-attached', 'module' => 'supplier', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'supplier.customers-detached', 'module' => 'supplier', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'customer-supplier.suppliers-attached', 'module' => 'supplier', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'customer-supplier.suppliers-detached', 'module' => 'supplier', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            // Recordatorios y vencimientos genéricos
            ['key' => 'reminder.general', 'module' => 'reminder', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'deadline.expiring-soon', 'module' => 'deadlines', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            // Empresa y sucursales (eliminación)
            ['key' => 'branch.deleted', 'module' => 'branch', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'company.deleted', 'module' => 'company', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            // Invitaciones de usuarios
            ['key' => 'invitation.sent', 'module' => 'invitation', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'invitation.activated', 'module' => 'invitation', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            // Revisiones técnicas
            ['key' => 'technical-review.batch-created', 'module' => 'technical-review', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'technical-review.batch-completed', 'module' => 'technical-review', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'technical-review.item-pending-review', 'module' => 'technical-review', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'technical-review.item-completed', 'module' => 'technical-review', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'technical-review.item-approved', 'module' => 'technical-review', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'technical-review.item-rejected', 'module' => 'technical-review', 'default_priority' => 'P2', 'default_channels' => ['inapp','email'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'technical-review.validation-error', 'module' => 'technical-review', 'default_priority' => 'P3', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
            ['key' => 'technical-review.equipment-available', 'module' => 'technical-review', 'default_priority' => 'P2', 'default_channels' => ['inapp'], 'critical' => false, 'enabled_global' => true],
        ];

        $typeLabels = config('notification_labels.types', []);

        // Asignar bucket (Important|Archived|Pending) por tipo y descripción en español
        foreach ($types as &$t) {
            $key = $t['key'];
            $priority = $t['default_priority'];
            $formattedKey = str_replace(['.', '-'], ' ', $key);
            $t['description'] = $typeLabels[$key] ?? Str::headline($formattedKey);
            if (str_ends_with($key, '.deleted')) {
                $t['bucket'] = 'Archived';
            } elseif ($priority === 'P1') {
                $t['bucket'] = 'Important';
            } else {
                $t['bucket'] = 'Pending';
            }
        }
        unset($t);

        $created = 0; $upserted = 0; $keys = [];
        foreach ($types as $t) {
            $model = NotificationType::updateOrCreate(['key' => $t['key']], $t);
            $model->wasRecentlyCreated ? $created++ : $upserted++;
            $keys[] = $t['key'];
        }

        if (isset($this->command)) {
            $this->command->info(sprintf(
                'NotificationTypes: %d creados, %d actualizados (%s)',
                $created,
                $upserted,
                implode(', ', $keys)
            ));
        }
    }
}
