<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class UnmappedWooCommerceProductsPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * Crea los permisos para gestionar productos WooCommerce sin emparejar y los asigna solo a super_admin.
     */
    public function run(): void
    {
        $this->command->info('🔄 Creando permisos para Productos WooCommerce sin emparejar...');

        // Obtener permisos desde permission_groups.php
        $permissionGroups = config('permission_groups');
        
        $unmappedPermissions = array_merge(
            $permissionGroups['unmapped-woocommerce-products'] ?? [],
            $permissionGroups['products-marketplace'] ?? []
        );

        $createdCount = 0;
        $existingCount = 0;

        foreach ($unmappedPermissions as $permissionName) {
            $permission = Permission::firstOrCreate(
                ['name' => $permissionName, 'guard_name' => 'api']
            );

            if ($permission->wasRecentlyCreated) {
                $createdCount++;
            } else {
                $existingCount++;
            }
        }

        $this->command->info("✅ Permisos de Productos sin emparejar: {$createdCount} creados, {$existingCount} ya existían");

        // Asignar permisos solo a super-admin
        $this->assignPermissionsToRoles($unmappedPermissions);
    }

    /**
     * Asigna los permisos solo al rol super-admin
     */
    private function assignPermissionsToRoles(array $permissions): void
    {
        $this->command->info('🔄 Asignando permisos a roles...');

        // Super Admin: todos los permisos
        $superAdmin = Role::where('name', 'super-admin')->where('guard_name', 'api')->first();
        if ($superAdmin) {
            $superAdmin->givePermissionTo($permissions);
            $this->command->info("   ✓ Rol 'super-admin' → " . count($permissions) . " permisos");
        } else {
            $this->command->warn("   ⚠ Rol 'super-admin' no encontrado");
        }

        $this->command->info('✅ Permisos asignados correctamente (solo super-admin tiene acceso)');
    }
}
