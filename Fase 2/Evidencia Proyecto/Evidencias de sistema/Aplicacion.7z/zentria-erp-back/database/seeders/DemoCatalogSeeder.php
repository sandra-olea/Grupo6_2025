<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use App\Models\Branch;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;

class DemoCatalogSeeder extends Seeder
{
    public function run(): void
    {
        $out = $this->command?->getOutput();

        DB::transaction(function () use ($out) {
            // ── 0) Branch destino (campo correcto: branch_name)
            $branchName = 'Casa Matriz EcoPC';
            /** @var Branch $branch */
            $branch = Branch::where('branch_name', $branchName)->firstOrFail();

            // ── 1) Brands (Lenovo, Dell) en la branch
            [$bNew, $bUpd] = [0, 0];
            $brandSlugCol = Schema::hasColumn('brands', 'slug');

            $lenovo = $this->upsertBrandInBranch($branch->id, 'Lenovo', $brandSlugCol, $bNew, $bUpd);
            $this->upsertBrandInBranch($branch->id, 'Dell',   $brandSlugCol, $bNew, $bUpd);

            // ── 2) Categories: Notebook (root) y Notebook mini (hija)
            $catSlugCol = Schema::hasColumn('categories', 'slug');

            $notebook = Category::firstOrCreate(
                $catSlugCol ? ['slug' => 'notebook'] : ['name' => 'Notebook', 'parent_id' => null],
                ['name' => 'Notebook', 'parent_id' => null] + ($catSlugCol ? ['slug' => 'notebook'] : [])
            );

            $notebookMini = Category::firstOrCreate(
                $catSlugCol ? ['slug' => 'notebook-mini'] : ['name' => 'Notebook mini', 'parent_id' => $notebook->id],
                ['name' => 'Notebook mini', 'parent_id' => $notebook->id] + ($catSlugCol ? ['slug' => 'notebook-mini'] : [])
            );

            // ── 3) Producto X390-B (Lenovo) con atributos y categoría Notebook
            $data = [
                'branch_id'         => $branch->id,
                'sku'               => 'X390-B',
                'name'              => 'Lenovo thinkpad x390 Grado B',
                'brand_id'          => $lenovo->id,
                'product_type'      => 'notebook',
                'warranty_months'   => 6,
                'serial_tracking'   => false,
                'short_description' => 'prueba',
                'long_description'  => 'prueba',
                'snippet_description'=> 'prueba',
                'cost'              => '69990.00',
                'price'             => '329990.00',
                'offer_price'       => null,
                'product_status'    => null,
                'is_active'         => true,
                'stock'             => 50, // Stock disponible para sincronización
                'attributes_json'   => [
                    'os' => [
                        'name' => 'Windows',
                        'version' => '11 Home'
                    ],
                    'CPU' => 'I7 8350U',
                    'RAM' => '16 GB',
                    'cpu' => [
                        'brand' => 'Intel',
                        'model' => 'I7 14700',
                        'family' => 'Celeron',
                        'generation' => '13th Gen'
                    ],
                    'gpu' => [
                        'type' => 'integrated',
                        'model' => 'integrada intel'
                    ],
                    'ram' => [
                        'type' => 'DDR4',
                        'channel' => 'dual',
                        'modules' => 2,
                        'upgradable' => true,
                        'capacity_gb' => 8,
                        'max_supported_gb' => 32
                    ],
                    'grade' => 'B',
                    'display' => [
                        'panel' => 'IPS',
                        'touch' => true,
                        'resolution' => '1920x1080',
                        'size_inches' => 15.6
                    ],
                    'storage' => [
                        'config' => 'single',
                        'primary' => [
                            'type' => 'NVMe',
                            'capacity_gb' => 256
                        ],
                        'upgradable' => true,
                        'available_slots' => [
                            'm2' => 1,
                            'sata' => 0
                        ],
                        'max_supported_gb' => 2000
                    ],
                    'packaging' => [
                        'charger_type' => 'original',
                        'charger_included' => true
                    ],
                    'connectivity' => [
                        'wifi' => '802.11ax',
                        'ethernet' => '1GbE',
                        'bluetooth' => '5.0'
                    ],
                    'product_kind' => 'notebook',
                    'category_grade' => 'A'
                ],
            ];

            $product = Product::where('branch_id', $branch->id)
                ->whereRaw('LOWER(sku)=LOWER(?)', ['X390-B'])
                ->first();

            $created = false;
            if ($product) {
                $product->update($data);
            } else {
                $product = Product::create($data);
                $created = true;
            }

            // pivot categorías (solo Notebook)
            $product->categories()->sync([
                $notebook->id => ['assigned_at' => now()],
                $notebookMini->id => ['assigned_at' => now()],
            ]);

            // ── 4) Output estilo “checklist”
            if ($out) {
                $out->writeln('');
                $out->writeln('✅ Seeder de catálogo completado:');
                $out->writeln('  - Branch destino: <info>'.$branchName.'</info> (id '.$branch->id.')');
                $out->writeln('  - Marcas creadas/actualizadas: <info>'.$bNew.'</info>/<info>'.$bUpd.'</info> (Lenovo, Dell)');
                $out->writeln('  - Categorías: <info>Notebook</info> (root), <info>Notebook mini</info> (hija de Notebook)');
                $out->writeln('  - Producto '.($created ? 'creado' : 'actualizado').': <info>X390-B</info> (Lenovo) con categoría <info>Notebook</info>');
                $out->writeln('');
            }
        });
    }

    /**
     * Crea/actualiza una Brand por (branch_id + name CI).
     * Incrementa contadores por referencia.
     */
    private function upsertBrandInBranch(int $branchId, string $name, bool $hasSlug, int &$created, int &$updated): Brand
    {
        $existing = Brand::where('branch_id', $branchId)
            ->whereRaw('LOWER(name)=LOWER(?)', [$name])
            ->first();

        $payload = ['name' => $name] + ($hasSlug ? ['slug' => Str::slug($name)] : []);

        if ($existing) {
            $existing->update($payload);
            $updated++;
            return $existing;
        }

        $brand = Brand::create(['branch_id' => $branchId] + $payload);
        $created++;
        return $brand;
    }
}
