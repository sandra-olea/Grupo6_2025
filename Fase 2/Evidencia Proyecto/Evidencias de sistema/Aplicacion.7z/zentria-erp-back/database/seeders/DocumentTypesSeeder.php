<?php

namespace Database\Seeders;

use App\Models\DocumentType;
use Illuminate\Database\Seeder;

class DocumentTypesSeeder extends Seeder
{
    public function run(): void
    {
        $this->command?->info('Sembrando tipos de documentos conocidos...');

        $known = [
            // Tributarios base
            ['code' => 'factura',        'name' => 'Factura',              'description' => 'Documento tributario - factura',                 'is_active' => true],
            ['code' => 'boleta',         'name' => 'Boleta',               'description' => 'Documento tributario - boleta',                  'is_active' => true],
            ['code' => 'nota_credito',   'name' => 'Nota de Crédito',      'description' => 'Documento tributario - nota de crédito',         'is_active' => true],

            // Operativos de venta/logística
            ['code' => 'cotizacion',     'name' => 'Cotización',           'description' => 'Cotización comercial',                             'is_active' => true],
            ['code' => 'guia_despacho',  'name' => 'Guía de Despacho',     'description' => 'Documento de traslado/entrega',                   'is_active' => true],
            ['code' => 'orden_compra',   'name' => 'Orden de Compra',      'description' => 'Orden de compra del cliente',                     'is_active' => true],
            ['code' => 'recibo_pago',    'name' => 'Recibo de Pago',       'description' => 'Comprobante/recibo de pago',                      'is_active' => true],

            // Técnicos / certificaciones
            ['code' => 'certificado_rt',         'name' => 'Certificado RT',        'description' => 'Certificado de Revisión Técnica',    'is_active' => true],
            ['code' => 'certificado_garantia',   'name' => 'Certificado Garantía',  'description' => 'Certificado de garantía del producto','is_active' => true],
        ];

        $created = 0; $updated = 0; $rows = [];
        foreach ($known as $k) {
            $model = DocumentType::firstOrNew(['code' => $k['code']]);
            $model->fill([
                'name' => $k['name'],
                'description' => $k['description'] ?? null,
                'is_active' => $k['is_active'] ?? true,
            ]);
            $isNew = !$model->exists;
            $model->save();
            $isNew ? $created++ : $updated++;
            $rows[] = sprintf(' - %s (%s)%s', $model->name, $model->code, $isNew ? ' [CREADO]' : ' [ACTUALIZADO]');
        }

        foreach ($rows as $line) { $this->command?->info($line); }
        $this->command?->info(sprintf('Tipos de documento → creados: %d, actualizados: %d', $created, $updated));
    }
}
