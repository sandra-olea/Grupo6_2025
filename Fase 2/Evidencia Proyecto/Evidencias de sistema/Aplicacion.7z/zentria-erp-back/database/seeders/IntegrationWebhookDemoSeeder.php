<?php

namespace Database\Seeders;

use App\Models\Integration;
use App\Models\Subsidiary;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class IntegrationWebhookDemoSeeder extends Seeder
{
    public function run(): void
    {
        $subsidiary = Subsidiary::query()->find(1) ?: Subsidiary::query()->first();
        if (!$subsidiary) {
            $this->command?->warn('No subsidiaries found. Skipping IntegrationWebhookDemoSeeder.');
            return;
        }

        $name = 'Woocommerce Prueba de Ventas';
        $provider = 'woocommerce';
        $baseUrl = 'https://zentriaweb.test';
        $scopes = ['orders','refunds'];

        // Consumer Key y Secret de WooCommerce (para hacer requests a su API)
        $consumerKey = 'ck_tu_consumer_key_aqui';
        $consumerSecret = 'cs_tu_consumer_secret_aqui';

        // API Key y Webhook Secret (para recibir webhooks DE WooCommerce)
        $apiKeyPlain = '36c17de30ed6da8b9cada52fa9de5ffda77471bfe77e5708d9b67e9d83a9f301';
        $webhookSecretPlain = '5b12236f37204947da512b916eacf96a1563210f9b8f4fde574b060e0848a424';

        $integration = Integration::query()
            ->where('subsidiary_id', $subsidiary->id)
            ->where('provider', $provider)
            ->where('name', $name)
            ->first();

        $created = false;
        if (!$integration) {
            $integration = new Integration();
            $integration->id = (string) Str::uuid();
            $integration->subsidiary_id = $subsidiary->id;
            $integration->name = $name;
            $integration->provider = $provider;
            $created = true;
        }

        $integration->base_url = $baseUrl;
        $integration->mode = 'read';
        $integration->is_active = true;
        $integration->scopes = $scopes;
        $integration->consumer_key = $consumerKey;
        $integration->consumer_secret = $consumerSecret;
        $integration->api_key_prefix = substr($apiKeyPlain, 0, 16);
        $integration->api_key_hash = Hash::make($apiKeyPlain);
        $integration->webhook_secret = Crypt::encryptString($webhookSecretPlain);
        $integration->save();

        if (isset($this->command)) {
            $this->command->info(sprintf(
                '✅ IntegrationWebhookDemoSeeder: %s integración %s (id=%s, subsidiary_id=%s)',
                $created ? 'creó' : 'actualizó',
                $name,
                $integration->id,
                $subsidiary->id
            ));
            $this->command->warn('➡️  Usa estos valores para configurar Woo:');
            $this->command->line('   Delivery URL: {BASE}/api/integrations/woocommerce/webhooks/'.$apiKeyPlain.'/orders');
            $this->command->line('   Secreto: '.$webhookSecretPlain);
        }
    }
}

