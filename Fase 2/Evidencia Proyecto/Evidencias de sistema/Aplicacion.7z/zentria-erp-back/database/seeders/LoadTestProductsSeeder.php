<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Branch;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;

class LoadTestProductsSeeder extends Seeder
{
    public function run(): void
    {
        // Desactivado temporalmente: usamos DemoCatalogSeeder para crear el producto demo.
        // Dejar este seeder intacto para poder reactivarlo en el futuro.
        return;

        $out = $this->command?->getOutput();

        DB::transaction(function () use ($out) {
            // Obtener branch 1
            $branch = Branch::findOrFail(1);
            
            if ($out) {
                $out->writeln('');
                $out->writeln('🚀 Iniciando creación de 60 productos de prueba de carga...');
                $out->writeln('  - Branch: <info>'.$branch->branch_name.'</info> (ID: '.$branch->id.')');
                $out->writeln('');
            }

            // Obtener o crear la marca Lenovo
            $brand = Brand::firstOrCreate(
                [
                    'branch_id' => $branch->id,
                    'name' => 'Lenovo'
                ],
                [
                    'slug' => 'lenovo'
                ]
            );

            // Obtener categorías Notebook y Notebook mini
            $notebookCategory = Category::firstOrCreate(
                ['slug' => 'notebook'],
                ['name' => 'Notebook', 'parent_id' => null]
            );

            $notebookMiniCategory = Category::firstOrCreate(
                ['slug' => 'notebook-mini'],
                ['name' => 'Notebook mini', 'parent_id' => $notebookCategory->id]
            );

            $categoryIds = [$notebookCategory->id, $notebookMiniCategory->id];

            // Datos base del producto original
            $baseProduct = [
                'branch_id' => $branch->id,
                'brand_id' => $brand->id,
                'name' => 'Lenovo thinkpad x390 Grado B',
                'product_type' => 'notebook',
                'warranty_months' => 6,
                'serial_tracking' => false,
                'short_description' => 'prueba',
                'long_description' => 'prueba',
                'snippet_description' => 'prueba',
                'cost' => '69990.00',
                'price' => '329990.00',
                'offer_price' => null,
                'product_status' => null,
                'is_active' => true,
                'attributes_json' => [
                    'os' => [
                        'name' => 'Windows',
                        'version' => '11 Home'
                    ],
                    'CPU' => 'I7 8350U',
                    'RAM' => '16 GB',
                    'cpu' => [
                        'brand' => 'Intel',
                        'model' => 'I7 14700',
                        'family' => 'Celeron',
                        'generation' => '13th Gen'
                    ],
                    'gpu' => [
                        'type' => 'integrated',
                        'model' => 'integrada intel'
                    ],
                    'ram' => [
                        'type' => 'DDR4',
                        'channel' => 'dual',
                        'modules' => 2,
                        'upgradable' => true,
                        'capacity_gb' => 8,
                        'max_supported_gb' => 32
                    ],
                    'grade' => 'B',
                    'display' => [
                        'panel' => 'IPS',
                        'touch' => true,
                        'resolution' => '1920x1080',
                        'size_inches' => 15.6
                    ],
                    'storage' => [
                        'config' => 'single',
                        'primary' => [
                            'type' => 'NVMe',
                            'capacity_gb' => 256
                        ],
                        'upgradable' => true,
                        'available_slots' => [
                            'm2' => 1,
                            'sata' => 0
                        ],
                        'max_supported_gb' => 2000
                    ],
                    'packaging' => [
                        'charger_type' => 'original',
                        'charger_included' => true
                    ],
                    'connectivity' => [
                        'wifi' => '802.11ax',
                        'ethernet' => '1GbE',
                        'bluetooth' => '5.0'
                    ],
                    'product_kind' => 'notebook',
                    'category_grade' => 'A'
                ]
            ];

            $createdCount = 0;
            $progressBar = $out ? $out->createProgressBar(60) : null;

            if ($progressBar) {
                $progressBar->setFormat(' %current%/%max% [%bar%] %percent:3s%% - Creando productos...');
                $progressBar->start();
            }

            // Crear 60 productos con variaciones
            for ($i = 1; $i <= 60; $i++) {
                // SKU aleatorio único
                $sku = 'X390-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
                
                // Stock aleatorio entre 1 y 50
                $stock = rand(1, 50);

                // Crear el producto
                $product = Product::create(array_merge($baseProduct, [
                    'sku' => $sku,
                    'stock' => $stock,
                ]));

                // Asignar ambas categorías al producto
                $product->categories()->sync([
                    $notebookCategory->id => ['assigned_at' => now()],
                    $notebookMiniCategory->id => ['assigned_at' => now()],
                ]);

                $createdCount++;

                if ($progressBar) {
                    $progressBar->advance();
                }
            }

            if ($progressBar) {
                $progressBar->finish();
                $out->writeln('');
            }

            // Resumen final
            if ($out) {
                $out->writeln('');
                $out->writeln('✅ Seeder de productos de prueba completado:');
                $out->writeln('  - Branch: <info>'.$branch->branch_name.'</info> (ID: '.$branch->id.')');
                $out->writeln('  - Marca: <info>Lenovo</info> (ID: '.$brand->id.')');
                $out->writeln('  - Categorías asignadas: <info>Notebook</info> y <info>Notebook mini</info>');
                $out->writeln('  - Productos creados: <info>'.$createdCount.'</info>');
                $out->writeln('  - SKUs generados: <comment>Aleatorios (X390-XXXXXXXX)</comment>');
                $out->writeln('  - Stock por producto: <comment>Aleatorio entre 1 y 50</comment>');
                $out->writeln('');
            }
        });
    }
}
