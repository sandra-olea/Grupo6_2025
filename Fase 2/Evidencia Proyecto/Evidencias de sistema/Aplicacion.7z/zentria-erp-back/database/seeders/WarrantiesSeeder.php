<?php

namespace Database\Seeders;

use App\Models\CustomerSale;
use App\Models\Product;
use App\Models\Sale;
use App\Models\Subsidiary;
use App\Models\Warranty;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class WarrantiesSeeder extends Seeder
{
    public function run(): void
    {
        $this->command?->info('Sembrando garantías de demostración (basadas en ventas)...');

        $sales = Sale::with(['items.product'])
            ->orderByDesc('id')
            ->limit(20)
            ->get();

        $created = 0; $updated = 0; $rows = [];

        if ($sales->isEmpty()) {
            // Fallback: crear 3 garantías simples por primera subsidiary/cliente
            $subsidiary = Subsidiary::query()->first();
            $customer = $subsidiary ? CustomerSale::where('subsidiary_id', $subsidiary->id)->first() : null;
            $product = $subsidiary ? Product::whereHas('branch', fn($q) => $q->where('subsidiary_id', $subsidiary->id))->first() : null;

            if (!$subsidiary || !$customer) {
                $this->command?->warn('No hay ventas ni base mínima (subsidiaria/cliente). Omitiendo garantías.');
                return;
            }

            for ($i=0; $i<3; $i++) {
                $start = Carbon::now()->subDays(10 - $i);
                $months = (int) ($product?->warranty_months ?? 12);
                $end = (clone $start)->addMonths($months);

                $model = Warranty::firstOrNew([
                    'subsidiary_id' => $subsidiary->id,
                    'sale_id' => null,
                    'customer_id' => $customer->id,
                    'product_id' => $product?->id,
                    'start_date' => $start->toDateString(),
                ]);
                $isNew = !$model->exists;
                $model->fill([
                    'end_date' => $end->toDateString(),
                    'status' => $end->isPast() ? 'Expirada' : 'Activa',
                    'notes' => 'Garantía de demostración (sin venta asociada).',
                ]);
                $model->save();
                $isNew ? $created++ : $updated++;
                $rows[] = sprintf(' - Subsidiaria:%d | Cliente:%d | %s → %s%s',
                    $subsidiary->id, $customer->id, $start->toDateString(), $end->toDateString(), $isNew ? ' [CREADA]' : ' [ACTUALIZADA]');
            }
        } else {
            foreach ($sales as $sale) {
                $item = $sale->items->first();
                $product = $item?->product; // puede ser null
                $months = (int) ($product?->warranty_months ?? 12);
                $start = Carbon::parse($sale->sale_date ?? $sale->created_at ?? Carbon::now());
                $end = (clone $start)->addMonths($months);

                // Una garantía por venta (demo)
                $model = Warranty::firstOrNew([
                    'subsidiary_id' => $sale->subsidiary_id,
                    'sale_id' => $sale->id,
                ]);
                $isNew = !$model->exists;
                $model->fill([
                    'customer_id' => $sale->customer_id,
                    'product_id' => $product?->id,
                    'start_date' => $start->toDateString(),
                    'end_date' => $end->toDateString(),
                    'status' => $end->isPast() ? 'Expirada' : 'Activa',
                    'notes' => 'Garantía generada desde venta (seeder).',
                ]);
                $model->save();
                $isNew ? $created++ : $updated++;
                $rows[] = sprintf(' - Venta:%d | Cliente:%d | %s → %s%s',
                    $sale->id, $sale->customer_id, $start->toDateString(), $end->toDateString(), $isNew ? ' [CREADA]' : ' [ACTUALIZADA]');
            }
        }

        foreach ($rows as $line) { $this->command?->info($line); }
        $this->command?->info(sprintf('Garantías → creadas: %d, actualizadas: %d', $created, $updated));
    }
}

