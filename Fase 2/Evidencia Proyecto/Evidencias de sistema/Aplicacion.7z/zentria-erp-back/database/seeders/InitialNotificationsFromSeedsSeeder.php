<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Company;
use App\Models\Subsidiary;
use App\Models\Branch;
use App\Models\Brand;
use App\Models\Product;
use App\Models\Category;
use App\Models\Supplier;
use App\Models\CustomerSupplier;
use App\Models\Warehouse;
use App\Models\TechnicalReviewBatch;
use App\Models\TechnicalReviewItem;
use App\Models\User;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\NotificationEvent;
use App\Services\Notifications\NotificationRouter;

class InitialNotificationsFromSeedsSeeder extends Seeder
{
    public function run(): void
    {
        $out = $this->command?->getOutput();
        $created = [
            'company' => 0,
            'subsidiary' => 0,
            'branch' => 0,
            'brand' => 0,
            'product' => 0,
            'category' => 0,
            'supplier' => 0,
            'customer_supplier' => 0,
            'warehouse' => 0,
            'technical_review_batch' => 0,
            'technical_review_item' => 0,
        ];

        // Cargar tipos
        $types = NotificationType::all()->keyBy('key');
        $router = app(NotificationRouter::class);

        DB::transaction(function () use (&$created, $types, $router) {
            // Autor por defecto para eventos generados por seed
            $author = User::role('super-admin')->first() ?: User::first();
            $authorName = $author ? (trim(($author->first_name ?? '').' '.($author->last_name ?? '')) ?: ($author->email ?? 'Sistema')) : 'Sistema';
            $authorId = $author->id ?? null;
            // Company
            foreach (Company::all() as $c) {
                $key = 'company.updated';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$c->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'company',
                        'entity_id' => $c->id,
                        'company_id' => $c->id,
                        'subsidiary_id' => null,
                        'branch_id' => null,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'company_name' => $c->company_name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['company']++;
                }
            }

            // Subsidiaries
            foreach (Subsidiary::all() as $s) {
                $key = 'subsidiary.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$s->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'subsidiary',
                        'entity_id' => $s->id,
                        'company_id' => $s->company_id,
                        'subsidiary_id' => $s->id,
                        'branch_id' => null,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'subsidiary_name' => $s->subsidiary_name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['subsidiary']++;
                }
            }

            // Branches
            foreach (Branch::all() as $b) {
                $key = 'branch.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$b->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'branch',
                        'entity_id' => $b->id,
                        'company_id' => optional($b->subsidiary)->company_id,
                        'subsidiary_id' => $b->subsidiary_id,
                        'branch_id' => $b->id,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'branch_name' => $b->branch_name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['branch']++;
                }
            }

            // Brands
            foreach (Brand::all() as $br) {
                $key = 'brand.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$br->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $subsidiaryId = optional($br->branch)->subsidiary_id;
                    $companyId = optional(optional($br->branch)->subsidiary)->company_id;
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'brand',
                        'entity_id' => $br->id,
                        'company_id' => $companyId,
                        'subsidiary_id' => $subsidiaryId,
                        'branch_id' => $br->branch_id,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'brand_name' => $br->name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['brand']++;
                }
            }

            // Products
            foreach (Product::all() as $p) {
                $key = 'product.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$p->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $subsidiaryId = optional($p->branch)->subsidiary_id;
                    $companyId = optional(optional($p->branch)->subsidiary)->company_id;
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'product',
                        'entity_id' => $p->id,
                        'company_id' => $companyId,
                        'subsidiary_id' => $subsidiaryId,
                        'branch_id' => $p->branch_id,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'product_name' => $p->name,
                            'sku' => $p->sku,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['product']++;
                }
            }

            // Categories (sin scope propio: se asocian a la primera empresa si existe)
            $company = Company::first();
            foreach (Category::all() as $cat) {
                $key = 'category.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$cat->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'category',
                        'entity_id' => $cat->id,
                        'company_id' => $company?->id,
                        'subsidiary_id' => null,
                        'branch_id' => null,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'category_name' => $cat->name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['category']++;
                }
            }

            // Suppliers
            foreach (Supplier::with('subsidiary')->get() as $sup) {
                $key = 'supplier.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$sup->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'supplier',
                        'entity_id' => $sup->id,
                        'company_id' => optional($sup->subsidiary)->company_id,
                        'subsidiary_id' => $sup->subsidiary_id,
                        'branch_id' => null,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'supplier_name' => $sup->name,
                            'subsidiary_name' => optional($sup->subsidiary)->subsidiary_name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['supplier']++;
                }
            }

            // Customer Suppliers
            foreach (CustomerSupplier::with('subsidiary')->get() as $cs) {
                $key = 'customer-supplier.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$cs->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'customer_supplier',
                        'entity_id' => $cs->id,
                        'company_id' => optional($cs->subsidiary)->company_id,
                        'subsidiary_id' => $cs->subsidiary_id,
                        'branch_id' => null,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'customer_supplier_name' => $cs->name,
                            'subsidiary_name' => optional($cs->subsidiary)->subsidiary_name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => now(),
                    ]);
                    $router->route($ev);
                    $created['customer_supplier']++;
                }
            }

            // Warehouses
            foreach (Warehouse::with('branch.subsidiary.company')->get() as $wh) {
                $key = 'warehouse.created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$wh->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'warehouse',
                        'entity_id' => $wh->id,
                        'company_id' => optional($wh->branch->subsidiary)->company_id,
                        'subsidiary_id' => optional($wh->branch)->subsidiary_id,
                        'branch_id' => $wh->branch_id,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'warehouse_id' => $wh->id,
                            'warehouse_name' => $wh->name,
                            'warehouse_code' => $wh->code,
                            'branch_name' => optional($wh->branch)->branch_name ?? 'Sin sucursal',
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => $wh->created_at ?? now(),
                    ]);
                    $router->route($ev);
                    $created['warehouse']++;
                }
            }

            // Technical Review Batches
            foreach (TechnicalReviewBatch::with(['branch', 'warehouse'])->get() as $batch) {
                $key = 'technical-review.batch-created';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$batch->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'technical_review_batch',
                        'entity_id' => $batch->id,
                        'company_id' => optional($batch->branch)->company_id,
                        'subsidiary_id' => optional($batch->branch)->subsidiary_id,
                        'branch_id' => $batch->branch_id,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'batch_code' => $batch->code,
                            'expected_quantity' => $batch->expected_quantity,
                            'branch_name' => optional($batch->branch)->name,
                            'warehouse_name' => optional($batch->warehouse)->name,
                            'created_by' => $authorName,
                            'created_by_id' => $authorId,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => $batch->created_at ?? now(),
                    ]);
                    $router->route($ev);
                    $created['technical_review_batch']++;
                }
            }

            // Technical Review Items (solo aprobados y disponibles)
            foreach (TechnicalReviewItem::with(['batch.branch', 'traceability'])->whereNotNull('approved_at')->get() as $item) {
                $key = 'technical-review.item-approved';
                if (!isset($types[$key])) { continue; }
                $dedup = $key.':'.$item->id;
                if (! NotificationEvent::where('dedup_key', $dedup)->exists()) {
                    $ev = NotificationEvent::create([
                        'type_id' => $types[$key]->id,
                        'entity_type' => 'technical_review_item',
                        'entity_id' => $item->id,
                        'company_id' => optional($item->batch->branch)->company_id,
                        'subsidiary_id' => optional($item->batch->branch)->subsidiary_id,
                        'branch_id' => $item->batch->branch_id,
                        'priority' => $types[$key]->default_priority,
                        'payload' => [
                            'serial_number' => $item->serial_number,
                            'equipment_type' => $item->equipment_type->value,
                            'grade' => $item->grade?->value ?? $item->suggested_grade,
                            'batch_code' => $item->batch->code,
                            'approved_by' => $authorName,
                            'approved_by_id' => $item->approved_by,
                        ],
                        'dedup_key' => $dedup,
                        'occurred_at' => $item->approved_at ?? now(),
                    ]);
                    $router->route($ev);
                    $created['technical_review_item']++;
                }
            }
        });

        if ($out) {
            $out->writeln('');
            $out->writeln('✔ Notificaciones iniciales desde seeds:');
            $out->writeln(sprintf('  - Company:          <info>%d</info>', $created['company']));
            $out->writeln(sprintf('  - Subsidiary:       <info>%d</info>', $created['subsidiary']));
            $out->writeln(sprintf('  - Branch:           <info>%d</info>', $created['branch']));
            $out->writeln(sprintf('  - Brand:            <info>%d</info>', $created['brand']));
            $out->writeln(sprintf('  - Product:          <info>%d</info>', $created['product']));
            $out->writeln(sprintf('  - Category:         <info>%d</info>', $created['category']));
            $out->writeln(sprintf('  - Supplier:         <info>%d</info>', $created['supplier']));
            $out->writeln(sprintf('  - Customer Supplier: <info>%d</info>', $created['customer_supplier']));
            $out->writeln(sprintf('  - Warehouse:        <info>%d</info>', $created['warehouse']));
            $out->writeln(sprintf('  - Technical Review Batch: <info>%d</info>', $created['technical_review_batch']));
            $out->writeln(sprintf('  - Technical Review Item: <info>%d</info>', $created['technical_review_item']));
            $out->writeln('');
        }
    }
}
