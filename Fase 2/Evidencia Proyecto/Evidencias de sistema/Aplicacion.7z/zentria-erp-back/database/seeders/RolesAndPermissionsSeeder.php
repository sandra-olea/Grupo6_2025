<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run()
    {
        // Reset cache de Spatie (antes y después por seguridad)
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // ===== 1) Cargar permisos desde config (asi evitamos duplicados) =====
        $groups = config('permission_groups', []);
        if (!is_array($groups) || empty($groups)) {
            $this->command->error('permission_groups.php vacío o mal formateado.');
            return;
        }

        // Reunir todos los permisos uinicos de todos los grupos
        $allPermissions = collect($groups)->flatten()->unique()->values()->toArray();

        foreach ($allPermissions as $perm) {
            // Garantiza que TODOS los permisos existen en guard 'api'
            Permission::firstOrCreate(
                ['name' => $perm, 'guard_name' => 'api']
            );
        }

        // Helper para leer los gruposdd
        $G = fn(string $group) => $groups[$group] ?? [];

        // ===== 2) Como declarar ROLES =====
        // Sintaxis de cada item:
        //  - '*'                      => todos los permisos
        //  - '@grupo'                 => todo el grupo del configuracion
        //  - ['grupo' => ['perm1']]   => subset del grupo
        //  - 'permiso-suelto'         => fueraa de grupos
        $ROLE_MATRIX = [
            // Super Admin: todos los permisos actuales y futuros (Gate::before ya lo otorga)
            'super-admin' => ['*'],

            // Admins contextuales existentes
            'admin' => [
                // Admin general (no super): acceso amplio de gestión
                '@dashboard', '@user', '@company', '@subsidiary', '@branch', '@payslip', '@report', '@product', '@category', '@brand', '@supplier', '@customer-sale', '@customer-supplier', '@warehouse', '@sale', '@quote', '@document', '@document-type', '@warranty', '@notification',
                'manage-invitations',
            ],

            // Admins contextuales existentes
            'company-admin' => [
                '@user', '@company', '@subsidiary', '@branch', '@payslip', '@report', '@product', '@category', '@brand', '@supplier', '@customer-sale', '@customer-supplier', '@warehouse', '@sale', '@quote', '@notification',
                'manage-roles', // extras fuera de grupos
            ],

            'subsidiary-admin' => [
                '@user', '@subsidiary', '@branch', '@payslip', '@report', '@product', '@category', '@brand', '@supplier', '@customer-sale', '@customer-supplier', '@warehouse', '@sale', '@quote', '@document', '@document-type', '@warranty', '@notification',
            ],

            'branch-admin' => [
                '@user', '@branch', '@payslip', '@report', '@product', '@category', '@brand', '@supplier', '@customer-sale', '@customer-supplier', '@warehouse', '@sale', '@quote', '@notification',
            ],

            'catalog-admin' => [
                '@product', '@category', '@brand', '@notification',
            ],

            'manager' => [
                ['user'    => ['view-user', 'edit-user']],
                ['branch'  => ['view-branch']],
                ['payslip' => ['view-payslips', 'edit-payslips']],
                ['report'  => ['view-reports']],
                '@notification',
            ],

            'employee' => [
                ['user'    => ['view-user']],
                ['branch'  => ['view-branch']],
                ['payslip' => ['view-payslips']],
                '@notification',
            ],

            'technician' => [
                ['user'    => ['view-user']],
                ['branch'  => ['view-branch']],
                ['payslip' => ['view-payslips']],
                '@technical-reviews-batches',
                '@technical-reviews-items',
                '@technical-reviews-reports',
                '@notification',
            ],

            'warehouse-employee' => [
                ['user'    => ['view-user']],
                ['branch'  => ['view-branch']],
                ['payslip' => ['view-payslips']],
                '@notification',
            ],

            // ===== Nuevos roles normalizados en inglés =====
            // Supervisor Empresa → lectura en toda la estructura + dashboards/reportes
            'company-supervisor' => [
                ['dashboard'  => ['view-dashboard']],
                ['user'       => ['view-user']],
                ['company'    => ['view-company']],
                ['subsidiary' => ['view-subsidiary']],
                ['branch'     => ['view-branch']],
                ['product'    => ['view-product']],
                ['category'   => ['view-category']],
                ['brand'      => ['view-brand']],
                ['report'     => ['view-reports','export-reports']],
                '@notification',
            ],

            // Warehouse Manager (encargado de bodega)
            'warehouse-manager' => [
                '@warehouse',
                '@product',
                ['category' => ['view-category']],
                ['brand'    => ['view-brand']],
                ['report'   => ['view-reports']],
                '@notification',
            ],

            // Salesperson (vendedor)
            'salesperson' => [
                ['product'  => ['view-product']],
                ['category' => ['view-category']],
                ['brand'    => ['view-brand']],
                ['report'   => ['view-reports']],
                '@sale',        // permisos de ventas (según permission_groups)
                '@quote',       // permisos de cotizaciones (view/create/edit/delete)
                '@notification',
            ],

            // After-sales (postventa)
            'after-sales' => [
                ['user'     => ['view-user']],
                ['product'  => ['view-product']],
                ['report'   => ['view-reports']],
                '@sale',
                '@quote',
                '@warranty',
                '@notification',
            ],

            // Cashier (cajero)
            'cashier' => [
                ['product'  => ['view-product']],
                ['category' => ['view-category']],
                ['brand'    => ['view-brand']],
                ['report'   => ['view-reports','export-reports']],
                '@sale',
                '@quote',
                '@notification',
            ],
        ];

        // Ordenar roles alfabéticamente por nombre (case-insensitive, natural)
        ksort($ROLE_MATRIX, SORT_NATURAL | SORT_FLAG_CASE);

        // ===== 3) Resolver matriz → lista final de permisos por rol =====
        $resolveSpec = function ($spec) use ($G, $groups, $allPermissions) {
            // '*' => todos
            if ($spec === '*') {
                return $allPermissions;
            }

            // '@grupo' => todo el grupo
            if (is_string($spec) && str_starts_with($spec, '@')) {
                $group = substr($spec, 1);
                if (!array_key_exists($group, $groups)) {
                    $this->command->warn("Grupo '@{$group}' no existe en permission_groups.php");
                    return [];
                }
                return $G($group);
            }

            // ['grupo' => ['perm1','perm2']]
            if (is_array($spec)) {
                $expanded = [];
                foreach ($spec as $group => $subset) {
                    if (!array_key_exists($group, $groups)) {
                        $this->command->warn("Grupo '{$group}' no existe en permission_groups.php");
                        continue;
                    }
                    // Filtrar solo los que existen dentro del grupo
                    $valid = array_values(array_intersect($G($group), (array) $subset));
                    $missing = array_diff((array) $subset, $valid);
                    if (!empty($missing)) {
                        $this->command->warn("Permisos no encontrados en grupo '{$group}': ".implode(', ', $missing));
                    }
                    $expanded = array_merge($expanded, $valid);
                }
                return $expanded;
            }

            // 'permiso-suelto'
            if (is_string($spec)) {
                if (!in_array($spec, $allPermissions, true)) {
                    $this->command->warn("Permiso suelto '{$spec}' no existe en permission_groups.php");
                    return [];
                }
                return [$spec];
            }

            // Desconocido
            $this->command->warn('Especificación de rol desconocida: '.json_encode($spec));
            return [];
        };

        $expandRole = function (array $roleSpec) use ($resolveSpec) {
            $perms = [];
            foreach ($roleSpec as $spec) {
                $perms = array_merge($perms, $resolveSpec($spec));
            }
            // unique y ordenado
            $perms = array_values(array_unique($perms));
            return $perms;
        };

        // ===== 4) Crear roles y sincronizar permisos (orden alfabético) =====
        foreach ($ROLE_MATRIX as $roleName => $roleSpec) {
            /** @var \Spatie\Permission\Models\Role $role */
            $role = Role::firstOrCreate(['name' => $roleName, 'guard_name' => 'api']);

            $permNames = is_array($roleSpec) ? $expandRole($roleSpec) : [];

            // Resolver a modelos Permission (solo guard api)
            $permModels = Permission::query()
                ->where('guard_name', 'api')
                ->whereIn('name', $permNames)
                ->get();

            // Loguear faltantes para depurar por si algún grupo no se resolvió
            $resolvedNames = $permModels->pluck('name')->all();
            $missing = array_values(array_diff($permNames, $resolvedNames));
            if (!empty($missing)) {
                $this->command->warn("Permisos no encontrados para rol {$roleName}: ".implode(', ', $missing));
            }

            $role->syncPermissions($permModels); // deja el rol exactamente con estos permisos

            $this->command->info(sprintf(
                "Rol %-20s → %d permisos",
                $roleName,
                $permModels->count()
            ));
        }

        // Limpiar cache nuevamente tras asignaciones
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        $this->command->info('✅ Roles y permisos creados/actualizados desde permission_groups.php');
    }
}
