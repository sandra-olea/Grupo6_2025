<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\TechnicalReviewScoringRule;

class TechnicalReviewScoringRulesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * Crea las reglas de puntuación automática para la calificación de equipos.
     * Estas reglas permiten calcular el grado (A/B/C/M) basándose en las condiciones del equipo.
     */
    public function run(): void
    {
        $this->command->info('🔄 Creando reglas de scoring para revisiones técnicas...');

        $rules = [
            // ==========================================
            // NOTEBOOKS - General Condition
            // ==========================================
            [
                'equipment_type' => 'notebook',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'like_new'],
                'points' => 10,
                'affects_grade' => 'A',
                'reasoning' => 'Estado general: Como nuevo (+10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'good_shape'],
                'points' => 5,
                'affects_grade' => 'A',
                'reasoning' => 'Estado general: Buen estado (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'visible_wear'],
                'points' => 2,
                'affects_grade' => 'B',
                'reasoning' => 'Estado general: Desgaste visible - Máximo B (+2 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'needs_repair'],
                'points' => -20,
                'affects_grade' => 'C',
                'reasoning' => 'Estado general: Necesita reparación - Máximo C (-20 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // NOTEBOOKS - Screen Condition
            // ==========================================
            [
                'equipment_type' => 'notebook',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'ok'],
                'points' => 15,
                'affects_grade' => 'A',
                'reasoning' => 'Pantalla sin observaciones (+15 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'minor_wear'],
                'points' => 10,
                'affects_grade' => 'A',
                'reasoning' => 'Pantalla con detalles leves - pequeños signos de uso o marcas por suciedad (+10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'worn'],
                'points' => 5,
                'affects_grade' => 'B',
                'reasoning' => 'Pantalla con líneas/desgaste visible/manchas blancas - Máximo B (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'scratched'],
                'points' => 2,
                'affects_grade' => 'B',
                'reasoning' => 'Pantalla rayada - Máximo B (+2 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'broken'],
                'points' => -50,
                'affects_grade' => 'M',
                'reasoning' => 'Pantalla rota/Píxeles muertos excesivos/Manchas excesivas - CRÍTICO - Máximo M (-50 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // NOTEBOOKS - Cover Condition (CUBIERTA/TAPA)
            // ==========================================
            [
                'equipment_type' => 'notebook',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'ok'],
                'points' => 10,
                'affects_grade' => 'A',
                'reasoning' => 'Cubierta sin daños (+10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'minor_wear'],
                'points' => 8,
                'affects_grade' => 'A',
                'reasoning' => 'Cubierta con daños leves - rayaduras no notorias, signos de uso (+8 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'worn'],
                'points' => 5,
                'affects_grade' => 'B',
                'reasoning' => 'Cubierta con desgaste visible y rayas - Máximo B (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'scratched'],
                'points' => 3,
                'affects_grade' => 'B',
                'reasoning' => 'Cubierta rayada - Máximo B (+3 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // NOTEBOOKS - Keyboard Condition
            // Máximo 1 tecla dañada o faltante para C, si excede -> M
            // ==========================================
            [
                'equipment_type' => 'notebook',
                'field_name' => 'keyboard_condition',
                'condition' => ['value' => 'ok'],
                'points' => 10,
                'affects_grade' => 'A',
                'reasoning' => 'Teclado en perfecto estado (+10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'keyboard_condition',
                'condition' => ['value' => 'worn'],
                'points' => 5,
                'affects_grade' => 'B',
                'reasoning' => 'Teclado con desgaste - Máximo B (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'keyboard_condition',
                'condition' => ['value' => 'missing_pieces'],
                'points' => -30,
                'affects_grade' => 'C',
                'reasoning' => 'Teclado con piezas faltantes (máximo 1 tecla) - Máximo C (-30 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'más de 1 tecla'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Teclado con más de 1 tecla dañada - CRÍTICO - Máximo M (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'múltiples teclas'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Teclado con múltiples teclas dañadas - CRÍTICO - Máximo M (-100 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // NOTEBOOKS - Hinge Condition
            // ==========================================
            [
                'equipment_type' => 'notebook',
                'field_name' => 'hinge_condition',
                'condition' => ['value' => 'ok'],
                'points' => 5,
                'affects_grade' => 'A',
                'reasoning' => 'Bisagras en buen estado (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'hinge_condition',
                'condition' => ['value' => 'worn'],
                'points' => 3,
                'affects_grade' => 'B',
                'reasoning' => 'Bisagras con desgaste - Máximo B (+3 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'hinge_condition',
                'condition' => ['value' => 'broken'],
                'points' => -25,
                'affects_grade' => 'B',
                'reasoning' => 'Bisagras rotas - Castigo fuerte - Máximo B (-25 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // NOTEBOOKS - Battery Status (AJUSTADO)
            // Batería >70% = puede ser A (si todo lo demás está perfecto)
            // Batería 60-70% = máximo A si estética perfecta, sino B
            // Batería <60% = automático B
            // Batería <50% = C
            // ==========================================
            [
                'equipment_type' => 'notebook',
                'field_name' => 'battery_status',
                'condition' => ['value' => 'excellent'],
                'points' => 10,
                'affects_grade' => 'A',
                'reasoning' => 'Batería excelente - >70% vida útil (+10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'battery_status',
                'condition' => ['value' => 'good'],
                'points' => 5,
                'affects_grade' => 'B',
                'reasoning' => 'Batería buena - 60-70% vida útil - Máximo B si hay desgastes (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'battery_status',
                'condition' => ['value' => 'fair'],
                'points' => -15,
                'affects_grade' => 'B',
                'reasoning' => 'Batería regular - <60% vida útil - Automático B (-15 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'battery_status',
                'condition' => ['value' => 'poor'],
                'points' => -30,
                'affects_grade' => 'C',
                'reasoning' => 'Batería en mal estado - <50% vida útil - Máximo C (-30 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'battery_status',
                'condition' => ['value' => 'no_battery'],
                'points' => -35,
                'affects_grade' => 'C',
                'reasoning' => 'Sin batería - Requiere uso con cargador - Máximo C (-35 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // NOTEBOOKS - Touchpad & Bottom
            // ==========================================
            [
                'equipment_type' => 'notebook',
                'field_name' => 'touchpad_condition',
                'condition' => ['value' => 'ok'],
                'points' => 5,
                'affects_grade' => 'A',
                'reasoning' => 'Touchpad funcional (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'touchpad_condition',
                'condition' => ['value' => 'broken'],
                'points' => -25,
                'affects_grade' => 'C',
                'reasoning' => 'Touchpad no funcional - Máximo C (-25 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'bottom_condition',
                'condition' => ['value' => 'ok'],
                'points' => 2,
                'affects_grade' => 'A',
                'reasoning' => 'Base en buen estado (+2 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'bottom_condition',
                'condition' => ['value' => 'worn'],
                'points' => 1,
                'affects_grade' => 'B',
                'reasoning' => 'Base con desgaste (+1 pt)',
                'is_active' => true,
            ],

            // ==========================================
            // NOTEBOOKS - CONDICIONES CRÍTICAS (EXTREMAS)
            // ==========================================
            // Equipo no prende - MÁXIMA PENALIZACIÓN
            [
                'equipment_type' => 'notebook',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'scrap'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'EQUIPO NO PRENDE - Malo no recuperable (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'no prende'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'EQUIPO NO PRENDE - Malo no recuperable (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'no enciende'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'EQUIPO NO ENCIENDE - Malo no recuperable (-100 pts)',
                'is_active' => true,
            ],
            
            // Puertos defectuosos
            // Si solo 1 puerto está dañado -> Máximo C
            // Si más de 1 puerto está dañado -> Automático M
            [
                'equipment_type' => 'notebook',
                'field_name' => 'defective_ports_count',
                'condition' => ['value' => 1],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Un puerto defectuoso - Máximo C (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'defective_ports_count',
                'condition' => ['min' => 2],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Más de un puerto defectuoso - CRÍTICO - Automático M (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'all_ports_functional',
                'condition' => ['value' => false],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Puertos defectuosos - CRÍTICO (-50 pts)',
                'is_active' => true,
            ],
            
            // Parlantes reventados - Bajan a C
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'parlantes reventados'],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Parlantes reventados - CRÍTICO (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'parlantes dañados'],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Parlantes dañados - CRÍTICO (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'sin audio'],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Sin audio - CRÍTICO (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'notebook',
                'field_name' => 'observations',
                'condition' => ['contains' => 'audio malo'],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Audio defectuoso - CRÍTICO (-50 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // DESKTOP - General Condition
            // Criterio: Desktop casi nunca es B, visible_wear o peor = C
            // ==========================================
            [
                'equipment_type' => 'desktop',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'like_new'],
                'points' => 20,
                'affects_grade' => 'A',
                'reasoning' => 'Estado general: Como nuevo (+20 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'good_shape'],
                'points' => 15,
                'affects_grade' => 'A',
                'reasoning' => 'Estado general: Buen estado (+15 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'visible_wear'],
                'points' => -10,
                'affects_grade' => 'C',
                'reasoning' => 'Estado general: Desgaste visible - Máximo C (-10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'needs_repair'],
                'points' => -30,
                'affects_grade' => 'C',
                'reasoning' => 'Estado general: Necesita reparación - Máximo C (-30 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'scrap'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Estado general: Chatarra - Malo no recuperable (-100 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // DESKTOP - Cover Condition (Cubierta/Carcasa)
            // Solo baja a C si le faltan piezas (gomitas, tapas) o está rota
            // ==========================================
            [
                'equipment_type' => 'desktop',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'ok'],
                'points' => 20,
                'affects_grade' => 'A',
                'reasoning' => 'Cubierta sin daños (+20 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'worn'],
                'points' => 10,
                'affects_grade' => 'A',
                'reasoning' => 'Cubierta con desgaste leve (+10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'scratched'],
                'points' => 5,
                'affects_grade' => 'A',
                'reasoning' => 'Cubierta rayada (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'missing_pieces'],
                'points' => -30,
                'affects_grade' => 'C',
                'reasoning' => 'Cubierta con piezas faltantes (gomitas, tapas) - Máximo C (-30 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'cover_condition',
                'condition' => ['value' => 'broken'],
                'points' => -50,
                'affects_grade' => 'M',
                'reasoning' => 'Cubierta rota/destruida - Malo (-50 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // DESKTOP - Puertos funcionales
            // ==========================================
            [
                'equipment_type' => 'desktop',
                'field_name' => 'all_ports_functional',
                'condition' => ['value' => true],
                'points' => 15,
                'affects_grade' => 'A',
                'reasoning' => 'Todos los puertos funcionales (+15 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'defective_ports_count',
                'condition' => ['value' => 1],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Un puerto defectuoso - Máximo C (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'defective_ports_count',
                'condition' => ['min' => 2],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Más de un puerto defectuoso - CRÍTICO - Automático M (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'all_ports_functional',
                'condition' => ['value' => false],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Puertos defectuosos - Máximo C (-50 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // DESKTOP - Condiciones críticas
            // ==========================================
            [
                'equipment_type' => 'desktop',
                'field_name' => 'observations',
                'condition' => ['contains' => 'no prende'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'EQUIPO NO PRENDE - Malo no recuperable (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'desktop',
                'field_name' => 'observations',
                'condition' => ['contains' => 'no enciende'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'EQUIPO NO ENCIENDE - Malo no recuperable (-100 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // DOCKING - Puertos defectuosos
            // ==========================================
            [
                'equipment_type' => 'docking',
                'field_name' => 'defective_ports_count',
                'condition' => ['value' => 1],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Un puerto defectuoso - Máximo C (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'docking',
                'field_name' => 'defective_ports_count',
                'condition' => ['min' => 2],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Más de un puerto defectuoso - CRÍTICO - Automático M (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'docking',
                'field_name' => 'all_ports_functional',
                'condition' => ['value' => false],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Puertos defectuosos - Máximo C (-50 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // AIO - Puertos defectuosos
            // ==========================================
            [
                'equipment_type' => 'aio',
                'field_name' => 'defective_ports_count',
                'condition' => ['value' => 1],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Un puerto defectuoso - Máximo C (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'aio',
                'field_name' => 'defective_ports_count',
                'condition' => ['min' => 2],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Más de un puerto defectuoso - CRÍTICO - Automático M (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'aio',
                'field_name' => 'all_ports_functional',
                'condition' => ['value' => false],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Puertos defectuosos - Máximo C (-50 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // MONITOR - Condición de pantalla
            // ==========================================
            [
                'equipment_type' => 'monitor',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'ok'],
                'points' => 10,
                'affects_grade' => 'A',
                'reasoning' => 'Pantalla sin observaciones (+10 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'dead_pixels'],
                'points' => -20,
                'affects_grade' => 'B',
                'reasoning' => 'Pantalla con pocos píxeles muertos - Máximo B (-20 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'worn'],
                'points' => -15,
                'affects_grade' => 'B',
                'reasoning' => 'Pantalla con micro rayas/rayones leves - Máximo B (-15 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'screen_condition',
                'condition' => ['value' => 'broken'],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Pantalla rota - CRÍTICO - Automático M (-100 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // MONITOR - Puertos defectuosos
            // ==========================================
            [
                'equipment_type' => 'monitor',
                'field_name' => 'defective_ports_count',
                'condition' => ['value' => 1],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Un puerto defectuoso - Máximo C (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'defective_ports_count',
                'condition' => ['min' => 2],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Más de un puerto defectuoso - CRÍTICO - Automático M (-100 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'all_ports_functional',
                'condition' => ['value' => false],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Puertos defectuosos - Máximo C (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'defective_ports_critical_count',
                'condition' => ['value' => 1],
                'points' => -50,
                'affects_grade' => 'C',
                'reasoning' => 'Un puerto crítico defectuoso - Máximo C (-50 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'defective_ports_critical_count',
                'condition' => ['min' => 2],
                'points' => -100,
                'affects_grade' => 'M',
                'reasoning' => 'Múltiples puertos críticos defectuosos - CRÍTICO - Automático M (-100 pts)',
                'is_active' => true,
            ],

            // ==========================================
            // MONITOR - Condición general y físico (positivos)
            // ==========================================
            [
                'equipment_type' => 'monitor',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'like_new'],
                'points' => 40,
                'affects_grade' => 'A',
                'reasoning' => 'Estado general como nuevo (+40 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'general_condition',
                'condition' => ['value' => 'good_shape'],
                'points' => 25,
                'affects_grade' => 'A',
                'reasoning' => 'Estado general en buen estado (+25 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'frame_condition',
                'condition' => ['value' => 'ok'],
                'points' => 5,
                'affects_grade' => 'A',
                'reasoning' => 'Marco/base sin daños (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'frame_condition',
                'condition' => ['in' => ['worn', 'scratched']],
                'points' => 2,
                'affects_grade' => 'A',
                'reasoning' => 'Marco/base con desgaste leve o micro rayas (+2 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'stand_condition',
                'condition' => ['value' => 'ok'],
                'points' => 5,
                'affects_grade' => 'A',
                'reasoning' => 'Soporte en buen estado (+5 pts)',
                'is_active' => true,
            ],
            [
                'equipment_type' => 'monitor',
                'field_name' => 'stand_condition',
                'condition' => ['value' => 'worn'],
                'points' => 2,
                'affects_grade' => 'A',
                'reasoning' => 'Soporte con desgaste leve (+2 pts)',
                'is_active' => true,
            ],
        ];

        foreach ($rules as $rule) {
            TechnicalReviewScoringRule::create($rule);
        }

        $this->command->info("✅ Reglas de scoring: " . count($rules) . " creadas");
        $this->command->info('   ℹ️  Las reglas permiten scoring automático de equipos');
    }
}
