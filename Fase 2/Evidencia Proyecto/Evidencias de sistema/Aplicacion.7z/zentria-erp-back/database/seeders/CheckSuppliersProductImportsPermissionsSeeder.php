<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

/**
 * Verifica y crea los permisos necesarios para suppliers y product imports
 * que ya están definidos en permission_groups.php
 */
class CheckSuppliersProductImportsPermissionsSeeder extends Seeder
{
    public function run()
    {
        // Reset cache de Spatie
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        $this->command->info('🔍 Verificando permisos de Suppliers y Product Imports...');

        // Los permisos ya deberían estar definidos en permission_groups.php
        $groups = config('permission_groups', []);

        // Permisos esperados (ya están en permission_groups.php)
        $expectedPermissions = [
            // Suppliers
            'view-supplier',
            'create-supplier',
            'edit-supplier',
            'delete-supplier',
            'manage-supplier-customers',
            
            // Customer Suppliers
            'view-customer-supplier',
            'create-customer-supplier',
            'edit-customer-supplier',
            'delete-customer-supplier',
            'manage-customer-suppliers',
            
            // Products (para imports)
            'view-product',
            'create-product',
            'edit-product',
            'delete-product',
        ];

        $created = 0;
        $existing = 0;

        foreach ($expectedPermissions as $permName) {
            $permission = Permission::firstOrCreate([
                'name' => $permName,
                'guard_name' => 'api',
            ]);

            if ($permission->wasRecentlyCreated) {
                $this->command->info("  ✅ Creado: {$permName}");
                $created++;
            } else {
                $this->command->line("  ℹ️  Existe: {$permName}");
                $existing++;
            }
        }

        $this->command->newLine();
        $this->command->info("📊 Resumen:");
        $this->command->info("   • Permisos creados: {$created}");
        $this->command->info("   • Permisos existentes: {$existing}");
        $this->command->info("   • Total verificados: " . count($expectedPermissions));

        // Verificar que estén en permission_groups.php
        $this->command->newLine();
        $this->command->info('🔍 Verificando permission_groups.php...');
        
        $supplierGroup = $groups['supplier'] ?? [];
        $customerSupplierGroup = $groups['customer-supplier'] ?? [];
        $productGroup = $groups['product'] ?? [];

        $missingInConfig = [];
        
        foreach ($expectedPermissions as $perm) {
            $found = in_array($perm, $supplierGroup) 
                || in_array($perm, $customerSupplierGroup) 
                || in_array($perm, $productGroup);
            
            if (!$found) {
                $missingInConfig[] = $perm;
            }
        }

        if (empty($missingInConfig)) {
            $this->command->info('  ✅ Todos los permisos están en permission_groups.php');
        } else {
            $this->command->warn('  ⚠️  Permisos faltantes en permission_groups.php:');
            foreach ($missingInConfig as $missing) {
                $this->command->warn("     - {$missing}");
            }
        }

        $this->command->newLine();
        $this->command->info('✅ Verificación completada');
    }
}
