<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\ScopeRole;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class FixContextRolesToSpatieSeeder extends Seeder
{
    public function run(): void
    {
        app()->make(PermissionRegistrar::class)->forgetCachedPermissions();

        $this->command?->info('🔧 Sincronizando roles contextuales a roles Spatie (guard api)');

        // Recolectar roles distintos usados en scope_roles
        $roleIds = ScopeRole::query()->distinct()->pluck('role_id');
        $roles = Role::whereIn('id', $roleIds)->get(['id','name','guard_name']);
        $countAssigned = 0;

        ScopeRole::query()
            ->select(['user_id','role_id'])
            ->orderBy('user_id')
            ->chunk(500, function ($rows) use ($roles, &$countAssigned) {
                foreach ($rows as $row) {
                    $r = $roles->firstWhere('id', $row->role_id);
                    if (!$r) continue;
                    $user = User::find($row->user_id);
                    if (!$user) continue;
                    if (!$user->hasRole($r->name)) {
                        $user->assignRole($r->name);
                        $countAssigned++;
                    }
                }
            });

        app()->make(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->command?->info("✅ Roles asignados/asegurados: {$countAssigned}");
    }
}

