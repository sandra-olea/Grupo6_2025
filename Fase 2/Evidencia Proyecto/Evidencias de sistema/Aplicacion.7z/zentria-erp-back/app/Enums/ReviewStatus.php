<?php

namespace App\Enums;

enum ReviewStatus: string
{
    case PENDING = 'pending';
    case IN_REVIEW = 'in_review';
    case REVIEWED = 'reviewed';
    case APPROVED = 'approved';

    public function label(): string
    {
        return match($this) {
            self::PENDING => 'Pendiente',
            self::IN_REVIEW => 'En Revisión',
            self::REVIEWED => 'Revisado',
            self::APPROVED => 'Aprobado',
        };
    }
}
