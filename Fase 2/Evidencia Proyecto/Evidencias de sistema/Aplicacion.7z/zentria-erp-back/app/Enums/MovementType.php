<?php

namespace App\Enums;

enum MovementType: string
{
    case ENTRY = 'entry';
    case STATUS_CHANGE = 'status_change';
    case WAREHOUSE_TRANSFER = 'warehouse_transfer';
    case RESERVATION = 'reservation';
    case SALE = 'sale';
    case RETURN = 'return';
    case ADJUSTMENT = 'adjustment';

    public function label(): string
    {
        return match($this) {
            self::ENTRY => 'Ingreso',
            self::STATUS_CHANGE => 'Cambio de Estado',
            self::WAREHOUSE_TRANSFER => 'Transferencia de Bodega',
            self::RESERVATION => 'Reserva',
            self::SALE => 'Venta',
            self::RETURN => 'Devolución',
            self::ADJUSTMENT => 'Ajuste de Inventario',
        };
    }
}
