<?php

namespace App\Enums;

enum EquipmentStatus: string
{
    case UNKNOWN = 'unknown';
    case RECEIVED = 'received';
    case IN_REVIEW = 'in_review';
    case REVIEWED = 'reviewed';
    case AVAILABLE_FOR_SALE = 'available_for_sale';
    case IN_QUOTATION = 'in_quotation';
    case RESERVED = 'reserved';
    case SOLD = 'sold';
    case RETURNED = 'returned';
    case SCRAPPED = 'scrapped';

    public function label(): string
    {
        return match($this) {
            self::UNKNOWN => 'Desconocido',
            self::RECEIVED => 'Ingresado',
            self::IN_REVIEW => 'En Revisión',
            self::REVIEWED => 'Revisado',
            self::AVAILABLE_FOR_SALE => 'Disponible para Venta',
            self::IN_QUOTATION => 'En Cotización',
            self::RESERVED => 'Reservado',
            self::SOLD => 'Vendido',
            self::RETURNED => 'Devuelto',
            self::SCRAPPED => 'Dado de Baja',
        };
    }

    public function color(): string
    {
        return match($this) {
            self::UNKNOWN => 'gray',
            self::RECEIVED => 'gray',
            self::IN_REVIEW => 'blue',
            self::REVIEWED => 'green',
            self::AVAILABLE_FOR_SALE => 'cyan',
            self::IN_QUOTATION => 'yellow',
            self::RESERVED => 'orange',
            self::SOLD => 'purple',
            self::RETURNED => 'red',
            self::SCRAPPED => 'black',
        };
    }

    /**
     * Estados válidos para transición
     */
    public function canTransitionTo(self $newStatus): bool
    {
        return match($this) {
            self::UNKNOWN => in_array($newStatus, [
                self::RECEIVED,
                self::IN_REVIEW,
                self::REVIEWED,
                self::AVAILABLE_FOR_SALE,
                self::IN_QUOTATION,
                self::RESERVED,
                self::SOLD,
                self::RETURNED,
                self::SCRAPPED,
            ]),
            self::RECEIVED => in_array($newStatus, [
                self::IN_REVIEW,
                self::SCRAPPED,
            ]),
            self::IN_REVIEW => in_array($newStatus, [
                self::REVIEWED,
                self::AVAILABLE_FOR_SALE,
                self::IN_QUOTATION,
                self::RESERVED,
                self::SCRAPPED,
            ]),
            self::REVIEWED => in_array($newStatus, [
                self::IN_REVIEW,
                self::AVAILABLE_FOR_SALE,
                self::SCRAPPED,
            ]),
            self::AVAILABLE_FOR_SALE => in_array($newStatus, [
                self::IN_REVIEW,
                self::IN_QUOTATION,
                self::RESERVED,
                self::SOLD,
            ]),
            self::IN_QUOTATION => in_array($newStatus, [
                self::IN_REVIEW,
                self::AVAILABLE_FOR_SALE,
                self::RESERVED,
                self::SOLD,
            ]),
            self::RESERVED => in_array($newStatus, [
                self::IN_REVIEW,
                self::AVAILABLE_FOR_SALE,
                self::SOLD,
            ]),
            self::SOLD => in_array($newStatus, [
                self::RETURNED,
            ]),
            self::RETURNED => in_array($newStatus, [
                self::IN_REVIEW,
                self::AVAILABLE_FOR_SALE,
            ]),
            self::SCRAPPED => false, // Estado final
        };
    }
}
