<?php

namespace App\Enums;

enum BatteryCondition: string
{
    case EXCELLENT = 'excellent';
    case GOOD = 'good';
    case FAIR = 'fair';
    case REGULAR = 'regular';
    case POOR = 'poor';
    case BAD = 'bad';
    case NO_BATTERY = 'no_battery';

    public function label(): string
    {
        return match ($this) {
            self::EXCELLENT => 'Excelente',
            self::GOOD => 'Bueno',
            self::FAIR => 'Aceptable',
            self::REGULAR => 'Regular',
            self::POOR => 'Pobre',
            self::BAD => 'Malo',
            self::NO_BATTERY => 'Sin batería',
        };
    }
}
