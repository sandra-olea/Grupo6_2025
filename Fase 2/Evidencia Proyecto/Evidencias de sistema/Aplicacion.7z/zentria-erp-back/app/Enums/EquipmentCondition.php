<?php

namespace App\Enums;

enum EquipmentCondition: string
{
    case LIKE_NEW = 'like_new';
    case GOOD_SHAPE = 'good_shape';
    case VISIBLE_WEAR = 'visible_wear';
    case NEEDS_REPAIR = 'needs_repair';
    case SCRAP = 'scrap';
    case OK = 'ok';
    case WORN = 'worn';
    case MISSING_PIECES = 'missing_pieces';
    case BROKEN = 'broken';
    case SCRATCHED = 'scratched';
    case NO_BATTERY = 'no_battery';
    case NO_STAND = 'no_stand';
    case DEAD_PIXELS = 'dead_pixels';

    public function label(): string
    {
        return match($this) {
            self::LIKE_NEW => 'Como nuevo',
            self::GOOD_SHAPE => 'Buen estado',
            self::VISIBLE_WEAR => 'Desgaste visible',
            self::NEEDS_REPAIR => 'Requiere reparación',
            self::SCRAP => 'Solo repuestos',
            self::OK => 'Funciona sin problemas',
            self::WORN => 'Desgastado',
            self::MISSING_PIECES => 'Faltan piezas',
            self::BROKEN => 'No funciona',
            self::SCRATCHED => 'Rallado',
            self::NO_BATTERY => 'Sin Batería',
            self::NO_STAND => 'Sin Base',
            self::DEAD_PIXELS => 'Píxeles Muertos',
        };
    }

    public function points(int $maxPoints): int
    {
        return match($this) {
            self::LIKE_NEW, self::OK => $maxPoints,
            self::GOOD_SHAPE => (int)($maxPoints * 0.8),
            self::VISIBLE_WEAR, self::WORN => (int)($maxPoints * 0.5),
            self::NEEDS_REPAIR, self::MISSING_PIECES, self::SCRATCHED => (int)($maxPoints * 0.25),
            self::SCRAP, self::BROKEN, self::NO_BATTERY, self::NO_STAND, self::DEAD_PIXELS => 0,
        };
    }
}
