<?php

namespace App\Enums;

enum EquipmentType: string
{
    case NOTEBOOK = 'notebook';
    case DESKTOP = 'desktop';
    case DOCKING = 'docking';
    case AIO = 'aio';
    case MONITOR = 'monitor';

    public function label(): string
    {
        return match($this) {
            self::NOTEBOOK => 'Notebook',
            self::DESKTOP => 'Desktop',
            self::DOCKING => 'Docking Station',
            self::AIO => 'All-in-One',
            self::MONITOR => 'Monitor',
        };
    }

    public function hasBattery(): bool
    {
        return match($this) {
            self::NOTEBOOK => true,
            default => false,
        };
    }
}
