<?php

namespace App\Enums;

enum EquipmentGrade: string
{
    case A = 'A';
    case B = 'B';
    case C = 'C';
    case M = 'M';

    public function label(): string
    {
        return match($this) {
            self::A => 'Categoría A - Excelente Estado',
            self::B => 'Categoría B - Buen Estado',
            self::C => 'Categoría C - Estado Aceptable',
            self::M => 'Categoría M - Malo',
        };
    }

    public function description(): string
    {
        return match($this) {
            self::A => '100% funcional, sin fallas o con detalles mínimos. Batería >50%. Estado estético 70%-100%.',
            self::B => '100% funcional, con detalles estéticos más visibles. Batería >50%. Estado estético 50%-70%.',
            self::C => 'Funcional con pequeños detalles en desempeño. Batería <50%. Estado estético 40%-50%.',
            self::M => 'Malo - Problemas funcionales graves o múltiples fallas. Estado estético <40%.',
        };
    }

    public function scoreRange(): array
    {
        return match($this) {
            self::A => [90, 100],
            self::B => [70, 89],
            self::C => [50, 69],
            self::M => [0, 49],
        };
    }
}
