<?php

namespace App\Enums;

enum RamType: string
{
    case DDR3 = 'DDR3';
    case DDR4 = 'DDR4';
    case DDR5 = 'DDR5';
    case LPDDR3 = 'LPDDR3';
    case LPDDR4 = 'LPDDR4';
    case LPDDR5 = 'LPDDR5';

    public function label(): string
    {
        return $this->value;
    }

    public function generation(): int
    {
        return match($this) {
            self::DDR3, self::LPDDR3 => 3,
            self::DDR4, self::LPDDR4 => 4,
            self::DDR5, self::LPDDR5 => 5,
        };
    }
}
