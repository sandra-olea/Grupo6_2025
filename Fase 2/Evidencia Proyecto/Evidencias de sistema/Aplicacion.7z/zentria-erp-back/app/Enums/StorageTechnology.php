<?php

namespace App\Enums;

enum StorageTechnology: string
{
    case HDD = 'HDD';
    case SSD = 'SSD';
    case M2 = 'M2';
    case NVME = 'NVME';
    case HYBRID = 'HYBRID';

    public function label(): string
    {
        return $this->value;
    }

    public function isFast(): bool
    {
        return in_array($this, [
            self::SSD,
            self::M2,
            self::NVME,
        ]);
    }
}
