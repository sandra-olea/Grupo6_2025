<?php

namespace App\Enums;

enum KeyboardLayout: string
{
    case ES = 'es';
    case US = 'us';
    case LATAM = 'latam';

    public function label(): string
    {
        return match($this) {
            self::ES => 'Español (ES)',
            self::US => 'Inglés (US)',
            self::LATAM => 'Latinoamericano',
        };
    }
}
