<?php

namespace App\Traits;

use App\Models\Branch;
use App\Models\Company;
use App\Models\Subsidiary;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\NotificationEvent;
use App\Services\Notifications\NotificationRouter;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

/**
 * Trait para despachar notificaciones de forma consistente.
 * 
 * Centraliza la lógica de creación de eventos de notificación,
 * evitando duplicación de código y garantizando consistencia.
 */
trait DispatchesNotifications
{
    /**
     * Despacha una notificación al sistema.
     *
     * @param string $typeKey Key del tipo de notificación (ej: 'branch.created')
     * @param string $entityType Tipo de entidad (ej: 'branch', 'product', 'subsidiary')
     * @param int $entityId ID de la entidad
     * @param array $scope Scope de la notificación ['company_id' => ?, 'subsidiary_id' => ?, 'branch_id' => ?]
     * @param array $payload Datos específicos para esta notificación
     * @param string|null $priority Prioridad override (P1, P2, P3), null usa el default del tipo
     * @param string|null $dedupKey Deduplication key custom, null usa el default
     * @return void
     */
    protected function dispatchNotification(
        string $typeKey,
        string $entityType,
        int $entityId,
        array $scope,
        array $payload,
        ?string $priority = null,
        ?string $dedupKey = null
    ): void {
        try {
            $type = NotificationType::where('key', $typeKey)->first();

            if (!$type) {
                // Intentar autocrear el tipo con defaults razonables
                try {
                    $module = explode('.', $typeKey, 2)[0] ?? 'system';
                    // Defaults por tipo conocido
                    $defaults = [
                        'sale.created' => ['priority' => 'P2', 'channels' => ['inapp'], 'critical' => false],
                        'sale.status-changed' => ['priority' => 'P3', 'channels' => ['inapp'], 'critical' => false],
                        'sale.stock-shortage' => ['priority' => 'P1', 'channels' => ['inapp'], 'critical' => true],
                    ];
                    $cfg = $defaults[$typeKey] ?? ['priority' => 'P3', 'channels' => ['inapp'], 'critical' => false];

                    $type = NotificationType::create([
                        'key' => $typeKey,
                        'module' => $module,
                        'default_priority' => $cfg['priority'],
                        'default_channels' => $cfg['channels'],
                        'critical' => $cfg['critical'],
                        'enabled_global' => true,
                    ]);
                } catch (\Throwable $e) {
                    Log::warning("Notification type not found", [
                        'type_key' => $typeKey,
                        'entity' => "{$entityType}:{$entityId}",
                        'auto_create_error' => $e->getMessage(),
                    ]);
                    return;
                }
            }

            $event = NotificationEvent::create([
                'type_id' => $type->id,
                'entity_type' => $entityType,
                'entity_id' => $entityId,
                'company_id' => $scope['company_id'] ?? null,
                'subsidiary_id' => $scope['subsidiary_id'] ?? null,
                'branch_id' => $scope['branch_id'] ?? null,
                'priority' => $priority ?? $type->default_priority,
                'payload' => $payload,
                'dedup_key' => $dedupKey ?? "{$typeKey}:{$entityId}",
                'occurred_at' => now(),
            ]);

            app(NotificationRouter::class)->route($event);

            Log::debug("Notification dispatched", [
                'type' => $typeKey,
                'entity' => "{$entityType}:{$entityId}",
                'event_id' => $event->id
            ]);
        } catch (\Throwable $e) {
            // No interrumpir el flujo principal en caso de error de notificaciones
            Log::error("Notification dispatch failed", [
                'type' => $typeKey,
                'entity' => "{$entityType}:{$entityId}",
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
        }
    }

    /**
     * Genera el scope para una notificación de Branch.
     *
     * @param Branch $branch
     * @return array
     */
    protected function branchScope(Branch $branch): array
    {
        return [
            'company_id' => optional($branch->subsidiary)->company_id,
            'subsidiary_id' => $branch->subsidiary_id,
            'branch_id' => $branch->id,
        ];
    }

    /**
     * Genera el scope para una notificación de Subsidiary.
     *
     * @param Subsidiary $subsidiary
     * @return array
     */
    protected function subsidiaryScope(Subsidiary $subsidiary): array
    {
        return [
            'company_id' => $subsidiary->company_id,
            'subsidiary_id' => $subsidiary->id,
            'branch_id' => null,
        ];
    }

    /**
     * Genera el scope para una notificación de Company.
     *
     * @param Company $company
     * @return array
     */
    protected function companyScope(Company $company): array
    {
        return [
            'company_id' => $company->id,
            'subsidiary_id' => null,
            'branch_id' => null,
        ];
    }

    /**
     * Genera el payload con información del usuario actual.
     * Útil para incluir quién realizó la acción.
     *
     * @param string $actionKey 'created_by' o 'updated_by'
     * @return array ['created_by' => 'Juan Pérez', 'created_by_id' => 123]
     */
    protected function currentUserPayload(string $actionKey = 'created_by'): array
    {
        $user = Auth::user();
        
        if (!$user) {
            return [
                $actionKey => 'Sistema',
                "{$actionKey}_id" => null,
            ];
        }

        $fullName = trim(($user->first_name ?? '') . ' ' . ($user->last_name ?? ''));
        $displayName = $fullName ?: ($user->email ?? 'Usuario');

        return [
            $actionKey => $displayName,
            "{$actionKey}_id" => $user->id,
        ];
    }

    /**
     * Genera un scope basado en el branch principal del usuario actual.
     * Útil para entidades que no tienen un branch/subsidiary directo.
     *
     * @return array
     */
    protected function currentUserBranchScope(): array
    {
        $user = Auth::user();
        $branch = $user?->primaryBranch;

        if ($branch) {
            return $this->branchScope($branch);
        }

        // Fallback: buscar company del usuario
        $company = $user?->primaryCompany() ?? $user?->companies->first();
        
        return [
            'company_id' => $company?->id,
            'subsidiary_id' => null,
            'branch_id' => null,
        ];
    }
}
