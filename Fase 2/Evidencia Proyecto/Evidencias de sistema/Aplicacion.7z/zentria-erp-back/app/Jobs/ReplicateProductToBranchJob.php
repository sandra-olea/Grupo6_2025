<?php

namespace App\Jobs;

use App\Models\Product;
use App\Models\Brand;
use App\Models\Branch;
use App\Models\Warehouse;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ReplicateProductToBranchJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        public int $originProductId,
        public int $toBranchId,
        public ?int $toWarehouseId = null,
    ) {}

    public function handle(): void
    {
        try {
            $origin = Product::with(['brand','parent'])->find($this->originProductId);
            $toBranch = Branch::find($this->toBranchId);
            if (!$origin || !$toBranch) return;

            // If already exists by SKU in destination branch, nothing to do
            $existing = Product::query()
                ->where('branch_id', $toBranch->id)
                ->where('sku', $origin->sku)
                ->first();
            if ($existing) {
                $this->attachToWarehouseIfAny($existing);
                return;
            }

            // Ensure brand in destination branch
            $brandId = null;
            if ($origin->brand) {
                $destBrand = Brand::query()
                    ->where('branch_id', $toBranch->id)
                    ->whereRaw('LOWER(name) = ?', [mb_strtolower($origin->brand->name)])
                    ->first();
                if (!$destBrand) {
                    $destBrand = Brand::create([
                        'branch_id' => $toBranch->id,
                        'name' => $origin->brand->name,
                    ]);
                }
                $brandId = $destBrand->id;
            }

            // If origin is a child (grade), attempt to ensure parent and child mapping
            if ($origin->parent_product_id) {
                $parent = $origin->parent;
                $destParent = Product::query()
                    ->where('branch_id', $toBranch->id)
                    ->where('sku', $parent?->sku)
                    ->first();
                if (!$destParent) {
                    $destParent = new Product();
                    $destParent->fill([
                        'branch_id' => $toBranch->id,
                        'sku' => $parent?->sku,
                        'commercial_sku' => $parent?->commercial_sku,
                        'barcode' => $parent?->barcode,
                        'name' => $parent?->name,
                        'brand_id' => $brandId,
                        'product_type' => $parent?->product_type,
                        'serial_tracking' => true,
                        'warranty_months' => $parent?->warranty_months,
                        'cost' => $parent?->cost,
                        'price' => $parent?->price,
                        'offer_price' => $parent?->offer_price,
                        'product_status' => $parent?->product_status,
                        'attributes_json' => $parent?->attributes_json,
                        'marketplace_external_ids' => null,
                        'is_active' => $parent?->is_active,
                        'short_description' => $parent?->short_description,
                        'long_description' => $parent?->long_description,
                        'snippet_description' => $parent?->snippet_description,
                        'stock' => 0,
                    ]);
                    $destParent->save();
                    $destParent->ensureGradeChildren();
                }

                $destChild = Product::query()
                    ->where('branch_id', $toBranch->id)
                    ->where('parent_product_id', $destParent->id)
                    ->where('grade', $origin->grade?->value)
                    ->first();
                if (!$destChild) {
                    $destChild = new Product();
                    $destChild->fill([
                        'branch_id' => $toBranch->id,
                        'parent_product_id' => $destParent->id,
                        'grade' => $origin->grade?->value,
                        'sku' => $origin->sku,
                        'commercial_sku' => $origin->commercial_sku,
                        'barcode' => null,
                        'name' => $origin->name,
                        'brand_id' => $brandId,
                        'product_type' => $origin->product_type,
                        'serial_tracking' => true,
                        'warranty_months' => $origin->warranty_months,
                        'cost' => $origin->cost,
                        'price' => $origin->price,
                        'offer_price' => $origin->offer_price,
                        'product_status' => $origin->product_status,
                        'attributes_json' => $origin->attributes_json,
                        'marketplace_external_ids' => null,
                        'is_active' => $origin->is_active,
                        'short_description' => $origin->short_description,
                        'long_description' => $origin->long_description,
                        'snippet_description' => $origin->snippet_description,
                        'stock' => 0,
                    ]);
                    $destChild->save();
                }

                $this->attachToWarehouseIfAny($destChild);
                return;
            }

            // Normal product (non-child)
            $dest = new Product();
            $dest->fill([
                'branch_id' => $toBranch->id,
                'sku' => $origin->sku,
                'commercial_sku' => $origin->commercial_sku,
                'barcode' => $origin->barcode,
                'name' => $origin->name,
                'brand_id' => $brandId,
                'product_type' => $origin->product_type,
                'serial_tracking' => $origin->serial_tracking,
                'warranty_months' => $origin->warranty_months,
                'cost' => $origin->cost,
                'price' => $origin->price,
                'offer_price' => $origin->offer_price,
                'product_status' => $origin->product_status,
                'attributes_json' => $origin->attributes_json,
                'marketplace_external_ids' => null,
                'is_active' => $origin->is_active,
                'short_description' => $origin->short_description,
                'long_description' => $origin->long_description,
                'snippet_description' => $origin->snippet_description,
                'stock' => 0,
            ]);
            $dest->save();

            $this->attachToWarehouseIfAny($dest);
        } catch (\Throwable $e) {
            Log::warning('ReplicateProductToBranchJob failed', [
                'origin_product_id' => $this->originProductId,
                'to_branch_id' => $this->toBranchId,
                'error' => $e->getMessage(),
            ]);
            // swallow error — non blocking by design
        }
    }

    protected function attachToWarehouseIfAny(Product $product): void
    {
        if (!$this->toWarehouseId) return;
        $warehouse = Warehouse::find($this->toWarehouseId);
        if (!$warehouse) return;
        if ($warehouse->branch_id !== $this->toBranchId) return;

        $warehouse->products()->syncWithoutDetaching([
            $product->id => ['quantity' => 0, 'sync_stock' => true],
        ]);
    }
}

