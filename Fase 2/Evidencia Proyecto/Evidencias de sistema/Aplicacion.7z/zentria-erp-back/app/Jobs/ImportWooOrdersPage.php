<?php

namespace App\Jobs;

use App\Models\Integration;
use App\Models\WooSyncState;
use App\Services\Integrations\WooApiService;
use App\Services\Integrations\WooOrderIngestService;
use Illuminate\Bus\Batchable;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ImportWooOrdersPage implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, Batchable;

    public function __construct(
        public string $integrationId,
        public int $page,
        public ?string $afterIso,
        public int $perPage = 50,
        public string $mode = 'created' // 'created' | 'modified'
    ) {}

    public function handle(WooApiService $api, WooOrderIngestService $ingest): void
    {
        if ($this->batch()?->cancelled()) {
            return;
        }

        $integration = Integration::findOrFail($this->integrationId);

        // Simple throttle via Redis lock so we leave room for other jobs
        $lockKey = 'woo:import:concurrency:'.$this->integrationId;
        $lock = Cache::lock($lockKey, 10); // 10s lock
        if (!$lock->get()) {
            // Could not acquire lock: requeue later to avoid contention
            $this->release(15);
            return;
        }

        try {
            // Mark as processing
            DB::table('woo_sync_states')
                ->where('integration_id', $integration->id)
                ->update(['current_batch_status' => 'processing']);

            $params = ['page' => $this->page, 'per_page' => $this->perPage];
            if ($this->mode === 'modified') {
                $params['orderby'] = 'modified';
                $params['order'] = 'asc';
                if ($this->afterIso) {
                    // Prefer explicit modified_after; also keep 'after' for wider compatibility
                    $params['modified_after'] = $this->afterIso;
                    $params['after'] = $this->afterIso;
                }
            } else {
                // created cursor
                $params['orderby'] = 'date';
                $params['order'] = 'asc';
                if ($this->afterIso) { $params['after'] = $this->afterIso; }
            }
            $orders = $api->listOrders($integration, $params);

            $maxCreated = null; $maxModified = null;
            $createdCount = 0;
            $updatedCount = 0;
            foreach ($orders as $o) {
                try {
                    $res = $ingest->ingest((int)$integration->subsidiary_id, $integration->id, $o, true);
                    if (($res['created'] ?? false) === true) {
                        $createdCount++;
                    } elseif (($res['changed'] ?? false) === true) {
                        $updatedCount++;
                    }
                    if ($this->mode === 'modified') {
                        $modifiedAt = $o['date_modified_gmt'] ?? ($o['date_modified'] ?? null);
                        if ($modifiedAt) {
                            $dtm = \Carbon\Carbon::parse($modifiedAt);
                            if (!$maxModified || $dtm->gt($maxModified)) { $maxModified = $dtm; }
                        }
                    } else {
                        $createdAt = $o['date_created_gmt'] ?? ($o['date_created'] ?? null);
                        if ($createdAt) {
                            $dt = \Carbon\Carbon::parse($createdAt);
                            if (!$maxCreated || $dt->gt($maxCreated)) { $maxCreated = $dt; }
                        }
                    }
                } catch (\Throwable $e) {
                    Log::warning('Woo import page: failed ingest', [
                        'integration_id' => $integration->id,
                        'page' => $this->page,
                        'order_id' => $o['id'] ?? null,
                        'error' => $e->getMessage(),
                    ]);
                }
            }

            // If we seem to have more pages, enqueue next page into the same batch
            if ($this->batch() && is_array($orders) && count($orders) === $this->perPage) {
                $this->batch()->add((new self($this->integrationId, $this->page + 1, $this->afterIso, $this->perPage, $this->mode))->onQueue('imports'));
                // keep our own counter of planned pages
                DB::table('woo_sync_states')
                    ->where('integration_id', $integration->id)
                    ->update(['current_batch_total' => DB::raw('COALESCE(current_batch_total, 0) + 1')]);
            }

            // Update progress counters and cursor safely
            DB::transaction(function () use ($integration, $maxCreated, $maxModified, $createdCount, $updatedCount) {
                $st = WooSyncState::lockForUpdate()->find($integration->id);
                if ($st) {
                    $st->current_batch_processed = (int) ($st->current_batch_processed ?? 0) + 1;
                    $st->orders_imported_count = (int) ($st->orders_imported_count ?? 0) + $createdCount;
                    $st->orders_updated_count = (int) ($st->orders_updated_count ?? 0) + $updatedCount;
                    if ($maxCreated && (!$st->last_order_created_at || $maxCreated->gt($st->last_order_created_at))) {
                        $st->last_order_created_at = $maxCreated;
                        $st->last_order_id = null;
                    }
                    if ($maxModified && (!$st->last_order_modified_at || $maxModified->gt($st->last_order_modified_at))) {
                        $st->last_order_modified_at = $maxModified;
                    }
                    $st->save();
                }
            });
        } finally {
            optional($lock)->release();
        }
    }
}
