<?php

namespace App\Jobs;

use App\Enums\EquipmentGrade;
use App\Models\Product;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class CreateSerialChildrenJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $backoff = 10;

    public function __construct(public int $parentProductId)
    {
        // no-op
    }

    public function handle(): void
    {
        $parent = Product::find($this->parentProductId);
        if (!$parent) return;

        // Solo aplica a padres con tracking por serie
        if (!$parent->serial_tracking || $parent->parent_product_id) {
            return;
        }

        // Reutiliza la lógica existente del modelo
        $parent->ensureGradeChildren();
        // Propaga metadatos del padre a los hijos recién creados
        $parent->propagateToChildren();
    }
}

