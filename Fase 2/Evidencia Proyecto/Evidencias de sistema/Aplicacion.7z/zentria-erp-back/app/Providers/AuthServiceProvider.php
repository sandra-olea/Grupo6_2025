<?php

namespace App\Providers;

use App\Models\Branch;
use App\Models\User;
use App\Models\Company;
use App\Models\Subsidiary;
use App\Models\Product;
use App\Models\Brand;
use App\Models\Category;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use App\Models\UserPersonalization;
use App\Policies\BranchPolicy;
use App\Policies\UserPersonalizationPolicy;
use App\Policies\UserPolicy;
use App\Policies\CompanyPolicy;
use App\Policies\SubsidiaryPolicy;
use App\Policies\ProductPolicy;
use App\Policies\BrandPolicy;
use App\Policies\CategoryPolicy;
use App\Models\Warehouse;
use App\Policies\WarehousePolicy;
use App\Models\TechnicalReviewBatch;
use App\Models\TechnicalReviewItem;
use App\Policies\TechnicalReviewBatchPolicy;
use App\Policies\TechnicalReviewItemPolicy;
use App\Models\UnmappedWooCommerceProduct;
use App\Models\Document;
use App\Models\DocumentType;
use App\Models\Warranty;
use App\Models\Transfer;
use App\Policies\UnmappedWooCommerceProductPolicy;
use App\Policies\DocumentPolicy;
use App\Policies\DocumentTypePolicy;
use App\Policies\WarrantyPolicy;
use App\Policies\TransferPolicy;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        UserPersonalization::class => UserPersonalizationPolicy::class,
        User::class => UserPolicy::class,
        Branch::class => BranchPolicy::class,
        Company::class => CompanyPolicy::class,
        Subsidiary::class => SubsidiaryPolicy::class,
        Product::class => ProductPolicy::class,
        Brand::class => BrandPolicy::class,
        Category::class => CategoryPolicy::class,
        Warehouse::class => WarehousePolicy::class,
        TechnicalReviewBatch::class => TechnicalReviewBatchPolicy::class,
        TechnicalReviewItem::class => TechnicalReviewItemPolicy::class,
        UnmappedWooCommerceProduct::class => UnmappedWooCommerceProductPolicy::class,
        Document::class => DocumentPolicy::class,
        DocumentType::class => DocumentTypePolicy::class,
        Warranty::class => \App\Policies\WarrantyPolicy::class,
        Transfer::class => TransferPolicy::class,
    ];

    public function register(): void
    {
    }
    

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        Gate::define('show-profile', function ($user){ 
            $personalization = $user->personalization;
                if (!$personalization) {
                return true;
            }

            return $user->can('view', $personalization);
        });
        
        Gate::define('edit-profile', function ($user) {
            $personalization = $user->personalization;

            if (!$personalization) {
                return true;
            }
            return $user->can('update', $personalization);
        });

        Gate::before(function ($user, $ability) {
            return $user->hasRole('super-admin') ? true : null;
        });
        
    }
}
