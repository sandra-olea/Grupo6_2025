<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Route;
use App\Models\Subsidiary;
use App\Models\Branch;
use App\Models\Product;
use App\Observers\SubsidiaryObserver;
use App\Observers\BranchObserver;
use App\Observers\ProductObserver;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Si por alguna razón el proceso web queda con APP_ENV=testing sin estar ejecutando PHPUnit,
        // forzamos a usar la conexión de BD real para evitar apuntar a sqlite :memory:
        if (app()->environment('testing') && ! app()->runningUnitTests() && ! env('PHPUNIT_RUNNING', false)) {
            $fallback = env('DB_CONNECTION_REAL', 'pgsql');
            Config::set('database.default', $fallback);
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // CORS se maneja en Nginx; no inyectar middleware a nivel app
        
        // Registrar observers para asignación automática de roles
        Subsidiary::observe(SubsidiaryObserver::class);
        Branch::observe(BranchObserver::class);
        
        // Registrar observer para protección de stock en productos con series
        Product::observe(ProductObserver::class);

        // Registrar comandos CLI adicionales en local
        if ($this->app->runningInConsole()) {
            $this->commands([
                \App\Console\Commands\RolesDiagnose::class,
                \App\Console\Commands\UsersRolesReport::class,
            ]);
        }
    }
}
