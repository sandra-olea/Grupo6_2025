<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CustomerSale extends Model
{
    protected $table = 'customer_sale';

    protected $fillable = [
        'subsidiary_id',
        'customer_code',
        'document_type',
        'type',
        'rut',
        'billing_company',
        'trade_activity',
        'contact_name',
        'primary_contact_name',
        'primary_contact_email',
        'primary_contact_phone',
        'email',
        'phone',
        'billing_address_1',
        'billing_address_2',
        'billing_city',
        'commune_id',
        'billing_state_code',
        'billing_postcode',
        'billing_country_code',
        'shipping_address_1',
        'shipping_address_2',
        'shipping_city',
        'shipping_commune_id',
        'shipping_state_code',
        'shipping_postcode',
        'shipping_country_code',
        'default_document_type',
        'preferred_payment_method',
        'purchase_order_number',
        'commercial_data',
        'notes',
        'is_active',
    ];

    protected $casts = [
        'commercial_data' => 'array',
        'is_active' => 'boolean',
    ];

    public function subsidiary(): BelongsTo
    {
        return $this->belongsTo(Subsidiary::class);
    }

    public function commune(): BelongsTo
    {
        return $this->belongsTo(Commune::class);
    }

    public function shippingCommune(): BelongsTo
    {
        return $this->belongsTo(Commune::class, 'shipping_commune_id');
    }
}
