<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Transfer extends Model
{
    protected $fillable = [
        'from_branch_id', 'to_branch_id',
        'from_warehouse_id', 'to_warehouse_id',
        'responsible_id', 'status',
        'total_items', 'total_quantity',
        'notes', 'meta',
    ];

    protected $casts = [
        'meta' => 'array',
    ];

    public function fromBranch(): BelongsTo { return $this->belongsTo(Branch::class, 'from_branch_id'); }
    public function toBranch(): BelongsTo { return $this->belongsTo(Branch::class, 'to_branch_id'); }
    public function fromWarehouse(): BelongsTo { return $this->belongsTo(Warehouse::class, 'from_warehouse_id'); }
    public function toWarehouse(): BelongsTo { return $this->belongsTo(Warehouse::class, 'to_warehouse_id'); }
    public function responsible(): BelongsTo { return $this->belongsTo(User::class, 'responsible_id'); }
    public function items(): HasMany { return $this->hasMany(TransferItem::class); }

    public function scopeByBranch($q, int $branchId)
    {
        return $q->where(function ($w) use ($branchId) {
            $w->where('from_branch_id', $branchId)
              ->orWhere('to_branch_id', $branchId);
        });
    }
}

