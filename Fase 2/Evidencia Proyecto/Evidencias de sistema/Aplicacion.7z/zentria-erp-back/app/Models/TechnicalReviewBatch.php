<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\CustomerSupplier;
use App\Enums\ReviewStatus;
use Carbon\Carbon;

class TechnicalReviewBatch extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'code',
        'branch_id',
        'warehouse_id',
        'customer_supplier_id',
        'supplier_id',
        'entry_date',
        'expected_quantity',
        'completed_quantity',
        'status',
        'notes',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'entry_date' => 'date',
        'expected_quantity' => 'integer',
        'completed_quantity' => 'integer',
    ];

    /**
     * Relación con sucursal
     */
    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    /**
     * Relación con bodega
     */
    public function warehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class);
    }

    /**
     * Cliente o proveedor origen
     */
    public function customerSupplier(): BelongsTo
    {
        return $this->belongsTo(CustomerSupplier::class, 'customer_supplier_id');
    }

    /**
     * Proveedor asociado al customer-supplier para este lote
     */
    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class, 'supplier_id');
    }

    /**
     * Items individuales de este lote
     */
    public function items(): HasMany
    {
        return $this->hasMany(TechnicalReviewItem::class, 'batch_id');
    }

    /**
     * Documentos adjuntos al lote
     */
    public function documents(): HasMany
    {
        return $this->hasMany(TechnicalReviewDocument::class, 'batch_id');
    }

    /**
     * Fotos del lote (usando Media Library)
     */
    public function photos(): MorphMany
    {
        return $this->morphMany(Media::class, 'model');
    }

    /**
     * Usuario que creó el lote
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * Usuario que actualizó el lote
     */
    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    /**
     * Scopes
     */
    public function scopeByBranch($query, int $branchId)
    {
        return $query->where('branch_id', $branchId);
    }

    public function scopeByWarehouse($query, int $warehouseId)
    {
        return $query->where('warehouse_id', $warehouseId);
    }

    public function scopeByStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    public function scopeInProgress($query)
    {
        return $query->where('status', 'in_progress');
    }

    /**
     * Calcular progreso del lote
     */
    public function getProgressAttribute(): float
    {
        if ($this->expected_quantity === 0) {
            return 0.0;
        }

        $progress = ($this->received_quantity / $this->expected_quantity) * 100;

        return min(100.0, max(0.0, $progress));
    }

    /**
     * Cantidad de equipos asignados al lote
     */
    public function getReceivedQuantityAttribute(): int
    {
        if (isset($this->items_count)) {
            return (int) $this->items_count;
        }

        if ($this->relationLoaded('items')) {
            return $this->items->count();
        }

        return $this->items()->count();
    }

    /**
     * Items pendientes por asociar
     */
    public function getPendingItemsCountAttribute(): int
    {
        return max(0, $this->expected_quantity - $this->received_quantity);
    }

    /**
     * Fecha de la primera revisión completada (primer reviewed_at)
     */
    public function getReviewDateAttribute(): ?Carbon
    {
        $firstReviewedAt = $this->items()
            ->whereIn('review_status', [ReviewStatus::REVIEWED->value, ReviewStatus::APPROVED->value])
            ->min('reviewed_at');

        return $firstReviewedAt ? Carbon::parse($firstReviewedAt) : null;
    }
}
