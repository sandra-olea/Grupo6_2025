<?php

namespace App\Models;

use App\Enums\EquipmentCondition;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TechnicalReviewDocking extends Model
{
    use HasFactory;

    protected $fillable = [
        'review_item_id',
        'brand',
        'model',
        'line',
        'power_cable_status',
        'includes_power_adapter',
        'other_includes',
        'general_condition',
        // Puertos (cantidades) migración 0063
        'vga_ports',
        'hdmi_ports',
        'displayport_ports',
        'usb_c_ports',
        'sd_readers',
        'has_wifi',
        'all_ports_functional',
        'defective_ports_count',
        'rj45_ports',
        'usb_a_ports',
        'cover_condition',
        'observations',
        'extra_attributes',
    ];

    protected $casts = [
        'general_condition' => EquipmentCondition::class,
        'cover_condition' => EquipmentCondition::class,
        'power_cable_status' => 'string',
        'includes_power_adapter' => 'boolean',
        'has_wifi' => 'boolean',
        'all_ports_functional' => 'boolean',
        'extra_attributes' => 'array',
    ];

    public function reviewItem(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewItem::class, 'review_item_id');
    }

    /**
     * Ocultar campos en la serialización JSON
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'extra_attributes',
    ];
}
