<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Sale extends Model
{
    protected $fillable = [
        'subsidiary_id','customer_id','wc_order_id','wc_order_number','sale_number','status',
        'quote_id','salesperson_id','sale_date','delivery_date','completed_at',
        'subtotal','tax_amount','discount_amount','shipping_amount','total_amount','paid_amount','pending_amount',
        'tax_rate','discount_rate','currency','exchange_rate',
        'inventory_reserved','inventory_delivered','inventory_reserved_at','inventory_delivered_at',
        'billing_snapshot','shipping_snapshot','delivery_address','payment_method','payment_method_title',
        'woo_metadata','documents_metadata','notes','internal_notes',
    ];

    protected $casts = [
        'sale_date' => 'date',
        'delivery_date' => 'date',
        'completed_at' => 'datetime',
        'inventory_reserved' => 'boolean',
        'inventory_delivered' => 'boolean',
        'billing_snapshot' => 'array',
        'shipping_snapshot' => 'array',
        'delivery_address' => 'array',
        'woo_metadata' => 'array',
        'documents_metadata' => 'array',
        'subtotal' => 'decimal:2',
        'tax_amount' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'shipping_amount' => 'decimal:2',
        'total_amount' => 'decimal:2',
        'paid_amount' => 'decimal:2',
        'pending_amount' => 'decimal:2',
        'tax_rate' => 'decimal:4',
        'discount_rate' => 'decimal:4',
    ];

    public function customer(): BelongsTo { return $this->belongsTo(CustomerSale::class, 'customer_id'); }
    public function subsidiary(): BelongsTo { return $this->belongsTo(Subsidiary::class); }
    public function items(): HasMany { return $this->hasMany(SaleItem::class); }
}

