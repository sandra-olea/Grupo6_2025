<?php

namespace App\Models;

use App\Enums\EquipmentCondition;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TechnicalReviewMonitor extends Model
{
    use HasFactory;

    protected $fillable = [
        'review_item_id',
        'brand',
        'model',
        'line',
        'includes_power_cable',
        'power_cable_status',
        'includes_video_cable',
        'includes_stand',
        'other_includes',
        'general_condition',
        // Puertos (cantidades) migración 0063
        'vga_ports',
        'hdmi_ports',
        'displayport_ports',
        'dvi_ports',
        'has_usb_hub',
        'all_ports_functional',
        'defective_ports_count',
    'defective_ports_critical_count',
        'usb_hub_ports',
        'screen_inches',
        'screen_resolution',
        'screen_condition',
        'is_touchscreen',
        'frame_condition',
        'stand_condition',
        'observations',
        'extra_attributes',
    ];

    protected $casts = [
        'general_condition' => EquipmentCondition::class,
        'screen_condition' => EquipmentCondition::class,
        'frame_condition' => EquipmentCondition::class,
        'stand_condition' => EquipmentCondition::class,
        'includes_power_cable' => 'boolean',
        'power_cable_status' => 'string',
        'includes_video_cable' => 'boolean',
        'includes_stand' => 'boolean',
        'has_usb_hub' => 'boolean',
        'all_ports_functional' => 'boolean',
        'defective_ports_count' => 'integer',
        'defective_ports_critical_count' => 'integer',
        'is_touchscreen' => 'boolean',
        'extra_attributes' => 'array',
    ];

    public function reviewItem(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewItem::class, 'review_item_id');
    }

    /**
     * Ocultar campos en la serialización JSON
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'extra_attributes',
        // Legacy name kept hidden if present in DB
        'resolution',
    ];
}
