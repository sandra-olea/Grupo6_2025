<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Document extends Model implements HasMedia
{
    use InteractsWithMedia;
    protected $fillable = [
        'subsidiary_id',
        'document_type_id',
        'name',
        'description',
        'output_format',
        'related_module',
        'related_id',
        'template_body',
        'metadata',
        'is_active',
    ];

    protected $casts = [
        'metadata' => 'array',
        'is_active' => 'boolean',
    ];

    public function subsidiary()
    {
        return $this->belongsTo(Subsidiary::class);
    }

    public function documentType()
    {
        return $this->belongsTo(DocumentType::class);
    }

    public static function primaryCollection(): string { return 'files'; }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('files')->useDisk(config('filesystems.default', 'public'));
        // Optional extra collection name alias
        $this->addMediaCollection('attachments')->useDisk(config('filesystems.default', 'public'));
    }
}
