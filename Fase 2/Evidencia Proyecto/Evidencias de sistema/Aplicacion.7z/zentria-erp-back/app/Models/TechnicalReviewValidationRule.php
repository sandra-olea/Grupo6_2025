<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TechnicalReviewValidationRule extends Model
{
    use HasFactory;

    protected $fillable = [
        'equipment_type',
        'field_name',
        'validation_type',
        'rule_config',
        'error_message',
        'help_text',
        'is_active',
        'priority',
    ];

    protected $casts = [
        'rule_config' => 'array',
        'is_active' => 'boolean',
        'priority' => 'integer',
    ];

    /**
     * Scopes
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeForEquipmentType($query, string $equipmentType)
    {
        return $query->where('equipment_type', $equipmentType);
    }

    public function scopeForField($query, string $fieldName)
    {
        return $query->where('field_name', $fieldName);
    }

    public function scopeByPriority($query)
    {
        return $query->orderBy('priority', 'desc');
    }
}
