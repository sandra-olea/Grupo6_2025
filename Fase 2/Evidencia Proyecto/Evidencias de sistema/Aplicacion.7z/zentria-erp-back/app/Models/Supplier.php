<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Supplier extends Model
{
    protected $fillable = ['subsidiary_id', 'name'];

    /**
     * Un proveedor pertenece a una subsidiary
     */
    public function subsidiary(): BelongsTo
    {
        return $this->belongsTo(Subsidiary::class);
    }

    /**
     * Un proveedor puede tener muchos clientes-proveedores
     */
    public function customerSuppliers(): BelongsToMany
    {
        return $this->belongsToMany(CustomerSupplier::class, 'customer_supplier_supplier')
            ->withTimestamps();
    }
}
