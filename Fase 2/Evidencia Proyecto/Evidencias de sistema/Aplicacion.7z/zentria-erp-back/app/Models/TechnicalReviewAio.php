<?php

namespace App\Models;

use App\Enums\EquipmentCondition;
use App\Enums\RamType;
use App\Enums\StorageTechnology;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TechnicalReviewAio extends Model
{
    use HasFactory;

    protected $fillable = [
        'review_item_id',
        'brand',
        'model',
        'line',
        'processor',
        'ram_size',
        'ram_slots',
        'ram_type',
        'storage_size',
        'storage_technology',
        'includes_power_adapter',
        'charger_status',
        'includes_keyboard',
        'includes_mouse',
        'other_includes',
        'general_condition',
        // Puertos (cantidades)
        'vga_ports',
        'hdmi_ports',
        'displayport_ports',
        'usb_c_ports',
        'sd_readers',
        'has_wifi',
        'rj45_ports',
        'has_bluetooth',
        'all_ports_functional',
        'defective_ports_count',
        'has_cd_drive',
        'usb_a_ports',
        'screen_inches',
        'screen_condition',
        'is_touchscreen',
        'cover_condition',
        'operating_system',
        'other_features',
        'observations',
        'extra_attributes',
    ];

    protected $casts = [
        'ram_type' => RamType::class,
        'storage_technology' => StorageTechnology::class,
        'general_condition' => EquipmentCondition::class,
        'screen_condition' => EquipmentCondition::class,
        'cover_condition' => EquipmentCondition::class,
        'includes_power_adapter' => 'boolean',
        'charger_status' => 'string',
        'includes_keyboard' => 'boolean',
        'includes_mouse' => 'boolean',
        'has_wifi' => 'boolean',
        'has_bluetooth' => 'boolean',
        'all_ports_functional' => 'boolean',
        'has_cd_drive' => 'boolean',
        'is_touchscreen' => 'boolean',
        'extra_attributes' => 'array',
    ];

    public function reviewItem(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewItem::class, 'review_item_id');
    }

    /**
     * Ocultar campos en la serialización JSON
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'extra_attributes',
        // Legacy column no longer used in AIO output
        'power_cable_status',
    ];
}
