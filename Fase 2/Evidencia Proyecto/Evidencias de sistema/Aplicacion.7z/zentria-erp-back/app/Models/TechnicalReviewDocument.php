<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TechnicalReviewDocument extends Model
{
    use HasFactory;

    protected $fillable = [
        'batch_id',
        'document_type',
        'file_path',
        'file_name',
        'mime_type',
        'file_size',
        'uploaded_by',
    ];

    /**
     * Relación con lote
     */
    public function batch(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewBatch::class, 'batch_id');
    }

    /**
     * Usuario que subió el documento
     */
    public function uploader(): BelongsTo
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    /**
     * Obtener URL pública del documento
     */
    public function getUrlAttribute(): string
    {
        return asset('storage/' . $this->file_path);
    }
}
