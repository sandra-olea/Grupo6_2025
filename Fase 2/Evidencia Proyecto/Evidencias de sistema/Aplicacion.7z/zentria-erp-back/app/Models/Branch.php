<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;


class Branch extends Model Implements HasMedia
{
    use InteractsWithMedia;

    protected $fillable = [
        'subsidiary_id',
        'branch_name',
        'branch_address',
        'commune_id',
        'branch_phone',
        'branch_email',
        'branch_status',
        'branch_manager_name',
        'branch_manager_phone',
        'branch_manager_email',
        'branch_opening_hours',
        'branch_location',
        'manager_id',
    ];

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('library')->useDisk('public'); // biblioteca propia de la sucursal
    }

    public function registerMediaConversions(\Spatie\MediaLibrary\MediaCollections\Models\Media $media=null): void
    {
        $this->addMediaConversion('thumb')->width(400)->height(400);
        $this->addMediaConversion('web')->format('webp')->width(1200);
    }

    public function subsidiary()
    {
        return $this->belongsTo(Subsidiary::class);
    }

    public function manager()
    {
        return $this->belongsTo(User::class, 'manager_id');
    }

    public function users() {
        return $this->belongsToMany(User::class)
            ->withPivot('is_primary', 'position')
            ->withTimestamps();
    }

    public function brands(): HasMany
    {
        return $this->hasMany(Brand::class);
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }

    public function warehouses(): HasMany
    {
        return $this->hasMany(Warehouse::class);
    }

    // Ubicación
    public function commune()
    {
        return $this->belongsTo(Commune::class);
    }

    // Scoping de visibilidad por usuario (herencia: company > subsidiary > branch)
    public function scopeVisibleTo($query, User $user)
    {
        if ($user->hasRole('super-admin')) {
            return $query;
        }

        return $query->where(function ($q) use ($user) {
            // Acceso directo por pivot branch_user
            $q->whereHas('users', function ($uq) use ($user) {
                $uq->where('users.id', $user->id);
            })
            // Acceso heredado por subsidiary-member
            ->orWhereExists(function ($sq) use ($user) {
                $sq->select(DB::raw(1))
                    ->from('scope_roles as sr')
                    ->join('roles as r', 'r.id', '=', 'sr.role_id')
                    ->whereColumn('sr.scope_id', 'branches.subsidiary_id')
                    ->where('sr.scope_type', 'subsidiary')
                    ->whereIn('r.name', ['subsidiary-member', 'subsidiary-admin'])
                    ->where('sr.user_id', $user->id);
            })
            // Acceso heredado por company-member
            ->orWhereExists(function ($sq) use ($user) {
                $sq->select(DB::raw(1))
                    ->from('scope_roles as sr')
                    ->join('roles as r', 'r.id', '=', 'sr.role_id')
                    ->join('subsidiaries as s', 's.company_id', '=', 'sr.scope_id')
                    ->whereColumn('s.id', 'branches.subsidiary_id')
                    ->where('sr.scope_type', 'company')
                    ->whereIn('r.name', ['company-member', 'company-admin'])
                    ->where('sr.user_id', $user->id);
            })
            // Acceso directo por rol contextual en la branch
            ->orWhereExists(function ($sq) use ($user) {
                $sq->select(DB::raw(1))
                    ->from('scope_roles as sr')
                    ->join('roles as r', 'r.id', '=', 'sr.role_id')
                    ->whereColumn('sr.scope_id', 'branches.id')
                    ->where('sr.scope_type', 'branch')
                    ->whereIn('r.name', ['branch-admin'])
                    ->where('sr.user_id', $user->id);
            });

            if ($user->primary_branch_id) {
                $q->orWhere('branches.id', $user->primary_branch_id);
            }
        });
    }
}
