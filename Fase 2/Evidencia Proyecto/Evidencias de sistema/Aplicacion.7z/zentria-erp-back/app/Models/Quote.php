<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Quote extends Model
{
    protected $fillable = [
        'subsidiary_id','customer_id','quote_number','status','salesperson_id',
        'quote_date','expiry_date','subtotal','tax_amount','discount_amount','total_amount',
        'tax_rate','discount_rate','terms_conditions','notes','internal_notes',
        'is_converted_to_sale','converted_at',
    ];

    protected $casts = [
        'quote_date' => 'date',
        'expiry_date' => 'date',
        'converted_at' => 'datetime',
        'terms_conditions' => 'array',
        'subtotal' => 'decimal:2',
        'tax_amount' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'total_amount' => 'decimal:2',
        'tax_rate' => 'decimal:4',
        'discount_rate' => 'decimal:4',
        'is_converted_to_sale' => 'boolean',
    ];

    public function customer(): BelongsTo { return $this->belongsTo(CustomerSale::class, 'customer_id'); }
    public function subsidiary(): BelongsTo { return $this->belongsTo(Subsidiary::class); }
    public function items(): HasMany { return $this->hasMany(QuoteItem::class); }
    public function salesperson(): BelongsTo { return $this->belongsTo(User::class, 'salesperson_id'); }
}
