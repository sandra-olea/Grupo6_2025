<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UnmappedWooCommerceProduct extends Model
{
    protected $table = 'unmapped_woocommerce_products';

    protected $fillable = [
        'integration_id',
        'sale_id',
        'external_line_id',
        'external_product_id',
        'external_variation_id',
        'sku',
        'name',
        'price',
        'quantity',
        'line_item_data',
        'wc_order_id',
        'resolution_status',
        'mapped_product_id',
        'mapped_at',
    ];

    protected $casts = [
        'line_item_data' => 'array',
        'price' => 'decimal:2',
        'quantity' => 'integer',
        'external_product_id' => 'integer',
        'external_variation_id' => 'integer',
        'wc_order_id' => 'integer',
        'mapped_at' => 'datetime',
    ];

    public function integration(): BelongsTo
    {
        return $this->belongsTo(Integration::class);
    }

    public function sale(): BelongsTo
    {
        return $this->belongsTo(Sale::class);
    }

    public function mappedProduct(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'mapped_product_id');
    }

    /**
     * Scope para filtrar solo productos pendientes de mapear
     */
    public function scopePending($query)
    {
        return $query->where('resolution_status', 'pending');
    }

    /**
     * Scope para filtrar productos ya mapeados
     */
    public function scopeMapped($query)
    {
        return $query->where('resolution_status', 'mapped');
    }
}
