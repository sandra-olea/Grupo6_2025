<?php

namespace App\Models;

use App\Enums\EquipmentGrade;
use App\Enums\EquipmentStatus;
use App\Enums\EquipmentType;
use App\Enums\ReviewStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use App\Models\Concerns\HasModelImages;
use App\Models\User;

class TechnicalReviewItem extends Model implements HasMedia
{
    use HasFactory, SoftDeletes;
    use InteractsWithMedia, HasModelImages;

    protected $fillable = [
        'batch_id',
        'branch_id',
        'warehouse_id',
        'customer_supplier_id',
        'serial_number',
        'product_id',
        'equipment_type',
        'review_status',
        'current_status',
        'grade',
        'suggested_grade',
        'scoring_confidence',
        'scoring_breakdown',
        'override_suggestion',
        'override_reason',
        'destination',
        'sale_id',
        'review_started_at',
        'reviewed_at',
        'approved_at',
        'created_by',
        'reviewed_by',
        'approved_by',
        'updated_by',
    ];

    protected $casts = [
        'equipment_type' => EquipmentType::class,
        'review_status' => ReviewStatus::class,
        'current_status' => EquipmentStatus::class,
        'grade' => EquipmentGrade::class,
        'scoring_breakdown' => 'array',
        'override_suggestion' => 'boolean',
        'review_started_at' => 'datetime',
        'reviewed_at' => 'datetime',
        'approved_at' => 'datetime',
    ];

    /**
     * Media Library collections and conversions
     */
    public static function primaryCollection(): string { return 'main'; }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('main')->singleFile()->useDisk('public');
        $this->addMediaCollection('gallery')->useDisk('public');
    }

    public function registerMediaConversions(\Spatie\MediaLibrary\MediaCollections\Models\Media $media = null): void
    {
        $this->addMediaConversion('thumb')->width(400)->height(400);
        $this->addMediaConversion('web')->format('webp')->width(1200);
    }

    /**
     * Relación polimórfica con detalles técnicos según tipo de equipo
     */
    public function details()
    {
        if (! $this->equipment_type instanceof EquipmentType) {
            return $this->hasOne(TechnicalReviewNotebook::class, 'review_item_id')
                ->whereRaw('1 = 0');
        }

        return match($this->equipment_type) {
            EquipmentType::NOTEBOOK => $this->hasOne(TechnicalReviewNotebook::class, 'review_item_id'),
            EquipmentType::DESKTOP => $this->hasOne(TechnicalReviewDesktop::class, 'review_item_id'),
            EquipmentType::DOCKING => $this->hasOne(TechnicalReviewDocking::class, 'review_item_id'),
            EquipmentType::AIO => $this->hasOne(TechnicalReviewAio::class, 'review_item_id'),
            EquipmentType::MONITOR => $this->hasOne(TechnicalReviewMonitor::class, 'review_item_id'),
            default => null,
        };
    }

    /**
     * Relaciones específicas por tipo de equipo (para eager loading)
     */
    public function notebookDetails(): HasOne
    {
        return $this->hasOne(TechnicalReviewNotebook::class, 'review_item_id');
    }

    public function desktopDetails(): HasOne
    {
        return $this->hasOne(TechnicalReviewDesktop::class, 'review_item_id');
    }

    public function dockingDetails(): HasOne
    {
        return $this->hasOne(TechnicalReviewDocking::class, 'review_item_id');
    }

    public function aioDetails(): HasOne
    {
        return $this->hasOne(TechnicalReviewAio::class, 'review_item_id');
    }

    public function monitorDetails(): HasOne
    {
        return $this->hasOne(TechnicalReviewMonitor::class, 'review_item_id');
    }

    /**
     * Relación con lote
     */
    public function batch(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewBatch::class, 'batch_id');
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    /**
     * Relación con bodega
     */
    public function warehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class);
    }

    public function customerSupplier(): BelongsTo
    {
        return $this->belongsTo(CustomerSupplier::class, 'customer_supplier_id');
    }

    /**
     * Relación con producto (opcional)
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Relación con venta
     */
    public function sale(): BelongsTo
    {
        return $this->belongsTo(Sale::class);
    }

    /**
     * Trazabilidad del equipo
     */
    public function traceability(): HasOne
    {
        return $this->hasOne(EquipmentTraceability::class, 'review_item_id');
    }

    /**
     * Usuario creador
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function createdBy(): BelongsTo
    {
        return $this->creator();
    }

    public function reviewedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    public function approvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    /**
     * Usuario actualizador
     */
    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    public function updatedBy(): BelongsTo
    {
        return $this->updater();
    }

    /**
     * Scopes
     */
    public function scopeBySerialNumber($query, string $serialNumber)
    {
        return $query->where('serial_number', $serialNumber);
    }

    public function scopeByBranch($query, int $branchId)
    {
        return $query->where('branch_id', $branchId);
    }

    public function scopeByEquipmentType($query, EquipmentType $type)
    {
        return $query->where('equipment_type', $type);
    }

    public function scopeByReviewStatus($query, ReviewStatus $status)
    {
        return $query->where('review_status', $status);
    }

    public function scopeByCurrentStatus($query, EquipmentStatus $status)
    {
        return $query->where('current_status', $status);
    }

    public function scopeByGrade($query, EquipmentGrade $grade)
    {
        return $query->where('grade', $grade);
    }

    public function scopePending($query)
    {
        return $query->where('review_status', ReviewStatus::PENDING);
    }

    public function scopeInReview($query)
    {
        return $query->where('review_status', ReviewStatus::IN_REVIEW);
    }

    public function scopeReviewed($query)
    {
        return $query->where('review_status', ReviewStatus::REVIEWED);
    }

    public function scopeApproved($query)
    {
        return $query->where('review_status', ReviewStatus::APPROVED);
    }

    public function scopeAvailableForSale($query)
    {
        return $query->where('current_status', EquipmentStatus::AVAILABLE_FOR_SALE);
    }

    /**
     * Verifica si el grado sugerido difiere del asignado
     */
    public function hasGradeOverride(): bool
    {
        return $this->suggested_grade !== null 
            && $this->grade !== null 
            && $this->suggested_grade !== $this->grade->value;
    }

    /**
     * Verifica si el scoring tiene alta confianza
     */
    public function hasHighConfidence(): bool
    {
        return $this->scoring_confidence !== null && $this->scoring_confidence >= 80;
    }
}
