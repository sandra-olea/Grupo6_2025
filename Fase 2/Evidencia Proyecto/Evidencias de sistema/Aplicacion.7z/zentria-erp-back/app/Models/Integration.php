<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Integration extends Model
{
    public $incrementing = false;
    protected $keyType = 'string'; // uuid

    protected $fillable = [
        'id',
        'subsidiary_id',
        'name',
        'provider',
        'base_url',
        'consumer_key',
        'consumer_secret',
        'api_token',
        'webhook_secret',
        'api_key_prefix',
        'api_key_hash',
        'mode',
        'is_active',
        'scopes',
        'allowed_ips',
        'params',
        'last_success_at',
        'last_error_at',
        'last_error_msg',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'scopes' => 'array',
        'allowed_ips' => 'array',
        'params' => 'array',
        'last_success_at' => 'datetime',
        'last_error_at' => 'datetime',
    ];

    public function subsidiary(): BelongsTo
    {
        return $this->belongsTo(Subsidiary::class);
    }
}

