<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductSoftHold extends Model
{
    protected $fillable = [
        'product_id','sale_id','sale_item_id','quantity','status',
    ];

    public function product(): BelongsTo { return $this->belongsTo(Product::class); }
    public function sale(): BelongsTo { return $this->belongsTo(Sale::class); }
    public function saleItem(): BelongsTo { return $this->belongsTo(SaleItem::class); }
}

