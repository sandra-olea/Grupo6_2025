<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TechnicalReviewScoringRule extends Model
{
    use HasFactory;

    protected $fillable = [
        'equipment_type',
        'field_name',
        'condition',
        'points',
        'affects_grade',
        'reasoning',
        'is_active',
    ];

    protected $casts = [
        'condition' => 'array',
        'points' => 'integer',
        'is_active' => 'boolean',
    ];

    /**
     * Scopes
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeForEquipmentType($query, string $equipmentType)
    {
        return $query->where('equipment_type', $equipmentType);
    }

    public function scopePositivePoints($query)
    {
        return $query->where('points', '>', 0);
    }

    public function scopeNegativePoints($query)
    {
        return $query->where('points', '<', 0);
    }
}
