<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WooSyncState extends Model
{
    protected $table = 'woo_sync_states';
    protected $primaryKey = 'integration_id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'integration_id',
        'subsidiary_id',
        'last_order_created_at',
        'last_order_modified_at',
        'last_order_id',
        'last_stock_sync_at',
        'current_batch_id',
        'current_batch_total',
        'current_batch_processed',
        'current_batch_status',
        'current_batch_started_at',
        'current_batch_finished_at',
        'orders_imported_count',
        'orders_updated_count',
    ];

    protected $casts = [
        'last_order_created_at' => 'datetime',
        'last_order_modified_at' => 'datetime',
        'last_stock_sync_at' => 'datetime',
        'current_batch_started_at' => 'datetime',
        'current_batch_finished_at' => 'datetime',
    ];
}
