<?php

namespace App\Models;

use App\Enums\EquipmentStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class EquipmentTraceability extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'equipment_traceability';

    protected $fillable = [
        'review_item_id',
        'serial_number',
        'warehouse_id',
        'warehouse_location',
        'status',
        'quotation_id',
        'sale_id',
        'customer_id',
        'current_responsible_id',
        'notes',
        'received_at',
        'reviewed_at',
        'available_at',
        'sold_at',
    ];

    protected $casts = [
        'status' => EquipmentStatus::class,
        'received_at' => 'datetime',
        'reviewed_at' => 'datetime',
        'available_at' => 'datetime',
        'sold_at' => 'datetime',
    ];

    /**
     * Relación con item de revisión
     */
    public function reviewItem(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewItem::class, 'review_item_id');
    }

    /**
     * Relación con bodega
     */
    public function warehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class);
    }

    /**
     * Relación con cotización
     */
    public function quotation(): BelongsTo
    {
        return $this->belongsTo(Quotation::class);
    }

    /**
     * Relación con venta
     */
    public function sale(): BelongsTo
    {
        return $this->belongsTo(Sale::class);
    }

    /**
     * Cliente asociado (CustomerSale)
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(CustomerSale::class, 'customer_id');
    }

    /**
     * Responsable actual
     */
    public function currentResponsible(): BelongsTo
    {
        return $this->belongsTo(User::class, 'current_responsible_id');
    }

    /**
     * Historial de movimientos
     */
    public function movements(): HasMany
    {
        return $this->hasMany(EquipmentMovement::class, 'traceability_id');
    }

    /**
     * Scopes
     */
    public function scopeInWarehouse($query, int $warehouseId)
    {
        return $query->where('warehouse_id', $warehouseId);
    }

    public function scopeByStatus($query, EquipmentStatus $status)
    {
        return $query->where('status', $status);
    }

    public function scopeAvailableForSale($query)
    {
        return $query->where('status', EquipmentStatus::AVAILABLE_FOR_SALE);
    }

    public function scopeBySerialNumber($query, string $serialNumber)
    {
        return $query->where('serial_number', $serialNumber);
    }
}
