<?php

namespace App\Models;

use App\Enums\BatteryCondition;
use App\Enums\EquipmentCondition;
use App\Enums\KeyboardLayout;
use App\Enums\RamType;
use App\Enums\StorageTechnology;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TechnicalReviewNotebook extends Model
{
    use HasFactory;

    protected $fillable = [
        'review_item_id',
        'brand',
        'model',
        'line',
        'processor',
        'ram_size',
        'ram_slots',
        'ram_type',
        'storage_size',
        'storage_technology',
        'includes_charger',
        'charger_watts',
        'other_includes',
        'general_condition',
        // Conteo de puertos (migración 0063)
        'vga_ports',
        'hdmi_ports',
        'displayport_ports',
        'usb_c_ports',
        'has_biometric',
        'sd_readers',
        'has_wifi',
        'rj45_ports',
        'has_bluetooth',
        'all_ports_functional',
        'usb_a_ports',
        'defective_ports_count',
        'screen_inches',
        'screen_condition',
        'is_touchscreen',
        'keyboard_condition',
        'keyboard_layout',
        'has_numeric_keypad',
        'has_backlit_keyboard',
        'touchpad_condition',
        'cover_condition',
        'hinge_condition',
        'bottom_condition',
        'battery_health',
        'battery_condition',
        'battery_status',
        'battery_percentage',
        'battery_holds_charge',
        'operating_system',
        'observations',
        'extra_attributes',
    ];

    protected $casts = [
        'ram_type' => RamType::class,
        'storage_technology' => StorageTechnology::class,
        'general_condition' => EquipmentCondition::class,
        'screen_condition' => EquipmentCondition::class,
        'keyboard_condition' => EquipmentCondition::class,
        'keyboard_layout' => KeyboardLayout::class,
        'touchpad_condition' => EquipmentCondition::class,
        'cover_condition' => EquipmentCondition::class,
        'hinge_condition' => EquipmentCondition::class,
        'bottom_condition' => EquipmentCondition::class,
        'battery_condition' => BatteryCondition::class,
        'includes_charger' => 'boolean',
        'has_biometric' => 'boolean',
        'has_wifi' => 'boolean',
        'has_bluetooth' => 'boolean',
        'all_ports_functional' => 'boolean',
        'is_touchscreen' => 'boolean',
        'has_numeric_keypad' => 'boolean',
        'has_backlit_keyboard' => 'boolean',
        'battery_holds_charge' => 'boolean',
        'extra_attributes' => 'array',
    ];

    /**
     * Relación con el item principal
     */
    public function reviewItem(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewItem::class, 'review_item_id');
    }

    /**
     * Ocultar campos en la serialización JSON
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'extra_attributes',
    ];

    /**
     * Agregar campos calculados a la serialización
     */
    protected $appends = [
        'charger_status',
    ];

    /**
     * Accessor para charger_status desde extra_attributes
     */
    public function getChargerStatusAttribute()
    {
        return $this->extra_attributes['charger_status'] ?? null;
    }
}
