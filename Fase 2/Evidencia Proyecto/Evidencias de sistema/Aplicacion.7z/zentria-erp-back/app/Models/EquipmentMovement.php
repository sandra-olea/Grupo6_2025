<?php

namespace App\Models;

use App\Enums\MovementType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class EquipmentMovement extends Model
{
    use HasFactory;

    protected $fillable = [
        'traceability_id',
        'serial_number',
        'from_warehouse_id',
        'to_warehouse_id',
        'previous_status',
        'new_status',
        'movement_type',
        'related_document_id',
        'related_document_type',
        'performed_by',
        'reason',
        'metadata',
        'movement_date',
    ];

    protected $casts = [
        'movement_type' => MovementType::class,
        'metadata' => 'array',
        'movement_date' => 'datetime',
    ];

    /**
     * Relación con trazabilidad
     */
    public function traceability(): BelongsTo
    {
        return $this->belongsTo(EquipmentTraceability::class, 'traceability_id');
    }

    /**
     * Bodega origen
     */
    public function fromWarehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class, 'from_warehouse_id');
    }

    /**
     * Bodega destino
     */
    public function toWarehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class, 'to_warehouse_id');
    }

    /**
     * Usuario que realizó el movimiento
     */
    public function performedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'performed_by');
    }

    /**
     * Documento relacionado (polimórfico)
     */
    public function relatedDocument(): MorphTo
    {
        return $this->morphTo(__FUNCTION__, 'related_document_type', 'related_document_id');
    }

    /**
     * Scopes
     */
    public function scopeBySerialNumber($query, string $serialNumber)
    {
        return $query->where('serial_number', $serialNumber);
    }

    public function scopeByMovementType($query, MovementType $type)
    {
        return $query->where('movement_type', $type);
    }

    public function scopeRecent($query, int $days = 30)
    {
        return $query->where('movement_date', '>=', now()->subDays($days));
    }
}
