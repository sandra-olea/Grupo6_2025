<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Warehouse extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'branch_id','name','code','description','address','storage_location','pallet_spot','commune_id',
        'maximum_capacity','schedule','capacity','warehouse_type','manager_id',
        'is_active','requires_serial_tracking',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'requires_serial_tracking' => 'boolean',
    ];

    public function branch(): BelongsTo { return $this->belongsTo(Branch::class); }
    public function manager(): BelongsTo { return $this->belongsTo(User::class, 'manager_id'); }
    public function commune(): BelongsTo { return $this->belongsTo(Commune::class); }
    
    public function products(): BelongsToMany 
    { 
        return $this->belongsToMany(Product::class, 'warehouse_products')
            ->withPivot('quantity', 'sync_stock')
            ->withTimestamps();
    }

    /**
     * Calcula la capacidad actual sumando las cantidades de todos los productos.
     */
    public function getCurrentCapacity(): int
    {
        return $this->products()->sum('warehouse_products.quantity');
    }

    /**
     * Verifica si hay espacio disponible para agregar más productos.
     */
    public function hasCapacityFor(int $quantity): bool
    {
        if ($this->maximum_capacity === null) {
            return true; // Sin límite
        }
        
        return ($this->getCurrentCapacity() + $quantity) <= $this->maximum_capacity;
    }
}
