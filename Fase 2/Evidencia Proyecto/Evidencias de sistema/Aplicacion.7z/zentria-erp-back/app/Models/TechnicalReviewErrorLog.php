<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TechnicalReviewErrorLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'review_item_id',
        'field_name',
        'error_type',
        'invalid_value',
        'suggested_value',
        'was_corrected',
    ];

    protected $casts = [
        'invalid_value' => 'array',
        'suggested_value' => 'array',
        'was_corrected' => 'boolean',
    ];

    /**
     * Usuario que cometió el error
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Item de revisión asociado
     */
    public function reviewItem(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewItem::class, 'review_item_id');
    }

    /**
     * Scopes
     */
    public function scopeByUser($query, int $userId)
    {
        return $query->where('user_id', $userId);
    }

    public function scopeByField($query, string $fieldName)
    {
        return $query->where('field_name', $fieldName);
    }

    public function scopeCorrected($query)
    {
        return $query->where('was_corrected', true);
    }

    public function scopeUncorrected($query)
    {
        return $query->where('was_corrected', false);
    }
}
