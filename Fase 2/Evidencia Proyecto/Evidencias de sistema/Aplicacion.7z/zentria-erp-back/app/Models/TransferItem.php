<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TransferItem extends Model
{
    protected $fillable = [
        'transfer_id', 'origin_product_id', 'destination_product_id', 'quantity',
    ];

    public function transfer(): BelongsTo { return $this->belongsTo(Transfer::class); }
    public function originProduct(): BelongsTo { return $this->belongsTo(Product::class, 'origin_product_id'); }
    public function destinationProduct(): BelongsTo { return $this->belongsTo(Product::class, 'destination_product_id'); }
}

