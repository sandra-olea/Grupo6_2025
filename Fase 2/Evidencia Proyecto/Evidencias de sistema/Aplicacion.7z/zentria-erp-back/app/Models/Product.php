<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use App\Models\Concerns\HasModelImages;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Enums\EquipmentGrade;
use App\Models\TechnicalReviewItem;
use App\Models\ProductSoftHold;

class Product extends Model implements HasMedia
{
    use HasFactory;

    use InteractsWithMedia, HasModelImages;

    protected $fillable = [
        'branch_id','sku','commercial_sku','barcode','name','brand_id',
        'product_type', 'serial_tracking', 'warranty_months','cost',
        'price', 'offer_price', 'product_status',
        'attributes_json','marketplace_external_ids','is_active',
        'short_description','long_description','stock','snippet_description',
        'parent_product_id','grade',
    ];

    protected $casts = [
        'serial_tracking' => 'boolean',
        'is_active' => 'boolean',
        'attributes_json' => 'array', // jsonb -> array
        'marketplace_external_ids' => 'array',
        'cost' => 'decimal:2',
        'price' => 'decimal:2',
        'offer_price' => 'decimal:2',
        'grade' => EquipmentGrade::class,
    ];

    public static function primaryCollection(): string { return 'main'; }

    public function branch(): BelongsTo { return $this->belongsTo(Branch::class); }
    
    public function brand(): BelongsTo { return $this->belongsTo(Brand::class); }

    /**
     * Parent/children relationship for serial-tracked variants per grade
     */
    public function parent(): BelongsTo { return $this->belongsTo(Product::class, 'parent_product_id'); }
    public function children(): HasMany { return $this->hasMany(Product::class, 'parent_product_id'); }

    public function categories()
    {
    return $this->belongsToMany(Category::class, 'product_category')
        ->withPivot(['assigned_at','deleted_at'])
        ->withTimestamps();
    }

    public function warehouses(): BelongsToMany
    {
        return $this->belongsToMany(\App\Models\Warehouse::class, 'warehouse_products')
            ->withPivot('quantity', 'sync_stock')
            ->withTimestamps();
    }

    // Scopes
    public function scopeFromBranch(Builder $q, int|string $branchId): Builder { return $q->where('branch_id', $branchId); }

    public function scopeSearch(Builder $q, ?string $term): Builder {
        if (!$term = trim((string)$term)) return $q;
        // Postgres: ILIKE para case-insensitive
        return $q->where(function($w) use ($term){
            $w->where('name','ILIKE',"%{$term}%")
              ->orWhere('sku','ILIKE',"%{$term}%")
              ->orWhere('barcode','ILIKE',"%{$term}%");
        });
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('main')->singleFile()->useDisk('public');
        $this->addMediaCollection('gallery')->useDisk('public');
    }

    public function registerMediaConversions(\Spatie\MediaLibrary\MediaCollections\Models\Media $media = null): void
    {
        $this->addMediaConversion('thumb')->width(400)->height(400);
        $this->addMediaConversion('web')->format('webp')->width(1200);
    }

    // Normalize empty-like strings to null for description fields
    protected function cleanEmptyString(?string $value): ?string
    {
        if ($value === null) return null;
        // Replace unicode spaces (including NBSP), then trim
        $value = preg_replace('/[\x{00A0}\x{1680}\x{2000}-\x{200B}\x{202F}\x{205F}\x{3000}]+/u', ' ', $value);
        $value = trim($value);
        return $value === '' ? null : $value;
    }

    public function setShortDescriptionAttribute($value): void
    {
        $this->attributes['short_description'] = $this->cleanEmptyString(is_string($value) ? $value : ($value === null ? null : (string)$value));
    }

    public function setLongDescriptionAttribute($value): void
    {
        $this->attributes['long_description'] = $this->cleanEmptyString(is_string($value) ? $value : ($value === null ? null : (string)$value));
    }

    public function setSnippetDescriptionAttribute($value): void
    {
        $this->attributes['snippet_description'] = $this->cleanEmptyString(is_string($value) ? $value : ($value === null ? null : (string)$value));
    }

    /**
     * Relación con items de revisión técnica (series).
     */
    public function technicalReviewItems()
    {
        return $this->hasMany(TechnicalReviewItem::class, 'product_id');
    }

    /**
     * Accessor: Calcula stock dinámicamente.
     * - Si serial_tracking = true: cuenta desde technical_review_items aprobados
     * - Si serial_tracking = false: usa el campo stock de la DB
     */
    public function getStockAttribute($value)
    {
        // Si el producto usa tracking por serie, calcular desde TRI, ajustando por soft holds
        if ($this->serial_tracking) {
            $isChildWithGrade = $this->parent_product_id && $this->grade;
            if ($isChildWithGrade) {
                $available = TechnicalReviewItem::where('product_id', $this->parent_product_id)
                    ->where('review_status', 'approved')
                    ->where('current_status', 'available_for_sale')
                    ->where('grade', $this->grade->value)
                    ->count();
                // Restar soft holds activos del hijo
                $holds = (int) ProductSoftHold::query()
                    ->where('product_id', $this->id)
                    ->where('status', 'active')
                    ->sum('quantity');
                return max(0, $available - $holds);
            }

            // Padre: disponibles totales menos soft holds activos de todos los hijos
            $available = $this->technicalReviewItems()
                ->where('review_status', 'approved')
                ->where('current_status', 'available_for_sale')
                ->count();

            $childIds = $this->children()->pluck('id');
            if ($childIds->isNotEmpty()) {
                $holds = (int) ProductSoftHold::query()
                    ->whereIn('product_id', $childIds)
                    ->where('status', 'active')
                    ->sum('quantity');
                $available = max(0, $available - $holds);
            }

            return (int) $available;
        }

        // Para productos sin serie, usar el valor de la columna stock
        return (int) $value;
    }

    /**
     * Mutator: Prevenir modificación de stock si tiene serial_tracking.
     */
    public function setStockAttribute($value)
    {
        // Si el producto usa tracking por serie, ignorar cualquier intento de setear stock
        if ($this->serial_tracking) {
            return; // No hacer nada, el stock se calcula automáticamente
        }

        // Para productos sin serie, permitir setear el stock normalmente
        $this->attributes['stock'] = (int) $value;
    }

    /**
     * Verifica si el producto tiene stock disponible.
     */
    public function hasAvailableStock(): bool
    {
        return $this->stock > 0;
    }

    /**
     * Obtiene las series disponibles (solo para productos con serial_tracking).
     */
    public function getAvailableSerials()
    {
        if (!$this->serial_tracking) {
            return collect();
        }

        return $this->technicalReviewItems()
            ->where('review_status', 'approved')
            ->where('current_status', 'available_for_sale')
            ->get();
    }

    /**
     * Obtiene los números de serie disponibles para el grado del hijo.
     * Aplica solo cuando el producto es hijo (tiene parent_product_id) y usa tracking por serie.
     * Devuelve una colección de strings (serial_number).
     */
    public function getAvailableSerialNumbersForChildGrade()
    {
        if (!($this->serial_tracking && $this->parent_product_id && $this->grade)) {
            return collect();
        }

        return TechnicalReviewItem::query()
            ->where('product_id', $this->parent_product_id)
            ->where('grade', $this->grade->value)
            ->where('review_status', 'approved')
            ->where('current_status', 'available_for_sale')
            ->orderBy('serial_number')
            ->pluck('serial_number');
    }

    /**
     * Obtiene el conteo de series por estado.
     */
    public function getSerialCountByStatus(): array
    {
        if (!$this->serial_tracking) {
            return [];
        }

        $baseQuery = $this->parent_product_id && $this->grade
            ? TechnicalReviewItem::where('product_id', $this->parent_product_id)
                  ->where('grade', $this->grade->value)
            : $this->technicalReviewItems();

        $available = (clone $baseQuery)
                ->where('review_status', 'approved')
                ->where('current_status', 'available_for_sale')
                ->count();

        // Calcular soft-holds activos
        $holds = 0;
        if ($this->parent_product_id) {
            // Hijo: holds propios
            $holds = (int) ProductSoftHold::query()
                ->where('product_id', $this->id)
                ->where('status', 'active')
                ->sum('quantity');
            $available = max(0, $available - $holds);
        } else {
            // Padre: sumar holds de todos los hijos
            $childIds = $this->children()->pluck('id');
            if ($childIds->isNotEmpty()) {
                $holds = (int) ProductSoftHold::query()
                    ->whereIn('product_id', $childIds)
                    ->where('status', 'active')
                    ->sum('quantity');
                $available = max(0, $available - $holds);
            }
        }

        return [
            'available' => $available,
            'on_hold' => $holds,
            'reserved' => (clone $baseQuery)
                ->where('review_status', 'approved')
                ->where('current_status', 'reserved')
                ->count(),
            'in_quotation' => (clone $baseQuery)
                ->where('review_status', 'approved')
                ->where('current_status', 'in_quotation')
                ->count(),
            'sold' => (clone $baseQuery)
                ->where('current_status', 'sold')
                ->count(),
            'total_approved' => (clone $baseQuery)
                ->where('review_status', 'approved')
                ->count(),
        ];
    }

    /**
     * Valida que una serie específica esté disponible para venta.
     * Útil para el módulo de ventas.
     */
    public function validateSerialForSale(string $serialNumber): bool
    {
        if (!$this->serial_tracking) {
            return false;
        }

        return $this->technicalReviewItems()
            ->where('serial_number', $serialNumber)
            ->where('review_status', 'approved')
            ->where('current_status', 'available_for_sale')
            ->exists();
    }

    protected static function booted(): void
    {
        // Crear hijos A/B/C/M en background al crear un padre con tracking por serie
        static::created(function (Product $p) {
            if ($p->serial_tracking && !$p->parent_product_id) {
                \App\Jobs\CreateSerialChildrenJob::dispatch($p->id)->afterCommit();
            }
        });

        // Propagación de cambios del padre a hijos (excepto precio y oferta)
        static::saved(function (Product $p) {
            if ($p->exists && !$p->parent_product_id) {
                $p->propagateToChildren();
            }
        });
    }

    /**
     * Crea hijos por grado (A/B/C/M) si faltan.
     */
    public function ensureGradeChildren(): void
    {
        $grades = [EquipmentGrade::A, EquipmentGrade::B, EquipmentGrade::C, EquipmentGrade::M];
        $existing = $this->children()->get()->keyBy(fn($c) => (string) $c->grade?->value);

        foreach ($grades as $g) {
            if ($existing->has($g->value)) {
                continue;
            }

            $child = new Product();
            $child->fill([
                'branch_id' => $this->branch_id,
                'parent_product_id' => $this->id,
                'grade' => $g->value,
                'name' => $this->name.' - Grado '.$g->value,
                'sku' => $this->sku ? ($this->sku.'-'.$g->value) : null,
                'commercial_sku' => $this->commercial_sku ? ($this->commercial_sku.'-'.$g->value) : null,
                'barcode' => null,
                'brand_id' => $this->brand_id,
                'product_type' => $this->product_type,
                'serial_tracking' => true,
                'warranty_months' => $this->warranty_months,
                'cost' => $this->cost,
                'product_status' => $this->product_status,
                'attributes_json' => $this->attributes_json,
                'marketplace_external_ids' => null,
                'is_active' => $this->is_active,
                'short_description' => $this->short_description,
                'long_description' => $this->long_description,
                'snippet_description' => $this->snippet_description,
            ]);
            $child->save();

            // Copiar asociaciones de bodegas con quantity 0
            $warehouses = $this->warehouses()->get()->mapWithKeys(function ($w) {
                return [$w->id => ['quantity' => 0, 'sync_stock' => $w->pivot->sync_stock]];
            })->all();
            if (!empty($warehouses)) {
                $child->warehouses()->syncWithoutDetaching($warehouses);
            }
        }
    }

    /**
     * Propaga cambios del padre a sus hijos, exceptuando precio/oferta.
     */
    public function propagateToChildren(): void
    {
        $dirty = $this->getDirty();
        if (empty($dirty)) return;

        $blocked = ['price', 'offer_price', 'id', 'parent_product_id'];
        $fields = array_diff(array_keys($dirty), $blocked);
        if (empty($fields)) return;

        $update = [];
        foreach ($fields as $f) {
            $update[$f] = $this->{$f};
        }

        // Ajustar nombres/sku de hijos que no han personalizado: siempre derivamos con sufijo -Grado/
        $children = $this->children()->get();
        foreach ($children as $c) {
            $payload = $update;
            unset($payload['id'], $payload['parent_product_id']);
            if (array_key_exists('name', $update)) {
                $payload['name'] = $this->name.' - Grado '.($c->grade?->value ?? '');
            }
            if (array_key_exists('sku', $update) && $this->sku) {
                $payload['sku'] = $this->sku.'-'.($c->grade?->value ?? '');
            }
            if (array_key_exists('commercial_sku', $update) && $this->commercial_sku) {
                $payload['commercial_sku'] = $this->commercial_sku.'-'.($c->grade?->value ?? '');
            }
            // No tocar price/offer_price
            $c->fill($payload);
            $c->save();
        }
    }

    /**
     * Marca una serie como vendida y la asocia a una venta.
     * Para usar desde el módulo de ventas.
     */
    public function markSerialAsSold(string $serialNumber, ?int $saleId = null): bool
    {
        if (!$this->serial_tracking) {
            return false;
        }

        $item = $this->technicalReviewItems()
            ->where('serial_number', $serialNumber)
            ->where('review_status', 'approved')
            ->where('current_status', 'available_for_sale')
            ->first();

        if (!$item) {
            return false;
        }

        $item->update([
            'current_status' => 'sold',
            'sale_id' => $saleId,
            'destination' => 'sold_to_final_customer',
        ]);

        return true;
    }

    /**
     * Reserva una serie para una venta (cotización o preventa).
     */
    public function reserveSerial(string $serialNumber, ?int $quoteId = null): bool
    {
        if (!$this->serial_tracking) {
            return false;
        }

        $item = $this->technicalReviewItems()
            ->where('serial_number', $serialNumber)
            ->where('review_status', 'approved')
            ->where('current_status', 'available_for_sale')
            ->first();

        if (!$item) {
            return false;
        }

        $item->update([
            'current_status' => $quoteId ? 'in_quotation' : 'reserved',
        ]);

        return true;
    }

    /**
     * Libera una serie reservada (por ejemplo, si se cancela una cotización).
     */
    public function releaseReservedSerial(string $serialNumber): bool
    {
        if (!$this->serial_tracking) {
            return false;
        }

        $item = $this->technicalReviewItems()
            ->where('serial_number', $serialNumber)
            ->whereIn('current_status', ['reserved', 'in_quotation'])
            ->first();

        if (!$item) {
            return false;
        }

        $item->update([
            'current_status' => 'available_for_sale',
        ]);

        return true;
    }
}
