<?php

namespace App\Models;

use App\Enums\EquipmentCondition;
use App\Enums\RamType;
use App\Enums\StorageTechnology;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TechnicalReviewDesktop extends Model
{
    use HasFactory;

    protected $fillable = [
        'review_item_id',
        'brand',
        'model',
        'line',
        'processor',
        'ram_size',
        'ram_slots',
        'ram_type',
        'storage_size',
        'storage_technology',
        'includes_charger',
        'charger_status',
        'general_condition',
        // Puertos (cantidades) migración 0063
        'vga_ports',
        'hdmi_ports',
        'displayport_ports',
        'usb_c_ports',
        'sd_readers',
        'rj45_ports',
        'has_wifi',
        'has_bluetooth',
        'all_ports_functional',
        'defective_ports_count',
        'has_cd_drive',
        'usb_a_ports',
        'cover_condition',
        'operating_system',
        'observations',
        'extra_attributes',
    ];

    protected $casts = [
        'ram_type' => RamType::class,
        'storage_technology' => StorageTechnology::class,
        'general_condition' => EquipmentCondition::class,
        // Para Desktop usamos tokens específicos: ok, good_condition, light_scratches, noticeable_wear, broken
        'cover_condition' => 'string',
        'includes_charger' => 'boolean',
        'charger_status' => 'string',
        'has_wifi' => 'boolean',
        'has_bluetooth' => 'boolean',
        'all_ports_functional' => 'boolean',
        'has_cd_drive' => 'boolean',
        'extra_attributes' => 'array',
    ];

    public function reviewItem(): BelongsTo
    {
        return $this->belongsTo(TechnicalReviewItem::class, 'review_item_id');
    }

    /**
     * Ocultar campos en la serialización JSON
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'extra_attributes',
    ];
}
