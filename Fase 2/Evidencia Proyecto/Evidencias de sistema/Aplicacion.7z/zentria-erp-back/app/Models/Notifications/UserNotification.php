<?php

namespace App\Models\Notifications;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserNotification extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'user_id', 'event_id', 'status', 'assigned_to', 'delivered_channels', 'read_at', 'ack_at', 'aggregate_count', 'delivered_to_user', 'last_occurred_at',
    ];

    protected $casts = [
        'delivered_channels' => 'array',
        'delivered_to_user' => 'boolean',
        'read_at' => 'datetime',
        'ack_at' => 'datetime',
        'last_occurred_at' => 'datetime',
    ];

    public function event()
    {
        return $this->belongsTo(NotificationEvent::class, 'event_id');
    }

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class, 'user_id');
    }

    public function assignee()
    {
        return $this->belongsTo(\App\Models\User::class, 'assigned_to');
    }
}
