<?php

namespace App\Models\Notifications;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class NotificationType extends Model
{
    protected $fillable = [
        'key', 'module', 'description', 'default_priority', 'default_channels', 'critical', 'enabled_global', 'bucket',
    ];

    protected $casts = [
        'default_channels' => 'array',
        'critical' => 'boolean',
        'enabled_global' => 'boolean',
    ];

    protected $appends = [
        'display_name',
        'module_label',
    ];

    public function events()
    {
        return $this->hasMany(NotificationEvent::class, 'type_id');
    }

    public function roleDefaults()
    {
        return $this->hasMany(RoleNotificationDefault::class, 'notification_type_id');
    }

    public function userPreferences()
    {
        return $this->hasMany(UserNotificationPreference::class, 'notification_type_id');
    }

    public function getDisplayNameAttribute(): string
    {
        $labels = config('notification_labels.types', []);
        $key = (string) $this->key;
        if (isset($labels[$key])) {
            return $labels[$key];
        }

        $formattedKey = str_replace(['.', '-'], ' ', $key);
        return Str::headline($formattedKey);
    }

    public function getModuleLabelAttribute(): string
    {
        $labels = config('notification_labels.modules', []);
        $module = (string) ($this->module ?? '');
        if (isset($labels[$module])) {
            return $labels[$module];
        }
        if ($module === '') {
            return 'General';
        }

        $formattedModule = str_replace(['.', '-', '_'], ' ', $module);
        return Str::headline($formattedModule);
    }
}
