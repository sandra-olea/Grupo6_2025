<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class CustomerSupplier extends Model
{
    protected $fillable = ['subsidiary_id', 'name'];

    /**
     * Un cliente-proveedor pertenece a una subsidiary
     */
    public function subsidiary(): BelongsTo
    {
        return $this->belongsTo(Subsidiary::class);
    }

    /**
     * Un cliente-proveedor puede tener muchos proveedores
     */
    public function suppliers(): BelongsToMany
    {
        return $this->belongsToMany(Supplier::class, 'customer_supplier_supplier')
            ->withTimestamps();
    }
}
