<?php

namespace App\Policies;

use App\Models\TechnicalReviewBatch;
use App\Models\User;

class TechnicalReviewBatchPolicy
{
    /**
     * Determine if the user can view any batches
     */
    public function viewAny(User $user): bool
    {
        return $user->can('view-technical-reviews-batches');
    }

    /**
     * Determine if the user can view the batch
     */
    public function view(User $user, TechnicalReviewBatch $batch): bool
    {
        return $user->can('view-technical-reviews-batches');
    }

    /**
     * Determine if the user can create batches
     */
    public function create(User $user): bool
    {
        return $user->can('create-technical-reviews-batches');
    }

    /**
     * Determine if the user can update the batch
     */
    public function update(User $user, TechnicalReviewBatch $batch): bool
    {
        return $user->can('edit-technical-reviews-batches');
    }

    /**
     * Determine if the user can delete the batch
     */
    public function delete(User $user, TechnicalReviewBatch $batch): bool
    {
        return $user->can('delete-technical-reviews-batches');
    }
}
