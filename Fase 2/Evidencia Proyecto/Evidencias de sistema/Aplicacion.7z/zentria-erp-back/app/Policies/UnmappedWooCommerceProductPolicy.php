<?php

namespace App\Policies;

use App\Models\UnmappedWooCommerceProduct;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class UnmappedWooCommerceProductPolicy
{
    /**
     * Determine whether the user can view any models.
     * Only super_admin can manage unmapped products.
     */
    public function viewAny(User $user): bool
    {
        return $user->hasPermissionTo('unmapped-woocommerce-products.index');
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, UnmappedWooCommerceProduct $unmappedWooCommerceProduct): bool
    {
        return $user->hasPermissionTo('unmapped-woocommerce-products.show');
    }

    /**
     * Determine whether the user can map the model to a product.
     */
    public function map(User $user, UnmappedWooCommerceProduct $unmappedWooCommerceProduct): bool
    {
        return $user->hasPermissionTo('unmapped-woocommerce-products.map');
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, UnmappedWooCommerceProduct $unmappedWooCommerceProduct): bool
    {
        return $user->hasPermissionTo('unmapped-woocommerce-products.delete');
    }
}
