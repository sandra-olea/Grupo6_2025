<?php

namespace App\Policies;

use App\Models\Warehouse;
use App\Models\Branch;
use App\Models\User;

class WarehousePolicy
{
    public function viewAny(User $user, Branch $branch): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->can('view-warehouse') && $user->canAccessEntity('branch', $branch->id);
    }

    public function view(User $user, Warehouse $warehouse): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->can('view-warehouse') && $user->canAccessEntity('branch', $warehouse->branch_id);
    }

    public function create(User $user, Branch $branch): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('create-warehouse') && $user->canAccessEntity('branch', $branch->id);
    }

    public function update(User $user, Warehouse $warehouse): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('edit-warehouse') && $user->canAccessEntity('branch', $warehouse->branch_id);
    }

    public function delete(User $user, Warehouse $warehouse): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('delete-warehouse') && $user->canAccessEntity('branch', $warehouse->branch_id);
    }

    public function viewDetail(User $user, Warehouse $warehouse): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('view-warehouse-detail') && $user->canAccessEntity('branch', $warehouse->branch_id);
    }

    public function attachProduct(User $user, Warehouse $warehouse): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('attach-warehouse-product') && $user->canAccessEntity('branch', $warehouse->branch_id);
    }

    public function detachProduct(User $user, Warehouse $warehouse): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('detach-warehouse-product') && $user->canAccessEntity('branch', $warehouse->branch_id);
    }
}

