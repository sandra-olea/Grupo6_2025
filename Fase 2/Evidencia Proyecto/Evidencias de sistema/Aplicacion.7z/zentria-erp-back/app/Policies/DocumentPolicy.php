<?php

namespace App\Policies;

use App\Models\Document;
use App\Models\Subsidiary;
use App\Models\User;

class DocumentPolicy
{
    public function viewAny(User $user, Subsidiary $subsidiary): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('view-document') && $user->canAccessEntity('subsidiary', $subsidiary->id);
    }

    public function view(User $user, Document $document): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('view-document') && ($document->subsidiary_id ? $user->canAccessEntity('subsidiary', $document->subsidiary_id) : true);
    }

    public function create(User $user, Subsidiary $subsidiary): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('create-document') && $user->canAccessEntity('subsidiary', $subsidiary->id);
    }

    public function update(User $user, Document $document): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('edit-document') && ($document->subsidiary_id ? $user->canAccessEntity('subsidiary', $document->subsidiary_id) : true);
    }

    public function delete(User $user, Document $document): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('delete-document') && ($document->subsidiary_id ? $user->canAccessEntity('subsidiary', $document->subsidiary_id) : true);
    }
}

