<?php

namespace App\Policies;

use App\Models\DocumentType;
use App\Models\User;

class DocumentTypePolicy
{
    public function viewAny(User $user): bool
    {   return $user->hasRole('super-admin') || $user->hasPermissionTo('view-document-type'); }

    public function view(User $user, DocumentType $documentType): bool
    {   return $user->hasRole('super-admin') || $user->hasPermissionTo('view-document-type'); }

    public function create(User $user): bool
    {   return $user->hasRole('super-admin') || $user->hasPermissionTo('create-document-type'); }

    public function update(User $user, DocumentType $documentType): bool
    {   return $user->hasRole('super-admin') || $user->hasPermissionTo('edit-document-type'); }

    public function delete(User $user, DocumentType $documentType): bool
    {   return $user->hasRole('super-admin') || $user->hasPermissionTo('delete-document-type'); }
}

