<?php

namespace App\Policies;

use App\Models\Warranty;
use App\Models\Subsidiary;
use App\Models\User;

class WarrantyPolicy
{
    public function viewAny(User $user, Subsidiary $subsidiary): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('view-warranty') && $user->canAccessEntity('subsidiary', $subsidiary->id);
    }

    public function view(User $user, Warranty $warranty): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('view-warranty') && $user->canAccessEntity('subsidiary', $warranty->subsidiary_id);
    }

    public function create(User $user, Subsidiary $subsidiary): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('create-warranty') && $user->canAccessEntity('subsidiary', $subsidiary->id);
    }

    public function update(User $user, Warranty $warranty): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('edit-warranty') && $user->canAccessEntity('subsidiary', $warranty->subsidiary_id);
    }

    public function delete(User $user, Warranty $warranty): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('delete-warranty') && $user->canAccessEntity('subsidiary', $warranty->subsidiary_id);
    }
}

