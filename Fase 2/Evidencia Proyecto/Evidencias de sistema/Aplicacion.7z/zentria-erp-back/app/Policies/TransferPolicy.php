<?php

namespace App\Policies;

use App\Models\Transfer;
use App\Models\Branch;
use App\Models\User;

class TransferPolicy
{
    public function viewAny(User $user, Branch $branch): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->can('view-transfer') && $user->canAccessEntity('branch', $branch->id);
    }

    public function view(User $user, Transfer $transfer): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->can('view-transfer') && (
            $user->canAccessEntity('branch', $transfer->from_branch_id) ||
            $user->canAccessEntity('branch', $transfer->to_branch_id)
        );
    }

    public function create(User $user, Branch $branch): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('create-transfer') && $user->canAccessEntity('branch', $branch->id);
    }

    public function update(User $user, Transfer $transfer): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('edit-transfer') && (
            $user->canAccessEntity('branch', $transfer->from_branch_id) ||
            $user->canAccessEntity('branch', $transfer->to_branch_id)
        );
    }

    public function delete(User $user, Transfer $transfer): bool
    {
        if ($user->hasRole('super-admin')) return true;
        return $user->hasPermissionTo('delete-transfer') && (
            $user->canAccessEntity('branch', $transfer->from_branch_id) ||
            $user->canAccessEntity('branch', $transfer->to_branch_id)
        );
    }
}

