<?php

namespace App\Policies;

use App\Models\TechnicalReviewItem;
use App\Models\User;

class TechnicalReviewItemPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('view-technical-reviews-items');
    }

    public function view(User $user, TechnicalReviewItem $item): bool
    {
        return $user->can('view-technical-reviews-items');
    }

    public function create(User $user): bool
    {
        return $user->can('create-technical-reviews-items');
    }

    public function update(User $user, TechnicalReviewItem $item): bool
    {
        return $user->can('edit-technical-reviews-items');
    }

    public function delete(User $user, TechnicalReviewItem $item): bool
    {
        return $user->can('delete-technical-reviews-items');
    }

    public function review(User $user, TechnicalReviewItem $item): bool
    {
        return $user->can('review-technical-reviews-items');
    }

    public function approve(User $user, TechnicalReviewItem $item): bool
    {
        return $user->can('approve-technical-reviews-items');
    }
}
