<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class PasswordResetLinkNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public string $resetUrl,
        public ?string $fullName = null,
        public ?int $expiresMinutes = null
    ) {}

    public function via($notifiable): array
    {
        return ['mail'];
    }

    public function toMail($notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Restablecer contraseña - ' . config('app.name'))
            ->markdown('vendor.mail.auth.password-reset', [
                'resetUrl'       => $this->resetUrl,
                'fullName'       => $this->fullName,
                'expiresMinutes' => $this->expiresMinutes,
            ]);
    }
}
