<?php

namespace App\Observers;

use App\Models\Subsidiary;
use App\Models\ScopeRole;
use Illuminate\Support\Facades\Log;

class SubsidiaryObserver
{
    /**
     * Handle the Subsidiary "created" event.
     */
    public function created(Subsidiary $subsidiary): void
    {
        if ($subsidiary->subsidiary_manager_id) {
            $this->assignManagerRole($subsidiary);
        }
    }

    /**
     * Handle the Subsidiary "updated" event.
     */
    public function updated(Subsidiary $subsidiary): void
    {
        // Si cambió el manager_id
        if ($subsidiary->isDirty('subsidiary_manager_id')) {
            $oldManagerId = $subsidiary->getOriginal('subsidiary_manager_id');
            $newManagerId = $subsidiary->subsidiary_manager_id;

            // Remover rol del manager anterior si existía
            if ($oldManagerId) {
                $this->removeManagerRole($subsidiary->id, $oldManagerId);
            }

            // Asignar rol al nuevo manager si existe
            if ($newManagerId) {
                $this->assignManagerRole($subsidiary);
            }
        }
    }

    /**
     * Handle the Subsidiary "deleted" event.
     */
    public function deleted(Subsidiary $subsidiary): void
    {
        // Remover el rol del manager al eliminar la subsidiary
        if ($subsidiary->subsidiary_manager_id) {
            $this->removeManagerRole($subsidiary->id, $subsidiary->subsidiary_manager_id);
        }
    }

    /**
     * Asignar rol de subsidiary-admin y acceso contextual (subsidiary-member) al manager
     */
    private function assignManagerRole(Subsidiary $subsidiary): void
    {
        try {
            // Asignar rol de administrador
            ScopeRole::assignContextRole(
                $subsidiary->subsidiary_manager_id,
                'subsidiary-admin',
                'subsidiary',
                $subsidiary->id
            );
            
            // Asignar acceso contextual (subsidiary-member) para que tenga visibilidad
            ScopeRole::assignContextRole(
                $subsidiary->subsidiary_manager_id,
                'subsidiary-member',
                'subsidiary',
                $subsidiary->id
            );
            
            Log::info("Roles subsidiary-admin y subsidiary-member asignados automáticamente", [
                'subsidiary_id' => $subsidiary->id,
                'user_id' => $subsidiary->subsidiary_manager_id
            ]);
        } catch (\Exception $e) {
            Log::error("Error al asignar roles de subsidiary: " . $e->getMessage());
        }
    }

    /**
     * Remover rol de subsidiary-admin y acceso contextual del manager
     */
    private function removeManagerRole(int $subsidiaryId, int $userId): void
    {
        try {
            // Remover rol de administrador
            ScopeRole::removeContextRole(
                $userId,
                'subsidiary-admin',
                'subsidiary',
                $subsidiaryId
            );
            
            // Remover acceso contextual (subsidiary-member)
            ScopeRole::removeContextRole(
                $userId,
                'subsidiary-member',
                'subsidiary',
                $subsidiaryId
            );
            
            Log::info("Roles subsidiary-admin y subsidiary-member removidos automáticamente", [
                'subsidiary_id' => $subsidiaryId,
                'user_id' => $userId
            ]);
        } catch (\Exception $e) {
            Log::error("Error al remover roles de subsidiary: " . $e->getMessage());
        }
    }
}
