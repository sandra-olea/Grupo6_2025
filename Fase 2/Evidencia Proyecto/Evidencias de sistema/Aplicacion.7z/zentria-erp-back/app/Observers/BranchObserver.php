<?php

namespace App\Observers;

use App\Models\Branch;
use App\Models\ScopeRole;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class BranchObserver
{
    /**
     * Handle the Branch "created" event.
     */
    public function created(Branch $branch): void
    {
        if ($branch->manager_id) {
            $this->assignManagerRole($branch);
        }
    }

    /**
     * Handle the Branch "updated" event.
     */
    public function updated(Branch $branch): void
    {
        // Si cambió el manager_id
        if ($branch->isDirty('manager_id')) {
            $oldManagerId = $branch->getOriginal('manager_id');
            $newManagerId = $branch->manager_id;

            // Remover rol del manager anterior si existía
            if ($oldManagerId) {
                $this->removeManagerRole($branch->id, $oldManagerId);
            }

            // Asignar rol al nuevo manager si existe
            if ($newManagerId) {
                $this->assignManagerRole($branch);
            }
        }
    }

    /**
     * Handle the Branch "deleted" event.
     */
    public function deleted(Branch $branch): void
    {
        // Remover el rol del manager al eliminar la branch
        if ($branch->manager_id) {
            $this->removeManagerRole($branch->id, $branch->manager_id);
        }
    }

    /**
     * Asignar rol de branch-admin y acceso contextual (branch_user pivot) al manager
     */
    private function assignManagerRole(Branch $branch): void
    {
        try {
            // Asignar rol de administrador
            ScopeRole::assignContextRole(
                $branch->manager_id,
                'branch-admin',
                'branch',
                $branch->id
            );
            
            // Asignar acceso contextual mediante pivot branch_user para que tenga visibilidad
            DB::table('branch_user')->updateOrInsert(
                [
                    'branch_id' => $branch->id,
                    'user_id' => $branch->manager_id,
                ],
                [
                    'is_primary' => false,
                    'position' => 'Manager',
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
            
            Log::info("Rol branch-admin y acceso via branch_user asignados automáticamente", [
                'branch_id' => $branch->id,
                'user_id' => $branch->manager_id
            ]);
        } catch (\Exception $e) {
            Log::error("Error al asignar acceso de branch: " . $e->getMessage());
        }
    }

    /**
     * Remover rol de branch-admin y acceso contextual del manager
     */
    private function removeManagerRole(int $branchId, int $userId): void
    {
        try {
            // Remover rol de administrador
            ScopeRole::removeContextRole(
                $userId,
                'branch-admin',
                'branch',
                $branchId
            );
            
            // Remover acceso contextual mediante pivot branch_user
            // Solo removemos si el usuario no tiene otros vínculos importantes con esta branch
            DB::table('branch_user')
                ->where('branch_id', $branchId)
                ->where('user_id', $userId)
                ->where('is_primary', false) // Solo remover si no es su branch principal
                ->delete();
            
            Log::info("Rol branch-admin y acceso via branch_user removidos automáticamente", [
                'branch_id' => $branchId,
                'user_id' => $userId
            ]);
        } catch (\Exception $e) {
            Log::error("Error al remover acceso de branch: " . $e->getMessage());
        }
    }
}
