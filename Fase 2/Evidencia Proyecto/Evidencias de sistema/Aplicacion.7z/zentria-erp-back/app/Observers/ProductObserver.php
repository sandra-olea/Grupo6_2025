<?php

namespace App\Observers;

use App\Models\Product;

class ProductObserver
{
    /**
     * Handle the Product "saving" event.
     * Previene modificación de stock si el producto tiene serial_tracking activado.
     */
    public function saving(Product $product): void
    {
        // Si el producto tiene serial_tracking activado
        if ($product->serial_tracking) {
            // Si se está intentando modificar el stock manualmente
            if ($product->isDirty('stock')) {
                // Revertir el cambio y dejar el valor original
                // (el accessor lo calculará automáticamente desde series)
                $product->stock = $product->getOriginal('stock');
            }
        }
    }

    /**
     * Handle the Product "updating" event.
     * Validación adicional en updates.
     */
    public function updating(Product $product): void
    {
        // Si se está cambiando serial_tracking de false a true
        if ($product->isDirty('serial_tracking') && $product->serial_tracking) {
            // Resetear stock a 0, se calculará desde series
            $product->attributes['stock'] = 0;
        }
    }

    /**
     * Handle the Product "updated" event.
     * Sincroniza automáticamente el stock con las bodegas que tienen sync_stock activado.
     */
    public function updated(Product $product): void
    {
        // Si se activó el seguimiento por serie en un padre, crear hijos en background
        if ($product->wasChanged('serial_tracking') && $product->serial_tracking && !$product->parent_product_id) {
            \App\Jobs\CreateSerialChildrenJob::dispatch($product->id)->afterCommit();
        }

        // Solo proceder si el stock cambió
        if (!$product->wasChanged('stock')) {
            return;
        }

        // Obtener todas las bodegas donde este producto tiene sync_stock = true
        $warehouses = $product->warehouses()
            ->wherePivot('sync_stock', true)
            ->get();

        if ($warehouses->isEmpty()) {
            return;
        }

        // Sincronizar el stock en cada bodega
        foreach ($warehouses as $warehouse) {
            $warehouse->products()->updateExistingPivot($product->id, [
                'quantity' => $product->stock,
            ]);
        }
    }
}
