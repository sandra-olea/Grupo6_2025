<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;

class ChileanRut implements Rule
{
    public function __construct(
        private ?string $documentType = 'rut'
    ) {}

    public function passes($attribute, $value): bool
    {
        // Validate only when documentType is RUT (default)
        $docType = strtolower((string)($this->documentType ?? 'rut'));
        if ($docType !== 'rut') {
            return true; // skip for non-RUT types
        }

        if ($value === null) return false;
        $raw = strtoupper(preg_replace('/[^0-9Kk]/', '', (string)$value));
        if ($raw === '' || strlen($raw) < 2) return false;

        $dv = substr($raw, -1);
        $num = substr($raw, 0, -1);
        if (!ctype_digit($num)) return false;

        $sum = 0; $factor = 2;
        for ($i = strlen($num) - 1; $i >= 0; $i--) {
            $sum += ((int)$num[$i]) * $factor;
            $factor = ($factor === 7) ? 2 : $factor + 1;
        }
        $rest = $sum % 11;
        $calc = 11 - $rest;
        $expected = match ($calc) {
            11 => '0',
            10 => 'K',
            default => (string)$calc,
        };

        return $dv === $expected;
    }

    public function message(): string
    {
        return 'El RUT no es válido.';
    }
}

