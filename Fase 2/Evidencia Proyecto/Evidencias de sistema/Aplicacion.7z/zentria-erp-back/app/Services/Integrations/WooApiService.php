<?php

namespace App\Services\Integrations;

use App\Models\Integration;
use Illuminate\Support\Facades\Http;

class WooApiService
{
    private function base(Integration $integration)
    {
        $base = rtrim((string) $integration->base_url, '/');
        return Http::withBasicAuth((string)$integration->consumer_key, (string)$integration->consumer_secret)
            ->baseUrl($base.'/wp-json/wc/v3')
            ->acceptJson()
            ->asJson();
    }

    public function listOrders(Integration $integration, array $params = []): array
    {
        $defaults = [
            'per_page' => 50,
            'page' => 1,
            'orderby' => 'date',
            'order' => 'asc',
        ];
        $res = $this->base($integration)->get('orders', array_merge($defaults, $params));
        if (!$res->successful()) {
            throw new \RuntimeException('Woo orders fetch failed: '.$res->status().' '.$res->body());
        }
        return $res->json();
    }

    /**
     * Fetch orders and return both data and response headers for pagination totals.
     * @return array{data: array, headers: array}
     */
    public function listOrdersWithMeta(Integration $integration, array $params = []): array
    {
        $defaults = [
            'per_page' => 50,
            'page' => 1,
            'orderby' => 'date',
            'order' => 'asc',
        ];
        $res = $this->base($integration)->get('orders', array_merge($defaults, $params));
        if (!$res->successful()) {
            throw new \RuntimeException('Woo orders fetch failed: '.$res->status().' '.$res->body());
        }
        return [
            'data' => $res->json(),
            'headers' => $res->headers(),
        ];
    }

    public function getOrder(Integration $integration, int $orderId): array
    {
        $res = $this->base($integration)->get('orders/'.$orderId);
        if (!$res->successful()) {
            throw new \RuntimeException('Woo order fetch failed: '.$res->status().' '.$res->body());
        }
        return $res->json();
    }

    public function findProductBySku(Integration $integration, string $sku): ?array
    {
        $res = $this->base($integration)->get('products', ['sku' => $sku, 'per_page' => 1]);
        if (!$res->successful()) { return null; }
        $arr = $res->json();
        if (is_array($arr) && count($arr) > 0) return $arr[0];
        return null;
    }

    public function updateProductStock(Integration $integration, int $productId, int $qty): array
    {
        $payload = [
            'manage_stock' => true,
            'stock_quantity' => $qty,
            'stock_status' => $qty > 0 ? 'instock' : 'outofstock',
        ];
        $res = $this->base($integration)->put('products/'.$productId, $payload);
        if (!$res->successful()) {
            throw new \RuntimeException('Woo product stock update failed: '.$res->status().' '.$res->body());
        }
        return $res->json();
    }

    public function updateVariationStock(Integration $integration, int $productId, int $variationId, int $qty): array
    {
        $payload = [
            'manage_stock' => true,
            'stock_quantity' => $qty,
            'stock_status' => $qty > 0 ? 'instock' : 'outofstock',
        ];
        $res = $this->base($integration)->put("products/{$productId}/variations/{$variationId}", $payload);
        if (!$res->successful()) {
            throw new \RuntimeException('Woo variation stock update failed: '.$res->status().' '.$res->body());
        }
        return $res->json();
    }
}
