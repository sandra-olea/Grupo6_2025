<?php

namespace App\Services\Integrations;

use App\Models\CustomerSale;
use App\Models\Commune;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\UnmappedWooCommerceProduct;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use App\Traits\DispatchesNotifications;
use Illuminate\Support\Facades\Log;

class WooOrderIngestService
{
    use DispatchesNotifications;
    public function ingest(int $subsidiaryId, string $integrationId, array $order, bool $suppressSaleNotifications = false): array
    {
        return DB::transaction(function () use ($subsidiaryId, $integrationId, $order) {
            $customerId = $this->upsertCustomer($subsidiaryId, $order);
            [$sale, $created, $oldStatus, $newStatus] = $this->upsertSale($subsidiaryId, $customerId, $order);
            $this->syncSaleItems($sale, $order, $integrationId);

            // Dispatch notifications (created / status changed)
            try {
                $scope = ['company_id' => null, 'subsidiary_id' => $sale->subsidiary_id, 'branch_id' => null];
                $channel = ($sale->wc_order_id || $sale->wc_order_number || $sale->woo_metadata) ? 'WooCommerce' : 'ERP';
                if ($created && !$suppressSaleNotifications) {
                    $this->dispatchNotification(
                        typeKey: 'sale.created',
                        entityType: 'sale',
                        entityId: $sale->id,
                        scope: $scope,
                        payload: [
                            'sale_id' => $sale->id,
                            'sale_number' => $sale->sale_number,
                            'wc_order_id' => $sale->wc_order_id,
                            'channel' => $channel,
                            'total_amount' => (string) $sale->total_amount,
                            'currency' => $sale->currency,
                        ]
                    );
                }
                if ($oldStatus !== null && $oldStatus !== $newStatus && !$suppressSaleNotifications) {
                    $this->dispatchNotification(
                        typeKey: 'sale.status-changed',
                        entityType: 'sale',
                        entityId: $sale->id,
                        scope: $scope,
                        payload: [
                            'sale_id' => $sale->id,
                            'sale_number' => $sale->sale_number,
                            'wc_order_id' => $sale->wc_order_id,
                            'channel' => $channel,
                            'old_status' => $oldStatus,
                            'new_status' => $newStatus,
                        ]
                    );
                }
            } catch (\Throwable $e) {}

            return ['sale_id' => $sale->id, 'created' => $created, 'old_status' => $oldStatus, 'new_status' => $newStatus];
        });
    }

    private function upsertCustomer(int $subsidiaryId, array $order): int
    {
        $billing = $order['billing'] ?? [];
        $meta = $order['meta_data'] ?? [];

        $rut = $this->extractRut($billing, $meta);
        $email = (string) ($billing['email'] ?? '');
        $company = trim((string) ($billing['company'] ?? '')) ?: null;
        $contact = trim(((string) ($billing['first_name'] ?? '')) . ' ' . ((string) ($billing['last_name'] ?? '')));
        $type = $company ? 'company' : 'natural';

        // Normalize RUT and apply safe fallback (max 20 chars)
        $rut = $this->normalizeRut($rut);
        if (!$rut) {
            // Use predictable guest key with order id to keep <= 20 chars
            $rut = 'guest-'.((string)($order['id'] ?? '0'));
        }
        // Enforce max length 20 for DB constraint
        $rut = substr($rut, 0, 20);
        if (!$email) { $email = 'guest+'.$order['id'].'@example.local'; }

        // Map communes from plugin state codes or city when possible
        $billingCommuneId = $this->resolveCommuneIdFromBilling($billing);
        $shippingCommuneId = $this->resolveCommuneIdFromBilling((array)($order['shipping'] ?? []));

        $defaults = [
            'type' => $type,
            'billing_company' => $company,
            'contact_name' => $company ? null : ($contact ?: null),
            'email' => $email,
            'phone' => $billing['phone'] ?? null,
            'billing_address_1' => $billing['address_1'] ?? null,
            'billing_address_2' => $billing['address_2'] ?? null,
            'billing_city' => $billing['city'] ?? null,
            'commune_id' => $billingCommuneId,
            'billing_state_code' => $billing['state'] ?? null,
            'billing_postcode' => $billing['postcode'] ?? null,
            'billing_country_code' => $billing['country'] ?? 'CL',
            'shipping_address_1' => ($order['shipping']['address_1'] ?? null),
            'shipping_address_2' => ($order['shipping']['address_2'] ?? null),
            'shipping_city' => ($order['shipping']['city'] ?? null),
            'shipping_commune_id' => $shippingCommuneId,
            'shipping_state_code' => ($order['shipping']['state'] ?? null),
            'shipping_postcode' => ($order['shipping']['postcode'] ?? null),
            'shipping_country_code' => ($order['shipping']['country'] ?? 'CL'),
            'default_document_type' => $company ? 'factura' : 'boleta',
            'preferred_payment_method' => $order['payment_method_title'] ?? null,
            'commercial_data' => [
                'woo_customer_id' => $order['customer_id'] ?? null,
                'guest' => ($order['customer_id'] ?? 0) == 0,
                'source' => 'woocommerce',
            ],
            'is_active' => true,
        ];

        /** @var CustomerSale $customer */
        $customer = CustomerSale::query()
            ->where('subsidiary_id', $subsidiaryId)
            ->where('rut', $rut)
            ->first();

        if ($customer) {
            $customer->fill($defaults);
            $customer->save();
        } else {
            $customer = CustomerSale::create(array_merge($defaults, [
                'subsidiary_id' => $subsidiaryId,
                'rut' => $rut,
            ]));
        }

        return (int) $customer->id;
    }

    /**
     * Resolve commune_id from Woo billing/shipping payload.
     * Supports plugin state codes like CL_142 using stored mapping file.
     */
    private function resolveCommuneIdFromBilling(array $addr): ?int
    {
        $state = trim((string) ($addr['state'] ?? ''));
        $city = trim((string) ($addr['city'] ?? ''));

        $communeName = null;
        if ($state !== '' && preg_match('/^CL_\d+$/', $state)) {
            $communeName = $this->lookupPluginCommuneName($state);
        }
        if (!$communeName && $city !== '') {
            $communeName = $city;
        }
        if (!$communeName) return null;

        $id = Commune::query()->where('name', 'ILIKE', $communeName)->value('id');
        if ($id) return (int) $id;
        $norm = preg_replace('/\s+/', ' ', mb_strtolower($communeName));
        $id = Commune::query()->whereRaw('LOWER(name) = ?', [$norm])->value('id');
        return $id ? (int) $id : null;
    }

    private function lookupPluginCommuneName(string $code): ?string
    {
        try {
            $path = storage_path('app/public/resources/communes.php');
            if (!is_file($path)) return null;
            // The included file defines $states
            $states = [];
            include $path;
            if (isset($states['CL'][$code])) {
                return (string) $states['CL'][$code];
            }
        } catch (\Throwable $e) {}
        return null;
    }

    private function upsertSale(int $subsidiaryId, int $customerId, array $order): array
    {
        $wcId = (int) ($order['id'] ?? 0);
        $wcNumber = (string) ($order['number'] ?? '');
        $wooStatusRaw = (string) ($order['status'] ?? 'pending');
        $status = $this->mapStatus($wooStatusRaw);
        $currency = (string) ($order['currency'] ?? 'CLP');

        $subtotal = $this->toDec($order['subtotal'] ?? null);
        // Woo usual: subtotal no viene en raíz o puede venir 0; sumamos desde line_items cuando corresponda
        if ($subtotal === null || $subtotal <= 0) {
            $items = $order['line_items'] ?? [];
            if (!empty($items)) {
                $subtotal = collect($items)->sum(function ($li) { return $this->toDec($li['subtotal'] ?? '0'); });
            } else {
                $subtotal = 0.0;
            }
        }
        $total = $this->toDec($order['total'] ?? '0');
        $discountTotal = $this->toDec($order['discount_total'] ?? '0');
        $taxTotal = $this->toDec($order['total_tax'] ?? '0');
        $shipping = $this->toDec($order['shipping_total'] ?? '0');

        $sale = Sale::query()
            ->where('subsidiary_id', $subsidiaryId)
            ->where('wc_order_id', $wcId)
            ->first();

        $oldStatus = $sale?->status;
        $existingDocMeta = (array) ($sale?->documents_metadata ?? []);

        // Extract payment information for Webpay Plus and compute paid/pending
        $webpayPayment = $this->extractWebpayPayment($order);
        $paidAmount = 0.0;
        if ($webpayPayment && isset($webpayPayment['paid_amount'])) {
            $paidAmount = (float) $webpayPayment['paid_amount'];
        }

        // If Transbank (Webpay Plus) authorized and fully covers the total, force status to 'paid'
        if ($webpayPayment && ($webpayPayment['authorized'] ?? false)) {
            $t = (float) $total;
            if ($t > 0 && $paidAmount >= ($t - 0.01)) {
                $status = 'paid';
            }
        }
        $payload = [
            'subsidiary_id' => $subsidiaryId,
            'customer_id' => $customerId,
            'wc_order_id' => $wcId,
            'wc_order_number' => $wcNumber ?: null,
            'sale_number' => $wcNumber ? ('W'.$wcNumber) : ('W'.$wcId),
            'status' => $status,
            'salesperson_id' => null, // nullable; podría configurarse desde integration params en el futuro
            'sale_date' => $this->parseDate($order['date_created'] ?? null) ?: now()->toDateString(),
            'subtotal' => $subtotal,
            'discount_amount' => $discountTotal,
            'tax_amount' => $taxTotal,
            'shipping_amount' => $shipping,
            'total_amount' => $total,
            'paid_amount' => $paidAmount,
            'pending_amount' => max(0.0, $total - $paidAmount),
            'currency' => $currency,
            'billing_snapshot' => $order['billing'] ?? null,
            'shipping_snapshot' => $order['shipping'] ?? null,
            'payment_method' => $order['payment_method'] ?? null,
            'payment_method_title' => $order['payment_method_title'] ?? null,
            'woo_metadata' => [
                'status' => $wooStatusRaw,
                'meta_data' => $order['meta_data'] ?? null,
                'fee_lines' => $order['fee_lines'] ?? null,
            ],
            // Merge existing documents_metadata but overwrite 'payment' node when applicable
            'documents_metadata' => array_merge($existingDocMeta, $webpayPayment ? ['payment' => $webpayPayment] : []),
        ];

        if ($sale) {
            // Detectar cambios reales en campos núcleo (evitar contar metadatos volátiles)
            $coreKeys = [
                'status','subtotal','discount_amount','tax_amount','shipping_amount','total_amount','paid_amount','pending_amount','wc_order_number'
            ];
            $coreChanged = false;
            foreach ($coreKeys as $k) {
                $newVal = $payload[$k] ?? null;
                $oldVal = $sale->{$k};
                // Comparación numérica para montos, string para otros
                if (in_array($k, ['subtotal','discount_amount','tax_amount','shipping_amount','total_amount','paid_amount','pending_amount'], true)) {
                    if ((float) $oldVal !== (float) $newVal) { $coreChanged = true; break; }
                } else {
                    if ((string) $oldVal !== (string) $newVal) { $coreChanged = true; break; }
                }
            }

            $sale->fill($payload);
            $sale->save();
            $created = false;
            $changed = $coreChanged || ($sale->wasChanged('status'));
        } else {
            $sale = Sale::create($payload);
            $created = true;
            $changed = true;
        }

        return [$sale, $created, $oldStatus, $status, 'changed' => $changed];
    }

    private function syncSaleItems(Sale $sale, array $order, string $integrationId): void
    {
        $items = $order['line_items'] ?? [];
        foreach ($items as $li) {
            $extId = (int) ($li['id'] ?? 0);
            $sku = (string) ($li['sku'] ?? '');
            $externalProductId = (int)($li['product_id'] ?? 0);
            $externalVariationId = (int)($li['variation_id'] ?? 0);
            
            $productId = $this->resolveProductId(
                $sale, 
                $integrationId, 
                $externalProductId, 
                $externalVariationId, 
                $sku, 
                $li
            );

            $data = [
                'product_id' => $productId,
                'quantity' => (int) ($li['quantity'] ?? 0),
                'unit_price' => $this->toDec($li['price'] ?? '0'),
                'subtotal' => $this->toDec($li['subtotal'] ?? '0'),
                'total' => $this->toDec($li['total'] ?? '0'),
                'discount_amount' => max(0, $this->toDec($li['subtotal'] ?? '0') - $this->toDec($li['total'] ?? '0')),
                'meta_json' => [
                    'name' => $li['name'] ?? null,
                    'meta_data' => $li['meta_data'] ?? [],
                    'mapping' => [
                        'resolved_by' => $productId ? 'id-or-sku' : 'unmapped',
                        'sku' => $sku,
                        'external_product_id' => $externalProductId,
                        'external_variation_id' => $externalVariationId,
                    ],
                ],
            ];

            // Debug log for mapping resolution
            try {
                Log::info('Woo ingest item mapping', [
                    'sale_id' => $sale->id,
                    'external_line_id' => $extId,
                    'external_product_id' => $externalProductId,
                    'external_variation_id' => $externalVariationId,
                    'sku_original' => $sku,
                    'sku_normalized' => $this->normalizeSku($sku),
                    'resolved_product_id' => $productId,
                ]);
            } catch (\Throwable $e) {}

            /** @var SaleItem $item */
            $item = SaleItem::query()
                ->where('sale_id', $sale->id)
                ->where('external_line_id', $extId)
                ->first();
            if ($item) {
                $item->fill($data);
                $item->save();
            } else {
                SaleItem::create(array_merge($data, [
                    'sale_id' => $sale->id,
                    'external_line_id' => $extId ?: null,
                ]));
            }

            // Fallback guard: ensure an unmapped record exists when product couldn't be resolved
            if (!$productId) {
                $this->createUnmappedProduct(
                    $sale,
                    $integrationId,
                    $externalProductId,
                    $externalVariationId,
                    $sku,
                    $li
                );
            }
        }

        // Incluir fee_lines como items de venta (sin product_id)
        $fees = $order['fee_lines'] ?? [];
        foreach ($fees as $fee) {
            $extId = (int) ($fee['id'] ?? 0);
            $name = (string) ($fee['name'] ?? 'Cargo adicional');
            $total = $this->toDec($fee['total'] ?? '0');
            $totalTax = $this->toDec($fee['total_tax'] ?? '0');

            // En Woo, fee total suele venir ya integrado al total del pedido.
            // Almacenar como item con cantidad 1 y precios iguales a total.
            $data = [
                'product_id' => null,
                'quantity' => 1,
                'unit_price' => $total,
                'subtotal' => $total,
                'total' => $total,
                'discount_amount' => 0,
                'meta_json' => [
                    'name' => $name,
                    'meta_data' => $fee['meta_data'] ?? [],
                    'mapping' => [
                        'resolved_by' => 'fee_line',
                        'sku' => null,
                        'external_product_id' => null,
                        'external_variation_id' => null,
                        'total_tax' => $totalTax,
                    ],
                ],
            ];

            /** @var SaleItem $existing */
            $existing = SaleItem::query()
                ->where('sale_id', $sale->id)
                ->where('external_line_id', $extId)
                ->first();
            if ($existing) {
                $existing->fill($data)->save();
            } else {
                SaleItem::create(array_merge($data, [
                    'sale_id' => $sale->id,
                    'external_line_id' => $extId ?: null,
                ]));
            }
        }
    }

    /**
     * Resolve product preferring stored external IDs; if missing, resolve by SKU and persist mapping.
     * NEVER maps to parent products with serial_tracking=true; creates unmapped record instead.
     */
    private function resolveProductId(
        Sale $sale,
        string $integrationId, 
        int $externalProductId, 
        int $externalVariationId, 
        ?string $sku,
        array $lineItemData
    ): ?int
    {
        // 1) Try by stored external_product_id in marketplace_external_ids->woocommerce
        if ($externalProductId > 0) {
            $id = Product::query()
                ->whereRaw("(marketplace_external_ids->'woocommerce'->>'external_product_id')::bigint = ?", [$externalProductId])
                ->value('id');
            if ($id) return (int) $id;
        }

        // 2) Try by SKU (child or parent), case-insensitive
        $id = $this->resolveProductIdBySku($sku);
        if ($id) {
            // Check if it's a parent with serial_tracking
            /** @var Product $p */
            $p = Product::query()->find($id);
            if ($p && $p->serial_tracking && !$p->parent_product_id) {
                // This is a PARENT with serial tracking - do NOT auto-map
                // Create unmapped record instead
                $this->createUnmappedProduct(
                    $sale,
                    $integrationId,
                    $externalProductId,
                    $externalVariationId,
                    $sku,
                    $lineItemData
                );
                
                Log::info('WooCommerce: Skipped auto-mapping to parent with serial_tracking', [
                    'product_id' => $p->id,
                    'sku' => $p->sku,
                    'sale_id' => $sale->id,
                    'external_product_id' => $externalProductId,
                ]);
                
                return null; // No product_id for this sale item
            }

            // It's a child or non-serial-tracked product, proceed with mapping
            if ($p) {
                $meta = $p->marketplace_external_ids ?? [];
                $woo = $meta['woocommerce'] ?? [];
                $changed = false;
                if ($externalProductId > 0 && ($woo['external_product_id'] ?? null) != $externalProductId) {
                    $woo['external_product_id'] = $externalProductId;
                    $changed = true;
                }
                if ($externalVariationId > 0 && ($woo['external_variation_id'] ?? null) != $externalVariationId) {
                    $woo['external_variation_id'] = $externalVariationId;
                    $changed = true;
                }
                if ($changed) {
                    $woo['last_seen_at'] = now()->toISOString();
                    $woo['integration_hint'] = $integrationId;
                    $meta['woocommerce'] = $woo;
                    $p->marketplace_external_ids = $meta;
                    $p->save();
                }
            }
            return (int) $id;
        }

        // 3) No product found - create unmapped record
        $this->createUnmappedProduct(
            $sale,
            $integrationId,
            $externalProductId,
            $externalVariationId,
            $sku,
            $lineItemData
        );

        return null;
    }

    /**
     * Create an unmapped WooCommerce product record for manual mapping later
     */
    private function createUnmappedProduct(
        Sale $sale,
        string $integrationId,
        int $externalProductId,
        int $externalVariationId,
        ?string $sku,
        array $lineItemData
    ): void
    {
        try {
            // Compute match_key: prefer SKU; else normalized name
            $rawSku = (string) ($sku ?? '');
            $normalizedSku = $this->normalizeSku($rawSku);
            $rawName = (string) ($lineItemData['name'] ?? '');
            $normalizedName = trim(preg_replace('/\s+/', ' ', mb_strtolower($rawName)) ?? '');
            $matchKey = null;
            if ($normalizedSku !== '') {
                $matchKey = 'sku:'.$normalizedSku;
            } elseif ($normalizedName !== '') {
                $matchKey = 'name:'.$normalizedName;
            }

            // Build payload; avoid including optional columns if not present
            $payload = [
                'sale_id' => $sale->id,
                'external_line_id' => (int)($lineItemData['id'] ?? 0) ?: null,
                'name' => $lineItemData['name'] ?? null,
                'price' => $this->toDec($lineItemData['price'] ?? 0),
                'quantity' => (int)($lineItemData['quantity'] ?? 1),
                'line_item_data' => json_encode($lineItemData),
                'wc_order_id' => $sale->wc_order_id,
                'resolution_status' => 'pending',
                'updated_at' => now(),
                'created_at' => now(),
            ];
            // Some environments may not have run the migration that adds match_key yet
            try {
                if (\Illuminate\Support\Facades\Schema::hasColumn('unmapped_woocommerce_products', 'match_key')) {
                    $payload['match_key'] = $matchKey;
                }
            } catch (\Throwable $e) { /* schema check failed in some contexts; ignore */ }

            // Use query builder to avoid fillable restrictions
            \DB::table('unmapped_woocommerce_products')->updateOrInsert(
                [
                    'integration_id' => $integrationId,
                    'external_product_id' => $externalProductId ?: null,
                    'external_variation_id' => $externalVariationId ?: null,
                    'sku' => $sku,
                ],
                $payload
            );
        } catch (\Throwable $e) {
            Log::error('Failed to create unmapped WooCommerce product', [
                'error' => $e->getMessage(),
                'sale_id' => $sale->id,
                'sku' => $sku,
                'external_product_id' => $externalProductId,
            ]);
        }
    }

    /**
     * Resolve local product_id by SKU (child or parent), case-insensitive; fallback tries commercial_sku.
     */
    private function resolveProductIdBySku(?string $sku): ?int
    {
        $sku = $this->normalizeSku($sku);
        if ($sku === '') return null;

        // Exact match first
        $id = Product::query()->where('sku', $sku)->value('id');
        if ($id) return (int)$id;

        // Case-insensitive match
        $id = Product::query()
            ->whereRaw('LOWER(sku) = ?', [mb_strtolower($sku)])
            ->value('id');
        if ($id) return (int)$id;

        // Try commercial_sku as alternative field
        $id = Product::query()->where('commercial_sku', $sku)->value('id');
        if ($id) return (int)$id;
        $id = Product::query()
            ->whereRaw('LOWER(commercial_sku) = ?', [mb_strtolower($sku)])
            ->value('id');
        if ($id) return (int)$id;

        return null;
    }

    private function normalizeSku(?string $sku): string
    {
        $s = (string)$sku;
        // Remove spaces and NBSP, trim, keep case as-is for exact match then try lower()
        $s = str_replace(["\xC2\xA0", ' '], '', $s); // NBSP and spaces
        return trim($s);
    }

    private function mapStatus(string $woo): string
    {
        return match ($woo) {
            'pending','on-hold' => 'confirmed',
            'processing' => 'partially_paid',
            'completed' => 'paid',
            'cancelled','failed' => 'cancelled',
            'refunded' => 'refunded',
            default => 'confirmed',
        };
    }

    private function parseDate($value): ?string
    {
        if (!$value) return null;
        try { return Carbon::parse($value)->toDateString(); } catch (\Throwable $e) { return null; }
    }

    private function toDec($value): float
    {
        if ($value === null || $value === '') return 0.0;
        return (float) $value;
    }

    private function toInt($value): ?int
    {
        if ($value === null || $value === '') return null;
        return (int) $value;
    }

    /**
     * Extract Webpay Plus payment information from Woo order meta.
     * Only applies for payment_method "webpay_plus" or when Webpay-specific keys exist.
     */
    private function extractWebpayPayment(array $order): ?array
    {
        $method = (string) ($order['payment_method'] ?? '');
        $meta = (array) ($order['meta_data'] ?? []);

        $hasWebpayMeta = false;
        foreach ($meta as $m) {
            $k = (string) (Arr::get($m, 'key') ?? '');
            if (in_array($k, ['transactionResponse','authorizationCode','transactionStatus','webpay_transaction_id','amount','paymentType','cardNumber','buyOrder','installmentsNumber'], true)) {
                $hasWebpayMeta = true; break;
            }
        }
        if ($method !== 'webpay_plus' && !$hasWebpayMeta) {
            return null;
        }

        $amountRaw = $this->findMeta($meta, ['amount']);
        $authorizationCode = $this->findMeta($meta, ['authorizationCode']);
        $transactionStatus = $this->findMeta($meta, ['transactionStatus']);
        $paymentType = $this->findMeta($meta, ['paymentType']);
        $cardLast4 = $this->findMeta($meta, ['cardNumber']);
        $transactionDate = $this->findMeta($meta, ['transactionDate']);
        $webpayTxId = $this->findMeta($meta, ['webpay_transaction_id']);
        $buyOrder = $this->findMeta($meta, ['buyOrder']);
        $installmentsNumber = $this->findMeta($meta, ['installmentsNumber']);
        $responseJson = $this->findMeta($meta, ['transactionResponse']);

        $response = null;
        if ($responseJson) {
            try { $response = json_decode((string)$responseJson, true); } catch (\Throwable $e) { $response = null; }
        }

        // Determine if payment is authorized
        $authorized = false;
        if ($transactionStatus) {
            $ts = mb_strtolower($transactionStatus);
            $authorized = in_array($ts, ['autorizada','authorized','autorizado','authorize'], true);
        }
        if (!$authorized && is_array($response)) {
            $code = (int) ($response['responseCode'] ?? 999);
            $status = (string) ($response['status'] ?? '');
            if ($code === 0 && mb_strtoupper($status) === 'AUTHORIZED') { $authorized = true; }
        }

        // Amount handling (CLP integer typical). Fallback to order total if authorized but amount absent
        $total = $this->toDec($order['total'] ?? 0);
        $amount = $amountRaw !== null ? (float) $amountRaw : (float) ($response['amount'] ?? 0);
        if ($amount <= 0 && $authorized) { $amount = $total; }
        if ($amount > 0) { $amount = round($amount, 2); }

        $paidAmount = $authorized ? min($amount > 0 ? $amount : $total, $total) : 0.0;

        return [
            'gateway' => 'webpay_plus',
            'authorized' => $authorized,
            'paid_amount' => $paidAmount,
            'confirmed_amount' => $amount > 0 ? $amount : null,
            'currency' => (string) ($order['currency'] ?? 'CLP'),
            'authorization_code' => $authorizationCode ?: ($response['authorizationCode'] ?? null),
            'payment_type' => $paymentType ?: ($response['paymentTypeCode'] ?? null),
            'card_last4' => $cardLast4 ?: (is_array($response['cardDetail'] ?? null) ? ($response['cardDetail']['card_number'] ?? null) : ($response['cardNumber'] ?? null)),
            'installments_number' => $this->toInt($installmentsNumber ?? ($response['installmentsNumber'] ?? null)),
            'transaction_status' => $transactionStatus ?: ($response['status'] ?? null),
            'transaction_date' => $this->normalizeDateTime($transactionDate ?: ($response['transactionDate'] ?? null)),
            'webpay_transaction_id' => $webpayTxId ?: null,
            'buy_order' => $buyOrder ?: ($response['buyOrder'] ?? null),
            'raw_response' => $response ?: null,
        ];
    }

    private function extractRut(array $billing, array $meta): ?string
    {
        $candidates = [
            $billing['rut'] ?? null,
            $this->findMeta($meta, ['billing_rut','_billing_rut','rut','RUT','woocommerce_rut']),
        ];
        foreach ($candidates as $c) {
            if ($c && trim((string)$c) !== '') {
                return strtoupper(str_replace(['.',' '],'', (string)$c));
            }
        }
        return null;
    }

    private function normalizeRut(?string $rut): ?string
    {
        if (!$rut) return null;
        $r = strtoupper(str_replace(['.', ' '], '', trim((string)$rut)));
        return $r === '' ? null : $r;
    }

    private function findMeta(array $meta, array $keys): ?string
    {
        foreach ($meta as $m) {
            $key = Arr::get($m, 'key');
            $val = Arr::get($m, 'value');
            if (in_array($key, $keys, true) && $val) return (string) $val;
        }
        return null;
    }

    private function normalizeDateTime($value): ?string
    {
        if (!$value) return null;
        try { return Carbon::parse($value)->toIso8601String(); } catch (\Throwable $e) { return null; }
    }
}
