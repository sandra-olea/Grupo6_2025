<?php

namespace App\Services\Integrations;

use App\Models\Integration;
use App\Models\WooSyncState;
use Illuminate\Support\Facades\Log;

class WooIncrementalImportService
{
    public function __construct(
        private WooApiService $api,
        private WooOrderIngestService $ingest,
    ) {}

    public function importMissing(Integration $integration): array
    {
        $state = WooSyncState::firstOrCreate([
            'integration_id' => $integration->id,
        ], [
            'subsidiary_id' => $integration->subsidiary_id,
        ]);

        $after = $state->last_order_created_at?->toIso8601String();
        $page = 1;
        $imported = 0; $updatedCursor = $state->last_order_created_at;

        do {
            $params = ['page' => $page, 'per_page' => 50];
            if ($after) { $params['after'] = $after; }
            $orders = $this->api->listOrders($integration, $params);
            foreach ($orders as $o) {
                try {
                    $res = $this->ingest->ingest((int)$integration->subsidiary_id, $integration->id, $o);
                    $imported++;
                    $createdAt = $o['date_created_gmt'] ?? ($o['date_created'] ?? null);
                    if ($createdAt) {
                        $dt = \Carbon\Carbon::parse($createdAt);
                        if (!$updatedCursor || $dt->gt($updatedCursor)) { $updatedCursor = $dt; }
                    }
                } catch (\Throwable $e) {
                    Log::warning('Woo incremental import failed for order', [
                        'integration_id' => $integration->id,
                        'order_id' => $o['id'] ?? null,
                        'error' => $e->getMessage(),
                    ]);
                }
            }
            $page++;
        } while (!empty($orders) && count($orders) === 50);

        if ($updatedCursor) {
            $state->last_order_created_at = $updatedCursor;
            $state->last_order_id = null; // we use date cursor
            $state->save();
        }

        return ['imported' => $imported, 'after' => $after, 'new_cursor' => $updatedCursor?->toIso8601String()];
    }
}

