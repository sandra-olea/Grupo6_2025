<?php

namespace App\Services\Integrations;

use App\Models\Branch;
use App\Models\Integration;
use App\Models\Product;
use Illuminate\Support\Facades\Log;

class WooStockSyncService
{
    public function __construct(private WooApiService $api) {}

    public function syncSubsidiaryStock(Integration $integration, ?array $filterSkus = null): array
    {
        $branchIds = Branch::where('subsidiary_id', $integration->subsidiary_id)->pluck('id');
        $q = Product::query()->whereIn('branch_id', $branchIds);
        if ($filterSkus && count($filterSkus) > 0) {
            $q->whereIn('sku', $filterSkus);
        }
        $products = $q->get();

        $updated = 0; $matchedBy = ['id' => 0, 'sku' => 0]; $skipped = 0; $errors = [];

        foreach ($products as $p) {
            try {
                $qty = (int) $p->stock; // uses model accessor for serial-tracked products
                $meta = $p->marketplace_external_ids ?? [];
                $woo = $meta['woocommerce'] ?? [];

                $prodId = $woo['external_product_id'] ?? null;
                $varId = $woo['external_variation_id'] ?? null;

                if ($prodId) {
                    if ($varId) {
                        $this->api->updateVariationStock($integration, (int)$prodId, (int)$varId, $qty);
                    } else {
                        $this->api->updateProductStock($integration, (int)$prodId, $qty);
                    }
                    $updated++; $matchedBy['id']++;
                    continue;
                }

                // Try to match by SKU
                $sku = $p->sku ?: $p->commercial_sku;
                if (!$sku) { $skipped++; continue; }
                $remote = $this->api->findProductBySku($integration, $sku);
                if (!$remote) { $skipped++; continue; }

                // Determine if variation
                $remoteType = $remote['type'] ?? '';
                if ($remoteType === 'variation') {
                    $parentId = (int) ($remote['parent_id'] ?? 0);
                    $variationId = (int) ($remote['id'] ?? 0);
                    if ($parentId && $variationId) {
                        $this->api->updateVariationStock($integration, $parentId, $variationId, $qty);
                        $this->persistMapping($p, $parentId, $variationId, $integration->id);
                        $updated++; $matchedBy['sku']++;
                        continue;
                    }
                }
                // Simple product
                $remoteId = (int) ($remote['id'] ?? 0);
                if ($remoteId) {
                    $this->api->updateProductStock($integration, $remoteId, $qty);
                    $this->persistMapping($p, $remoteId, null, $integration->id);
                    $updated++; $matchedBy['sku']++;
                } else {
                    $skipped++;
                }
            } catch (\Throwable $e) {
                $errors[] = ['product_id' => $p->id, 'sku' => $p->sku, 'error' => $e->getMessage()];
                Log::warning('Woo stock sync failed for product', end($errors));
            }
        }

        return compact('updated', 'matchedBy', 'skipped', 'errors');
    }

    private function persistMapping(Product $p, int $productId, ?int $variationId, string $integrationId): void
    {
        try {
            $meta = $p->marketplace_external_ids ?? [];
            $woo = $meta['woocommerce'] ?? [];
            $woo['external_product_id'] = $productId;
            if ($variationId) { $woo['external_variation_id'] = $variationId; }
            $woo['last_seen_at'] = now()->toIso8601String();
            $woo['integration_hint'] = $integrationId;
            $meta['woocommerce'] = $woo;
            $p->marketplace_external_ids = $meta;
            $p->save();
        } catch (\Throwable $e) {}
    }
}

