<?php

namespace App\Services;

class BatteryNormalizationService
{
    /**
     * Normaliza el valor de batería a porcentaje y estado
     *
     * @param string $batteryInput Puede ser "81%", "GOOD", "EXCELLENT", "FAIR", etc.
     * @return array
     */
    public function normalize(string $batteryInput): array
    {
        $input = strtoupper(trim($batteryInput));

        // Caso 1: Es un porcentaje (81%, 50, 90%)
        if (preg_match('/^(\d+)%?$/', $input, $matches)) {
            $percentage = (int)$matches[1];
            return [
                'percentage' => $percentage,
                'status' => $this->percentageToStatus($percentage),
                'original' => $batteryInput,
            ];
        }

        // Caso 2: Es un estado cualitativo (EXCELLENT, GOOD, FAIR, POOR)
        $statusMap = [
            'EXCELLENT' => 85,
            'GOOD' => 70,
            'FAIR' => 50,
            'POOR' => 25,
            'BAD' => 10,
        ];

        foreach ($statusMap as $status => $estimatedPercentage) {
            if (str_contains($input, $status)) {
                return [
                    'percentage' => $estimatedPercentage,
                    'status' => strtolower($status),
                    'original' => $batteryInput,
                ];
            }
        }

        // Caso 3: No se pudo determinar
        return [
            'percentage' => null,
            'status' => 'unknown',
            'original' => $batteryInput,
        ];
    }

    /**
     * Convierte porcentaje a estado cualitativo
     */
    private function percentageToStatus(int $percentage): string
    {
        return match(true) {
            $percentage >= 80 => 'excellent',
            $percentage >= 60 => 'good',
            $percentage >= 40 => 'fair',
            $percentage > 0 => 'poor',
            default => 'no_battery',
        };
    }

    /**
     * Determina si la batería cumple con el requisito de vida útil para una categoría
     */
    public function meetsLifeRequirement(int $percentage, string $categoryTarget): bool
    {
        return match($categoryTarget) {
            'A', 'B' => $percentage > 50,
            'C' => $percentage > 0,
            default => false,
        };
    }
}
