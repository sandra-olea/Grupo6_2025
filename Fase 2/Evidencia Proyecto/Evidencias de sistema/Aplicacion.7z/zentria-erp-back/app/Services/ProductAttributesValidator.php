<?php

namespace App\Services;

use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class ProductAttributesValidator
{
    /**
     * Valores permitidos para cada campo (estos deberían venir de la hoja de Excel)
     */
    protected array $allowedValues = [];

    /**
     * Carga los valores permitidos desde la hoja de Excel de validaciones
     *
     * @param array $validationSheet Hoja de Excel con valores permitidos
     */
    public function loadAllowedValues(array $validationSheet): void
    {
        // Aquí procesaremos la hoja de validaciones
        // Por ahora lo dejamos vacío, lo implementaremos después
        $this->allowedValues = $validationSheet;
    }

    /**
     * Valida atributos JSON para producto tipo Notebook
     *
     * @param array|string $attributes
     * @param bool $skipPreprocessing Si es true, asume que ya fue sanitizado y normalizado
     * @return array
     * @throws ValidationException
     */
    public function validateNotebookAttributes($attributes, bool $skipPreprocessing = false): array
    {
        // Si es string, decodificar
        if (is_string($attributes)) {
            $attributes = json_decode($attributes, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ValidationException::withMessages([
                    'attributes_json' => ['El JSON no es válido: ' . json_last_error_msg()]
                ]);
            }
        }

        // Si no se debe saltar el preprocesamiento, sanitizar y normalizar
        if (!$skipPreprocessing) {
            $attributes = $this->sanitizeAttributes($attributes);
            $attributes = $this->normalizeAttributes($attributes);
        }

        // Reglas de validación para Notebook (basadas en constantes del frontend)
        $rules = [
            // Packaging
            'packaging' => 'nullable|array',
            'packaging.charger_included' => 'nullable|boolean',
            'packaging.charger_type' => 'nullable|string|in:original,genérico,no aplica',

            // OS
            'os' => 'nullable|array',
            'os.name' => 'nullable|string|in:Windows,Ubuntu,Linux,No OS',
            'os.version' => 'nullable|string',
            'os.license_type' => 'nullable|string|in:digital,OEM,sticker,none,sin licencia',

            // CPU (legacy - para retrocompatibilidad)
            'CPU' => 'nullable|string',

            // RAM (legacy - para retrocompatibilidad)
            'RAM' => 'nullable|string',

            // CPU (nuevo formato)
            'cpu' => 'nullable|array',
            'cpu.brand' => 'nullable|string|in:Intel,AMD',
            'cpu.model' => 'nullable|string',
            'cpu.family' => 'nullable|string',
            'cpu.generation' => 'nullable|string',

            // GPU
            'gpu' => 'nullable|array',
            'gpu.type' => 'nullable|string|in:integrated,discrete',
            'gpu.model' => 'nullable|string',

            // RAM (nuevo formato)
            'ram' => 'nullable|array',
            'ram.type' => 'nullable|string|in:DDR3,DDR3L,DDR4,DDR5',
            'ram.channel' => 'nullable|string|in:single,dual,quad',
            'ram.modules' => 'nullable|integer|in:1,2,3,4',
            'ram.upgradable' => 'nullable|boolean',
            'ram.capacity_gb' => 'nullable|integer|in:4,8,16,24,32,40,48,56,64',
            'ram.max_supported_gb' => 'nullable|integer',

            // Grade (categoría de calidad)
            'grade' => 'nullable|string|in:A,B,C,M',
            'category_grade' => 'nullable|string|in:A,B,C,M',

            // Display
            'display' => 'nullable|array',
            'display.panel' => 'nullable|string|in:TN,VA,IPS,OLED',
            'display.touch' => 'nullable|boolean',
            'display.resolution' => 'nullable|string|in:1366x768,1600x900,1920x1080,2560x1440,3840x2160',
            'display.size_inches' => 'nullable|numeric|in:12.5,13.3,14.0,15.6,17.3',
            'display.refresh_rate' => 'nullable|integer|in:60,75,120,144',
            'display.aspect_ratio' => 'nullable|string|in:16:9,16:10,21:9',

            // Storage
            'storage' => 'nullable|array',
            'storage.config' => 'nullable|string|in:single,hybrid',
            'storage.primary' => 'nullable|array',
            'storage.primary.type' => 'nullable|string|in:NVMe,SSD SATA,HDD,SSD_SATA',
            'storage.primary.capacity_gb' => 'nullable|integer|in:64,128,240,256,500,512,1000,2000,4000',
            'storage.secondary' => 'nullable|array',
            'storage.secondary.type' => 'nullable|string|in:NVMe,SSD SATA,HDD,SSD_SATA',
            'storage.secondary.capacity_gb' => 'nullable|integer|in:64,128,240,256,500,512,1000,2000,4000',
            'storage.upgradable' => 'nullable|boolean',
            'storage.available_slots' => 'nullable|array',
            'storage.available_slots.m2' => 'nullable|integer|min:0',
            'storage.available_slots.sata' => 'nullable|integer|min:0',
            'storage.max_supported_gb' => 'nullable|integer',

            // Connectivity
            'connectivity' => 'nullable|array',
            'connectivity.wifi' => 'nullable|string|in:802.11n,802.11ac,802.11ax,USB/PCIe opcional,N/A',
            'connectivity.ethernet' => 'nullable|string|in:100 Mbps,1GbE,2.5GbE',
            'connectivity.bluetooth' => 'nullable|string|in:4.0,4.2,5.0,5.1,N/A',

            // Product kind
            'product_kind' => 'nullable|string|in:notebook,desktop_pc,aio,monitor',

            // Keyboard (para notebooks)
            'keyboard' => 'nullable|array',
            'keyboard.layout' => 'nullable|string|in:ES-LA,EN-US,FR,DE',
            'keyboard.backlit' => 'nullable|boolean',

            // Camera
            'camera' => 'nullable|array',
            'camera.available' => 'nullable|boolean',
            'camera.resolution_mp' => 'nullable|numeric|in:0.9,1.0,1.3,2.0',
        ];

        $validator = Validator::make($attributes, $rules);

        if ($validator->fails()) {
            throw new ValidationException($validator);
        }

        return $validator->validated();
    }

    /**
     * Valida que los valores estén en la lista permitida de la hoja de Excel
     *
     * @param array $attributes
     * @param string $productType
     * @return array Lista de errores encontrados
     */
    public function validateAgainstAllowedValues(array $attributes, string $productType = 'notebook'): array
    {
        $errors = [];

        // Si no hay valores permitidos cargados, no validar
        if (empty($this->allowedValues)) {
            return $errors;
        }

        // Aquí validaríamos contra la hoja de Excel
        // Por ahora retornamos vacío
        // TODO: Implementar validación contra allowed values

        return $errors;
    }

    /**
     * Sanitiza y normaliza atributos
     *
     * @param array $attributes
     * @return array
     */
    public function sanitizeAttributes(array $attributes): array
    {
        // Convertir strings booleanos
        array_walk_recursive($attributes, function (&$value) {
            if (is_string($value)) {
                $lower = strtolower($value);
                if ($lower === 'true' || $lower === 'yes' || $lower === 'si' || $lower === '1') {
                    $value = true;
                } elseif ($lower === 'false' || $lower === 'no' || $lower === '0') {
                    $value = false;
                }
            }
        });

        return $attributes;
    }

    /**
     * Convierte formato antiguo a nuevo formato
     *
     * @param array $attributes
     * @return array
     */
    public function normalizeAttributes(array $attributes): array
    {
        // Si tiene CPU (string) y no tiene cpu (array), convertir
        if (isset($attributes['CPU']) && !isset($attributes['cpu'])) {
            $attributes['cpu'] = [
                'model' => $attributes['CPU']
            ];
        }

        // Si tiene RAM (string) y no tiene ram (array), convertir
        if (isset($attributes['RAM']) && !isset($attributes['ram']['capacity_gb'])) {
            // Extraer número de GB (ej: "16 GB" -> 16)
            preg_match('/(\d+)\s*GB/i', $attributes['RAM'], $matches);
            if (!empty($matches[1])) {
                $attributes['ram']['capacity_gb'] = (int)$matches[1];
            }
        }

        return $attributes;
    }

    /**
     * Valida y procesa atributos completos
     *
     * @param array|string $attributes
     * @param string $productType
     * @return array
     * @throws ValidationException
     */
    public function validateAndProcess($attributes, string $productType = 'notebook'): array
    {
        // Si es string, decodificar
        if (is_string($attributes)) {
            $attributes = json_decode($attributes, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw ValidationException::withMessages([
                    'attributes_json' => ['El JSON no es válido: ' . json_last_error_msg()]
                ]);
            }
        }

        // IMPORTANTE: Sanitizar y normalizar ANTES de validar
        $attributes = $this->sanitizeAttributes($attributes);
        $attributes = $this->normalizeAttributes($attributes);

        // Ahora validar estructura según tipo de producto
        // Pasamos skipPreprocessing=true porque ya sanitizamos y normalizamos arriba
        switch ($productType) {
            case 'notebook':
                $validated = $this->validateNotebookAttributes($attributes, true);
                break;
            default:
                throw new \InvalidArgumentException("Tipo de producto no soportado: {$productType}");
        }

        // Validar contra valores permitidos (si están cargados)
        $allowedErrors = $this->validateAgainstAllowedValues($validated, $productType);
        if (!empty($allowedErrors)) {
            throw ValidationException::withMessages([
                'attributes_json' => $allowedErrors
            ]);
        }

        return $validated;
    }
}
