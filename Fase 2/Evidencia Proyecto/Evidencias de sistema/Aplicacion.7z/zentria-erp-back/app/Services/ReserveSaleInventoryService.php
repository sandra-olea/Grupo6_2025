<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\TechnicalReviewItem;
use App\Traits\DispatchesNotifications;
use Illuminate\Support\Arr;

class ReserveSaleInventoryService
{
    use DispatchesNotifications;

    public function __construct() {}

    /**
     * Reserve inventory (series) for all items in a sale. Idempotent.
     * - For serial-tracked children by grade: reserves available series from parent product.
     * - Marks shortages in item meta_json.reservation and sets sale.inventory_reserved.
     */
    public function reserve(Sale $sale): void
    {
        $sale->loadMissing(['items.product']);

        $anyShortage = false;

        /** @var SaleItem $item */
        foreach ($sale->items as $item) {
            $meta = $item->meta_json ?? [];
            $res = $meta['reservation'] ?? [];

            $product = $item->product;
            if ($product && $product->serial_tracking) {
                // SOFT-HOLD ÚNICO PARA PRODUCTOS CON SERIE (no seleccionar series ahora)
                $requestedQty = (int) $item->quantity;

                // Buscar cualquier hold previo (activo o liberado) por sale_item_id
                $existingHold = \App\Models\ProductSoftHold::query()
                    ->where('sale_item_id', $item->id)
                    ->first();

                // Compute approved available TRI for visibility/shortage (padre + grado del hijo)
                $parentId = $product->parent_product_id ?: $product->id;
                $ids = array_values(array_unique(array_filter([$parentId])));
                $grade = $product->grade?->value;

                $qAvail = TechnicalReviewItem::query()
                    ->whereIn('product_id', $ids)
                    ->where('review_status', 'approved')
                    ->where('current_status', 'available_for_sale');
                if ($grade) { $qAvail->where('grade', $grade); }
                $approvedAvailable = (int) $qAvail->count();

                // Holds ya activos en el mismo hijo (excluye el propio sale_item)
                $holdsOthers = (int) \App\Models\ProductSoftHold::query()
                    ->where('product_id', $product->id)
                    ->where('status', 'active')
                    ->where('sale_item_id', '!=', $item->id)
                    ->sum('quantity');

                $capacity = max(0, $approvedAvailable - $holdsOthers);
                $desiredHold = min($requestedQty, $capacity);

                // Upsert idempotente por sale_item_id (re-activa si estaba released)
                \App\Models\ProductSoftHold::updateOrCreate(
                    ['sale_item_id' => $item->id],
                    [
                        'product_id' => $product->id,
                        'sale_id' => $sale->id,
                        'quantity' => $desiredHold,
                        'status' => 'active',
                    ]
                );

                $shortage = max(0, $requestedQty - $desiredHold);
                if ($shortage > 0) { $anyShortage = true; }

                Arr::set($res, 'requested_qty', $requestedQty);
                Arr::set($res, 'hold_qty', $desiredHold);
                Arr::set($res, 'shortage_qty', $shortage);
                Arr::set($res, 'checked_at', now()->toISOString());

                // Notificar stock en cero solo una vez por sale_item
                $zeroNotified = (bool) Arr::get($res, 'zero_notified', false);
                $remainingAfter = max(0, $approvedAvailable - ($holdsOthers + $desiredHold));
                if (!$zeroNotified && $capacity > 0 && $remainingAfter === 0) {
                    try {
                        $this->dispatchNotification(
                            typeKey: 'product.stock-zero',
                            entityType: 'product',
                            entityId: $product->id,
                            scope: ['company_id' => null, 'subsidiary_id' => $sale->subsidiary_id, 'branch_id' => null],
                            payload: [
                                'product_id' => $product->id,
                                'product_name' => $product->name,
                                'sku' => $product->sku,
                            ],
                            priority: null,
                            dedupKey: 'product.stock-zero:'.$product->id
                        );
                        Arr::set($res, 'zero_notified', true);
                    } catch (\Throwable $e) {}
                }

                Arr::set($meta, 'reservation', $res);
                $item->meta_json = $meta;
                $item->save();

                // Log resumido del hold
                try {
                    \Log::info('ReserveService item summary', [
                        'sale_id' => $sale->id,
                        'sale_number' => $sale->sale_number,
                        'product_id' => $product->id,
                        'parent_id' => $product->parent_product_id,
                        'grade' => $product->grade?->value,
                        'requested' => $requestedQty,
                        'hold_now' => $desiredHold,
                        'shortage' => $shortage,
                    ]);
                } catch (\Throwable $e) {}

                continue; // siguiente item
            }

            if (!$product || !$product->serial_tracking) {
                // Non-serial: reservar descontando stock de Product.stock de forma idempotente
                if ($product && !$product->serial_tracking) {
                    $alreadyNonSerial = (int) Arr::get($res, 'nonserial.reserved_qty', 0);
                    $requested = (int) $item->quantity;
                    $needed = max(0, $requested - $alreadyNonSerial);

                    $availableBefore = max(0, (int) $product->stock);
                    $toReserve = min($needed, $availableBefore);

                    if ($toReserve > 0) {
                        // Descontar y acumular en meta
                        $product->decrement('stock', $toReserve);
                        Arr::set($res, 'nonserial.reserved_qty', $alreadyNonSerial + $toReserve);
                    }

                    $reservedNonSerial = (int) Arr::get($res, 'nonserial.reserved_qty', 0);
                    $shortage = max(0, $requested - $reservedNonSerial);
                    if ($shortage > 0) { $anyShortage = true; }

                    Arr::set($res, 'requested_qty', $requested);
                    Arr::set($res, 'reserved_qty', $reservedNonSerial);
                    Arr::set($res, 'shortage_qty', $shortage);
                    Arr::set($res, 'checked_at', now()->toISOString());
                    Arr::set($meta, 'reservation', $res);
                    $item->meta_json = $meta;
                    $item->save();
                }
                continue;
            }
        }

        $sale->inventory_reserved = !$anyShortage;
        $sale->save();

        if ($anyShortage) {
            // Dispatch shortage notification
            try {
                $this->dispatchNotification(
                    typeKey: 'sale.stock-shortage',
                    entityType: 'sale',
                    entityId: $sale->id,
                    scope: ['company_id' => null, 'subsidiary_id' => $sale->subsidiary_id, 'branch_id' => null],
                    payload: [
                        'sale_id' => $sale->id,
                        'sale_number' => $sale->sale_number,
                        'wc_order_id' => $sale->wc_order_id,
                        'channel' => ($sale->wc_order_id || $sale->wc_order_number || $sale->woo_metadata) ? 'WooCommerce' : 'ERP',
                        'message' => 'Faltante de stock al reservar venta',
                    ]
                );
            } catch (\Throwable $e) {}
        }
    }

    /**
     * Release previously reserved inventory (series) for a sale. Idempotent.
     * Used when Woo order goes to cancelled/refunded.
     */
    public function release(Sale $sale): void
    {
        $sale->loadMissing(['items.product']);

        /** @var SaleItem $item */
        foreach ($sale->items as $item) {
            $meta = $item->meta_json ?? [];
            $res = $meta['reservation'] ?? [];
            $product = $item->product;

            // Non-serial: reponer stock reservado/vendido
            if ($product && !$product->serial_tracking) {
                $reservedQty = (int) Arr::get($res, 'nonserial.reserved_qty', 0);
                $soldQty = (int) Arr::get($res, 'nonserial.sold_qty', 0);
                $toRestore = $reservedQty + $soldQty;
                if ($toRestore > 0) {
                    $product->increment('stock', $toRestore);
                }
                Arr::set($res, 'nonserial.reserved_qty', 0);
                Arr::set($res, 'nonserial.sold_qty', 0);
            }

            // Serial-tracked: liberar soft-holds (no mover estados de series aquí)
            if ($product && $product->serial_tracking) {
                \App\Models\ProductSoftHold::query()
                    ->where('sale_id', $sale->id)
                    ->where('sale_item_id', $item->id)
                    ->where('status', 'active')
                    ->update(['status' => 'released']);

                $requested = (int) ($res['requested_qty'] ?? $item->quantity ?? 0);
                Arr::set($res, 'hold_qty', 0);
                Arr::set($res, 'shortage_qty', $requested); // quedará pendiente para una futura reserva
                Arr::set($res, 'checked_at', now()->toISOString());
                Arr::set($meta, 'reservation', $res);
                $item->meta_json = $meta;
                $item->save();
            }
        }

        // Marca la venta como no reservada
        $sale->inventory_reserved = false;
        $sale->save();
    }

    /**
     * Mark reserved inventory as SOLD for a sale. Idempotent.
     */
    public function sell(Sale $sale): void
    {
        $sale->loadMissing(['items.product']);

        /** @var SaleItem $item */
        foreach ($sale->items as $item) {
            $meta = $item->meta_json ?? [];
            $res = $meta['reservation'] ?? [];
            $product = $item->product;

            // Para serial-tracking aún no vendemos series aquí; se hará cuando se asigne N° de serie.
            // Para no-serial, consolidar reservado -> vendido en meta
            if ($product && !$product->serial_tracking) {
                $alreadyNonSerial = (int) Arr::get($res, 'nonserial.reserved_qty', 0);
                $soldQty = (int) Arr::get($res, 'nonserial.sold_qty', 0);
                if ($alreadyNonSerial > 0) {
                    Arr::set($res, 'nonserial.sold_qty', $soldQty + $alreadyNonSerial);
                    Arr::set($meta, 'reservation', $res);
                    $item->meta_json = $meta;
                    $item->save();
                }
            }
        }
    }
}
