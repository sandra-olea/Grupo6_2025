<?php

namespace App\Services;

use App\Enums\EquipmentStatus;
use App\Enums\MovementType;
use App\Exceptions\InvalidStatusTransitionException;
use App\Models\EquipmentMovement;
use App\Models\EquipmentTraceability;
use App\Models\TechnicalReviewItem;
use Illuminate\Support\Facades\DB;

class EquipmentTraceabilityService
{
    /**
     * Inicializa trazabilidad cuando se ingresa un equipo
     */
    public function initializeTraceability(TechnicalReviewItem $item): EquipmentTraceability
    {
        return DB::transaction(function () use ($item) {
            $traceability = EquipmentTraceability::create([
                'review_item_id' => $item->id,
                'serial_number' => $item->serial_number,
                'warehouse_id' => $item->warehouse_id,
                'status' => EquipmentStatus::RECEIVED,
                'current_responsible_id' => auth()->id(),
                'received_at' => now(),
            ]);

            $this->recordMovement(
                $traceability,
                MovementType::ENTRY,
                null,
                EquipmentStatus::RECEIVED,
                'Ingreso inicial a bodega'
            );

            return $traceability;
        });
    }

    /**
     * Cambia el estado del equipo con validación
     */
    public function changeStatus(
        EquipmentTraceability $traceability,
        EquipmentStatus $newStatus,
        string $reason = null,
        array $metadata = []
    ): void {
        $currentStatus = $traceability->status;

        if (!$currentStatus->canTransitionTo($newStatus)) {
            throw new InvalidStatusTransitionException(
                "No se puede cambiar de {$currentStatus->label()} a {$newStatus->label()}"
            );
        }

        DB::transaction(function () use ($traceability, $currentStatus, $newStatus, $reason, $metadata) {
            $updates = ['status' => $newStatus];

            match($newStatus) {
                EquipmentStatus::IN_REVIEW => $updates['received_at'] = $updates['received_at'] ?? now(),
                EquipmentStatus::REVIEWED => $updates['reviewed_at'] = now(),
                EquipmentStatus::AVAILABLE_FOR_SALE => $updates['available_at'] = now(),
                EquipmentStatus::SOLD => $updates['sold_at'] = now(),
                default => null,
            };

            $traceability->update($updates);
            $traceability->reviewItem->update(['current_status' => $newStatus]);

            $this->recordMovement(
                $traceability,
                MovementType::STATUS_CHANGE,
                $currentStatus,
                $newStatus,
                $reason ?? "Cambio de estado: {$currentStatus->label()} → {$newStatus->label()}",
                $metadata
            );
        });
    }

    /**
     * Transferir equipo entre bodegas
     */
    public function transferWarehouse(
        EquipmentTraceability $traceability,
        int $toWarehouseId,
        string $reason = null,
        string $location = null
    ): void {
        DB::transaction(function () use ($traceability, $toWarehouseId, $reason, $location) {
            $fromWarehouseId = $traceability->warehouse_id;

            $traceability->update([
                'warehouse_id' => $toWarehouseId,
                'warehouse_location' => $location,
            ]);

            $traceability->reviewItem->update(['warehouse_id' => $toWarehouseId]);

            $this->recordMovement(
                $traceability,
                MovementType::WAREHOUSE_TRANSFER,
                $traceability->status,
                $traceability->status,
                $reason ?? 'Transferencia entre bodegas',
                ['location' => $location],
                relatedDocumentId: null,
                relatedDocumentType: null,
                fromWarehouseId: $fromWarehouseId,
                toWarehouseId: $toWarehouseId
            );
        });
    }

    /**
     * Registrar venta del equipo
     */
    public function markAsSold(
        EquipmentTraceability $traceability,
        int $saleId,
        int $customerId
    ): void {
        DB::transaction(function () use ($traceability, $saleId, $customerId) {
            $previousStatus = $traceability->status;
            $traceability->update([
                'status' => EquipmentStatus::SOLD,
                'sale_id' => $saleId,
                'quotation_id' => null,
                'customer_id' => $customerId,
                'sold_at' => now(),
            ]);

            $traceability->reviewItem->update([
                'current_status' => EquipmentStatus::SOLD,
                'sale_id' => $saleId,
            ]);

            $this->recordMovement(
                $traceability,
                MovementType::SALE,
                $previousStatus,
                EquipmentStatus::SOLD,
                'Equipo vendido',
                ['sale_id' => $saleId, 'customer_id' => $customerId],
                $saleId,
                'App\Models\Sale'
            );
        });
    }

    /**
     * Registrar un movimiento en el historial
     */
    private function recordMovement(
        EquipmentTraceability $traceability,
        MovementType $movementType,
        ?EquipmentStatus $previousStatus,
        EquipmentStatus $newStatus,
        string $reason,
        array $metadata = [],
        ?int $relatedDocumentId = null,
        ?string $relatedDocumentType = null,
        ?int $fromWarehouseId = null,
        ?int $toWarehouseId = null
    ): EquipmentMovement {
        return EquipmentMovement::create([
            'traceability_id' => $traceability->id,
            'serial_number' => $traceability->serial_number,
            'from_warehouse_id' => $fromWarehouseId ?? $traceability->warehouse_id,
            'to_warehouse_id' => $toWarehouseId ?? $traceability->warehouse_id,
            'previous_status' => $previousStatus?->value,
            'new_status' => $newStatus->value,
            'movement_type' => $movementType,
            'related_document_id' => $relatedDocumentId,
            'related_document_type' => $relatedDocumentType,
            'performed_by' => auth()->id(),
            'reason' => $reason,
            'metadata' => $metadata,
            'movement_date' => now(),
        ]);
    }

    /**
     * Obtener historial completo de un equipo
     */
    public function getHistory(string $serialNumber): array
    {
        $traceability = EquipmentTraceability::where('serial_number', $serialNumber)
            ->with(['reviewItem', 'warehouse', 'customer', 'sale'])
            ->firstOrFail();

        $movements = EquipmentMovement::where('serial_number', $serialNumber)
            ->with(['fromWarehouse', 'toWarehouse', 'performedBy'])
            ->orderBy('movement_date', 'desc')
            ->get();

        return [
            'current_status' => $traceability,
            'history' => $movements,
        ];
    }
}
