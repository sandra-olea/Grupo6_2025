<?php

namespace App\Services;

use App\Enums\EquipmentGrade;
use App\Enums\EquipmentType;
use App\Models\TechnicalReviewItem;
use App\Models\TechnicalReviewScoringRule;

class TechnicalReviewScoringService
{
    private const BASELINE_SCORE = 50;

    private array $scores = [];
    private array $reasoning = [];
    private array $categoryScores = [
        'aesthetic' => 0,
        'functionality' => 0,
        'battery' => 0,
    ];
    private ?EquipmentGrade $maxAllowedGrade = null;

    public function __construct(
        private BatteryNormalizationService $batteryService
    ) {}

    /**
     * Calcula el grado automáticamente basado en criterios de reacondicionados
     */
    public function calculateGrade(TechnicalReviewItem $item): array
    {
        $this->scores = [];
        $this->reasoning = [];
        $this->categoryScores = [
            'aesthetic' => 0,
            'functionality' => 0,
            'battery' => 0,
        ];
        $this->maxAllowedGrade = null;

        $details = $item->details;
        if (!$details) {
            return $this->buildResponse(null, 0, 0);
        }

        $equipmentType = $item->equipment_type instanceof EquipmentType
            ? $item->equipment_type->value
            : (string) $item->equipment_type;

        $rules = TechnicalReviewScoringRule::active()
            ->forEquipmentType($equipmentType)
            ->get();

        $score = self::BASELINE_SCORE;
        $evaluatedRules = 0;

        foreach ($rules as $rule) {
            $fieldValue = $details->{$rule->field_name} ?? null;
            if ($fieldValue === null || $fieldValue === '') {
                continue;
            }

            if ($rule->field_name === 'defective_ports_count') {
                $criticalPorts = $details->defective_ports_critical_count ?? null;
                if ($criticalPorts !== null && (int) $criticalPorts > 0) {
                    continue;
                }
            }

            if ($rule->field_name === 'all_ports_functional') {
                $defectivePorts = $details->defective_ports_count ?? null;
                $criticalPorts = $details->defective_ports_critical_count ?? null;
                if (
                    ($defectivePorts !== null && (int) $defectivePorts > 0) ||
                    ($criticalPorts !== null && (int) $criticalPorts > 0)
                ) {
                    continue;
                }
            }

            $evaluatedRules++;

            if ($this->ruleMatches($rule, $fieldValue)) {
                $score += $rule->points;
                $category = $this->categoryForField($rule->field_name);
                $this->categoryScores[$category] = ($this->categoryScores[$category] ?? 0) + $rule->points;
                $this->scores[$rule->field_name] = ($this->scores[$rule->field_name] ?? 0) + $rule->points;
                $this->reasoning[] = $rule->reasoning ?? $this->defaultReasoning($rule->field_name, $rule->points);
                
                // Aplicar restricción de grado máximo si la regla tiene penalización
                // o si explícitamente limita a B o C (incluso con puntos positivos)
                if ($rule->affects_grade) {
                    $ruleGrade = EquipmentGrade::tryFrom($rule->affects_grade);
                    if ($ruleGrade && ($rule->points < 0 || in_array($rule->affects_grade, ['B', 'C', 'M']))) {
                        // Si no hay restricción previa, o esta regla es más restrictiva, aplicarla
                        if ($this->maxAllowedGrade === null) {
                            $this->maxAllowedGrade = $ruleGrade;
                        } else {
                            $this->maxAllowedGrade = $this->getMostRestrictive($this->maxAllowedGrade, $ruleGrade);
                        }
                    }
                }
            }
        }

        if (($this->categoryScores['battery'] ?? 0) === 0 && $this->hasBattery($equipmentType)) {
            $this->applyBatteryFallback($details, $score);
        }

        $score = (int) round(max(0, min(100, $score)));
        $grade = $this->scoreToGrade($score);
        $confidence = $this->calculateConfidence($rules->count(), $evaluatedRules, $details);

        return $this->buildResponse($grade, $confidence, $score);
    }

    private function ruleMatches(TechnicalReviewScoringRule $rule, mixed $fieldValue): bool
    {
        $condition = $rule->condition ?? [];
        $normalizedValue = $this->normalizeScalar($fieldValue);

        if (array_key_exists('value', $condition)) {
            return $normalizedValue === $this->normalizeScalar($condition['value']);
        }

        if (isset($condition['contains'])) {
            $searchText = $this->normalizeScalar($condition['contains']);
            $normalizedStr = is_string($normalizedValue) ? $normalizedValue : (string) $normalizedValue;
            return str_contains($normalizedStr, $searchText);
        }

        if (isset($condition['in']) && is_array($condition['in'])) {
            $allowed = array_map([$this, 'normalizeScalar'], $condition['in']);
            return in_array($normalizedValue, $allowed, true);
        }

        if (isset($condition['not_in']) && is_array($condition['not_in'])) {
            $denied = array_map([$this, 'normalizeScalar'], $condition['not_in']);
            return !in_array($normalizedValue, $denied, true);
        }

        $numericValue = is_numeric($normalizedValue) ? (float) $normalizedValue : null;
        if ($numericValue !== null) {
            $min = $condition['min'] ?? $condition['min_value'] ?? null;
            $max = $condition['max'] ?? $condition['max_value'] ?? null;

            if (($min !== null && $numericValue < $min) || ($max !== null && $numericValue > $max)) {
                return false;
            }
        }

        if (($condition['exists'] ?? false) === true) {
            return $normalizedValue !== null && $normalizedValue !== '';
        }

        if (($condition['absent'] ?? false) === true) {
            return $normalizedValue === null || $normalizedValue === '';
        }

        return true;
    }

    private function categoryForField(string $field): string
    {
        $field = strtolower($field);

        if (str_contains($field, 'battery')) {
            return 'battery';
        }

        if (
            str_contains($field, 'screen') ||
            str_contains($field, 'cover') ||
            str_contains($field, 'keyboard') ||
            str_contains($field, 'hinge') ||
            str_contains($field, 'bottom') ||
            str_contains($field, 'case')
        ) {
            return 'aesthetic';
        }

        return 'functionality';
    }

    private function defaultReasoning(string $field, int $points): string
    {
        $label = ucwords(str_replace(['_', '.'], ' ', $field));
        $sign = $points >= 0 ? '+' : '';
        return "{$label} {$sign}{$points} pts";
    }

    private function applyBatteryFallback(mixed $details, int &$score): void
    {
        if (!isset($details->battery_health)) {
            return;
        }

        $batteryData = $this->batteryService->normalize($details->battery_health);
        $percentage = $batteryData['percentage'];

        if ($percentage === null) {
            return;
        }

        $points = match (true) {
            $percentage >= 80 => 20,
            $percentage >= 60 => 15,
            $percentage >= 50 => 10,
            $percentage >= 35 => 5,
            default => 0,
        };

        $score += $points;
        $this->categoryScores['battery'] += $points;
        $this->scores['battery_health'] = ($this->scores['battery_health'] ?? 0) + $points;
        $status = $batteryData['status'] ?? 'desconocido';
        $this->reasoning[] = "Batería: {$percentage}% ({$status}) {$this->formatPoints($points)} pts";
    }

    private function scoreToGrade(int $score): EquipmentGrade
    {
        $calculatedGrade = match (true) {
            $score >= 90 => EquipmentGrade::A,
            $score >= 70 => EquipmentGrade::B,
            $score >= 50 => EquipmentGrade::C,
            default => EquipmentGrade::M,
        };
        
        // Si hay una restricción de grado máximo, devolver el más restrictivo
        if ($this->maxAllowedGrade !== null) {
            $restrictedGrade = $this->getMostRestrictive($calculatedGrade, $this->maxAllowedGrade);

            if (
                $restrictedGrade === EquipmentGrade::M &&
                in_array($this->maxAllowedGrade, [EquipmentGrade::B, EquipmentGrade::C], true)
            ) {
                return $this->maxAllowedGrade;
            }

            return $restrictedGrade;
        }
        
        return $calculatedGrade;
    }
    
    /**
     * Devuelve el grado más restrictivo entre dos grados
     */
    private function getMostRestrictive(EquipmentGrade $grade1, EquipmentGrade $grade2): EquipmentGrade
    {
        // Orden de restricción: M > C > B > A (M es el más restrictivo)
        $order = [
            EquipmentGrade::A->value => 1,
            EquipmentGrade::B->value => 2,
            EquipmentGrade::C->value => 3,
            EquipmentGrade::M->value => 4,
        ];
        
        $order1 = $order[$grade1->value] ?? 0;
        $order2 = $order[$grade2->value] ?? 0;
        
        return $order1 > $order2 ? $grade1 : $grade2;
    }

    private function calculateConfidence(int $totalRules, int $evaluatedRules, mixed $details): int
    {
        if ($totalRules > 0) {
            return (int) round(($evaluatedRules / $totalRules) * 100);
        }

        // Si no hay reglas configuradas, usar datos básicos para determinar confianza
        $requiredFields = ['screen_condition', 'general_condition', 'processor'];
        $filled = 0;
        foreach ($requiredFields as $field) {
            if (isset($details->$field) && $details->$field !== '') {
                $filled++;
            }
        }

        return (int) round(($filled / count($requiredFields)) * 100);
    }

    private function buildResponse(?EquipmentGrade $grade, int $confidence, int $totalScore): array
    {
        // Calcular suma de breakdown
        $breakdownSum = ($this->categoryScores['aesthetic'] ?? 0) 
                      + ($this->categoryScores['functionality'] ?? 0) 
                      + ($this->categoryScores['battery'] ?? 0);
        
        $warnings = [];
        
        // Si el grado fue limitado por restricciones, agregar advertencia
        if ($this->maxAllowedGrade !== null) {
            $calculatedScore = match (true) {
                $totalScore >= 90 => 'A',
                $totalScore >= 70 => 'B',
                $totalScore >= 50 => 'C',
                default => 'M',
            };
            
            if ($calculatedScore !== $grade?->value) {
                $warnings[] = "Grado limitado a {$grade?->value} por condiciones críticas (puntuación sugería {$calculatedScore})";
            }
        }
        
        return [
            'suggested_grade' => $grade?->value,
            'confidence' => $confidence,
            'total_score' => $totalScore,
            'baseline_score' => self::BASELINE_SCORE,
            'earned_points' => $breakdownSum,
            'breakdown' => [
                'aesthetic' => $this->categoryScores['aesthetic'] ?? 0,
                'functionality' => $this->categoryScores['functionality'] ?? 0,
                'battery' => $this->categoryScores['battery'] ?? 0,
            ],
            'reasoning' => $this->reasoning,
            'scores' => $this->scores,
            'is_auto_assignable' => $confidence >= 80,
            'warnings' => $warnings,
        ];
    }

    private function normalizeScalar(mixed $value): mixed
    {
        // Convertir Enums a su valor subyacente
        if ($value instanceof \BackedEnum) {
            $value = $value->value;
        }

        if (is_string($value)) {
            return strtolower(trim($value));
        }

        if (is_numeric($value)) {
            return $value + 0;
        }

        return $value;
    }

    private function hasBattery(string $equipmentType): bool
    {
        return in_array($equipmentType, ['notebook', 'aio'], true);
    }

    private function formatPoints(int $points): string
    {
        return ($points >= 0 ? '+' : '') . $points;
    }
}
