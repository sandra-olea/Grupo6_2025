<?php

namespace App\Services;

use App\Models\Product;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Branch;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class ProductImportService
{
    protected ExcelReaderService $excelReader;
    protected ProductAttributesValidator $attributesValidator;

    public function __construct(
        ExcelReaderService $excelReader,
        ProductAttributesValidator $attributesValidator
    ) {
        $this->excelReader = $excelReader;
        $this->attributesValidator = $attributesValidator;
    }

    /**
     * Importa productos desde un archivo Excel
     *
     * @param string $filePath
     * @param int $branchId
     * @param array $options
     * @return array
     */
    public function importFromExcel(string $filePath, int $branchId, array $options = []): array
    {
        $startTime = microtime(true);
        
        // Verificar que la sucursal existe
        $branch = Branch::findOrFail($branchId);

        // Leer el archivo Excel
        $excelData = $this->excelReader->readExcelFile($filePath);

        $results = [
            'total_sheets' => $excelData['total_sheets'],
            'sheets_processed' => [],
            'total_products' => 0,
            'successful' => 0,
            'failed' => 0,
            'skipped' => 0,
            'errors' => [],
            'created_products' => [],
            'processing_time' => 0
        ];

        // Cargar hoja de validaciones si existe
        $validationSheet = $this->findValidationSheet($excelData);
        if ($validationSheet) {
            $this->attributesValidator->loadAllowedValues($validationSheet);
        }

        // Procesar cada hoja
        foreach ($excelData['sheets'] as $sheet) {
            // Saltar hojas de validación o configuración
            if ($this->isValidationSheet($sheet['name'])) {
                continue;
            }

            $sheetResult = $this->processSheet($sheet, $branch, $options);
            
            $results['sheets_processed'][] = [
                'name' => $sheet['name'],
                'total_rows' => $sheet['total_rows'] - 1, // Excluir encabezados
                'processed' => $sheetResult['processed'],
                'successful' => $sheetResult['successful'],
                'failed' => $sheetResult['failed'],
                'skipped' => $sheetResult['skipped'],
            ];

            $results['total_products'] += $sheetResult['processed'];
            $results['successful'] += $sheetResult['successful'];
            $results['failed'] += $sheetResult['failed'];
            $results['skipped'] += $sheetResult['skipped'];
            $results['errors'] = array_merge($results['errors'], $sheetResult['errors']);
            $results['created_products'] = array_merge($results['created_products'], $sheetResult['created_products']);
        }

        $results['processing_time'] = round(microtime(true) - $startTime, 2);

        return $results;
    }

    /**
     * Procesa una hoja individual del Excel
     *
     * @param array $sheet
     * @param Branch $branch
     * @param array $options
     * @return array
     */
    protected function processSheet(array $sheet, Branch $branch, array $options = []): array
    {
        $result = [
            'processed' => 0,
            'successful' => 0,
            'failed' => 0,
            'skipped' => 0,
            'errors' => [],
            'created_products' => []
        ];

        $headers = $sheet['headers'];
        $data = $sheet['data'];

        // Mapear índices de columnas
        $columnMap = $this->mapColumns($headers);

        if (empty($columnMap['sku'])) {
            $result['errors'][] = [
                'sheet' => $sheet['name'],
                'error' => 'No se encontró la columna SKU en la hoja'
            ];
            return $result;
        }

        // Procesar cada fila
        foreach ($data as $rowIndex => $row) {
            $result['processed']++;
            $rowNumber = $rowIndex + 2; // +2 porque Excel empieza en 1 y la fila 1 son encabezados

            try {
                // Saltar filas vacías
                if ($this->isEmptyRow($row)) {
                    $result['skipped']++;
                    continue;
                }

                // Extraer datos de la fila
                $productData = $this->extractProductData($row, $columnMap);

                // Validar datos básicos
                $this->validateBasicData($productData, $rowNumber);

                // Crear o actualizar producto
                $product = $this->createOrUpdateProduct($productData, $branch, $options);

                $result['successful']++;
                $result['created_products'][] = [
                    'sku' => $product->sku,
                    'name' => $product->name,
                    'id' => $product->id,
                    'row' => $rowNumber
                ];

            } catch (\Exception $e) {
                $result['failed']++;
                $result['errors'][] = [
                    'sheet' => $sheet['name'],
                    'row' => $rowNumber,
                    'sku' => $productData['sku'] ?? 'N/A',
                    'error' => $e->getMessage()
                ];

                Log::error("Error importando producto en fila {$rowNumber}: " . $e->getMessage(), [
                    'sheet' => $sheet['name'],
                    'row_data' => $row
                ]);
            }
        }

        return $result;
    }

    /**
     * Mapea las columnas del Excel a campos conocidos
     *
     * @param array $headers
     * @return array
     */
    protected function mapColumns(array $headers): array
    {
        $map = [
            'basic' => [],      // Campos básicos del producto
            'attributes' => []  // Campos que irán a attributes_json
        ];
        
        foreach ($headers as $index => $header) {
            $normalized = strtolower(trim($header));
            $original = trim($header);
            
            // Mapeo de columnas básicas del producto
            $basicMappings = [
                'sku' => ['sku', 'codigo', 'código'],
                'name' => ['name', 'nombre', 'product_name', 'producto'],
                'brand' => ['brand', 'marca'],
                'category' => ['category', 'categoria', 'categoría'],
                'cost' => ['cost', 'costo', 'precio_costo'],
                'price' => ['price', 'precio', 'precio_venta'],
                'stock' => ['stock', 'existencia', 'cantidad'],
                'description' => ['description', 'descripcion', 'descripción'],
                'barcode' => ['barcode', 'codigo_barras', 'ean'],
                'product_type' => ['product_type', 'tipo', 'tipo_producto', 'type'],
                'warranty_months' => ['warranty', 'garantia', 'garantía', 'warranty_months'],
            ];

            $isBasicField = false;
            foreach ($basicMappings as $field => $possibleNames) {
                if (in_array($normalized, $possibleNames)) {
                    $map['basic'][$field] = $index;
                    $isBasicField = true;
                    break;
                }
            }

            // Si no es un campo básico, se considera un atributo
            if (!$isBasicField) {
                $attributePath = $this->parseAttributePath($original);
                if ($attributePath) {
                    $map['attributes'][] = [
                        'index' => $index,
                        'path' => $attributePath,
                        'original' => $original
                    ];
                }
            }
        }

        return $map;
    }

    /**
     * Parsea el nombre de una columna para obtener la ruta en attributes_json
     * Ejemplo: "cpu.brand" -> ["cpu", "brand"]
     * Ejemplo: "RAM" -> ["ram", "capacity_gb"]
     * Ejemplo: "display.size_inches" -> ["display", "size_inches"]
     *
     * @param string $columnName
     * @return array|null
     */
    protected function parseAttributePath(string $columnName): ?array
    {
        $normalized = strtolower(trim($columnName));
        
        // Mapeos especiales para retrocompatibilidad
        $specialMappings = [
            'cpu' => ['cpu', 'model'],
            'ram' => ['ram', 'capacity_gb'],
            'grade' => ['grade'],
            'grado' => ['grade'],
            'product_kind' => ['product_kind'],
            'tipo_producto' => ['product_kind'],
            'category_grade' => ['category_grade'],
        ];

        // Verificar mapeos especiales
        if (isset($specialMappings[$normalized])) {
            return $specialMappings[$normalized];
        }

        // Si contiene punto, dividir (ej: "cpu.brand")
        if (strpos($columnName, '.') !== false) {
            return explode('.', $columnName);
        }

        // Si empieza con un prefijo conocido, usarlo como path
        $knownPrefixes = [
            'packaging_' => 'packaging',
            'os_' => 'os',
            'cpu_' => 'cpu',
            'gpu_' => 'gpu',
            'ram_' => 'ram',
            'display_' => 'display',
            'storage_' => 'storage',
            'connectivity_' => 'connectivity',
        ];

        foreach ($knownPrefixes as $prefix => $section) {
            if (strpos($normalized, $prefix) === 0) {
                $field = substr($normalized, strlen($prefix));
                return [$section, $field];
            }
        }

        // Si no coincide con nada, retornar null (se ignorará)
        return null;
    }

    /**
     * Extrae datos del producto de una fila
     *
     * @param array $row
     * @param array $columnMap
     * @return array
     */
    protected function extractProductData(array $row, array $columnMap): array
    {
        $data = [];

        // Extraer campos básicos
        foreach ($columnMap['basic'] as $field => $index) {
            $value = $row[$index] ?? null;
            
            // Limpiar valor
            if (is_string($value)) {
                $value = trim($value);
                if ($value === '' || $value === 'NULL' || $value === 'null') {
                    $value = null;
                }
            }

            $data[$field] = $value;
        }

        // Construir attributes_json desde las columnas de atributos
        $attributes = [];
        foreach ($columnMap['attributes'] as $attrConfig) {
            $value = $row[$attrConfig['index']] ?? null;
            
            // Limpiar y normalizar valor
            if (is_string($value)) {
                $value = trim($value);
                if ($value === '' || $value === 'NULL' || $value === 'null') {
                    $value = null;
                }
            }

            // Si el valor no es nulo, agregarlo a attributes
            if ($value !== null) {
                $value = $this->normalizeAttributeValue($value, $attrConfig['path']);
                $this->setNestedValue($attributes, $attrConfig['path'], $value);
            }
        }

        // Si se construyeron atributos, agregarlos
        if (!empty($attributes)) {
            $data['attributes_json'] = $attributes;
        }

        return $data;
    }

    /**
     * Normaliza un valor de atributo según su tipo esperado
     *
     * @param mixed $value
     * @param array $path
     * @return mixed
     */
    protected function normalizeAttributeValue($value, array $path): mixed
    {
        // Convertir booleanos
        if (is_string($value)) {
            $lower = strtolower($value);
            if (in_array($lower, ['true', 'yes', 'si', 'sí', '1'])) {
                return true;
            }
            if (in_array($lower, ['false', 'no', '0'])) {
                return false;
            }
        }

        // Campos que deben ser numéricos
        $numericFields = ['capacity_gb', 'max_supported_gb', 'modules', 'm2', 'sata', 'size_inches', 'warranty_months'];
        $lastKey = end($path);
        
        if (in_array($lastKey, $numericFields) && is_numeric($value)) {
            // Si termina en _gb o es modules, convertir a entero
            if (strpos($lastKey, '_gb') !== false || $lastKey === 'modules' || $lastKey === 'm2' || $lastKey === 'sata') {
                return (int) $value;
            }
            // size_inches puede ser decimal
            if ($lastKey === 'size_inches') {
                return (float) $value;
            }
            return $value;
        }

        // Extraer números de strings (ej: "16 GB" -> 16)
        if ($lastKey === 'capacity_gb' && is_string($value) && preg_match('/(\d+)\s*GB/i', $value, $matches)) {
            return (int) $matches[1];
        }

        return $value;
    }

    /**
     * Establece un valor en un array anidado usando un path
     *
     * @param array &$array
     * @param array $path
     * @param mixed $value
     */
    protected function setNestedValue(array &$array, array $path, $value): void
    {
        $current = &$array;
        $lastKey = array_pop($path);

        foreach ($path as $key) {
            if (!isset($current[$key]) || !is_array($current[$key])) {
                $current[$key] = [];
            }
            $current = &$current[$key];
        }

        $current[$lastKey] = $value;
    }

    /**
     * Valida datos básicos del producto
     *
     * @param array $data
     * @param int $rowNumber
     * @throws \Exception
     */
    protected function validateBasicData(array $data, int $rowNumber): void
    {
        if (empty($data['sku'])) {
            throw new \Exception("SKU es requerido en la fila {$rowNumber}");
        }

        if (empty($data['name'])) {
            throw new \Exception("Nombre es requerido en la fila {$rowNumber}");
        }
    }

    /**
     * Crea o actualiza un producto
     *
     * @param array $data
     * @param Branch $branch
     * @param array $options
     * @return Product
     */
    protected function createOrUpdateProduct(array $data, Branch $branch, array $options = []): Product
    {
        DB::beginTransaction();

        try {
            // Buscar o crear marca
            $brand = null;
            if (!empty($data['brand'])) {
                $brand = $this->findOrCreateBrand($data['brand'], $branch->id);
            }

            // Buscar o crear categorías
            $categories = [];
            if (!empty($data['category'])) {
                $categoryNames = is_array($data['category']) 
                    ? $data['category'] 
                    : explode(',', $data['category']);
                
                foreach ($categoryNames as $categoryName) {
                    $category = $this->findOrCreateCategory(trim($categoryName));
                    $categories[] = $category->id;
                }
            }

            // Validar y procesar attributes_json
            $attributesJson = null;
            if (!empty($data['attributes_json'])) {
                $productType = $data['product_type'] ?? 'notebook';
                $attributesJson = $this->attributesValidator->validateAndProcess(
                    $data['attributes_json'],
                    $productType
                );
            }

            // Preparar datos del producto
            $productData = [
                'branch_id' => $branch->id,
                'sku' => $data['sku'],
                'name' => $data['name'],
                'brand_id' => $brand?->id,
                'product_type' => $data['product_type'] ?? 'notebook',
                'cost' => $data['cost'] ?? 0,
                'price' => $data['price'] ?? 0,
                'stock' => $data['stock'] ?? 0,
                'barcode' => $data['barcode'] ?? null,
                'short_description' => $data['description'] ?? null,
                'warranty_months' => $data['warranty_months'] ?? 12,
                'attributes_json' => $attributesJson,
                'is_active' => true,
                'product_status' => 'available',
            ];

            // Buscar producto existente por SKU en esta sucursal
            $product = Product::where('branch_id', $branch->id)
                ->where('sku', $data['sku'])
                ->first();

            if ($product && !($options['update_existing'] ?? true)) {
                throw new \Exception("Producto con SKU {$data['sku']} ya existe y update_existing está deshabilitado");
            }

            if ($product) {
                $product->update($productData);
            } else {
                $product = Product::create($productData);
            }

            // Sincronizar categorías
            if (!empty($categories)) {
                $product->categories()->sync($categories);
            }

            DB::commit();

            return $product;

        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Encuentra o crea una marca
     *
     * @param string $brandName
     * @param int $branchId
     * @return Brand
     */
    protected function findOrCreateBrand(string $brandName, int $branchId): Brand
    {
        $slug = Str::slug($brandName);

        return Brand::firstOrCreate(
            ['slug' => $slug, 'branch_id' => $branchId],
            ['name' => $brandName]
        );
    }

    /**
     * Encuentra o crea una categoría
     *
     * @param string $categoryName
     * @return Category
     */
    protected function findOrCreateCategory(string $categoryName): Category
    {
        $slug = Str::slug($categoryName);

        return Category::firstOrCreate(
            ['slug' => $slug],
            ['name' => $categoryName]
        );
    }

    /**
     * Verifica si una fila está vacía
     *
     * @param array $row
     * @return bool
     */
    protected function isEmptyRow(array $row): bool
    {
        foreach ($row as $cell) {
            if ($cell === null) continue;
            if (is_string($cell)) {
                // Reemplazar espacios unicode y recortar
                $cell = preg_replace('/[\x{00A0}\x{1680}\x{2000}-\x{200B}\x{202F}\x{205F}\x{3000}]+/u', ' ', $cell);
                if (trim($cell) !== '') {
                    return false;
                }
            } else if (!empty($cell)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Encuentra la hoja de validaciones
     *
     * @param array $excelData
     * @return array|null
     */
    protected function findValidationSheet(array $excelData): ?array
    {
        foreach ($excelData['sheets'] as $sheet) {
            if ($this->isValidationSheet($sheet['name'])) {
                return $sheet;
            }
        }
        return null;
    }

    /**
     * Verifica si una hoja es de validación
     *
     * @param string $sheetName
     * @return bool
     */
    protected function isValidationSheet(string $sheetName): bool
    {
        $validationNames = ['validaciones', 'validations', 'allowed_values', 'valores_permitidos', 'config'];
        $normalized = strtolower(trim($sheetName));
        
        return in_array($normalized, $validationNames);
    }
}
