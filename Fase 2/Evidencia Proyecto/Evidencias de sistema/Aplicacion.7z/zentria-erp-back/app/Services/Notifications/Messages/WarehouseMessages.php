<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class WarehouseMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'warehouse.created',
            'warehouse.updated',
            'warehouse.deleted',
            'warehouse.product.attached',
            'warehouse.product.detached',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'warehouse.created' => $this->fmt('Bodega creada: %s - Sucursal %s', $payload['warehouse_name'] ?? null, $payload['branch_name'] ?? null),
            'warehouse.updated' => $this->fmt('Bodega actualizada: %s - Sucursal %s', $payload['warehouse_name'] ?? null, $payload['branch_name'] ?? null),
            'warehouse.deleted' => $this->fmt('Bodega eliminada: %s - Sucursal %s', $payload['warehouse_name'] ?? null, $payload['branch_name'] ?? null),
            'warehouse.product.attached' => $this->fmt(
                'Producto asociado a bodega: %s en %s%s',
                $payload['product_name'] ?? null,
                $payload['warehouse_name'] ?? null,
                $this->branchSuffix($event, $payload)
            ),
            'warehouse.product.detached' => $this->fmt(
                'Producto desasociado de bodega: %s en %s%s',
                $payload['product_name'] ?? null,
                $payload['warehouse_name'] ?? null,
                $this->branchSuffix($event, $payload)
            ),
            default => null,
        };
    }
}
