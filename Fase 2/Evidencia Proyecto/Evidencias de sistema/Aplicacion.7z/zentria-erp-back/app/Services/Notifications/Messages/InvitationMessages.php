<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class InvitationMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'invitation.sent',
            'invitation.activated',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'invitation.sent' => $this->fmt('Invitación enviada a %s (%s)', $payload['invitee_name'] ?? ($payload['email'] ?? null), $payload['role'] ?? null),
            'invitation.activated' => $this->fmt('Invitación activada por %s', $payload['invitee_name'] ?? ($payload['email'] ?? null)),
            default => null,
        };
    }
}
