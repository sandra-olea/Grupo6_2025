<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class SubsidiaryMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'subsidiary.created',
            'subsidiary.updated',
            'subsidiary.deleted',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'subsidiary.created' => $this->fmt('Subempresa creada: %s', $payload['subsidiary_name'] ?? null),
            'subsidiary.updated' => $this->fmt('Subempresa actualizada: %s', $payload['subsidiary_name'] ?? null),
            'subsidiary.deleted' => $this->fmt('Subempresa eliminada: %s', $payload['subsidiary_name'] ?? null),
            default => null,
        };
    }
}
