<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

abstract class AbstractMessageFormatter
{
    /**
     * Format a message string with values
     */
    protected function fmt(string $pattern, mixed ...$vals): string
    {
        try {
            return vsprintf($pattern, array_map(fn($v) => $v ?? '', $vals));
        } catch (\Throwable $e) {
            return trim(preg_replace('/\s+/', ' ', vsprintf($pattern, array_map(fn($v) => (string) $v, $vals))));
        }
    }

    /**
     * Get SKU suffix if available
     */
    protected function skuSuffix(array $payload): string
    {
        return isset($payload['sku']) && $payload['sku'] !== null && $payload['sku'] !== '' 
            ? ' ('.$payload['sku'].')' 
            : '';
    }

    /**
     * Format amount with thousands separator
     */
    protected function fmtAmount($amount): string
    {
        if ($amount === null) return '';
        return number_format((float) $amount, 0, ',', '.');
    }

    /**
     * Get branch suffix from payload or event
     */
    protected function branchSuffix(?NotificationEvent $event, array $payload): string
    {
        $name = $payload['branch_name'] ?? null;
        if (!$name && $event && $event->branch_id) {
            try {
                $branch = \App\Models\Branch::find($event->branch_id);
                $name = $branch?->branch_name;
            } catch (\Throwable $e) {
                $name = null;
            }
        }
        return $name ? ' - Sucursal '.$name : '';
    }

    /**
     * Format a notification message based on event key and payload
     */
    abstract public function format(string $key, NotificationEvent $event, array $payload): ?string;

    /**
     * Get the notification keys this formatter handles
     */
    abstract public function handles(): array;
}
