<?php

namespace App\Services\Notifications;

use App\Models\Notifications\NotificationEvent;
use App\Services\Notifications\Messages\AbstractMessageFormatter;
use App\Services\Notifications\Messages\CompanyMessages;
use App\Services\Notifications\Messages\SubsidiaryMessages;
use App\Services\Notifications\Messages\BranchMessages;
use App\Services\Notifications\Messages\ProductMessages;
use App\Services\Notifications\Messages\InvitationMessages;
use App\Services\Notifications\Messages\SupplierMessages;
use App\Services\Notifications\Messages\CustomerSupplierMessages;
use App\Services\Notifications\Messages\CustomerSaleMessages;
use App\Services\Notifications\Messages\SaleMessages;
use App\Services\Notifications\Messages\SystemMessages;
use App\Services\Notifications\Messages\GenericMessages;
use App\Services\Notifications\Messages\WarehouseMessages;
use App\Services\Notifications\Messages\TechnicalReviewMessages;

class NotificationMessageService
{
    /**
     * @var array<string, AbstractMessageFormatter>
     */
    private array $formatters = [];

    /**
     * @var array<string, string>
     */
    private array $keyToFormatterMap = [];

    public function __construct()
    {
        $this->registerFormatters();
    }

    /**
     * Register all message formatters and build the key-to-formatter map
     */
    private function registerFormatters(): void
    {
        $formatterClasses = [
            CompanyMessages::class,
            SubsidiaryMessages::class,
            BranchMessages::class,
            ProductMessages::class,
            InvitationMessages::class,
            SupplierMessages::class,
            CustomerSupplierMessages::class,
            CustomerSaleMessages::class,
            SaleMessages::class,
            SystemMessages::class,
            WarehouseMessages::class,
            TechnicalReviewMessages::class,
        ];

        foreach ($formatterClasses as $formatterClass) {
            $formatter = new $formatterClass();
            $this->formatters[$formatterClass] = $formatter;

            foreach ($formatter->handles() as $key) {
                $this->keyToFormatterMap[$key] = $formatterClass;
            }
        }

        // Generic fallback formatter
        $this->formatters[GenericMessages::class] = new GenericMessages();
    }

    public function format(?NotificationEvent $event): string
    {
        if (!$event || !$event->type) {
            return 'Notificación';
        }

        $key = (string) $event->type->key;
        $payload = (array) ($event->payload ?? []);

        // If an explicit message override is provided in the payload, return it verbatim
        // EXCEPT for certain types where we want to enforce centralized templates.
        $noOverrideFor = [
            'supplier.created','supplier.updated','supplier.deleted',
            'customer-supplier.created','customer-supplier.updated','customer-supplier.deleted',
            'supplier.customers-attached','supplier.customers-detached',
            'customer-supplier.suppliers-attached','customer-supplier.suppliers-detached',
            'customer-sale.created','customer-sale.updated','customer-sale.deleted',
            'sale.stock-shortage',
        ];
        $allowOverride = !in_array($key, $noOverrideFor, true);
        if ($allowOverride && isset($payload['message']) && is_string($payload['message']) && trim($payload['message']) !== '') {
            return trim($payload['message']);
        }

        // Find the appropriate formatter for this key
        $formatterClass = $this->keyToFormatterMap[$key] ?? GenericMessages::class;
        $formatter = $this->formatters[$formatterClass];

        // Format the message using the appropriate formatter
        $message = $formatter->format($key, $event, $payload);

        return $message ?? 'Notificación';
    }
}
