<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class SaleMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'sale.stock-shortage',
            'sale.created',
            'sale.status-changed',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'sale.stock-shortage' => $this->fmt(
                'Faltante de stock en venta %s (Canal: %s)',
                $payload['sale_number'] ?? ('#'.$payload['sale_id'] ?? 'N/A'),
                $payload['channel'] ?? 'ERP'
            ),
            'sale.created' => $this->fmt(
                'Venta creada %s (Canal: %s)',
                $payload['sale_number'] ?? ('#'.$payload['sale_id'] ?? 'N/A'),
                $payload['channel'] ?? 'ERP'
            ),
            'sale.status-changed' => $this->fmt(
                'Estado de venta %s: %s → %s (Canal: %s)',
                $payload['sale_number'] ?? ('#'.$payload['sale_id'] ?? 'N/A'),
                $payload['old_status'] ?? 'N/A',
                $payload['new_status'] ?? 'N/A',
                $payload['channel'] ?? 'ERP'
            ),
            default => null,
        };
    }
}
