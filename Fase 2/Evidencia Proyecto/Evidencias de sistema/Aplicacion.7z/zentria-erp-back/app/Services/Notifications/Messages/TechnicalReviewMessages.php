<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class TechnicalReviewMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'technical-review.batch-created',
            'technical-review.batch-completed',
            'technical-review.item-pending-review',
            'technical-review.item-completed',
            'technical-review.item-approved',
            'technical-review.item-rejected',
            'technical-review.validation-error',
            'technical-review.equipment-available',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        $branchSuffix = $this->branchSuffix($event, $payload);
        $warehouseSuffix = $this->warehouseSuffix($payload);

        return match ($key) {
            'technical-review.batch-created' => $this->fmt(
                'Lote de revisión técnica creado: %s (%s equipos esperados)%s',
                $payload['batch_code'] ?? null,
                $payload['expected_quantity'] ?? '?',
                $branchSuffix
            ),
            
            'technical-review.batch-completed' => $this->fmt(
                'Lote de revisión técnica completado: %s (%s/%s equipos)%s',
                $payload['batch_code'] ?? null,
                $payload['completed_quantity'] ?? '?',
                $payload['expected_quantity'] ?? '?',
                $branchSuffix
            ),
            
            'technical-review.item-pending-review' => $this->fmt(
                'Equipo pendiente de revisión: %s (%s) en lote %s%s',
                $payload['serial_number'] ?? null,
                $this->equipmentTypeLabel($payload['equipment_type'] ?? null),
                $payload['batch_code'] ?? '?',
                $branchSuffix
            ),
            
            'technical-review.item-completed' => $this->fmt(
                'Revisión completada: %s (%s) - Grado sugerido: %s%s',
                $payload['serial_number'] ?? null,
                $this->equipmentTypeLabel($payload['equipment_type'] ?? null),
                $payload['suggested_grade'] ?? '?',
                $branchSuffix
            ),
            
            'technical-review.item-approved' => $this->fmt(
                'Equipo aprobado: %s (%s) - Grado: %s - Lote %s%s',
                $payload['serial_number'] ?? null,
                $this->equipmentTypeLabel($payload['equipment_type'] ?? null),
                $payload['grade'] ?? '?',
                $payload['batch_code'] ?? '?',
                $warehouseSuffix
            ),
            
            'technical-review.item-rejected' => $this->fmt(
                'Equipo rechazado: %s (%s) - Grado: %s%s',
                $payload['serial_number'] ?? null,
                $this->equipmentTypeLabel($payload['equipment_type'] ?? null),
                $payload['grade'] ?? 'M',
                $branchSuffix
            ),
            
            'technical-review.validation-error' => $this->fmt(
                'Error de validación en revisión: %s - %s%s',
                $payload['serial_number'] ?? null,
                $payload['error_message'] ?? 'Error desconocido',
                $branchSuffix
            ),
            
            'technical-review.equipment-available' => $this->fmt(
                'Equipo disponible para venta: %s (%s) - Grado %s en bodega %s',
                $payload['serial_number'] ?? null,
                $this->equipmentTypeLabel($payload['equipment_type'] ?? null),
                $payload['grade'] ?? '?',
                $payload['warehouse_name'] ?? '?'
            ),
            
            default => null,
        };
    }

    /**
     * Convierte el tipo de equipo a etiqueta legible en español
     */
    private function equipmentTypeLabel(?string $type): string
    {
        if (!$type) {
            return 'Equipo';
        }

        return match (strtoupper($type)) {
            'NOTEBOOK' => 'Notebook',
            'DESKTOP' => 'Desktop',
            'MONITOR' => 'Monitor',
            'AIO' => 'All-in-One',
            'DOCKING' => 'Docking Station',
            default => ucfirst($type),
        };
    }

    /**
     * Agrega sufijo con bodega si viene en el payload
     */
    private function warehouseSuffix(array $payload): string
    {
        $name = $payload['warehouse_name'] ?? null;
        return $name ? ' - Bodega '.$name : '';
    }
}
