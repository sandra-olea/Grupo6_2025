<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class BranchMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'branch.created',
            'branch.updated',
            'branch.deleted',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'branch.created' => $this->fmt('Sucursal creada: %s', $payload['branch_name'] ?? null),
            'branch.updated' => $this->fmt('Sucursal actualizada: %s', $payload['branch_name'] ?? null),
            'branch.deleted' => $this->fmt('Sucursal eliminada: %s', $payload['branch_name'] ?? null),
            default => null,
        };
    }
}
