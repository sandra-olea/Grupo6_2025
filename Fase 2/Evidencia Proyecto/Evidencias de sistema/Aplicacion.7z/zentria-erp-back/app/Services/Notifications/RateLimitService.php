<?php

namespace App\Services\Notifications;

class RateLimitService
{
    public function allow(string $key, int $max, int $windowSeconds): bool
    {
            try {
            $redis = \Illuminate\Support\Facades\Redis::connection();
            $nowKey = 'rate:'.$key;
            $count = $redis->incr($nowKey);
            if ($count === 1) {
                $redis->expire($nowKey, $windowSeconds);
            }
            return $count <= $max;
        } catch (\Throwable $e) {
            // Fallback allow when Redis is not available
            return true;
        }
    }
}
