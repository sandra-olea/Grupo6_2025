<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class CustomerSaleMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'customer-sale.created',
            'customer-sale.updated',
            'customer-sale.deleted',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'customer-sale.created' => $this->fmt('Cliente de venta creado: %s - En: %s', $payload['customer_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'customer-sale.updated' => $this->fmt('Cliente de venta actualizado: %s - En: %s', $payload['customer_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'customer-sale.deleted' => $this->fmt('Cliente de venta eliminado: %s - En: %s', $payload['customer_name'] ?? null, $payload['subsidiary_name'] ?? null),
            default => null,
        };
    }
}

