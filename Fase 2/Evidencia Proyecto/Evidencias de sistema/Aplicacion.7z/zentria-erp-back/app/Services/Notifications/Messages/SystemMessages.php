<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class SystemMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'system.sync-failed',
            'payment.confirmed',
            'quote.expiring-soon',
            'deadline.expiring-soon',
            'reminder.general',
            'woocommerce.import.started',
            'woocommerce.import.finished',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'system.sync-failed' => $this->fmt('Fallo de sincronización: %s — %s', $payload['component'] ?? null, $payload['error'] ?? null),
            'payment.confirmed' => $this->fmt('Pago confirmado: %s %s', $this->fmtAmount($payload['amount'] ?? null), $payload['currency'] ?? null),
            'quote.expiring-soon' => $this->fmt('Cotización próxima a vencer: %s días restantes', $payload['days_left'] ?? null),
            'deadline.expiring-soon' => $this->fmt('Vencimiento próximo: %s — %s', $payload['subject'] ?? ($payload['title'] ?? null), $payload['due_date'] ?? null),
            'reminder.general' => $this->fmt('Recordatorio: %s', $payload['title'] ?? ($payload['subject'] ?? null)),
            'woocommerce.import.started' => $this->fmt(
                'Importación de órdenes iniciada: %s%s',
                $payload['integration_name'] ?? 'WooCommerce',
                isset($payload['subsidiary_name']) && $payload['subsidiary_name'] ? ' - Subsidiaria '.$payload['subsidiary_name'] : ''
            ),
            'woocommerce.import.finished' => $this->fmt(
                'Importación de órdenes finalizada: %s%s%s',
                $payload['integration_name'] ?? 'WooCommerce',
                isset($payload['error']) && $payload['error'] ? ' (con errores)' : '',
                (isset($payload['orders_imported']) || isset($payload['orders_updated']))
                    ? (' — Importadas: '.(int)($payload['orders_imported'] ?? 0).', Actualizadas: '.(int)($payload['orders_updated'] ?? 0))
                    : ''
            ),
            default => null,
        };
    }
}
