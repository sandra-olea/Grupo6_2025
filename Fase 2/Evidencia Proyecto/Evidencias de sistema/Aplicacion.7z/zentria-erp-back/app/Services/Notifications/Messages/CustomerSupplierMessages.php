<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class CustomerSupplierMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'customer-supplier.created',
            'customer-supplier.updated',
            'customer-supplier.deleted',
            'customer-supplier.suppliers-attached',
            'customer-supplier.suppliers-detached',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'customer-supplier.created' => $this->fmt('Cliente-Proveedor creado: %s - En: %s', $payload['customer_supplier_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'customer-supplier.updated' => $this->fmt('Cliente-Proveedor actualizado: %s - En: %s', $payload['customer_supplier_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'customer-supplier.deleted' => $this->fmt('Cliente-Proveedor eliminado: %s - En: %s', $payload['customer_supplier_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'customer-supplier.suppliers-attached' => $this->formatSuppliersAttached($payload),
            'customer-supplier.suppliers-detached' => $this->formatSuppliersDetached($payload),
            default => null,
        };
    }

    private function formatSuppliersAttached(array $payload): string
    {
        $count = (int)($payload['suppliers_count'] ?? 0);
        $customerName = $payload['customer_supplier_name'] ?? 'Cliente';
        $supplierNames = $payload['supplier_names'] ?? null;
        $subsidiary = $payload['subsidiary_name'] ?? null;

        if ($count === 1 && $supplierNames) {
            return $this->fmt('El cliente "%s" ahora trabaja con el proveedor: %s | %s', $customerName, $supplierNames, $subsidiary);
        }

        if ($supplierNames) {
            return $this->fmt('El cliente "%s" ahora trabaja con %s proveedores: %s | %s', $customerName, (string)$count, $supplierNames, $subsidiary);
        }

        return $this->fmt('Se asociaron %s proveedor(es) al cliente "%s" | %s', (string)$count, $customerName, $subsidiary);
    }

    private function formatSuppliersDetached(array $payload): string
    {
        $count = (int)($payload['suppliers_count'] ?? 0);
        $customerName = $payload['customer_supplier_name'] ?? 'Cliente';
        $supplierNames = $payload['supplier_names'] ?? null;
        $subsidiary = $payload['subsidiary_name'] ?? null;

        if ($count === 1 && $supplierNames) {
            return $this->fmt('El cliente "%s" ya no trabaja con el proveedor: %s | %s', $customerName, $supplierNames, $subsidiary);
        }

        if ($supplierNames) {
            return $this->fmt('El cliente "%s" se desvinculó de %s proveedores: %s | %s', $customerName, (string)$count, $supplierNames, $subsidiary);
        }

        return $this->fmt('Se desasociaron %s proveedor(es) del cliente "%s" | %s', (string)$count, $customerName, $subsidiary);
    }
}
