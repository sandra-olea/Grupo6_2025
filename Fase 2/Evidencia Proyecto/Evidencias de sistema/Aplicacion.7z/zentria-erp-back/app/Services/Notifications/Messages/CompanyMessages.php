<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class CompanyMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'company.updated',
            'company.deleted',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'company.updated' => $this->fmt('Compañía actualizada: %s', $payload['company_name'] ?? null),
            'company.deleted' => $this->fmt('Compañía eliminada: %s', $payload['company_name'] ?? null),
            default => null,
        };
    }
}
