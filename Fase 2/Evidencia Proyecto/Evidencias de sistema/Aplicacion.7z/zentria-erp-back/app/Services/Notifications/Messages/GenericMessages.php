<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class GenericMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        // This handler catches everything else as a fallback
        return [];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        $entity = $event->entity_type ? $event->entity_type.' #'.$event->entity_id : 'evento';
        return ucfirst(str_replace('.', ' ', $key)).': '.$entity;
    }
}
