<?php

namespace App\Services\Notifications;

use App\Models\Notifications\NotificationType;
use App\Models\Notifications\RoleNotificationDefault;
use App\Models\Notifications\UserNotificationPreference;
use App\Models\Branch;
use App\Models\Subsidiary;
use App\Models\Company;
use App\Models\User;

class NotificationPolicyService
{
    /**
     * Determina si el usuario es elegible para un tipo según sus roles.
     * Super-admin siempre es elegible.
     */
    public function isRoleEligibleForType(User $user, NotificationType $type): bool
    {
        if ($user->hasRole('super-admin')) return true;

        // Admin global: todas las notificaciones excepto las de sistema interno
        $key = (string) $type->key;
        $module = (string) ($type->module ?? '');
        if ($user->hasRole('admin')) {
            if ($module === 'system' || str_starts_with($key, 'system.')) {
                return false;
            }
            return true;
        }

        $key = (string) $type->key;
        $module = (string) ($type->module ?? '');

        $hasAnyRole = fn(array $roles) => $user->hasAnyRole($roles);

        // Catálogo (productos, marcas, categorías)
        if (in_array($module, ['catalog'])) {
            return $hasAnyRole(['branch-admin','warehouse-employee','company-admin','subsidiary-admin']);
        }
        if (str_starts_with($key, 'product.') || str_starts_with($key, 'brand.') || str_starts_with($key, 'category.')) {
            return $hasAnyRole(['branch-admin','warehouse-employee','company-admin','subsidiary-admin']);
        }

        // Sucursal
        if ($module === 'branch' || str_starts_with($key, 'branch.')) {
            return $hasAnyRole(['branch-admin','subsidiary-admin','company-admin']);
        }

        // Subempresa
        if ($module === 'subsidiary' || str_starts_with($key, 'subsidiary.')) {
            return $hasAnyRole(['subsidiary-admin','company-admin']);
        }

        // Empresa
        if ($module === 'company' || str_starts_with($key, 'company.')) {
            return $hasAnyRole(['company-admin']);
        }

        // Invitaciones: relevantes para quienes gestionan usuarios
        if ($module === 'invitation' || str_starts_with($key, 'invitation.')) {
            return $hasAnyRole(['company-admin','subsidiary-admin','branch-admin']);
        }

        // Recordatorios genéricos: abiertos a todos los miembros
        if ($module === 'reminder' || str_starts_with($key, 'reminder.')) {
            return $hasAnyRole(['company-member','subsidiary-member','branch-admin','company-admin','subsidiary-admin','warehouse-employee','technician']);
        }

        // Vencimientos: relevantes para operativos y admins
        if ($module === 'deadlines' || str_starts_with($key, 'deadline.')) {
            return $hasAnyRole(['branch-admin','company-admin','subsidiary-admin','warehouse-employee']);
        }

        // Sistema/operacionales existentes: mantener permisivos por ahora
        return true;
    }
    public function resolveEffective(User $user, NotificationType $type, array $context): array
    {
        $allowed = (bool) ($type->enabled_global ?? true);
        $channels = $type->default_channels ?? ['inapp'];
        $priority = $type->default_priority;
        $origin = 'global';

        // Role-level overrides
        $roleIds = $user->roles()->pluck('id');
        if ($roleIds->isNotEmpty()) {
            $roleDefault = RoleNotificationDefault::whereIn('role_id', $roleIds)
                ->where('notification_type_id', $type->id)
                ->first();
            if ($roleDefault) {
                $allowed = (bool) $roleDefault->allowed;
                if (!empty($roleDefault->channels)) {
                    $channels = $roleDefault->channels;
                }
                if (!empty($roleDefault->priority_override)) {
                    $priority = $roleDefault->priority_override;
                }
                $origin = 'role';
            }
        }

        // User preferences overrides
        $pref = UserNotificationPreference::where('user_id', $user->id)
            ->where('notification_type_id', $type->id)
            ->first();
        if ($pref) {
            $allowed = (bool) $pref->allowed;
            if (!empty($pref->channels)) {
                $channels = $pref->channels;
            }
            $origin = 'user';
        }

        // P1 lock: cannot be disabled and must include inapp
        $isP1 = ($priority === 'P1') || (bool) $type->critical;
        if ($isP1) {
            $allowed = true;
            if (!in_array('inapp', $channels, true)) {
                $channels[] = 'inapp';
            }
        }

        // Elegibilidad por rol: si no calza, deshabilita
        if (! $this->isRoleEligibleForType($user, $type)) {
            $allowed = false;
        }

        return [
            'allowed' => $allowed,
            'channels' => array_values(array_unique($channels)),
            'priority' => $priority,
            'origin' => $origin,
            'locked' => $isP1,
        ];
    }

    public function userCanReceive(User $user, array $eventScope): bool
    {
            // Global admins reciben todo a nivel de alcance
        if ($user->hasRole('super-admin') || $user->hasRole('admin')) {
            return true;
        }

        // Determine scope specificity: branch > subsidiary > company
        if (!empty($eventScope['branch_id'])) {
            $branch = Branch::find($eventScope['branch_id']);
            return $branch ? $user->canAccessEntity('branch', $branch->id) : false;
        }
        if (!empty($eventScope['subsidiary_id'])) {
            $subs = Subsidiary::find($eventScope['subsidiary_id']);
            return $subs ? $user->canAccessEntity('subsidiary', $subs->id) : false;
        }
        if (!empty($eventScope['company_id'])) {
            $company = Company::find($eventScope['company_id']);
            return $company ? $user->canAccessEntity('company', $company->id) : false;
        }

        // No scope provided: allow
        return true;
    }

    /**
     * IDs de tipos permitidos para un usuario, según defaults y roles.
     */
    public function allowedTypeIdsForUser(User $user)
    {
        $types = NotificationType::all();
        $ids = [];
        foreach ($types as $t) {
            $eff = $this->resolveEffective($user, $t, []);
            if ($eff['allowed']) { $ids[] = $t->id; }
        }
        return $ids;
    }
}
