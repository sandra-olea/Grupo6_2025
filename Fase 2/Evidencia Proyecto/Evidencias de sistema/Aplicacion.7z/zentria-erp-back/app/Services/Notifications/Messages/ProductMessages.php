<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class ProductMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'product.created',
            'product.updated',
            'product.deleted',
            'product.stock-zero',
            'brand.created',
            'brand.updated',
            'brand.deleted',
            'category.created',
            'category.updated',
            'category.deleted',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        $branchSuffix = $this->branchSuffix($event, $payload);

        return match ($key) {
            'product.created' => (
                !empty($payload['serial_tracking']) && !empty($payload['is_parent'])
                    ? $this->fmt('Producto con seguimiento por serie creado: %s%s%s', $payload['product_name'] ?? null, $this->skuSuffix($payload), $branchSuffix)
                    : $this->fmt('Producto creado: %s%s%s', $payload['product_name'] ?? null, $this->skuSuffix($payload), $branchSuffix)
            ),
            'product.updated' => $this->fmt('Producto actualizado: %s%s%s', $payload['product_name'] ?? null, $this->skuSuffix($payload), $branchSuffix),
            'product.deleted' => $this->fmt('Producto eliminado: %s%s%s', $payload['product_name'] ?? null, $this->skuSuffix($payload), $branchSuffix),
            'product.stock-zero' => $this->fmt('Producto sin stock: %s%s', $payload['product_name'] ?? ('#'.$event->entity_id ?? 'Producto'), $this->skuSuffix($payload)),
            'brand.created' => $this->fmt('Marca creada: %s%s', $payload['brand_name'] ?? null, $branchSuffix),
            'brand.updated' => $this->fmt('Marca actualizada: %s%s', $payload['brand_name'] ?? null, $branchSuffix),
            'brand.deleted' => $this->fmt('Marca eliminada: %s%s', $payload['brand_name'] ?? null, $branchSuffix),
            'category.created' => $this->fmt('Categoría creada: %s%s', $payload['category_name'] ?? null, $branchSuffix),
            'category.updated' => $this->fmt('Categoría actualizada: %s%s', $payload['category_name'] ?? null, $branchSuffix),
            'category.deleted' => $this->fmt('Categoría eliminada: %s%s', $payload['category_name'] ?? null, $branchSuffix),
            default => null,
        };
    }
}
