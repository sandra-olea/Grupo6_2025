<?php

namespace App\Services\Notifications;

use App\Models\Notifications\NotificationEvent;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\UserNotification;
use App\Models\Notifications\NotificationDeliveryLog;
use App\Models\User;
use App\Models\ScopeRole;
use App\Models\Branch;
use App\Models\Subsidiary;
use App\Models\Company;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Jobs\SendP1NotificationEmail;

class NotificationRouter
{
    public function route(NotificationEvent $event): void
    {
        $type = NotificationType::find($event->type_id);
        if (!$type || !$type->enabled_global) {
            return; // disabled globally
        }

        $recipients = $this->resolveRecipients($event);

        $policy = app(NotificationPolicyService::class);
        $realtime = app(RealtimeService::class);
        $dedup = app(DeduplicationService::class);
        $rate = app(RateLimitService::class);

        $dedupTtl = (int) config('notifications.dedup_ttl', 7200);
        $windowStart = now()->subSeconds($dedupTtl);

        DB::transaction(function () use ($recipients, $policy, $type, $event, $realtime, $dedup, $rate, $windowStart) {
            foreach ($recipients as $user) {
                // scope enforcement (double-check)
                if (! $policy->userCanReceive($user, [
                    'company_id' => $event->company_id,
                    'subsidiary_id' => $event->subsidiary_id,
                    'branch_id' => $event->branch_id,
                ])) {
                    continue;
                }

                // Precedencia: allowed/channels/priority
                $effective = $policy->resolveEffective($user, $type, [
                    'company_id' => $event->company_id,
                    'subsidiary_id' => $event->subsidiary_id,
                    'branch_id' => $event->branch_id,
                ]);

                if (!$effective['allowed']) {
                    continue;
                }

                // Rate limit per user+type to avoid flooding
                $rateKey = $type->key.':user:'.$user->id;
                if (! $rate->allow($rateKey, 50, 60)) { // max 50/min per user+type
                    continue;
                }

                // Fast dedup guard via Redis; if duplicate, try aggregate path below
                $aggregate = $dedup->shouldAggregate($event->dedup_key.':user:'.$user->id, config('notifications.dedup_ttl', 7200));

                // Dedup/aggregate by dedup_key within TTL
                $existing = UserNotification::where('user_id', $user->id)
                    ->whereHas('event', function ($q) use ($event, $windowStart) {
                        $q->where('dedup_key', $event->dedup_key)
                          ->where('occurred_at', '>=', $windowStart);
                    })
                    ->latest('id')
                    ->first();

                if ($existing || $aggregate) {
                    $existing = $existing ?: UserNotification::create([
                        'user_id' => $user->id,
                        'event_id' => $event->id,
                        'status' => 'unread',
                        'delivered_channels' => in_array('inapp', $effective['channels'], true) ? ['inapp'] : [],
                        'delivered_to_user' => false,
                        'aggregate_count' => 0,
                    ]);
                    $existing->aggregate_count = ($existing->aggregate_count ?? 1) + 1;
                    $existing->last_occurred_at = $event->occurred_at ?? now();
                    $existing->save();

                    $realtime->emit($existing);
                    continue;
                }

                // Create fresh notification
                $notif = UserNotification::create([
                    'user_id' => $user->id,
                    'event_id' => $event->id,
                    'status' => 'unread',
                    'delivered_channels' => in_array('inapp', $effective['channels'], true) ? ['inapp'] : [],
                    'delivered_to_user' => false,
                    'aggregate_count' => 1,
                    'last_occurred_at' => null,
                ]);

                // Log in-app delivery
                if (in_array('inapp', $effective['channels'], true)) {
                    NotificationDeliveryLog::create([
                        'user_notification_id' => $notif->id,
                        'channel' => 'inapp',
                        'delivered_at' => now(),
                        'status' => 'ok',
                    ]);
                }

                $realtime->emit($notif);

                // For P1 notifications, queue an email per recipient using Redis with retries
                if (strtoupper((string) $event->priority) === 'P1') {
                    try {
                        SendP1NotificationEmail::dispatch($notif->id)
                            ->onConnection('redis')
                            ->onQueue('notifications.p1')
                            ->afterCommit();
                    } catch (\Throwable $e) {
                        Log::error('Failed to dispatch P1 email job', [
                            'user_id' => $user->id ?? null,
                            'notification_id' => $notif->id,
                            'error' => $e->getMessage(),
                        ]);
                    }
                }
            }
        });
    }

    /**
     * Resolve users who should receive this event based on scope.
     *
     * @return \Illuminate\Support\Collection<int, User>
     */
    protected function resolveRecipients(NotificationEvent $event)
    {
        if ($event->branch_id) {
            $branch = Branch::with(['users','subsidiary.company'])->find($event->branch_id);
            if (!$branch) return collect();

            $users = collect();
            // Usuarios directamente en la sucursal
            $users = $users->merge($branch->users);

            // Incluir branch-admins por scope_role aunque no estén en el pivot de usuarios
            try {
                $branchAdminIds = ScopeRole::whereHas('role', fn($q) => $q->where('name', 'branch-admin'))
                    ->where('scope_type', 'branch')
                    ->where('scope_id', $branch->id)
                    ->pluck('user_id');
                if ($branchAdminIds->isNotEmpty()) {
                    $branchAdmins = \App\Models\User::whereIn('id', $branchAdminIds)->get();
                    $users = $users->merge($branchAdmins);
                }
            } catch (\Throwable $e) {}

            // Incluir admins de subempresa/empresa con acceso aunque no estén unidos a la sucursal
            try {
                $subsId = $branch->subsidiary_id;
                $companyId = optional($branch->subsidiary)->company_id;
                $companyAdmins = \App\Models\User::role('company-admin')->get()
                    ->filter(fn($u) => $u->canAccessEntity('company', $companyId));
                $subsAdmins = \App\Models\User::role('subsidiary-admin')->get()
                    ->filter(fn($u) => $u->canAccessEntity('subsidiary', $subsId));
                $users = $users->merge($companyAdmins)->merge($subsAdmins);
            } catch (\Throwable $e) {}

            return $this->withSuperAdmins($users)->unique('id')->values();
        }
        if ($event->subsidiary_id) {
            $subs = Subsidiary::with(['branches.users','company'])->find($event->subsidiary_id);
            if (!$subs) return collect();
            $users = $subs->branches->flatMap(fn($b) => $b->users);
            // Incluir admins de empresa/subempresa
            try {
                $companyId = optional($subs->company)->id;
                $companyAdmins = \App\Models\User::role('company-admin')->get()
                    ->filter(fn($u) => $u->canAccessEntity('company', $companyId));
                $subsAdmins = \App\Models\User::role('subsidiary-admin')->get()
                    ->filter(fn($u) => $u->canAccessEntity('subsidiary', $subs->id));
                $users = $users->merge($companyAdmins)->merge($subsAdmins);
            } catch (\Throwable $e) {}
            return $this->withSuperAdmins($users)->unique('id')->values();
        }
        if ($event->company_id) {
            $company = Company::with(['subsidiaries.branches.users', 'users'])->find($event->company_id);
            if (!$company) return collect();
            $usersViaBranches = $company->subsidiaries->flatMap(fn($s) => $s->branches)->flatMap(fn($b) => $b->users);
            $users = $usersViaBranches->merge($company->users);
            // Incluir admins de empresa aunque no estén vinculados por pivote
            try {
                $companyAdmins = \App\Models\User::role('company-admin')->get()
                    ->filter(fn($u) => $u->canAccessEntity('company', $company->id));
                $users = $users->merge($companyAdmins);
            } catch (\Throwable $e) {}
            return $this->withSuperAdmins($users)->unique('id')->values();
        }

        // Fallback: no scope => no recipients
        return $this->withSuperAdmins(collect())->unique('id')->values();
    }

    protected function withSuperAdmins($users)
    {
        try {
            $supers = \App\Models\User::role('super-admin')->get();
            $admins = \App\Models\User::role('admin')->get();
            return $users->merge($supers)->merge($admins);
        } catch (\Throwable $e) {
            return $users; // si falla Spatie en early boot, no interrumpir
        }
    }
}
