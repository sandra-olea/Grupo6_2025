<?php

namespace App\Services\Notifications;

class DigestService
{
    public function dispatchPendingDigests(): void
    {
        // Placeholder
    }
}

