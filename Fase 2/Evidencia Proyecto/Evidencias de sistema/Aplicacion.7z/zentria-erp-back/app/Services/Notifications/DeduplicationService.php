<?php

namespace App\Services\Notifications;

class DeduplicationService
{
    public function shouldAggregate(string $dedupKey, int $ttlSeconds): bool
    {
        // Use Redis SETNX to detect duplicates within TTL window
        try {
            $key = 'dedup:'.$dedupKey;
            $redis = \Illuminate\Support\Facades\Redis::connection();
            $wasSet = $redis->setnx($key, '1');
            if ($wasSet) {
                // first time seen in window; set TTL
                $redis->expire($key, $ttlSeconds);
                return false; // do not aggregate, it's new
            }
            return true; // already exists -> aggregate
        } catch (\Throwable $e) {
            // Fallback: without Redis, rely on DB logic done by router
            return false;
        }
    }
}
