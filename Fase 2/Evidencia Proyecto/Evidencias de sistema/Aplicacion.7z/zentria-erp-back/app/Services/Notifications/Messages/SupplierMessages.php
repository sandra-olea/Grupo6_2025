<?php

namespace App\Services\Notifications\Messages;

use App\Models\Notifications\NotificationEvent;

class SupplierMessages extends AbstractMessageFormatter
{
    public function handles(): array
    {
        return [
            'supplier.created',
            'supplier.updated',
            'supplier.deleted',
            'supplier.customers-attached',
            'supplier.customers-detached',
        ];
    }

    public function format(string $key, NotificationEvent $event, array $payload): ?string
    {
        return match ($key) {
            'supplier.created' => $this->fmt('Proveedor creado: %s - Creado en: %s', $payload['supplier_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'supplier.updated' => $this->fmt('Proveedor actualizado: %s - Creado en: %s', $payload['supplier_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'supplier.deleted' => $this->fmt('Proveedor eliminado: %s - Creado en: %s', $payload['supplier_name'] ?? null, $payload['subsidiary_name'] ?? null),
            'supplier.customers-attached' => $this->formatCustomersAttached($payload),
            'supplier.customers-detached' => $this->formatCustomersDetached($payload),
            default => null,
        };
    }

    private function formatCustomersAttached(array $payload): string
    {
        $count = (int)($payload['customers_count'] ?? 0);
        $supplierName = $payload['supplier_name'] ?? 'Proveedor';
        $customerNames = $payload['customer_names'] ?? null;
        $subsidiary = $payload['subsidiary_name'] ?? null;

        if ($count === 1 && $customerNames) {
            return $this->fmt('El proveedor "%s" ahora abastece al cliente: %s | %s', $supplierName, $customerNames, $subsidiary);
        }

        if ($customerNames) {
            return $this->fmt('El proveedor "%s" ahora abastece a %s clientes: %s | %s', $supplierName, (string)$count, $customerNames, $subsidiary);
        }

        return $this->fmt('Se asociaron %s cliente(s) al proveedor "%s" | %s', (string)$count, $supplierName, $subsidiary);
    }

    private function formatCustomersDetached(array $payload): string
    {
        $count = (int)($payload['customers_count'] ?? 0);
        $supplierName = $payload['supplier_name'] ?? 'Proveedor';
        $customerNames = $payload['customer_names'] ?? null;
        $subsidiary = $payload['subsidiary_name'] ?? null;

        if ($count === 1 && $customerNames) {
            return $this->fmt('El proveedor "%s" dejó de abastecer al cliente: %s | %s', $supplierName, $customerNames, $subsidiary);
        }

        if ($customerNames) {
            return $this->fmt('El proveedor "%s" se desvinculó de %s clientes: %s | %s', $supplierName, (string)$count, $customerNames, $subsidiary);
        }

        return $this->fmt('Se desasociaron %s cliente(s) del proveedor "%s" | %s', (string)$count, $supplierName, $subsidiary);
    }
}
