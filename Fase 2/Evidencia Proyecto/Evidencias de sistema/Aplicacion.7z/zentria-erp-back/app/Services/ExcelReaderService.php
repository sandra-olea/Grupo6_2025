<?php

namespace App\Services;

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Illuminate\Support\Facades\Log;

class ExcelReaderService
{
    /**
     * Lee un archivo Excel y retorna información sobre su estructura
     *
     * @param string $filePath Ruta completa al archivo Excel
     * @return array
     * @throws \Exception
     */
    public function readExcelFile(string $filePath): array
    {
        if (!file_exists($filePath)) {
            throw new \Exception("El archivo no existe: {$filePath}");
        }

        try {
            // Cargar el archivo Excel
            $spreadsheet = IOFactory::load($filePath);
            
            $result = [
                'file_name' => basename($filePath),
                'total_sheets' => $spreadsheet->getSheetCount(),
                'sheets' => []
            ];

            // Iterar sobre cada hoja
            foreach ($spreadsheet->getAllSheets() as $index => $sheet) {
                $sheetData = $this->readSheet($sheet, $index);
                $result['sheets'][] = $sheetData;
            }

            return $result;
        } catch (\Exception $e) {
            Log::error("Error al leer el archivo Excel: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Lee una hoja específica del Excel
     *
     * @param Worksheet $sheet
     * @param int $index
     * @return array
     */
    protected function readSheet(Worksheet $sheet, int $index): array
    {
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);

        // Leer encabezados (primera fila)
        $headers = [];
        for ($col = 1; $col <= $highestColumnIndex; $col++) {
            $columnLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($col);
            $cellValue = $sheet->getCell($columnLetter . '1')->getValue();
            $headers[] = $cellValue ?? '';
        }

        // Leer todas las filas de datos
        $data = [];
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = [];
            for ($col = 1; $col <= $highestColumnIndex; $col++) {
                $columnLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($col);
                $cellValue = $sheet->getCell($columnLetter . $row)->getValue();
                $rowData[] = $cellValue;
            }
            $data[] = $rowData;
        }

        return [
            'index' => $index,
            'name' => $sheet->getTitle(),
            'total_rows' => $highestRow,
            'total_columns' => $highestColumnIndex,
            'highest_column' => $highestColumn,
            'headers' => $headers,
            'data' => $data,
            'sample_data' => array_slice($data, 0, 5) // Primeras 5 filas como muestra
        ];
    }

    /**
     * Lee solo los encabezados de un archivo Excel
     *
     * @param string $filePath
     * @param int|null $sheetIndex Si es null, lee todas las hojas
     * @return array
     */
    public function readHeaders(string $filePath, ?int $sheetIndex = 0): array
    {
        if (!file_exists($filePath)) {
            throw new \Exception("El archivo no existe: {$filePath}");
        }

        $spreadsheet = IOFactory::load($filePath);
        
        // Si sheetIndex es null, leer todas las hojas
        if ($sheetIndex === null) {
            $result = [
                'file_name' => basename($filePath),
                'total_sheets' => $spreadsheet->getSheetCount(),
                'sheets' => []
            ];
            
            foreach ($spreadsheet->getAllSheets() as $index => $sheet) {
                $result['sheets'][] = $this->getSheetHeaders($sheet, $index);
            }
            
            return $result;
        }
        
        // Leer solo una hoja específica
        $sheet = $spreadsheet->getSheet($sheetIndex);
        return $this->getSheetHeaders($sheet, $sheetIndex);
    }
    
    /**
     * Obtiene los encabezados de una hoja específica
     *
     * @param Worksheet $sheet
     * @param int $index
     * @return array
     */
    protected function getSheetHeaders(Worksheet $sheet, int $index): array
    {
        $highestColumn = $sheet->getHighestColumn();
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);

        $headers = [];
        for ($col = 1; $col <= $highestColumnIndex; $col++) {
            $columnLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($col);
            $cellValue = $sheet->getCell($columnLetter . '1')->getValue();
            $headers[$columnLetter] = $cellValue ?? '';
        }

        return [
            'sheet_index' => $index,
            'sheet_name' => $sheet->getTitle(),
            'total_columns' => $highestColumnIndex,
            'highest_column' => $highestColumn,
            'headers' => $headers
        ];
    }

    /**
     * Valida que un archivo Excel tenga los encabezados requeridos
     *
     * @param string $filePath
     * @param array $requiredHeaders
     * @param int $sheetIndex
     * @return array
     */
    public function validateHeaders(string $filePath, array $requiredHeaders, int $sheetIndex = 0): array
    {
        $headerInfo = $this->readHeaders($filePath, $sheetIndex);
        $actualHeaders = array_values($headerInfo['headers']);
        
        $missingHeaders = array_diff($requiredHeaders, $actualHeaders);
        $extraHeaders = array_diff($actualHeaders, $requiredHeaders);

        return [
            'valid' => empty($missingHeaders),
            'required_headers' => $requiredHeaders,
            'actual_headers' => $actualHeaders,
            'missing_headers' => array_values($missingHeaders),
            'extra_headers' => array_values($extraHeaders)
        ];
    }

    /**
     * Lee el archivo de plantilla ECOPC
     *
     * @return array
     */
    public function readEcopcTemplate(): array
    {
        $templatePath = public_path('templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx');
        
        if (!file_exists($templatePath)) {
            throw new \Exception("La plantilla ECOPC no existe en: {$templatePath}");
        }

        return $this->readExcelFile($templatePath);
    }
    
    /**
     * Obtiene información básica de todas las hojas de un archivo Excel
     *
     * @param string $filePath
     * @return array
     */
    public function getSheetsList(string $filePath): array
    {
        if (!file_exists($filePath)) {
            throw new \Exception("El archivo no existe: {$filePath}");
        }

        $spreadsheet = IOFactory::load($filePath);
        
        $sheets = [];
        foreach ($spreadsheet->getAllSheets() as $index => $sheet) {
            $sheets[] = [
                'index' => $index,
                'name' => $sheet->getTitle(),
                'total_rows' => $sheet->getHighestRow(),
                'total_columns' => \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($sheet->getHighestColumn()),
                'highest_column' => $sheet->getHighestColumn(),
                'is_active' => $spreadsheet->getActiveSheetIndex() === $index
            ];
        }
        
        return [
            'file_name' => basename($filePath),
            'total_sheets' => count($sheets),
            'sheets' => $sheets
        ];
    }
    
    /**
     * Lee una hoja específica por nombre
     *
     * @param string $filePath
     * @param string $sheetName
     * @return array
     */
    public function readSheetByName(string $filePath, string $sheetName): array
    {
        if (!file_exists($filePath)) {
            throw new \Exception("El archivo no existe: {$filePath}");
        }

        $spreadsheet = IOFactory::load($filePath);
        
        try {
            $sheet = $spreadsheet->getSheetByName($sheetName);
            
            if (!$sheet) {
                throw new \Exception("La hoja '{$sheetName}' no existe en el archivo");
            }
            
            $sheetIndex = $spreadsheet->getIndex($sheet);
            return $this->readSheet($sheet, $sheetIndex);
        } catch (\Exception $e) {
            throw new \Exception("Error al leer la hoja '{$sheetName}': " . $e->getMessage());
        }
    }
}
