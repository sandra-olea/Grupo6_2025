<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use Spatie\Permission\PermissionRegistrar;

class UsersRolesReport extends Command
{
    protected $signature = 'users:roles {--guard=api} {--details} {--only= : Email o ID (coma-separado) para filtrar usuarios}';
    protected $description = 'Lista roles y permisos por usuario (guard api por defecto)';

    public function handle(): int
    {
        app()->make(PermissionRegistrar::class)->forgetCachedPermissions();

        $guard = (string) $this->option('guard');
        $only  = (string) $this->option('only');

        $q = User::query()->with(['roles', 'permissions']);

        if ($only) {
            $tokens = collect(explode(',', $only))->map(fn($v) => trim($v))->filter();
            $q->where(function ($w) use ($tokens) {
                foreach ($tokens as $t) {
                    if (ctype_digit($t)) {
                        $w->orWhere('id', (int) $t);
                    } else {
                        $w->orWhere('email', $t);
                    }
                }
            });
        }

        $users = $q->orderBy('id')->get();

        foreach ($users as $u) {
            $name = trim(($u->first_name.' '.$u->last_name)) ?: ($u->email ?? ('#'.$u->id));
            $this->line("\n".str_repeat('-', 60));
            $this->info(sprintf('#%d  %s  <%s>', $u->id, $name, $u->email));

            // Roles (mostrar todos, indicando guard)
            $roles = $u->roles->map(fn($r) => $r->name.'@'.$r->guard_name)->values()->all();
            $this->line('Roles: '.(empty($roles) ? '(ninguno)' : implode(', ', $roles)));

            // Permisos efectivos (vía roles + directos), filtrando por guard requerido
            $allPerms = $u->getAllPermissions()->filter(fn($p) => $p->guard_name === $guard)->pluck('name')->unique()->values();
            $this->line('Permisos ('.$guard.'): '.$allPerms->count());

            if ($this->option('details')) {
                foreach ($allPerms as $p) {
                    $this->line('  - '.$p);
                }
            }

            // Permisos directos
            $direct = $u->permissions->filter(fn($p) => $p->guard_name === $guard)->pluck('name')->values();
            if ($direct->isNotEmpty()) {
                $this->line('Directos: '.implode(', ', $direct->all()));
            }
        }

        $this->newLine();
        $this->info('Listado completado.');
        return self::SUCCESS;
    }
}

