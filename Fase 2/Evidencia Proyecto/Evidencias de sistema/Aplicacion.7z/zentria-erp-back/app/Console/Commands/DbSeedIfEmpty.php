<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DbSeedIfEmpty extends Command
{
    protected $signature = 'db:seed-if-empty {--force}';
    protected $description = 'Run DatabaseSeeder if key tables (notifications) are empty';

    public function handle(): int
    {
        try {
            if (!Schema::hasTable('notification_types')) {
                $this->info('notification_types table not found; skipping auto-seed.');
                return self::SUCCESS;
            }

            $countTypes = (int) DB::table('notification_types')->count();
            $countDefaults = Schema::hasTable('role_notification_defaults') ? (int) DB::table('role_notification_defaults')->count() : 0;

            if ($countTypes === 0 || $countDefaults === 0) {
                $this->warn('Seeding database because notifications tables are empty...');
                $this->call('db:seed', ['--force' => true]);
            } else {
                $this->info('Notifications already seeded. Skipping.');
            }
        } catch (\Throwable $e) {
            $this->error('db:seed-if-empty failed: '.$e->getMessage());
            return self::FAILURE;
        }

        return self::SUCCESS;
    }
}

