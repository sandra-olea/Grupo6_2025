<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class RolesDiagnose extends Command
{
    protected $signature = 'roles:diagnose {--guard=api} {--details}';
    protected $description = 'Muestra conteo de permisos por rol y posibles problemas de guard o duplicados';

    public function handle(): int
    {
        app()->make(PermissionRegistrar::class)->forgetCachedPermissions();

        $guard = (string) $this->option('guard');

        $this->info("Guard: {$guard}");

        $roles = Role::query()->orderBy('name')->get(['id','name','guard_name']);

        $byName = $roles->groupBy('name');
        foreach ($byName as $name => $set) {
            if ($set->count() > 1) {
                $this->warn("Duplicado de rol '{$name}' en guards: ". $set->pluck('guard_name')->join(', '));
            }
        }

        $this->newLine();
        $this->line(str_pad('ROL', 28) . str_pad('GUARD', 10) . 'PERMISOS');
        $this->line(str_repeat('-', 50));

        $roles->each(function (Role $role) use ($guard) {
            $count = $role->permissions()->count();
            $label = str_pad($role->name, 28) . str_pad($role->guard_name, 10) . $count;
            if ($role->guard_name !== $guard) {
                $this->warn($label . '   (otro guard)');
            } elseif ($count === 0) {
                $this->error($label . '   (sin permisos)');
            } else {
                $this->info($label);
            }

            if ($this->option('details')) {
                $perms = $role->permissions()->pluck('name')->all();
                foreach ($perms as $p) {
                    $this->line('  - '.$p);
                }
            }
        });

        $this->newLine();
        $missing = [];
        foreach (['company-admin','subsidiary-admin','branch-admin','warehouse-employee','super-admin'] as $r) {
            $role = $roles->firstWhere('name',$r);
            if (!$role) {
                $missing[] = $r;
            }
        }
        if ($missing) {
            $this->warn('Roles esperados no encontrados: '.implode(', ', $missing));
        }

        $guards = Permission::select('guard_name')->distinct()->pluck('guard_name')->all();
        $this->line('Guards en permissions: '.implode(', ', $guards));

        return self::SUCCESS;
    }
}
