<?php

namespace App\Console\Commands;

use App\Services\ProductImportService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class ImportProductsFromExcel extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'products:import 
                            {file : Ruta al archivo Excel a importar}
                            {branch_id : ID de la sucursal}
                            {--update-existing : Actualizar productos existentes}
                            {--preview : Solo mostrar vista previa sin importar}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Importa productos desde un archivo Excel';

    protected ProductImportService $importService;

    /**
     * Create a new command instance.
     */
    public function __construct(ProductImportService $importService)
    {
        parent::__construct();
        $this->importService = $importService;
    }

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $filePath = $this->argument('file');
        $branchId = $this->argument('branch_id');
        $updateExisting = $this->option('update-existing');
        $preview = $this->option('preview');

        // Verificar que el archivo existe
        if (!file_exists($filePath)) {
            $this->error("El archivo no existe: {$filePath}");
            return Command::FAILURE;
        }

        // Verificar que la sucursal existe
        $branch = \App\Models\Branch::find($branchId);
        if (!$branch) {
            $this->error("La sucursal con ID {$branchId} no existe");
            return Command::FAILURE;
        }

        $this->info("📦 Iniciando importación de productos...");
        $this->info("📁 Archivo: {$filePath}");
        $this->info("🏢 Sucursal: {$branch->name} (ID: {$branchId})");
        $this->newLine();

        if ($preview) {
            return $this->handlePreview($filePath);
        }

        try {
            $options = [
                'update_existing' => $updateExisting,
            ];

            $this->info("⏳ Procesando archivo...");
            $startTime = microtime(true);

            $results = $this->importService->importFromExcel($filePath, $branchId, $options);

            $processingTime = round(microtime(true) - $startTime, 2);

            $this->newLine();
            $this->info("✅ Importación completada en {$processingTime} segundos");
            $this->newLine();

            // Mostrar resumen
            $this->displayResults($results);

            // Mostrar errores si los hay
            if (!empty($results['errors'])) {
                $this->newLine();
                $this->displayErrors($results['errors']);
            }

            return Command::SUCCESS;

        } catch (\Exception $e) {
            $this->error("❌ Error durante la importación: " . $e->getMessage());
            Log::error("Error en importación de productos", [
                'file' => $filePath,
                'branch_id' => $branchId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return Command::FAILURE;
        }
    }

    /**
     * Muestra una vista previa de lo que se importaría
     */
    protected function handlePreview(string $filePath): int
    {
        try {
            $excelReader = app(\App\Services\ExcelReaderService::class);
            $excelData = $excelReader->readExcelFile($filePath);

            $this->info("📊 Vista previa del archivo");
            $this->info("Total de hojas: {$excelData['total_sheets']}");
            $this->newLine();

            foreach ($excelData['sheets'] as $sheet) {
                // Saltar hojas de validación
                if (in_array(strtolower($sheet['name']), ['validaciones', 'validations', 'config'])) {
                    continue;
                }

                $this->info("📄 Hoja: {$sheet['name']}");
                $this->info("   Total de filas: " . ($sheet['total_rows'] - 1));
                $this->info("   Total de columnas: {$sheet['total_columns']}");
                
                $this->newLine();
                $this->info("   Columnas detectadas:");
                
                // Mostrar columnas en formato de tabla
                $headers = array_map(function($h) {
                    return substr($h ?? 'N/A', 0, 20);
                }, $sheet['headers']);
                
                $chunks = array_chunk($headers, 5);
                foreach ($chunks as $chunk) {
                    $this->line("   - " . implode(', ', $chunk));
                }

                // Mostrar muestra de datos
                if (!empty($sheet['sample_data'])) {
                    $this->newLine();
                    $this->info("   Muestra de datos (primeras 3 filas):");
                    
                    foreach (array_slice($sheet['sample_data'], 0, 3) as $index => $row) {
                        $rowNumber = $index + 2;
                        $sku = $row[0] ?? 'N/A';
                        $name = isset($row[1]) ? substr($row[1], 0, 30) : 'N/A';
                        $this->line("   Fila {$rowNumber}: SKU={$sku}, Name={$name}...");
                    }
                }

                $this->newLine();
            }

            $this->info("✅ Vista previa generada correctamente");
            $this->comment("💡 Para importar los productos, ejecuta el comando sin la opción --preview");

            return Command::SUCCESS;

        } catch (\Exception $e) {
            $this->error("❌ Error generando vista previa: " . $e->getMessage());
            return Command::FAILURE;
        }
    }

    /**
     * Muestra los resultados de la importación
     */
    protected function displayResults(array $results): void
    {
        $this->table(
            ['Métrica', 'Valor'],
            [
                ['Total de hojas', $results['total_sheets']],
                ['Hojas procesadas', count($results['sheets_processed'])],
                ['Total de productos', $results['total_products']],
                ['Exitosos', $results['successful']],
                ['Fallidos', $results['failed']],
                ['Omitidos', $results['skipped']],
                ['Tiempo de procesamiento', $results['processing_time'] . 's'],
            ]
        );

        if (!empty($results['sheets_processed'])) {
            $this->newLine();
            $this->info("📊 Detalle por hoja:");
            
            $sheetData = [];
            foreach ($results['sheets_processed'] as $sheet) {
                $sheetData[] = [
                    $sheet['name'],
                    $sheet['total_rows'],
                    $sheet['processed'],
                    $sheet['successful'],
                    $sheet['failed'],
                    $sheet['skipped'],
                ];
            }

            $this->table(
                ['Hoja', 'Total', 'Procesados', 'Exitosos', 'Fallidos', 'Omitidos'],
                $sheetData
            );
        }
    }

    /**
     * Muestra los errores de la importación
     */
    protected function displayErrors(array $errors): void
    {
        $this->error("⚠️  Errores encontrados durante la importación:");
        $this->newLine();

        $errorData = [];
        foreach (array_slice($errors, 0, 10) as $error) {
            $errorData[] = [
                $error['sheet'] ?? 'N/A',
                $error['row'] ?? 'N/A',
                $error['sku'] ?? 'N/A',
                substr($error['error'] ?? 'Error desconocido', 0, 50),
            ];
        }

        $this->table(
            ['Hoja', 'Fila', 'SKU', 'Error'],
            $errorData
        );

        if (count($errors) > 10) {
            $remaining = count($errors) - 10;
            $this->warn("... y {$remaining} errores más (revisa los logs para ver todos)");
        }
    }
}
