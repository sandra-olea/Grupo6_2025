<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class InspectTemplateXlsx extends Command
{
    protected $signature = 'excel:inspect-template {path=storage/app/public/templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx}';

    protected $description = 'List sheet names and first-row headers from an XLSX template';

    public function handle(): int
    {
        $path = base_path($this->argument('path'));
        if (!is_file($path)) {
            $this->error("File not found: {$path}");
            return self::FAILURE;
        }

        try {
            // PhpSpreadsheet is the underlying reader
            $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($path);
            $reader->setReadDataOnly(true);
            $spreadsheet = $reader->load($path);
        } catch (\Throwable $e) {
            $this->error('Failed to read XLSX. Ensure phpoffice/phpspreadsheet is installed and ext-zip is enabled.');
            $this->line($e->getMessage());
            return self::FAILURE;
        }

        foreach ($spreadsheet->getAllSheets() as $sheet) {
            $title = $sheet->getTitle();
            $highestColumn = $sheet->getHighestColumn();
            $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);

            $headers = [];
            for ($col = 1; $col <= $highestColumnIndex; $col++) {
                $value = (string) $sheet->getCellByColumnAndRow($col, 1)->getValue();
                $headers[] = trim($value);
            }

            $this->info("Sheet: {$title}");
            if (count(array_filter($headers, fn($h) => $h !== '')) === 0) {
                $this->line('  (No headers found in first row)');
            } else {
                foreach ($headers as $i => $header) {
                    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i + 1);
                    $this->line("  {$colLetter}: " . ($header !== '' ? $header : '[empty]'));
                }
            }

            $this->newLine();
        }

        return self::SUCCESS;
    }
}

