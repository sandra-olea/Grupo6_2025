<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TechnicalReviewBatchResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $tz = config('app.timezone', 'America/Santiago');

        return [
            'id' => $this->id,
            'code' => $this->code,
            'branch' => [
                'id' => $this->branch_id,
                'name' => $this->branch?->branch_name,
            ],
            'warehouse' => [
                'id' => $this->warehouse_id,
                'name' => $this->warehouse?->name,
            ],
            'customer_supplier' => $this->customerSupplier ? [
                'id' => $this->customer_supplier_id,
                'name' => $this->customerSupplier->name,
            ] : null,
            'supplier' => $this->supplier ? [
                'id' => $this->supplier_id,
                'name' => $this->supplier->name,
            ] : null,
            'entry_date' => $this->entry_date?->format('Y-m-d'),
            'review_date' => $this->review_date?->format('Y-m-d'),
            'expected_quantity' => $this->expected_quantity,
            'received_quantity' => $this->received_quantity,
            'completed_quantity' => $this->completed_quantity,
            'pending_count' => $this->pending_items_count,
            'progress' => round($this->progress, 2),
            'status' => $this->status,
            'notes' => $this->notes,
            'created_by' => [
                'id' => $this->created_by,
                'name' => $this->resolveUserName($this->creator),
            ],
            'updated_by' => $this->updated_by ? [
                'id' => $this->updated_by,
                'name' => $this->resolveUserName($this->updater),
            ] : null,
            'created_at' => $this->created_at?->timezone($tz)->toIso8601String(),
            'updated_at' => $this->updated_at?->timezone($tz)->toIso8601String(),
            // Resumen para facilitar tabs por tipo y KPIs en la vista del lote
            'items_summary' => $this->when($this->relationLoaded('items'), function () {
                $items = $this->items;

                $byType = [
                    'notebook' => 0,
                    'desktop' => 0,
                    'docking' => 0,
                    'aio' => 0,
                    'monitor' => 0,
                ];
                $byReviewStatus = [];
                $byCurrentStatus = [];
                $byGrade = [
                    'A' => 0,
                    'B' => 0,
                    'C' => 0,
                    'M' => 0,
                ];

                foreach ($items as $it) {
                    // Por tipo
                    $t = is_object($it->equipment_type) ? $it->equipment_type->value : (string) $it->equipment_type;
                    if (isset($byType[$t])) $byType[$t]++;

                    // Por estado de revisión
                    $rs = is_object($it->review_status) ? $it->review_status->value : (string) $it->review_status;
                    if ($rs !== '') $byReviewStatus[$rs] = ($byReviewStatus[$rs] ?? 0) + 1;

                    // Por estado actual (trazabilidad)
                    $cs = is_object($it->current_status) ? $it->current_status->value : (string) $it->current_status;
                    if ($cs !== '') $byCurrentStatus[$cs] = ($byCurrentStatus[$cs] ?? 0) + 1;

                    // Por grado final (si existe)
                    if ($it->grade) {
                        $gv = is_object($it->grade) ? $it->grade->value : (string) $it->grade;
                        if (isset($byGrade[$gv])) $byGrade[$gv]++;
                    }
                }

                return [
                    'total' => $items->count(),
                    'by_equipment_type' => $byType,
                    'by_review_status' => $byReviewStatus,
                    'by_current_status' => $byCurrentStatus,
                    'by_grade' => $byGrade,
                ];
            }),
        ];
    }

    private function resolveUserName($user): ?string
    {
        if (! $user) {
            return null;
        }

        $fullName = trim((string) $user->full_name);
        if ($fullName !== '') {
            return $fullName;
        }

        $fallback = array_filter([$user->first_name, $user->last_name]);
        if (!empty($fallback)) {
            return trim(implode(' ', $fallback));
        }

        return $user->email;
    }
}
