<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\Document;

class DocumentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        // Resolve media items (attachments) for size and uploader calculations
        $shouldLoadAttachments = $request->boolean('with_attachments') || $this->relationLoaded('media');
        $attachments = collect();
        if ($shouldLoadAttachments) {
            if ($this->relationLoaded('media')) {
                // Filter only known collections when media is eager loaded
                $attachments = $this->media->filter(function ($m) {
                    return in_array($m->collection_name, ['files', 'attachments']);
                })->values();
            } else {
                // Merge the configured collections
                $attachments = collect()
                    ->merge($this->getMedia('files'))
                    ->merge($this->getMedia('attachments'));
            }
        }
        $totalSize = $attachments->sum('size');
        $latest = $attachments->sortByDesc('created_at')->first();
        $uploadedBy = $latest?->getCustomProperty('uploaded_by');

        return [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'document_type_id' => $this->document_type_id,
            'name' => $this->name,
            'description' => $this->description,
            'output_format' => $this->output_format,
            'related_module' => $this->related_module,
            'related_id' => $this->related_id,
            'template_body' => $this->template_body,
            'metadata' => $this->metadata,
            'is_active' => (bool) $this->is_active,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            // Aggregated info (size reported in KB)
            'size' => $shouldLoadAttachments ? (int) round($totalSize / 1024) : null,
            'uploaded_by' => $shouldLoadAttachments ? $uploadedBy : null,
            'document_type' => $this->whenLoaded('documentType', fn() => new DocumentTypeResource($this->documentType)),
            'subsidiary' => $this->whenLoaded('subsidiary', fn() => new SubsidiaryResource($this->subsidiary)),
            // Incluir adjuntos cuando:
            // - se solicita con ?with_attachments=1, o
            // - el controlador cargó la relación 'media' explícitamente (detalle)
            'attachments' => $this->when($request->boolean('with_attachments') || $this->relationLoaded('media'), function () use ($attachments) {
                $items = $attachments;
                return $items->map(function ($m) {
                    return [
                        'id' => $m->id,
                        'collection' => $m->collection_name,
                        'url' => $m->getUrl(),
                        'file_name' => $m->file_name,
                        'mime_type' => $m->mime_type,
                        // Individual attachment size in KB
                        'size' => (int) round($m->size / 1024),
                        'original_name' => $m->getCustomProperty('original_name'),
                        'uploaded_by' => $m->getCustomProperty('uploaded_by'),
                        'uploaded_at' => $m->created_at,
                    ];
                });
            }),
        ];
    }
}
