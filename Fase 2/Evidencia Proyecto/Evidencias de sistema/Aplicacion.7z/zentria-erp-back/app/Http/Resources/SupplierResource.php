<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SupplierResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'name' => $this->name,
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),
            
            // Relaciones opcionales
            'subsidiary' => $this->whenLoaded('subsidiary', fn() => [
                'id' => $this->subsidiary->id,
                'name' => $this->subsidiary->subsidiary_name,
            ]),
            
            'customer_suppliers_count' => $this->when(
                isset($this->customer_suppliers_count),
                $this->customer_suppliers_count
            ),
            
            'customer_suppliers' => CustomerSupplierResource::collection(
                $this->whenLoaded('customerSuppliers')
            ),
            
            // Indicar si hay más clientes disponibles
            'has_more_customers' => $this->when(
                $this->relationLoaded('customerSuppliers') && isset($this->customer_suppliers_count),
                fn() => $this->customerSuppliers->count() < $this->customer_suppliers_count
            ),
        ];
    }
}
