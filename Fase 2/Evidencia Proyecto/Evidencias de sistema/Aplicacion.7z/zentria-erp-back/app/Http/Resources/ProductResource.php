<?php
namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray($request) {
        return [
            'id' => $this->id,
            'branch_id' => $this->branch_id,
            'parent_product_id' => $this->parent_product_id,
            'is_parent' => $this->when($this->serial_tracking, $this->parent_product_id === null),
            'is_child' => $this->when($this->serial_tracking, $this->parent_product_id !== null),
            'sku' => $this->sku,
            'commercial_sku' => $this->commercial_sku,
            'barcode' => $this->barcode,
            'name' => $this->name,
            'grade' => $this->grade?->value,
            'brand' => $this->whenLoaded('brand', fn() => [
                'id' => $this->brand->id,
                'name' => $this->brand->name,
                'slug' => $this->brand->slug,
            ]),
            'product_type' => $this->product_type,
            'warranty_months' => $this->warranty_months,
            'serial_tracking' => $this->serial_tracking,
            'short_description' => $this->short_description,
            'long_description' => $this->long_description,
            'stock' => $this->stock,
            'snippet_description' => $this->snippet_description,
            'cost' => $this->cost,
            'price' => $this->price,
            'offer_price' => $this->offer_price,
            'product_status' => $this->product_status,
            'attributes_json' => $this->attributes_json,
            'marketplace_external_ids' => $this->marketplace_external_ids,
            'is_active' => $this->is_active,
            'category_ids' => $this->whenLoaded('categories', fn() => $this->categories->map(fn($c) => [
                'id' => $c->id, 'name' => $c->name, 'slug' => $c->slug,
            ])),
            'image'   => $this->primaryImagePayload(),
            'gallery' => $this->galleryPayload(),
            // Desgloses de stock basados en series aprobadas
            'stock_by_status' => $this->when($this->serial_tracking, fn() => $this->getSerialCountByStatus()),
            // Información del padre cuando es variante (hijo)
            'parent' => $this->when($this->parent_product_id && $this->relationLoaded('parent'), function () {
                return [
                    'id' => $this->parent->id,
                    'sku' => $this->parent->sku,
                    'name' => $this->parent->name,
                ];
            }),
            // Hijos por grado cuando es producto padre con tracking por serie
            'children' => $this->when($this->serial_tracking && !$this->parent_product_id, function () {
                $children = $this->relationLoaded('children') ? $this->children : collect();
                return $children->map(function ($c) {
                    return [
                        'id' => $c->id,
                        'grade' => $c->grade?->value,
                        'sku' => $c->sku,
                        'name' => $c->name,
                        'marketplace_external_ids' => $c->marketplace_external_ids,
                        'price' => $c->price,
                        'offer_price' => $c->offer_price,
                        'stock' => $c->stock,
                        'stock_by_status' => $c->getSerialCountByStatus(),
                    ];
                })->values();
            }),
            // Series disponibles por grado (solo en hijos con tracking por serie). Si no hay, no se incluye.
            'available_serials' => $this->when(
                $this->serial_tracking
                && $this->parent_product_id
                && optional($request->route())->getActionMethod() === 'show',
                function () {
                    $serials = $this->getAvailableSerialNumbersForChildGrade();
                    return $serials->isNotEmpty() ? $serials->values() : null;
                }
            ),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
