<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EquipmentMovementResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $tz = config('app.timezone', 'America/Santiago');

        return [
            'id' => $this->id,
            'serial_number' => $this->serial_number,
            'movement_type' => [
                'value' => $this->movement_type?->value,
                'label' => $this->movement_type?->label(),
            ],
            'from_warehouse' => $this->fromWarehouse ? [
                'id' => $this->from_warehouse_id,
                'name' => $this->fromWarehouse->name,
            ] : null,
            'to_warehouse' => $this->toWarehouse ? [
                'id' => $this->to_warehouse_id,
                'name' => $this->toWarehouse->name,
            ] : null,
            'previous_status' => $this->previous_status,
            'new_status' => $this->new_status,
            'reason' => $this->reason,
            'metadata' => $this->metadata,
            'performed_by' => [
                'id' => $this->performed_by,
                'name' => $this->performedBy?->short_name,
            ],
            'movement_date' => $this->movement_date?->timezone($tz)->toIso8601String(),
            'created_at' => $this->created_at?->timezone($tz)->toIso8601String(),
        ];
    }
}
