<?php
namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class WarehouseProductResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'sku' => $this->sku,
            'name' => $this->name,
            'description' => $this->description,
            'branch_id' => $this->branch_id,
            'brand_id' => $this->brand_id,
            'brand_name' => $this->brand?->name,
            'quantity' => $this->pivot->quantity ?? 0,
            'sync_stock' => $this->pivot->sync_stock ?? false,
            'price' => $this->price,
            'cost' => $this->cost,
            'is_active' => $this->is_active,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'pivot_created_at' => $this->pivot->created_at ?? null,
            'pivot_updated_at' => $this->pivot->updated_at ?? null,
        ];
    }
}
