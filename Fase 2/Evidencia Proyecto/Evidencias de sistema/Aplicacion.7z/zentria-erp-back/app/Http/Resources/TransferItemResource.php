<?php
namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TransferItemResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'quantity' => (int) $this->quantity,
            'origin_product' => [
                'id' => $this->originProduct?->id,
                'sku' => $this->originProduct?->sku,
                'name' => $this->originProduct?->name,
            ],
            'destination_product' => [
                'id' => $this->destinationProduct?->id,
                'sku' => $this->destinationProduct?->sku,
                'name' => $this->destinationProduct?->name,
            ],
        ];
    }
}

