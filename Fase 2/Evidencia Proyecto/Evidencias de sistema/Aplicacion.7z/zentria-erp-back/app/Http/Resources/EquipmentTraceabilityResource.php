<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EquipmentTraceabilityResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $tz = config('app.timezone', 'America/Santiago');

        return [
            'id' => $this->id,
            'serial_number' => $this->serial_number,
            'status' => [
                'value' => $this->status?->value,
                'label' => $this->status?->label(),
                'color' => $this->status?->color(),
            ],
            'warehouse' => [
                'id' => $this->warehouse_id,
                'name' => $this->warehouse?->name,
                'location' => $this->warehouse_location,
            ],
            'customer' => $this->customer ? [
                'id' => $this->customer_id,
                'name' => $this->customer->name,
            ] : null,
            'sale_id' => $this->sale_id,
            'quotation_id' => $this->quotation_id,
            'current_responsible' => $this->currentResponsible ? [
                'id' => $this->current_responsible_id,
                'name' => $this->currentResponsible->short_name,
            ] : null,
            'notes' => $this->notes,
            'received_at' => $this->received_at?->timezone($tz)->toIso8601String(),
            'reviewed_at' => $this->reviewed_at?->timezone($tz)->toIso8601String(),
            'available_at' => $this->available_at?->timezone($tz)->toIso8601String(),
            'sold_at' => $this->sold_at?->timezone($tz)->toIso8601String(),
            'movements' => $this->when($this->relationLoaded('movements'), function () {
                return EquipmentMovementResource::collection($this->movements);
            }),
        ];
    }
}
