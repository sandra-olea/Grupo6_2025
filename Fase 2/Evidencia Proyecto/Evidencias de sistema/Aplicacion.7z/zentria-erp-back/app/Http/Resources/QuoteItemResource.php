<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class QuoteItemResource extends JsonResource
{
    public function toArray($request)
    {
        $taxRate = (float) ($this->quote->tax_rate ?? 0.19);
        if ($taxRate <= 0) { $taxRate = 0.19; }

        $qty = max(1, (int) $this->quantity);
        $lineTotalStored = (float) ($this->total ?? 0);
        $lineSubtotalStored = (float) ($this->subtotal ?? 0);

        // Detectar si la cotización proviene de Woo (mantener comportamiento previo)
        $notes = (string) ($this->quote->notes ?? '');
        $isFromWoo = stripos($notes, 'Cotización generada desde venta #') !== false;

        // Caso especial: Cotización manual de producto del sistema → precio guardado incluye IVA
        $isManualProduct = !$isFromWoo && (bool) $this->product_id;

        if ($isManualProduct) {
            // Interpretar unit_price almacenado como BRUTO y convertir a NETO
            $stored = (float) ($this->unit_price ?? 0);
            if ($stored > 0) {
                $unitGross = round($stored, 2);
                $unitNet = round($unitGross / (1.0 + $taxRate), 2);
            } else {
                // Fallback: desde producto (precio base con IVA)
                $p = $this->relationLoaded('product') ? $this->product : $this->product()->first();
                $unitGrossFromProduct = (float) ($p?->offer_price ?: $p?->price ?: 0);
                $unitGross = round($unitGrossFromProduct, 2);
                $unitNet = round($unitGross / (1.0 + $taxRate), 2);
            }
        } else {
            // Flujo normal: interpretar unit_price como NETO con fallbacks desde totales
            $unitNet = (float) ($this->unit_price ?? 0);
            if ($unitNet <= 0) {
                if ($lineTotalStored > 0 && $qty > 0) {
                    $unitNet = round($lineTotalStored / $qty, 2);
                } elseif ($lineSubtotalStored > 0 && $qty > 0) {
                    $unitNet = round($lineSubtotalStored / $qty, 2);
                } else {
                    $p = $this->relationLoaded('product') ? $this->product : $this->product()->first();
                    $unitGrossFromProduct = (float) ($p?->offer_price ?: $p?->price ?: 0);
                    $unitNet = round($unitGrossFromProduct / (1.0 + $taxRate), 2);
                }
            }
            $unitGross = round($unitNet * (1.0 + $taxRate), 2);
        }
        $lineNet = round($unitNet * $qty, 2);
        $discNet = (float) ($this->discount_amount ?? 0);
        if ($discNet < 0) { $discNet = 0.0; }
        if ($discNet > $lineNet) { $discNet = $lineNet; }
        $lineNetAfterDisc = round($lineNet - $discNet, 2);
        $lineIva = round($lineNetAfterDisc * $taxRate, 2);
        $lineTotal = round($lineNetAfterDisc + $lineIva, 2);
        $discIva = round($discNet * $taxRate, 2);
        $discTotal = round($discNet + $discIva, 2);

        // Construir objeto de producto siempre (null si no hay producto)
        $productData = null;
        if ($this->relationLoaded('product')) {
            if ($this->product) {
                $productData = [
                    'id' => $this->product->id,
                    'sku' => $this->product->sku,
                    'name' => $this->product->name,
                ];
            } else {
                $productData = null;
            }
        }

        // Normalizar campos clave a strings y asegurar presencia
        // unit_price debe representar el valor NETO = precio bruto / (1 + IVA)
        $unitPriceOut = number_format($unitNet, 2, '.', '');
        $discountRateOut = $this->discount_rate !== null
            ? (string) $this->discount_rate
            : number_format(0, 4, '.', '');
        $discountAmountOut = $this->discount_amount !== null
            ? (string) $this->discount_amount
            : number_format(0, 2, '.', '');
        $subtotalOut = $this->subtotal !== null
            ? (string) $this->subtotal
            : number_format(round($unitNet * $qty, 2), 2, '.', '');
        $totalOut = $this->total !== null
            ? (string) $this->total
            : $subtotalOut;

        return [
            'id' => $this->id,
            'quote_id' => $this->quote_id,
            'product_id' => $this->product_id,
            'quantity' => $this->quantity,
            'unit_price' => $unitPriceOut,
            'discount_rate' => $discountRateOut,
            'discount_amount' => $discountAmountOut,
            'subtotal' => $subtotalOut,
            'total' => $totalOut,
            // Cálculos consistentes con PDF/venta (netos, IVA y totales)
            'tax_rate' => $taxRate,
            'unit_price_gross' => $unitGross,
            'unit_price_net' => $unitNet,
            'line_net' => $lineNetAfterDisc,
            'line_iva' => $lineIva,
            'line_total' => $lineTotal,
            'discount_net' => $discNet,
            'discount_iva' => $discIva,
            'discount_total' => $discTotal,
            'customer_sku' => $this->customer_sku,
            'customer_name' => $this->customer_name,
            'description' => $this->description,
            'notes' => $this->notes,
            'product_attributes' => $this->product_attributes,
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),
            'product' => $productData,
        ];
    }
}
