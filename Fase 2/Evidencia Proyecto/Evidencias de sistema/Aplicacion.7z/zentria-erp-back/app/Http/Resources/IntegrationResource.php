<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class IntegrationResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'name' => $this->name,
            'provider' => $this->provider,
            'base_url' => $this->base_url,
            'mode' => $this->mode,
            'is_active' => (bool) $this->is_active,
            'scopes' => $this->scopes,
            'allowed_ips' => $this->allowed_ips,
            'params' => $this->params,
            'api_key_prefix' => $this->api_key_prefix,
            'has_api_key' => (bool) $this->api_key_hash,
            'has_consumer_secret' => (bool) $this->consumer_secret,
            'has_api_token' => (bool) $this->api_token,
            'has_webhook_secret' => (bool) $this->webhook_secret,
            'last_success_at' => $this->last_success_at?->toIso8601String(),
            'last_error_at' => $this->last_error_at?->toIso8601String(),
            'last_error_msg' => $this->last_error_msg,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}

