<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CustomerSaleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'customer_code' => $this->customer_code,
            'document_type' => $this->document_type ?: 'rut',
            'document_number' => $this->rut, // alias
            'type' => $this->type,
            'rut' => $this->rut,
            'billing_company' => $this->billing_company,
            'trade_activity' => $this->trade_activity,
            'giro' => $this->trade_activity, // alias para front
            'contact_name' => $this->contact_name,
            'primary_contact' => [
                'name' => $this->primary_contact_name ?: ($this->contact_name ?: ($this->billing_company ?: null)),
                'email' => $this->primary_contact_email ?: $this->email,
                'phone' => $this->primary_contact_phone ?: $this->phone,
            ],
            'email' => $this->email,
            'phone' => $this->phone,
            'billing_address_1' => $this->billing_address_1,
            'address' => $this->billing_address_1, // alias para front
            'billing_address_2' => $this->billing_address_2,
            'billing_city' => $this->billing_city,
            'commune_id' => $this->commune_id,
            'billing_state_code' => $this->billing_state_code,
            'billing_postcode' => $this->billing_postcode,
            'billing_country_code' => $this->billing_country_code,
            'shipping_address_1' => $this->shipping_address_1,
            'shipping_address_2' => $this->shipping_address_2,
            'shipping_city' => $this->shipping_city,
            'shipping_commune_id' => $this->shipping_commune_id,
            'shipping_state_code' => $this->shipping_state_code,
            'shipping_postcode' => $this->shipping_postcode,
            'shipping_country_code' => $this->shipping_country_code,
            'default_document_type' => $this->default_document_type,
            'preferred_payment_method' => $this->preferred_payment_method,
            'purchase_order_number' => $this->purchase_order_number,
            'commercial_data' => $this->commercial_data,
            'notes' => $this->notes,
            'is_active' => (bool) $this->is_active,
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),

            'subsidiary' => $this->whenLoaded('subsidiary', fn() => [
                'id' => $this->subsidiary->id,
                'name' => $this->subsidiary->subsidiary_name,
            ]),
            'commune' => $this->whenLoaded('commune', fn() => [
                'id' => $this->commune->id,
                'name' => $this->commune->name,
            ]),
            'shipping_commune' => $this->whenLoaded('shippingCommune', fn() => [
                'id' => $this->shippingCommune->id,
                'name' => $this->shippingCommune->name,
            ]),
        ];
    }
}
