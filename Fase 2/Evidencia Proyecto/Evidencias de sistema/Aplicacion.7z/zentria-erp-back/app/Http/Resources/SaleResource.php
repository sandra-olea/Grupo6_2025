<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class SaleResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'customer_id' => $this->customer_id,
            'wc_order_id' => $this->wc_order_id,
            'wc_order_number' => $this->wc_order_number,
            'sale_number' => $this->sale_number,
            'status' => $this->status,
            'salesperson_id' => $this->salesperson_id,
            'sale_date' => $this->sale_date?->toDateString(),
            'delivery_date' => $this->delivery_date?->toDateString(),
            'completed_at' => $this->completed_at?->toISOString(),
            'subtotal' => $this->subtotal,
            'tax_amount' => $this->tax_amount,
            'discount_amount' => $this->discount_amount,
            'shipping_amount' => $this->shipping_amount,
            'total_amount' => $this->total_amount,
            'paid_amount' => $this->paid_amount,
            'pending_amount' => $this->pending_amount,
            'tax_rate' => $this->tax_rate,
            'discount_rate' => $this->discount_rate,
            'currency' => $this->currency,
            'exchange_rate' => $this->exchange_rate,
            'billing_snapshot' => $this->billing_snapshot,
            'shipping_snapshot' => $this->shipping_snapshot,
            'delivery_address' => $this->delivery_address,
            'payment_method' => $this->payment_method,
            'payment_method_title' => $this->payment_method_title,
            'woo_metadata' => $this->woo_metadata,
            'documents_metadata' => $this->documents_metadata,
            'notes' => $this->notes,
            'internal_notes' => $this->internal_notes,
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),

            'customer' => $this->whenLoaded('customer', fn() => [
                'id' => $this->customer->id,
                'rut' => $this->customer->rut,
                'name' => $this->customer->billing_company ?: $this->customer->contact_name,
                'email' => $this->customer->email,
            ]),
            'items_count' => $this->whenCounted('items'),
        ];
    }
}

