<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TechnicalReviewItemResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $tz = config('app.timezone', 'America/Santiago');

        return [
            'id' => $this->id,
            'serial_number' => $this->serial_number,
            'batch' => $this->batch ? [
                'id' => $this->batch_id,
                'code' => $this->batch->code,
                'entry_date' => $this->batch->entry_date?->format('Y-m-d'),
            ] : null,
            'branch' => [
                'id' => $this->branch_id,
                'name' => $this->branch?->branch_name ?? $this->batch?->branch?->branch_name,
            ],
            'customer_supplier' => $this->customer_supplier_id ? [
                'id' => $this->customer_supplier_id,
                'name' => $this->customerSupplier?->name ?? $this->batch?->customerSupplier?->name,
            ] : null,
            'equipment_type' => [
                'value' => $this->equipment_type?->value,
                'label' => $this->equipment_type?->label(),
            ],
            'review_status' => [
                'value' => $this->review_status?->value,
                'label' => $this->review_status?->label(),
            ],
            'current_status' => [
                'value' => $this->current_status?->value,
                'label' => $this->current_status?->label(),
                'color' => $this->current_status?->color(),
            ],
            'grade' => $this->grade ? [
                'value' => $this->grade->value,
                'label' => $this->grade->label(),
                'description' => $this->grade->description(),
            ] : null,
            'suggested_grade' => $this->suggested_grade,
            'scoring_confidence' => $this->scoring_confidence,
            'override' => [
                'was_overridden' => $this->override_suggestion,
                'reason' => $this->override_reason,
            ],
            'has_grade_override' => $this->hasGradeOverride(),
            'has_high_confidence' => $this->hasHighConfidence(),
            'product' => $this->product ? [
                'id' => $this->product_id,
                'name' => $this->product->name,
                'sku' => $this->product->sku,
            ] : null,
            'warehouse' => [
                'id' => $this->warehouse_id,
                'name' => $this->warehouse?->name,
            ],
            // Fotos asociadas a la serie (misma estructura que productos)
            'image'   => method_exists($this->resource, 'primaryImagePayload') ? $this->primaryImagePayload() : null,
            'gallery' => method_exists($this->resource, 'galleryPayload') ? $this->galleryPayload() : [],
            // Exponer detalles según tipo de equipo
            'details' => $this->getDetailsData(),
            'traceability' => $this->when($this->relationLoaded('traceability'), function () {
                return new EquipmentTraceabilityResource($this->traceability);
            }),
            'review_started_at' => $this->review_started_at?->timezone($tz)->toIso8601String(),
            'reviewed_at' => $this->reviewed_at?->timezone($tz)->toIso8601String(),
            'approved_at' => $this->approved_at?->timezone($tz)->toIso8601String(),
            'created_at' => $this->created_at?->timezone($tz)->toIso8601String(),
            'created_by' => [
                'id' => $this->created_by,
                'name' => $this->createdBy?->full_name,
            ],
            'reviewed_by' => $this->reviewed_by ? [
                'id' => $this->reviewed_by,
                'name' => $this->reviewedBy?->full_name,
            ] : null,
            'approved_by' => $this->approved_by ? [
                'id' => $this->approved_by,
                'name' => $this->approvedBy?->full_name,
            ] : null,
        ];
    }

    /**
     * Get details data from the appropriate loaded relation
     */
    private function getDetailsData()
    {
        // Intentar obtener la relación específica cargada
        $relationMap = [
            'notebook' => 'notebookDetails',
            'desktop' => 'desktopDetails',
            'docking' => 'dockingDetails',
            'aio' => 'aioDetails',
            'monitor' => 'monitorDetails',
        ];

        $equipmentType = $this->equipment_type?->value;
        $relationName = $relationMap[$equipmentType] ?? null;

        if ($relationName && $this->relationLoaded($relationName)) {
            return $this->$relationName;
        }

        // Fallback: usar el método details() dinámico
        return $this->details;
    }
}
