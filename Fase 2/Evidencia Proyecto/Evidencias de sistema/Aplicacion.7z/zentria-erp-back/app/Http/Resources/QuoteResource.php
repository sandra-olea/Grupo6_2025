<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class QuoteResource extends JsonResource
{
    public function toArray($request)
    {
        $base = [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'customer_id' => $this->customer_id,
            'quote_number' => $this->quote_number,
            'status' => $this->status,
            'salesperson_id' => $this->salesperson_id,
            'quote_date' => $this->quote_date?->toDateString(),
            'expiry_date' => $this->expiry_date?->toDateString(),
            'subtotal' => $this->subtotal,
            'tax_amount' => $this->tax_amount,
            'discount_amount' => $this->discount_amount,
            'total_amount' => $this->total_amount,
            'tax_rate' => $this->tax_rate,
            'discount_rate' => $this->discount_rate,
            'terms_conditions' => $this->terms_conditions,
            'notes' => $this->notes,
            'internal_notes' => $this->internal_notes,
            'is_converted_to_sale' => $this->is_converted_to_sale,
            'converted_at' => $this->converted_at?->toISOString(),
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),

            'customer' => $this->whenLoaded('customer', function () {
                $customer = $this->customer;
                $giro = $customer->trade_activity ?: 'N/A';
                $comuna = optional($customer->commune)->name ?: 'N/A';
                $telefono = $customer->phone ?: ($customer->primary_contact_phone ?: 'N/A');
                // Dirección de facturación SIN comuna y sin códigos postales/país.
                // Limpia comas/puntuación sobrante al final de cada segmento para evitar ",,".
                $sanitize = function ($v) {
                    $v = trim((string)$v);
                    // eliminar comas/puntos/punto y coma finales repetidos
                    $v = preg_replace('/[\s,;\.]+$/', '', $v ?? '');
                    return $v;
                };
                $addrParts = array_map($sanitize, [
                    $customer->billing_address_1,
                    $customer->billing_address_2,
                    $customer->billing_city,
                    // Excluimos commune, state_code, postcode y country según requerimiento
                ]);
                $addrParts = array_values(array_filter($addrParts, fn($v) => $v !== null && $v !== ''));
                $direccion = count($addrParts) ? implode(', ', $addrParts) : 'N/A';

                return [
                    'id' => $customer->id,
                    'rut' => $customer->rut,
                    'name' => $customer->billing_company ?: $customer->contact_name,
                    'email' => $customer->email,
                    'giro' => $giro,
                    'comuna' => $comuna,
                    'telefono' => $telefono,
                    'direccion' => $direccion,
                ];
            }),
            'items_count' => $this->whenCounted('items'),
            // Seller info (as an object): { branch, contact, email }
            'salesmen' => (function () {
                $u = $this->salesperson ?: auth('api')->user();
                $branchName = $u?->primaryBranch?->branch_name ?? $u?->branch?->branch_name ?? 'N/A';
                $name = null;
                if ($u) {
                    $name = trim((string) ($u->full_name ?? ''));
                    if ($name === '') {
                        $parts = array_filter([$u->first_name ?? null, $u->middle_name ?? null, $u->last_name ?? null, $u->second_last_name ?? null]);
                        $name = trim(implode(' ', $parts));
                    }
                }
                if (!$name || trim($name) === '') { $name = $u?->email ?? 'N/A'; }
                $email = $u?->email ?? 'N/A';
                return [
                    'branch' => $branchName ?: 'N/A',
                    'contact' => $name ?: 'N/A',
                    'email' => $email,
                ];
            })(),
        ];

        // Si viene con items cargados y el cliente lo solicita (?calc=1), recalcular totales
        // Por defecto se respetan los totales almacenados (importante para ventas Woo)
        $shouldRecalc = false;
        try {
            $shouldRecalc = (bool) ($request?->boolean('calc') || $request?->boolean('recalc'));
        } catch (\Throwable $e) {}

        // Detectar si la cotización proviene de Woo (notas estándar)
        $notes = (string) ($this->notes ?? '');
        $isFromWoo = stripos($notes, 'Cotización generada desde venta #') !== false;

        // Recalcular por defecto cuando NO proviene de Woo (cotización manual),
        // o cuando el cliente lo solicita mediante ?calc=1
        if (($shouldRecalc || !$isFromWoo) && $this->relationLoaded('items')) {
            $taxRate = (float) ($this->tax_rate ?? 0.19);
            if ($taxRate <= 0) { $taxRate = 0.19; }

            $itemsNetTotal = 0.0;
            $discountNetTotal = 0.0;

            foreach ($this->items as $it) {
                $qty = max(1, (int) $it->quantity);
                // Tratar unit_price como BRUTO cuando está presente, con fallbacks
                $unitGross = (float) ($it->unit_price ?? 0);
                if ($unitGross <= 0) {
                    $lineTotal = (float) ($it->total ?? 0);
                    $lineSubtotal = (float) ($it->subtotal ?? 0);
                    if ($lineTotal > 0 && $qty > 0) {
                        $unitGross = round($lineTotal / $qty, 2);
                    } elseif ($lineSubtotal > 0 && $qty > 0) {
                        $unitGross = round($lineSubtotal / $qty, 2);
                    } elseif ($it->product) {
                        $unitGross = (float) ($it->product->offer_price ?: $it->product->price ?: 0);
                    }
                }
                $unitNet = round($unitGross / (1.0 + $taxRate), 2);
                $lineNet = round($unitNet * $qty, 2);

                $discNet = (float) ($it->discount_amount ?? 0);
                if ($discNet < 0) { $discNet = 0.0; }
                if ($discNet > $lineNet) { $discNet = $lineNet; }

                $itemsNetTotal += round($lineNet - $discNet, 2);
                $discountNetTotal += $discNet;
            }

            $iva = round($itemsNetTotal * $taxRate, 2);
            $grand = round($itemsNetTotal + $iva, 2);

            $base['subtotal'] = round($itemsNetTotal, 2);
            $base['tax_amount'] = $iva;
            $base['discount_amount'] = round($discountNetTotal, 2);
            $base['total_amount'] = $grand;
        }

        return $base;
    }
}
