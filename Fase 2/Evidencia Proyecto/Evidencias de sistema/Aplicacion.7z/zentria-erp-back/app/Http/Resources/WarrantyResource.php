<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class WarrantyResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'serial_number' => $this->serial_number,
            'product_id' => $this->product_id,
            'customer_id' => $this->customer_id,
            'sale_id' => $this->sale_id,
            'start_date' => optional($this->start_date)->toDateString(),
            'end_date' => optional($this->end_date)->toDateString(),
            'status' => $this->status,
            'notes' => $this->notes,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'product' => $this->whenLoaded('product', fn() => new ProductResource($this->product)),
            'customer' => $this->whenLoaded('customer', fn() => new CustomerSaleResource($this->customer)),
            'sale' => $this->whenLoaded('sale', fn() => new SaleResource($this->sale)),
            'subsidiary' => $this->whenLoaded('subsidiary', fn() => new SubsidiaryResource($this->subsidiary)),
        ];
    }
}

