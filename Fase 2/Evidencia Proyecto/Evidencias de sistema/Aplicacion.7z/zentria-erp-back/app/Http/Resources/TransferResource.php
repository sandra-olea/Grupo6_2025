<?php
namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TransferResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'status' => $this->status,
            'from_branch' => [
                'id' => $this->from_branch_id,
                'name' => $this->fromBranch?->branch_name,
            ],
            'to_branch' => [
                'id' => $this->to_branch_id,
                'name' => $this->toBranch?->branch_name,
            ],
            'from_warehouse' => $this->when($this->relationLoaded('fromWarehouse') || $this->from_warehouse_id, function () {
                return [
                    'id' => $this->from_warehouse_id,
                    'name' => $this->fromWarehouse?->name,
                ];
            }),
            'to_warehouse' => $this->when($this->relationLoaded('toWarehouse') || $this->to_warehouse_id, function () {
                return [
                    'id' => $this->to_warehouse_id,
                    'name' => $this->toWarehouse?->name,
                ];
            }),
            'responsible' => [
                'id' => $this->responsible?->id,
                'name' => $this->responsible ? trim(($this->responsible->first_name ?? $this->responsible->name).' '.($this->responsible->last_name ?? '')) : null,
                'email' => $this->responsible?->email,
            ],
            'totals' => [
                'items' => (int) $this->total_items,
                'quantity' => (int) $this->total_quantity,
            ],
            'notes' => $this->notes,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,

            'items' => $this->whenLoaded('items', function () {
                return TransferItemResource::collection($this->items);
            }),
        ];
    }
}

