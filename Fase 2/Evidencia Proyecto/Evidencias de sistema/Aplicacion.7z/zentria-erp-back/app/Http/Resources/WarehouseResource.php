<?php
namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class WarehouseResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'branch_id' => $this->branch_id,
            'branch_name' => $this->branch?->branch_name,
            'name' => $this->name,
            'code' => $this->code,
            'description' => $this->description,
            'address' => $this->address,
            'storage_location' => $this->storage_location,
            'pallet_spot' => $this->pallet_spot,
            'commune_id' => $this->commune_id,
            'commune_name' => $this->commune?->name,
            'maximum_capacity' => $this->maximum_capacity,
            'current_capacity' => $this->getCurrentCapacity(),
            'available_capacity' => $this->maximum_capacity !== null
                ? max(0, (int)$this->maximum_capacity - (int)$this->getCurrentCapacity())
                : null,
            'schedule' => $this->schedule,
            'capacity' => $this->capacity,
            'warehouse_type' => $this->warehouse_type,
            'manager_id' => $this->manager_id,
            'manager_name' => $this->manager ? trim($this->manager->name . ' ' . $this->manager->last_name) : null,
            'is_active' => $this->is_active,
            'requires_serial_tracking' => $this->requires_serial_tracking,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
