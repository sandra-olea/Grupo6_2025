<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CustomerSupplierResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'subsidiary_id' => $this->subsidiary_id,
            'name' => $this->name,
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),
            
            // Relaciones opcionales
            'subsidiary' => $this->whenLoaded('subsidiary', fn() => [
                'id' => $this->subsidiary->id,
                'name' => $this->subsidiary->subsidiary_name,
            ]),
            
            'suppliers_count' => $this->when(
                isset($this->suppliers_count),
                $this->suppliers_count
            ),
            
            'suppliers' => SupplierResource::collection(
                $this->whenLoaded('suppliers')
            ),
            
            // Indicar si hay más proveedores disponibles
            'has_more_suppliers' => $this->when(
                $this->relationLoaded('suppliers') && isset($this->suppliers_count),
                fn() => $this->suppliers->count() < $this->suppliers_count
            ),
        ];
    }
}
