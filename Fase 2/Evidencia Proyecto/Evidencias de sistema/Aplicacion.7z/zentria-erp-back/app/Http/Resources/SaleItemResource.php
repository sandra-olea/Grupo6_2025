<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class SaleItemResource extends JsonResource
{
    public function toArray($request)
    {
        $taxRate = (float) ($this->sale->tax_rate ?? 0.19);
        if ($taxRate <= 0) { $taxRate = 0.19; }

        $qty = max(1, (int) $this->quantity);
        $lineTotalStored = (float) ($this->total ?? 0);
        $lineSubtotalStored = (float) ($this->subtotal ?? 0);
        $unitStored = (float) ($this->unit_price ?? 0);

        // Prefer Woo "total" (net after discounts); fallback to subtotal; then unit_price
        if ($lineTotalStored > 0) {
            $unitNet = round($lineTotalStored / $qty, 2);
        } elseif ($lineSubtotalStored > 0) {
            $unitNet = round($lineSubtotalStored / $qty, 2);
        } elseif ($unitStored > 0) {
            $unitNet = round($unitStored, 2);
        } else {
            $unitNet = 0.0;
        }

        // If sale has no tax_amount, consider gross == net for display
        $taxApplied = ((float) ($this->sale->tax_amount ?? 0)) > 0;
        $unitGross = $taxApplied ? round($unitNet * (1.0 + $taxRate), 2) : $unitNet;

        $lineNet = round($unitNet * $qty, 2);
        $lineIva = $taxApplied ? round($lineNet * $taxRate, 2) : 0.0;
        $lineTotal = round($lineNet + $lineIva, 2);

        $discNet = (float) ($this->discount_amount ?? 0);
        $discIva = $taxApplied ? round($discNet * $taxRate, 2) : 0.0;
        $discTotal = round($discNet + $discIva, 2);

        // Normalize important fields as strings
        $unitPriceOut = number_format($unitNet, 2, '.', '');
        $discountAmountOut = $this->discount_amount !== null ? (string) $this->discount_amount : number_format(0, 2, '.', '');
        $subtotalOut = $this->subtotal !== null ? (string) $this->subtotal : number_format($lineNet, 2, '.', '');
        $totalOut = $this->total !== null ? (string) $this->total : $subtotalOut;

        // Product payload when available
        $productData = null;
        if ($this->relationLoaded('product')) {
            if ($this->product) {
                $productData = [
                    'id' => $this->product->id,
                    'sku' => $this->product->sku,
                    'name' => $this->product->name,
                ];
            }
        }

        return [
            'id' => $this->id,
            'sale_id' => $this->sale_id,
            'product_id' => $this->product_id,
            'name' => $this->when(true, function(){
                if ($this->relationLoaded('product') && $this->product) {
                    return $this->product->name;
                }
                $meta = $this->meta_json ?? [];
                return $meta['name'] ?? null;
            }),
            'quantity' => $this->quantity,
            // unit_price en NETO (string 2 decimales)
            'unit_price' => $unitPriceOut,
            'discount_amount' => $discountAmountOut,
            'subtotal' => $subtotalOut,
            'total' => $totalOut,
            'external_line_id' => $this->external_line_id,
            'meta_json' => $this->meta_json,

            // Campos calculados consistentes
            'tax_rate' => $taxRate,
            'unit_price_gross' => $unitGross,
            'unit_price_net' => $unitNet,
            'line_net' => $lineNet,
            'line_iva' => $lineIva,
            'line_total' => $lineTotal,
            'discount_net' => $discNet,
            'discount_iva' => $discIva,
            'discount_total' => $discTotal,

            'product' => $productData,
        ];
    }
}
