<?php

namespace App\Http\Resources;

use App\Models\Branch;
use Illuminate\Http\Resources\Json\JsonResource;

class SubsidiaryResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'company_id' => $this->company_id,
            'subsidiary_name' => $this->subsidiary_name,
            'subsidiary_rut' => $this->subsidiary_rut,
            'subsidiary_website' => $this->subsidiary_website,
            'subsidiary_phone' => $this->subsidiary_phone,
            'subsidiary_address' => $this->subsidiary_address,
            'subsidiary_email' => $this->subsidiary_email,
            'commune_id' => $this->commune_id,
            'subsidiary_manager_id' => $this->subsidiary_manager_id,
            'subsidiary_status' => $this->subsidiary_status,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,

            // Manager information
            'manager' => $this->whenLoaded('manager', function () {
                return $this->manager ? [
                    'id' => $this->manager->id,
                    'name' => $this->manager->full_name,
                    'email' => $this->manager->email,
                    'phone' => $this->manager->phone,
                ] : null;
            }),

            'commune' => $this->whenLoaded('commune', function () {
                return [
                    'id' => $this->commune->id,
                    'name' => $this->commune->name,
                    'province_id' => $this->commune->province_id,
                ];
            }),

            'branches' => $this->whenLoaded('branches', function () {
                return $this->branches->map(function (Branch $branch) {
                    return [
                        'id' => $branch->id,
                        'subsidiary_id' => $branch->subsidiary_id,
                        'branch_name' => $branch->branch_name,
                        'branch_address' => $branch->branch_address,
                        'commune_id' => $branch->commune_id,
                        'branch_phone' => $branch->branch_phone,
                        'branch_email' => $branch->branch_email,
                        'branch_status' => $branch->branch_status,
                        'manager_id' => $branch->manager_id,
                        'branch_opening_hours' => $branch->branch_opening_hours,
                        'branch_location' => $branch->branch_location,
                        'manager' => $branch->relationLoaded('manager') && $branch->manager ? [
                            'id' => $branch->manager->id,
                            'name' => $branch->manager->full_name,
                            'email' => $branch->manager->email,
                            'phone' => $branch->manager->phone,
                        ] : null,
                        'commune' => $branch->relationLoaded('commune') && $branch->commune ? [
                            'id' => $branch->commune->id,
                            'name' => $branch->commune->name,
                            'province_id' => $branch->commune->province_id,
                        ] : null,
                    ];
                });
            }),
        ];
    }
}

