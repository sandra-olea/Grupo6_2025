<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UnmappedWooCommerceProductResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'integration_id' => $this->integration_id,
            'sale_id' => $this->sale_id,
            'external_line_id' => $this->external_line_id,
            'external_product_id' => $this->external_product_id,
            'external_variation_id' => $this->external_variation_id,
            'sku' => $this->sku,
            'name' => $this->name,
            'price' => $this->price,
            'quantity' => $this->quantity,
            'wc_order_id' => $this->wc_order_id,
            'resolution_status' => $this->resolution_status,
            'mapped_product_id' => $this->mapped_product_id,
            'mapped_at' => $this->mapped_at?->toISOString(),
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),
            
            // Related data
            'integration' => $this->whenLoaded('integration', function () {
                return [
                    'id' => $this->integration->id,
                    'provider' => $this->integration->provider,
                    'name' => $this->integration->name,
                ];
            }),
            'sale' => $this->whenLoaded('sale', function () {
                return [
                    'id' => $this->sale->id,
                    'sale_number' => $this->sale->sale_number,
                    'status' => $this->sale->status,
                    'total_amount' => $this->sale->total_amount,
                ];
            }),
            'mapped_product' => $this->whenLoaded('mappedProduct', function () {
                return $this->mappedProduct ? [
                    'id' => $this->mappedProduct->id,
                    'sku' => $this->mappedProduct->sku,
                    'name' => $this->mappedProduct->name,
                ] : null;
            }),
            
            // Line item details for context
            'line_item_data' => $this->line_item_data,
        ];
    }
}
