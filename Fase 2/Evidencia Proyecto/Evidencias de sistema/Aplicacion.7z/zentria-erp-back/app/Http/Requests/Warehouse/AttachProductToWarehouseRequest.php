<?php
namespace App\Http\Requests\Warehouse;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Warehouse;
use App\Models\Product;

class AttachProductToWarehouseRequest extends FormRequest
{
    /**
     * Productos procesados listos para ser asociados.
     *
     * @var array<int, array{product_id:int, product:\App\Models\Product, final_quantity:int, sync_stock:bool}>
     */
    protected array $productsData = [];

    public function authorize(): bool
    {
        /** @var Warehouse $warehouse */
        $warehouse = $this->route('warehouse');
        return $this->user()->can('attachProduct', $warehouse);
    }

    public function rules(): array
    {
        return [
            'product_id' => ['required'],
            'quantity' => ['nullable'],
            'sync_stock' => ['nullable'],
        ];
    }

    public function messages(): array
    {
        return [
            'product_id.required' => 'Debe proporcionar al menos un producto.',
        ];
    }

    /**
     * Validación adicional después de las reglas básicas.
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $warehouse = $this->route('warehouse');
            $productIds = $this->normalizeToArray($this->input('product_id'));

            if (empty($productIds)) {
                $validator->errors()->add('product_id', 'Debe proporcionar al menos un producto válido.');
                return;
            }

            $quantities = $this->normalizeToArray($this->input('quantity'), count($productIds));
            $syncFlags = $this->normalizeToArray($this->input('sync_stock'), count($productIds));

            $this->productsData = [];
            $totalToAdd = 0;
            $seen = [];

            foreach ($productIds as $index => $rawId) {
                $fieldKey = is_array($this->input('product_id')) ? "product_id.$index" : 'product_id';

                if (!is_numeric($rawId)) {
                    $validator->errors()->add($fieldKey, 'El identificador de producto no es válido.');
                    continue;
                }

                $productId = (int) $rawId;

                if ($productId <= 0) {
                    $validator->errors()->add($fieldKey, 'El identificador de producto no es válido.');
                    continue;
                }

                if (isset($seen[$productId])) {
                    $validator->errors()->add($fieldKey, 'El producto se repite en la solicitud.');
                    continue;
                }
                $seen[$productId] = true;

                $product = Product::find($productId);
                if (!$product) {
                    $validator->errors()->add($fieldKey, 'El producto seleccionado no existe.');
                    continue;
                }

                if ($product->branch_id !== $warehouse->branch_id) {
                    $validator->errors()->add($fieldKey, 'El producto debe pertenecer a la misma sucursal que la bodega.');
                    continue;
                }

                if ($warehouse->products()->where('product_id', $productId)->exists()) {
                    $validator->errors()->add($fieldKey, 'Este producto ya está asociado a la bodega.');
                    continue;
                }

                $syncValue = $this->toBoolean($syncFlags[$index] ?? false);
                $quantityRaw = $quantities[$index] ?? null;
                $finalQuantity = null;

                if ($syncValue) {
                    if ($product->stock <= 0) {
                        $validator->errors()->add(is_array($this->input('sync_stock')) ? "sync_stock.$index" : 'sync_stock', 'El producto no tiene stock disponible para sincronizar.');
                        continue;
                    }

                    $finalQuantity = (int) $product->stock;
                } else {
                    if ($quantityRaw === null || $quantityRaw === '') {
                        $validator->errors()->add(is_array($this->input('quantity')) ? "quantity.$index" : 'quantity', 'Debe especificar una cantidad para el producto seleccionado.');
                        continue;
                    }

                    if (!is_numeric($quantityRaw)) {
                        $validator->errors()->add(is_array($this->input('quantity')) ? "quantity.$index" : 'quantity', 'La cantidad debe ser un número entero.');
                        continue;
                    }

                    $quantityValue = (int) $quantityRaw;
                    if ($quantityValue < 1) {
                        $validator->errors()->add(is_array($this->input('quantity')) ? "quantity.$index" : 'quantity', 'La cantidad debe ser al menos 1.');
                        continue;
                    }

                    $finalQuantity = $quantityValue;
                }

                if ($finalQuantity === null || $finalQuantity <= 0) {
                    $validator->errors()->add($fieldKey, 'La cantidad resultante debe ser mayor a 0.');
                    continue;
                }

                $this->productsData[] = [
                    'product_id' => $productId,
                    'product' => $product,
                    'final_quantity' => $finalQuantity,
                    'sync_stock' => $syncValue,
                ];

                $totalToAdd += $finalQuantity;
            }

            if (empty($this->productsData)) {
                if (!$validator->errors()->has('product_id')) {
                    $validator->errors()->add('product_id', 'No se pudo procesar ningún producto para asociar.');
                }
                return;
            }

            if ($totalToAdd > 0
                && $warehouse->maximum_capacity !== null
                && !$warehouse->hasCapacityFor($totalToAdd)) {
                $validator->errors()->add('quantity', 'No hay capacidad suficiente en la bodega. Capacidad máxima: ' . $warehouse->maximum_capacity . ', capacidad actual: ' . $warehouse->getCurrentCapacity() . ', se requiere: ' . $totalToAdd);
                $this->productsData = [];
            }
        });
    }

    /**
     * Obtiene la cantidad final a usar (manual o sincronizada).
     */
    public function getProductsData(): array
    {
        return $this->productsData;
    }

    /**
     * Normaliza un valor (scalar/array/null) a un arreglo indexado.
     */
    protected function normalizeToArray($value, ?int $targetCount = null): array
    {
        if (is_array($value)) {
            return array_values($value);
        }

        if ($targetCount !== null) {
            return array_fill(0, $targetCount, $value);
        }

        if ($value === null) {
            return [];
        }

        return [$value];
    }

    /**
     * Convierte un valor arbitrario a booleano.
     */
    protected function toBoolean($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (int) $value === 1;
        }

        if (is_string($value)) {
            return in_array(strtolower($value), ['1', 'true', 'on', 'yes'], true);
        }

        return false;
    }
}
