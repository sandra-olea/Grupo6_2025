<?php

namespace App\Http\Requests\Supplier;

use Illuminate\Foundation\Http\FormRequest;

class UpdateSupplierRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // La autorización se maneja en el controlador
    }

    public function rules(): array
    {
        // Obtener subsidiary_id y supplier_id de la ruta
        $subsidiaryId = $this->route('subsidiary')->id;
        $supplierId = $this->route('supplier')->id;
        
        return [
            'name' => [
                'sometimes',
                'required',
                'string',
                'max:255',
                // Validar unicidad dentro de la misma subsidiary, excepto el registro actual
                "unique:suppliers,name,{$supplierId},id,subsidiary_id,{$subsidiaryId}"
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'El nombre del proveedor es obligatorio.',
            'name.string' => 'El nombre del proveedor debe ser texto.',
            'name.max' => 'El nombre del proveedor no puede exceder 255 caracteres.',
            'name.unique' => 'Ya existe otro proveedor con este nombre en esta sucursal.',
        ];
    }
}
