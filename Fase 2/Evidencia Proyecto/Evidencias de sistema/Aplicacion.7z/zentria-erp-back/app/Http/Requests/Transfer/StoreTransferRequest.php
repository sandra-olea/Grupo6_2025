<?php
namespace App\Http\Requests\Transfer;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;
use App\Models\Branch;
use App\Models\Product;
use App\Models\Warehouse;

class StoreTransferRequest extends FormRequest
{
    /**
     * @var array<int, array{
     *   origin: \App\Models\Product,
     *   destination?: \App\Models\Product|null,
     *   quantity: int,
     *   sku?: string
     * }>
     */
    protected array $normalizedItems = [];

    protected ?Warehouse $fromWarehouse = null;
    protected ?Warehouse $toWarehouse = null;
    protected ?Branch $toBranch = null;
    protected bool $autoCreateDestination = false;

    public function rules(): array
    {
        return [
            'to_branch_id' => ['required','integer','exists:branches,id'],
            'from_warehouse_id' => ['nullable','integer','exists:warehouses,id'],
            'to_warehouse_id' => ['nullable','integer','exists:warehouses,id'],
            'notes' => ['nullable','string','max:500'],
            'items' => ['required','array','min:1'],
            'items.*.product_id' => ['required','integer','exists:products,id'],
            'items.*.quantity' => ['required','integer','min:1'],
            'auto_create_destination_product' => ['sometimes','boolean'],
        ];
    }

    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('create-transfer') ?? false;
    }

    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator) {
            /** @var Branch $fromBranch */
            $fromBranch = $this->route('branch');
            if (!$fromBranch) {
                $validator->errors()->add('branch', 'Sucursal origen inválida.');
                return;
            }

            $toBranchId = (int) $this->input('to_branch_id');
            if ($toBranchId === (int)$fromBranch->id) {
                $validator->errors()->add('to_branch_id', 'La sucursal destino debe ser distinta a la de origen.');
                return;
            }

            $toBranch = Branch::find($toBranchId);
            if (!$toBranch) {
                $validator->errors()->add('to_branch_id', 'Sucursal destino no existe.');
                return;
            }
            $this->toBranch = $toBranch;

            // Validate optional warehouses belong to respective branches
            $fromWarehouseId = $this->input('from_warehouse_id');
            if ($fromWarehouseId) {
                $fw = Warehouse::find((int)$fromWarehouseId);
                if (!$fw || $fw->branch_id !== $fromBranch->id) {
                    $validator->errors()->add('from_warehouse_id', 'La bodega origen no pertenece a la sucursal origen.');
                    return;
                }
                $this->fromWarehouse = $fw;
            }

            $toWarehouseId = $this->input('to_warehouse_id');
            if ($toWarehouseId) {
                $tw = Warehouse::find((int)$toWarehouseId);
                if (!$tw || $tw->branch_id !== $toBranch->id) {
                    $validator->errors()->add('to_warehouse_id', 'La bodega destino no pertenece a la sucursal destino.');
                    return;
                }
                $this->toWarehouse = $tw;
            }

            // Flag: auto-crear producto en destino si no existe
            $this->autoCreateDestination = $this->toBoolean($this->input('auto_create_destination_product'));

            $items = $this->input('items', []);
            if (!is_array($items) || empty($items)) {
                $validator->errors()->add('items', 'Debe incluir al menos un producto a transferir.');
                return;
            }

            // Aggregate quantities per origin product
            $aggregate = [];
            foreach ($items as $idx => $it) {
                $pId = (int)($it['product_id'] ?? 0);
                $qty = (int)($it['quantity'] ?? 0);
                if ($pId <= 0 || $qty <= 0) {
                    $validator->errors()->add("items.$idx", 'Producto o cantidad inválidos.');
                    continue;
                }
                $aggregate[$pId] = ($aggregate[$pId] ?? 0) + $qty;
            }

            if (empty($aggregate)) {
                $validator->errors()->add('items', 'No se pudo procesar ningún ítem.');
                return;
            }

            $this->normalizedItems = [];
            foreach ($aggregate as $originId => $qty) {
                $origin = Product::find($originId);
                if (!$origin) {
                    $validator->errors()->add('items', "Producto $originId no existe.");
                    continue;
                }
                if ($origin->branch_id !== $fromBranch->id) {
                    $validator->errors()->add('items', "El producto $originId no pertenece a la sucursal origen.");
                    continue;
                }
                if ($origin->serial_tracking) {
                    $validator->errors()->add('items', "El producto $originId usa tracking por serie. Use el endpoint de traslado de equipos.");
                    continue;
                }

                // Find destination product by SKU in destination branch
                $sku = $origin->sku;
                if (!$sku) {
                    $validator->errors()->add('items', "El producto $originId no tiene SKU; no puede mapearse en la sucursal destino.");
                    continue;
                }

                $destination = Product::query()
                    ->where('branch_id', $toBranch->id)
                    ->where('sku', $sku)
                    ->first();

                if (!$destination) {
                    if ($this->autoCreateDestination) {
                        // posponer creación al controlador, incluir sku y dejar destino null
                        $this->normalizedItems[] = [
                            'origin' => $origin,
                            'destination' => null,
                            'quantity' => $qty,
                            'sku' => $sku,
                        ];
                        continue;
                    }
                    $validator->errors()->add('items', "No existe producto con SKU $sku en la sucursal destino.");
                    continue;
                }

                if ($destination->serial_tracking) {
                    $validator->errors()->add('items', "El producto destino con SKU $sku usa tracking por serie. Use el endpoint de traslado de equipos.");
                    continue;
                }

                $this->normalizedItems[] = [
                    'origin' => $origin,
                    'destination' => $destination,
                    'quantity' => $qty,
                ];
            }

            if (empty($this->normalizedItems)) {
                $validator->errors()->add('items', 'No hay ítems válidos para transferir.');
                return;
            }
        });
    }

    public function normalizedItems(): array
    {
        return $this->normalizedItems;
    }

    public function destinationBranch(): ?Branch
    {
        return $this->toBranch;
    }

    public function resolvedFromWarehouse(): ?Warehouse
    {
        return $this->fromWarehouse;
    }

    public function resolvedToWarehouse(): ?Warehouse
    {
        return $this->toWarehouse;
    }

    private function toBoolean($value): bool
    {
        if (is_bool($value)) return $value;
        if (is_numeric($value)) return ((int) $value) === 1;
        if (is_string($value)) {
            $v = strtolower($value);
            return in_array($v, ['1','true','on','yes','si','sí'], true);
        }
        return false;
    }
}
