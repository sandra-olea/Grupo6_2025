<?php
namespace App\Http\Requests\Warehouse;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Warehouse;

class UpdateWarehouseRequest extends FormRequest
{
    public function authorize(): bool
    {
        /** @var Warehouse $warehouse */
        $warehouse = $this->route('warehouse');
        return $this->user()->can('update', $warehouse);
    }

    public function rules(): array
    {
        return [
            'name' => ['sometimes','string','max:255'],
            'code' => ['sometimes','string','max:255'],
            'description' => ['sometimes','nullable','string'],
            'address' => ['sometimes','nullable','string','max:255'],
            'storage_location' => ['sometimes','nullable','string','max:255'],
            'pallet_spot' => ['sometimes','nullable','string','max:255'],
            'commune_id' => ['sometimes','nullable','integer','exists:communes,id'],
            'maximum_capacity' => ['sometimes','nullable','integer','min:0'],
            'schedule' => ['sometimes','nullable','string'],
            'capacity' => ['sometimes','nullable','integer','min:0'],
            'warehouse_type' => ['sometimes','string','max:255'],
            'manager_id' => ['sometimes','nullable','integer','exists:users,id'],
            'is_active' => ['sometimes','boolean'],
            'requires_serial_tracking' => ['sometimes','boolean'],
        ];
    }
}
