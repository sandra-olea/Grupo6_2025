<?php

namespace App\Http\Requests\Integration;

use Illuminate\Foundation\Http\FormRequest;

class UpdateIntegrationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth('api')->check();
    }

    public function rules(): array
    {
        return [
            'name' => 'sometimes|string|max:255',
            'provider' => 'sometimes|string|max:50',
            'base_url' => 'sometimes|string',
            'consumer_key' => 'sometimes|nullable|string',
            'consumer_secret' => 'sometimes|nullable|string',
            'api_token' => 'sometimes|nullable|string',
            'webhook_secret' => 'sometimes|nullable|string',
            'api_key_plain' => 'sometimes|nullable|string|min:24',
            'mode' => 'sometimes|in:read,write,read_write,webhook',
            'rotate_api_key' => 'sometimes|boolean',
            'rotate_webhook_secret' => 'sometimes|boolean',
            'is_active' => 'sometimes|boolean',
            'scopes' => 'sometimes|nullable|array',
            'allowed_ips' => 'sometimes|nullable|array',
            'params' => 'sometimes|nullable|array',
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($v) {
            $data = $this->all();
            $provider = array_key_exists('provider', $data) ? (string)$data['provider'] : null;
            $mode = array_key_exists('mode', $data) ? (string)$data['mode'] : null;
            $isActive = array_key_exists('is_active', $data) ? filter_var($data['is_active'], FILTER_VALIDATE_BOOL) : null;

            // Resolver registro actual y valores efectivos tras update
            /** @var \App\Models\Integration|null $current */
            $current = null;
            try {
                $subsidiary = $this->route('subsidiary');
                $id = (string) $this->route('integration');
                $current = \App\Models\Integration::where('subsidiary_id', optional($subsidiary)->id)->find($id);
            } catch (\Throwable $e) {}
            if (!$current) return;

            $effectiveProvider = strtolower($provider ?? $current->provider);
            $effectiveMode = $mode ?? $current->mode;
            $effectiveActive = $isActive === null ? (bool)$current->is_active : $isActive;

            if ($effectiveProvider !== 'woocommerce' || !$effectiveActive) {
                return; // regla aplica solo a WooCommerce activas
            }

            $isWebhook = $effectiveMode === 'webhook';
            $isRest = in_array($effectiveMode, ['read','read_write'], true);
            if (!$isWebhook && !$isRest) return;

            $exists = \App\Models\Integration::query()
                ->where('subsidiary_id', $current->subsidiary_id)
                ->where('provider', 'woocommerce')
                ->where('is_active', true)
                ->when($isWebhook, fn($q) => $q->where('mode', 'webhook'))
                ->when($isRest, fn($q) => $q->whereIn('mode', ['read','read_write']))
                ->where('id', '<>', $current->id)
                ->exists();

            if ($exists) {
                $type = $isWebhook ? 'webhook' : 'REST';
                $v->errors()->add('mode', "Ya existe una integración WooCommerce activa de tipo {$type} para esta subsidiaria. Desactívela antes de activar otra.");
            }
        });
    }
}
