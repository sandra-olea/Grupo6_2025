<?php

namespace App\Http\Requests\Warranty;

use Illuminate\Foundation\Http\FormRequest;

class UpdateWarrantyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // policy + gates en controlador
    }

    public function rules(): array
    {
        return [
            'serial_number' => ['nullable','string','max:255'],
            'product_id' => ['nullable','integer','exists:products,id'],
            'customer_id' => ['nullable','integer','exists:customer_sale,id'],
            'sale_id' => ['nullable','integer','exists:sales,id'],
            'start_date' => ['sometimes','date'],
            'end_date' => ['sometimes','date','after_or_equal:start_date'],
            'status' => ['sometimes','in:Activa,Expirada,Usada,Anulada'],
            'notes' => ['nullable','string'],
        ];
    }
}

