<?php

namespace App\Http\Requests\TechnicalReview;

use App\Enums\EquipmentType;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreTechnicalReviewItemRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create-technical-reviews-items');
    }

    protected function prepareForValidation(): void
    {
        if ($this->filled('serial_number')) {
            $this->merge([
                'serial_number' => strtoupper($this->input('serial_number')),
            ]);
        }
    }

    public function rules(): array
    {
        return [
            'batch_id' => 'required|exists:technical_review_batches,id',
            'serial_number' => [
                'required',
                'string',
                'max:255',
                Rule::unique('technical_review_items', 'serial_number')
                    ->whereNull('deleted_at'),
            ],
            'product_id' => 'nullable|exists:products,id',
            'equipment_type' => ['nullable', Rule::enum(EquipmentType::class)],
        ];
    }

    public function messages(): array
    {
        return [
            'batch_id.required' => 'Debe seleccionar un lote',
            'serial_number.required' => 'El número de serie es obligatorio',
            'serial_number.unique' => 'Este número de serie ya está registrado en otra revisión técnica',
            'equipment_type.enum' => 'El tipo de equipo seleccionado no es válido',
        ];
    }
}
