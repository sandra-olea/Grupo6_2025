<?php

namespace App\Http\Requests\Integration;

use Illuminate\Foundation\Http\FormRequest;

class StoreIntegrationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth('api')->check();
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'provider' => 'required|string|max:50',
            'base_url' => 'required|string',
            'consumer_key' => 'nullable|string',
            'consumer_secret' => 'nullable|string',
            'api_token' => 'nullable|string',
            'webhook_secret' => 'nullable|string',
            'api_key_plain' => 'nullable|string|min:24',
            'mode' => 'nullable|in:read,write,read_write,webhook',
            'is_active' => 'boolean',
            'scopes' => 'nullable|array',
            'allowed_ips' => 'nullable|array',
            'params' => 'nullable|array',
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($v) {
            $data = $this->all();
            $provider = (string)($data['provider'] ?? '');
            $mode = (string)($data['mode'] ?? 'read');
            $isActive = filter_var($data['is_active'] ?? true, FILTER_VALIDATE_BOOL);

            if (strtolower($provider) !== 'woocommerce' || !$isActive) {
                return; // regla aplica solo a WooCommerce activas
            }

            $subsidiaryId = (int) optional($this->route('subsidiary'))->id;
            if (!$subsidiaryId) return;

            $isWebhook = $mode === 'webhook';
            $isRest = in_array($mode, ['read', 'read_write'], true);

            if (!$isWebhook && !$isRest) return;

            $exists = \App\Models\Integration::query()
                ->where('subsidiary_id', $subsidiaryId)
                ->where('provider', 'woocommerce')
                ->where('is_active', true)
                ->when($isWebhook, fn($q) => $q->where('mode', 'webhook'))
                ->when($isRest, fn($q) => $q->whereIn('mode', ['read','read_write']))
                ->exists();

            if ($exists) {
                $type = $isWebhook ? 'webhook' : 'REST';
                $v->errors()->add('mode', "Ya existe una integración WooCommerce activa de tipo {$type} para esta subsidiaria. Desactívela antes de crear otra.");
            }
        });
    }
}
