<?php

namespace App\Http\Requests\CustomerSupplier;

use Illuminate\Foundation\Http\FormRequest;

class StoreCustomerSupplierRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // La autorización se maneja en el controlador
    }

    public function rules(): array
    {
        // Obtener subsidiary_id de la ruta
        $subsidiaryId = $this->route('subsidiary')->id;
        
        return [
            'name' => [
                'required',
                'string',
                'max:255',
                // Validar unicidad dentro de la misma subsidiary
                "unique:customer_suppliers,name,NULL,id,subsidiary_id,{$subsidiaryId}"
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'El nombre del cliente-proveedor es obligatorio.',
            'name.string' => 'El nombre del cliente-proveedor debe ser texto.',
            'name.max' => 'El nombre del cliente-proveedor no puede exceder 255 caracteres.',
            'name.unique' => 'Ya existe un cliente-proveedor con este nombre en esta sucursal.',
        ];
    }
}
