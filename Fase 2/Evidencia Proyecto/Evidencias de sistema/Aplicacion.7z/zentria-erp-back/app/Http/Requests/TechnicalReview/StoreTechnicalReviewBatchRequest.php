<?php

namespace App\Http\Requests\TechnicalReview;

use App\Models\Branch;
use App\Models\CustomerSupplier;
use App\Models\TechnicalReviewBatch;
use App\Models\Warehouse;
use Illuminate\Foundation\Http\FormRequest;

class StoreTechnicalReviewBatchRequest extends FormRequest
{
    protected function prepareForValidation(): void
    {
        $branch = $this->route('branch');
        if ($branch) {
            $branchId = is_object($branch) && method_exists($branch, 'getKey')
                ? $branch->getKey()
                : $branch;

            $this->merge(['branch_id' => $branchId]);
        }

        // Autoselección de supplier si el customer-supplier tiene exactamente 1
        // y no se envía supplier explícitamente.
        $customerSupplierId = $this->input('customer_supplier_id');
        if ($customerSupplierId && !$this->filled('supplier_id')) {
            $cs = CustomerSupplier::withCount('suppliers')->find($customerSupplierId);
            if ($cs && $cs->suppliers_count === 1) {
                $onlySupplierId = $cs->suppliers()->value('suppliers.id');
                if ($onlySupplierId) {
                    $this->merge(['supplier_id' => $onlySupplierId]);
                }
            }
        }
    }

    public function authorize(): bool
    {
        if ($this->isMethod('post')) {
            return $this->user()->can('create-technical-reviews-batches');
        }

        if ($this->isMethod('put') || $this->isMethod('patch')) {
            return $this->user()->can('edit-technical-reviews-batches');
        }

        return false;
    }

    public function rules(): array
    {
        $isUpdate = $this->isMethod('patch') || $this->isMethod('put');

        return [
            'branch_id' => 'required|exists:branches,id',
            'warehouse_id' => array_merge($isUpdate ? ['sometimes'] : ['required'], ['exists:warehouses,id']),
            'customer_supplier_id' => array_merge($isUpdate ? ['sometimes'] : ['required'], ['exists:customer_suppliers,id']),
            'supplier_id' => array_merge($isUpdate ? ['sometimes'] : [], ['nullable', 'exists:suppliers,id']),
            'entry_date' => array_merge($isUpdate ? ['sometimes'] : ['required'], ['date']),
            'expected_quantity' => array_merge($isUpdate ? ['sometimes'] : ['required'], ['integer', 'min:1']),
            'notes' => array_merge($isUpdate ? ['sometimes'] : [], ['nullable', 'string', 'max:1000']),
        ];
    }

    public function messages(): array
    {
        return [
            'branch_id.required' => 'Debe seleccionar una sucursal',
            'warehouse_id.required' => 'Debe seleccionar una bodega',
            'customer_supplier_id.required' => 'Debe seleccionar un customer supplier',
            'entry_date.required' => 'La fecha de ingreso es obligatoria',
            'expected_quantity.required' => 'Debe indicar la cantidad esperada de equipos',
            'expected_quantity.min' => 'Debe ingresar al menos 1 equipo',
        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            $isUpdate = $this->isMethod('patch') || $this->isMethod('put');

            if ($isUpdate) {
                $updatableFields = ['warehouse_id', 'customer_supplier_id', 'entry_date', 'expected_quantity', 'notes'];
                $hasAnyField = collect($updatableFields)->contains(fn($field) => $this->exists($field));

                if (! $hasAnyField) {
                    $validator->errors()->add('update', 'Debes proporcionar al menos un campo para actualizar.');
                }
            }

            $branchParam = $this->route('branch');
            $branch = $branchParam instanceof Branch
                ? $branchParam
                : ($this->input('branch_id') ? Branch::find($this->input('branch_id')) : null);

            if (! $branch) {
                return;
            }

            if ($this->filled('warehouse_id')) {
                $warehouseValid = Warehouse::where('id', $this->input('warehouse_id'))
                    ->where('branch_id', $branch->getKey())
                    ->exists();

                if (! $warehouseValid) {
                    $validator->errors()->add('warehouse_id', 'La bodega seleccionada no pertenece a esta sucursal.');
                }
            }

            if ($this->filled('customer_supplier_id')) {
                $customerSupplierValid = CustomerSupplier::where('id', $this->input('customer_supplier_id'))
                    ->where('subsidiary_id', $branch->subsidiary_id)
                    ->exists();

                if (! $customerSupplierValid) {
                    $validator->errors()->add('customer_supplier_id', 'El customer supplier seleccionado no pertenece a la subsidiaria asociada a esta sucursal.');
                }
            }

            // Validación de supplier asociado al customer-supplier
            // Reglas:
            // - Crear: si el CS tiene >1 suppliers, supplier_id es obligatorio y debe estar asociado.
            // - Crear: si el CS tiene 1 supplier, se fuerza ese supplier (automerge en prepare) y no se permite otro.
            // - Update: si envían supplier_id, debe estar asociado al CS efectivo (enviado o existente).
            $methodIsCreate = $this->isMethod('post');

            // Determinar CS efectivo (en create viene en payload; en update puede no venir)
            $routeBatchId = $this->route('batch');
            $existingBatch = $routeBatchId ? TechnicalReviewBatch::find($routeBatchId) : null;
            $effectiveCustomerSupplierId = $this->input('customer_supplier_id') ?? $existingBatch?->customer_supplier_id;

            if ($effectiveCustomerSupplierId) {
                $cs = CustomerSupplier::with('suppliers:id')->find($effectiveCustomerSupplierId);
                if ($cs) {
                    $supplierIds = $cs->suppliers->pluck('id')->all();
                    $supplierCount = count($supplierIds);

                    if ($this->filled('supplier_id')) {
                        $supId = (int) $this->input('supplier_id');
                        if (!in_array($supId, $supplierIds, true)) {
                            $validator->errors()->add('supplier_id', 'El supplier seleccionado no está asociado al customer supplier.');
                        }
                    } else {
                        // No se envió supplier
                        if ($methodIsCreate && $supplierCount > 1) {
                            $validator->errors()->add('supplier_id', 'Debe seleccionar un supplier asociado al customer supplier.');
                        }
                    }
                }
            }
        });
    }
}
