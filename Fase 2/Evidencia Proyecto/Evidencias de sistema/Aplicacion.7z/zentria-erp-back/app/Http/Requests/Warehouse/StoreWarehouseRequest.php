<?php
namespace App\Http\Requests\Warehouse;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Branch;
use App\Models\Warehouse;

class StoreWarehouseRequest extends FormRequest
{
    public function authorize(): bool
    {
        /** @var Branch $branch */
        $branch = $this->route('branch');
        return $this->user()->can('create', [Warehouse::class, $branch]);
    }

    public function rules(): array
    {
        return [
            'name' => ['required','string','max:255'],
            'code' => ['required','string','max:255'],
            'description' => ['nullable','string'],
            'address' => ['nullable','string','max:255'],
            'storage_location' => ['nullable','string','max:255'],
            'pallet_spot' => ['nullable','string','max:255'],
            'commune_id' => ['nullable','integer','exists:communes,id'],
            'maximum_capacity' => ['nullable','integer','min:0'],
            'schedule' => ['nullable','string'],
            'capacity' => ['nullable','integer','min:0'],
            'warehouse_type' => ['required','string','max:255'],
            'manager_id' => ['nullable','integer','exists:users,id'],
            'is_active' => ['boolean'],
            'requires_serial_tracking' => ['boolean'],
        ];
    }
}
