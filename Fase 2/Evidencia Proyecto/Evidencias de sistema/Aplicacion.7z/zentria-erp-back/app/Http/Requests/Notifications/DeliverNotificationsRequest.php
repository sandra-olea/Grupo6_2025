<?php

namespace App\Http\Requests\Notifications;

use Illuminate\Foundation\Http\FormRequest;

class DeliverNotificationsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'notification_id' => ['nullable', 'integer', 'min:1'],
            'notification_ids' => ['nullable', 'array', 'min:1'],
            'notification_ids.*' => ['integer', 'min:1'],
        ];
    }

    protected function prepareForValidation(): void
    {
        $ids = collect($this->input('notification_ids', []))->filter()->map(fn($id) => (int) $id);

        if ($this->filled('notification_id')) {
            $ids->push((int) $this->input('notification_id'));
        }

        $ids = $ids->unique()->values();

        if ($ids->isNotEmpty()) {
            $this->merge(['notification_ids' => $ids->all()]);
        }
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            $ids = $this->input('notification_ids');
            if (empty($ids) || !is_array($ids)) {
                $validator->errors()->add('notification_ids', 'Debes proporcionar al menos una notificación a actualizar.');
            }
        });
    }

    public function notificationIds(): array
    {
        return $this->input('notification_ids', []);
    }
}
