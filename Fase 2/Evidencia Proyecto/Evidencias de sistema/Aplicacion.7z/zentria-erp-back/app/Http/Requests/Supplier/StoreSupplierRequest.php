<?php

namespace App\Http\Requests\Supplier;

use Illuminate\Foundation\Http\FormRequest;

class StoreSupplierRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // La autorización se maneja en el controlador
    }

    public function rules(): array
    {
        // Obtener subsidiary_id de la ruta
        $subsidiaryId = $this->route('subsidiary')->id;
        
        return [
            'name' => [
                'required',
                'string',
                'max:255',
                // Validar unicidad dentro de la misma subsidiary
                "unique:suppliers,name,NULL,id,subsidiary_id,{$subsidiaryId}"
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'El nombre del proveedor es obligatorio.',
            'name.string' => 'El nombre del proveedor debe ser texto.',
            'name.max' => 'El nombre del proveedor no puede exceder 255 caracteres.',
            'name.unique' => 'Ya existe un proveedor con este nombre en esta sucursal.',
        ];
    }
}
