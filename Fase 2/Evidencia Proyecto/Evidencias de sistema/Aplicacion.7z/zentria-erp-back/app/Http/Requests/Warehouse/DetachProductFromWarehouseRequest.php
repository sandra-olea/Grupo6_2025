<?php
namespace App\Http\Requests\Warehouse;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Warehouse;

class DetachProductFromWarehouseRequest extends FormRequest
{
    /**
     * IDs de productos validados listos para desasociar.
     *
     * @var array<int>
     */
    protected array $productIds = [];

    public function authorize(): bool
    {
        /** @var Warehouse $warehouse */
        $warehouse = $this->route('warehouse');
        return $this->user()->can('detachProduct', $warehouse);
    }

    public function rules(): array
    {
        return [
            'product_id' => ['required'],
        ];
    }

    public function messages(): array
    {
        return [
            'product_id.required' => 'Debe proporcionar al menos un producto.',
        ];
    }

    /**
     * Validación adicional después de las reglas básicas.
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $warehouse = $this->route('warehouse');
            $productIds = $this->normalizeToArray($this->input('product_id'));

            if (empty($productIds)) {
                $validator->errors()->add('product_id', 'Debe proporcionar al menos un producto válido.');
                return;
            }

            $this->productIds = [];
            $seen = [];

            foreach ($productIds as $index => $rawId) {
                $fieldKey = is_array($this->input('product_id')) ? "product_id.$index" : 'product_id';

                if (!is_numeric($rawId)) {
                    $validator->errors()->add($fieldKey, 'El identificador de producto no es válido.');
                    continue;
                }

                $productId = (int) $rawId;

                if ($productId <= 0) {
                    $validator->errors()->add($fieldKey, 'El identificador de producto no es válido.');
                    continue;
                }

                if (isset($seen[$productId])) {
                    $validator->errors()->add($fieldKey, 'El producto se repite en la solicitud.');
                    continue;
                }
                $seen[$productId] = true;

                // Verificar que el producto esté asociado a la warehouse
                if (!$warehouse->products()->where('product_id', $productId)->exists()) {
                    $validator->errors()->add($fieldKey, 'Este producto no está asociado a la bodega.');
                    continue;
                }

                $this->productIds[] = $productId;
            }

            if (empty($this->productIds)) {
                if (!$validator->errors()->has('product_id')) {
                    $validator->errors()->add('product_id', 'No se pudo procesar ningún producto para desasociar.');
                }
            }
        });
    }

    /**
     * Obtiene los IDs de productos validados.
     */
    public function getProductIds(): array
    {
        return $this->productIds;
    }

    /**
     * Normaliza un valor (scalar/array/null) a un arreglo indexado.
     */
    protected function normalizeToArray($value): array
    {
        if (is_array($value)) {
            return array_values($value);
        }

        if ($value === null) {
            return [];
        }

        return [$value];
    }
}
