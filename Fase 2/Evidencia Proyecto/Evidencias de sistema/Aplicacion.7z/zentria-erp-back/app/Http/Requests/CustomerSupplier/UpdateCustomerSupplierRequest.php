<?php

namespace App\Http\Requests\CustomerSupplier;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCustomerSupplierRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // La autorización se maneja en el controlador
    }

    public function rules(): array
    {
        // Obtener subsidiary_id y customerSupplier_id de la ruta
        $subsidiaryId = $this->route('subsidiary')->id;
        $customerSupplierId = $this->route('customerSupplier')->id;
        
        return [
            'name' => [
                'sometimes',
                'required',
                'string',
                'max:255',
                // Validar unicidad dentro de la misma subsidiary, excepto el registro actual
                "unique:customer_suppliers,name,{$customerSupplierId},id,subsidiary_id,{$subsidiaryId}"
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'El nombre del cliente-proveedor es obligatorio.',
            'name.string' => 'El nombre del cliente-proveedor debe ser texto.',
            'name.max' => 'El nombre del cliente-proveedor no puede exceder 255 caracteres.',
            'name.unique' => 'Ya existe otro cliente-proveedor con este nombre en esta sucursal.',
        ];
    }
}
