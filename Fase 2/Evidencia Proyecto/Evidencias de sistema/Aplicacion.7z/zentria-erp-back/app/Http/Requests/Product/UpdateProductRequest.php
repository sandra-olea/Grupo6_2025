<?php
namespace App\Http\Requests\Product;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Models\Product;

class UpdateProductRequest extends FormRequest
{
    public function authorize(): bool {
        /** @var Product $product */
        $product = $this->route('product');
        return $this->user()->can('update', $product);
    }
    public function rules(): array {
        /** @var Product $product */
        $product = $this->route('product');
        return [
            'sku' => [
                'sometimes','string','max:255',
                Rule::unique('products','sku')->ignore($product->id)->where('branch_id', $product->branch_id),
            ],
            'commercial_sku' => ['sometimes','nullable','string','max:255'],
            'barcode' => ['sometimes','nullable','string','max:255'],
            'name' => ['sometimes','string','max:255'],
            'brand_id' => ['sometimes','exists:brands,id'],
            'product_type' => ['sometimes','string','max:255'],
            'warranty_months' => ['sometimes','integer','min:0'],
            'serial_tracking' => ['sometimes','boolean'],
            'short_description' => ['sometimes','nullable','string'],
            'long_description' => ['sometimes','nullable','string'],
            'stock' => ['sometimes','integer','min:0'],
            'snippet_description' => ['sometimes','nullable','string'],
            'cost' => ['sometimes','numeric','min:0'],
            'price' => ['sometimes','numeric','min:0'],
            'offer_price' => ['sometimes', 'numeric','min:0', 'lte:price'],
            'product_status' => ['sometimes','string','max:255'],
            'attributes_json' => ['sometimes','nullable','array'],
            'marketplace_external_ids' => ['sometimes','nullable','array'],
            'is_active' => ['sometimes','boolean'],
            'category_ids' => ['sometimes','array'],
            'category_ids.*' => ['integer','exists:categories,id'],
        ];
    }

    /**
     * Prepara los datos antes de la validación.
     * Elimina 'stock' si el producto actual o el request tiene serial_tracking = true.
     */
    protected function prepareForValidation()
    {
        /** @var Product $product */
        $product = $this->route('product');

        // Si el producto YA tiene serial_tracking o si se está activando en el request
        $hasSerialTracking = $product->serial_tracking || $this->boolean('serial_tracking');

        if ($hasSerialTracking) {
            $this->request->remove('stock');
        }
    }

    /**
     * Obtiene los datos validados, asegurando que stock no se incluya si serial_tracking = true.
     */
    public function validated($key = null, $default = null)
    {
        $validated = parent::validated($key, $default);

        /** @var Product $product */
        $product = $this->route('product');

        // Doble verificación: Si serial_tracking = true (actual o nuevo), eliminar stock
        if (is_array($validated)) {
            $hasSerialTracking = $product->serial_tracking || 
                                 (isset($validated['serial_tracking']) && $validated['serial_tracking']);
            
            if ($hasSerialTracking) {
                unset($validated['stock']);
            }
        }

        return $validated;
    }
}
