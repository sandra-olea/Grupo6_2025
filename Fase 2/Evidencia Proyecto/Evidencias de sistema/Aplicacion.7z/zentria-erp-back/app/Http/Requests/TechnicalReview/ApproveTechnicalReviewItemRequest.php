<?php

namespace App\Http\Requests\TechnicalReview;

use App\Enums\EquipmentGrade;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ApproveTechnicalReviewItemRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('approve-technical-reviews-items');
    }

    public function rules(): array
    {
        return [
            'grade' => ['required', Rule::enum(EquipmentGrade::class)],
            'override_suggestion' => 'sometimes|boolean',
            'override_reason' => 'required_if:override_suggestion,true|string|max:500',
        ];
    }

    public function messages(): array
    {
        return [
            'grade.required' => 'Debes seleccionar un grado (A, B, C o M)',
            'override_reason.required_if' => 'Debes justificar por qué ignoras la sugerencia automática',
        ];
    }
}
