<?php

namespace App\Http\Controllers;

use App\Http\Resources\QuoteItemResource;
use App\Http\Resources\QuoteResource;
use App\Models\Quote;
use App\Models\QuoteItem;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\Subsidiary;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;

class SubsidiaryQuotesController extends Controller
{
    /**
     * GET /api/subsidiaries/{subsidiary}/quotes
     */
    public function index(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $q = Quote::query()
            ->where('subsidiary_id', $subsidiary->id)
            ->with(['items.product']) // cargar items para recalcular totales en listado
            ->withCount('items');

        if ($request->filled('status')) {
            $q->where('status', (string) $request->query('status'));
        }
        if ($search = trim((string) $request->query('q'))) {
            $q->where(function ($w) use ($search) {
                $w->where('quote_number', 'ILIKE', "%{$search}%");
            });
        }
        if ($request->boolean('with_customer')) { $q->with(['customer.commune']); }
        // Incluir datos de vendedor por defecto (usuario que creó la cotización)
        $q->with(['salesperson.primaryBranch']);

        $q->orderByDesc('id');

        return QuoteResource::collection(
            $q->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/quotes/{quote}
     */
    public function show(Subsidiary $subsidiary, int $quote)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $record = Quote::where('subsidiary_id', $subsidiary->id)
            ->with(['customer.commune','items.product','salesperson.primaryBranch'])
            ->findOrFail($quote);

        return QuoteResource::make($record);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/quotes/{quote}/items
     */
    public function items(Subsidiary $subsidiary, int $quote)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $record = Quote::where('subsidiary_id', $subsidiary->id)->findOrFail($quote);
        $items = $record->items()->with(['product','quote'])->orderBy('id')->get();

        return QuoteItemResource::collection($items);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/quotes/{quote}/items
     * Agrega un ítem a la cotización. Los montos son NETOS.
     */
    public function addItem(Request $request, Subsidiary $subsidiary, int $quote)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $record = Quote::where('subsidiary_id', $subsidiary->id)->findOrFail($quote);

        $data = $request->validate([
            'product_id' => ['nullable','integer','exists:products,id'],
            'quantity' => ['required','integer','min:1'],
            'unit_price' => ['nullable','numeric','min:0','required_without:product_id'], // neto; opcional si viene product_id
            'discount_rate' => ['nullable','numeric','min:0'],
            'discount_amount' => ['nullable','numeric','min:0'],
            'customer_sku' => ['nullable','string','max:100'],
            'customer_name' => ['nullable','string','max:255'],
            'description' => ['nullable','string'],
            'notes' => ['nullable','string'],
            'product_attributes' => ['nullable','array'],
        ]);

        $qty = (int) $data['quantity'];
        $unit = (float) ($data['unit_price'] ?? 0);

        // Si viene product_id y no se envió unit_price, tomar precio del producto (offer_price > price)
        if (($data['product_id'] ?? null) && !array_key_exists('unit_price', $data)) {
            $p = \App\Models\Product::find($data['product_id']);
            if ($p) {
                $unit = (float) ($p->offer_price ?: $p->price ?: 0);
                if ($unit <= 0) {
                    return response()->json([
                        'message' => 'El producto no tiene precio definido',
                        'errors' => [ 'unit_price' => ['El producto no tiene precio definido'] ],
                    ], 422);
                }
            } else {
                return response()->json([
                    'message' => 'Producto no encontrado',
                    'errors' => [ 'product_id' => ['Producto no encontrado'] ],
                ], 422);
            }
        }
        $subtotal = round($unit * $qty, 2);

        $item = QuoteItem::create(array_merge($data, [
            'quote_id' => $record->id,
            'subtotal' => $subtotal,
            'total' => $subtotal, // mantener total = neto; descuentos son informativos
        ]));

        return QuoteItemResource::make($item->load('product','quote'));
    }

    /**
     * PATCH /api/subsidiaries/{subsidiary}/quotes/{quote}/items/{item}
     */
    public function updateItem(Request $request, Subsidiary $subsidiary, int $quote, int $item)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $record = Quote::where('subsidiary_id', $subsidiary->id)->findOrFail($quote);
        $qi = $record->items()->where('id', $item)->firstOrFail();

        $data = $request->validate([
            'product_id' => ['sometimes','nullable','integer','exists:products,id'],
            'quantity' => ['sometimes','integer','min:1'],
            'unit_price' => ['sometimes','nullable','numeric','min:0'], // neto
            'discount_rate' => ['nullable','numeric','min:0'],
            'discount_amount' => ['nullable','numeric','min:0'],
            'customer_sku' => ['nullable','string','max:100'],
            'customer_name' => ['nullable','string','max:255'],
            'description' => ['nullable','string'],
            'notes' => ['nullable','string'],
            'product_attributes' => ['nullable','array'],
        ]);

        $qi->fill($data);
        // Si se cambió product_id y no se envió unit_price, usar precio del producto
        if (array_key_exists('product_id', $data) && !array_key_exists('unit_price', $data) && $qi->product_id) {
            $p = \App\Models\Product::find($qi->product_id);
            if ($p) {
                $val = (float) ($p->offer_price ?: $p->price ?: 0);
                if ($val <= 0) {
                    return response()->json([
                        'message' => 'El producto no tiene precio definido',
                        'errors' => [ 'unit_price' => ['El producto no tiene precio definido'] ],
                    ], 422);
                }
                $qi->unit_price = $val;
            } else {
                return response()->json([
                    'message' => 'Producto no encontrado',
                    'errors' => [ 'product_id' => ['Producto no encontrado'] ],
                ], 422);
            }
        }
        $qty = (int) ($qi->quantity ?? 1);
        $unit = (float) ($qi->unit_price ?? 0);
        $qi->subtotal = round($unit * max(1, $qty), 2);
        $qi->total = $qi->subtotal;
        $qi->save();

        return QuoteItemResource::make($qi->load('product','quote'));
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/quotes/{quote}/items/{item}
     */
    public function deleteItem(Subsidiary $subsidiary, int $quote, int $item)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $record = Quote::where('subsidiary_id', $subsidiary->id)->findOrFail($quote);
        $qi = $record->items()->where('id', $item)->firstOrFail();
        $qi->delete();

        return response()->json(['deleted' => true]);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/quotes
     */
    public function store(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $validated = $request->validate([
            'customer_id' => ['required','integer','exists:customer_sale,id'],
            'quote_number' => [
                'nullable','string','max:255',
                Rule::unique('quotes','quote_number')->where(fn($q) => $q->where('subsidiary_id', $subsidiary->id)),
            ],
            'status' => 'in:draft,sent,approved,converted,rejected,expired',
            'salesperson_id' => 'nullable|integer',
            'quote_date' => 'required|date',
            'expiry_date' => 'required|date',
            'subtotal' => 'nullable|numeric',
            'tax_amount' => 'nullable|numeric',
            'discount_amount' => 'nullable|numeric',
            'total_amount' => 'nullable|numeric',
            'tax_rate' => 'nullable|numeric',
            'discount_rate' => 'nullable|numeric',
            'terms_conditions' => 'nullable|array',
            'notes' => 'nullable|string',
            'internal_notes' => 'nullable|string',
        ]);

        $salespersonId = $validated['salesperson_id'] ?? (auth('api')->id() ?: null);
        $quote = Quote::create(array_merge($validated, [
            'subsidiary_id' => $subsidiary->id,
            'status' => $validated['status'] ?? 'draft',
            'salesperson_id' => $salespersonId,
        ]));

        return QuoteResource::make($quote);
    }

    /**
     * PATCH /api/subsidiaries/{subsidiary}/quotes/{quote}
     */
    public function update(Request $request, Subsidiary $subsidiary, int $quote)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $record = Quote::where('subsidiary_id', $subsidiary->id)->findOrFail($quote);

        $validated = $request->validate([
            'customer_id' => ['sometimes','integer','exists:customer_sale,id'],
            'quote_number' => [
                'sometimes','nullable','string','max:255',
                Rule::unique('quotes','quote_number')->where(fn($q) => $q->where('subsidiary_id', $subsidiary->id))->ignore($record->id),
            ],
            'status' => 'sometimes|in:draft,sent,approved,converted,rejected,expired',
            'salesperson_id' => 'nullable|integer',
            'quote_date' => 'sometimes|date',
            'expiry_date' => 'sometimes|date',
            'subtotal' => 'nullable|numeric',
            'tax_amount' => 'nullable|numeric',
            'discount_amount' => 'nullable|numeric',
            'total_amount' => 'nullable|numeric',
            'tax_rate' => 'nullable|numeric',
            'discount_rate' => 'nullable|numeric',
            'terms_conditions' => 'nullable|array',
            'notes' => 'nullable|string',
            'internal_notes' => 'nullable|string',
            'is_converted_to_sale' => 'sometimes|boolean',
            'converted_at' => 'nullable|date',
        ]);

        $record->fill($validated);
        $record->save();

        return QuoteResource::make($record);
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/quotes/{quote}
     */
    public function destroy(Subsidiary $subsidiary, int $quote)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);
        $record = Quote::where('subsidiary_id', $subsidiary->id)->findOrFail($quote);
        $record->delete();
        return response()->json(['message' => 'Cotización eliminada correctamente']);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/quotes/{quote}/pdf
     * Genera y descarga el PDF de la cotización.
     */
    public function downloadPdf(Subsidiary $subsidiary, int $quote)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        /** @var Quote $record */
        $record = Quote::with(['items.product', 'customer.commune.province.region'])
            ->where('subsidiary_id', $subsidiary->id)
            ->findOrFail($quote);

        $customer = $record->customer;
        $taxRate = (float) ($record->tax_rate ?? 0.19);
        if ($taxRate <= 0) { $taxRate = 0.19; }

        $computed = [];
        foreach ($record->items as $it) {
            $qty = max(1, (int) $it->quantity);
            // Los precios de la cotización vienen con IVA incluido: neto = precio / (1 + IVA)
            // Fallbacks cuando falta unit_price: usar total/qty, subtotal/qty o precio del producto
            $unitGross = (float) ($it->unit_price ?? 0);
            if ($unitGross <= 0) {
                $lineTotal = (float) ($it->total ?? 0);
                $lineSubtotal = (float) ($it->subtotal ?? 0);
                if ($lineTotal > 0 && $qty > 0) {
                    $unitGross = round($lineTotal / $qty, 2);
                } elseif ($lineSubtotal > 0 && $qty > 0) {
                    $unitGross = round($lineSubtotal / $qty, 2);
                } elseif ($it->product) {
                    $unitGross = (float) ($it->product->offer_price ?: $it->product->price ?: 0);
                }
            }
            $unitNet = round($unitGross / (1.0 + $taxRate), 2);
            $totalNet = round($unitNet * $qty, 2);
            $computed[] = [
                'quantity' => $qty,
                'sku' => $it->product?->sku ?: ($it->customer_sku ?? ''),
                'name' => $it->product?->name ?: ($it->customer_name ?? 'Producto'),
                'addons' => null,
                'unit_net' => round($unitNet, 2),
                'total_net' => round($totalNet, 2),
                'has_discount' => ((float)($it->discount_amount ?? 0)) > 0,
                'discount_amount' => (float) ($it->discount_amount ?? 0),
            ];
        }

        $itemsNetTotal = (float) array_sum(array_column($computed, 'total_net'));
        $shippingNet = 0.0; // como ítem separado cuando aplique
        $iva = round($itemsNetTotal * $taxRate, 2);
        $grandTotal = round($itemsNetTotal + $iva, 2);

        // Dirección formateada (similar a plantilla)
        $commune = $customer?->commune; $province = $commune?->province; $region = $province?->region;
        $addrParts = array_filter([
            $customer?->billing_address_1,
            $customer?->billing_address_2,
            $customer?->billing_city,
            $commune?->name,
            $region?->name,
            $customer?->billing_postcode,
        ], fn ($v) => $v && trim((string)$v) !== '');
        $address = implode(', ', $addrParts);

        $data = [
            'quote' => $record,
            'quote_number_display' => (string) $record->id, // mostrar ID incremental
            'date_display' => $record->quote_date?->toDateString() ?: now()->toDateString(),
            'payment_title' => 'N/A',
            'document_type' => $customer?->default_document_type ?: 'boleta',
            'po_number' => $customer?->purchase_order_number ?: null,
            'buyer_name' => $customer?->billing_company ?: ($customer?->contact_name ?: 'N/A'),
            'rut' => $customer?->rut ?: 'N/A',
            'giro' => $customer?->billing_company ?: 'N/A',
            'address' => $address,
            'contact_name' => $customer?->contact_name ?: 'N/A',
            'email' => $customer?->email ?: 'N/A',
            'items' => $computed,
            'totals' => [
                'shipping_net' => $shippingNet,
                'total_net' => $itemsNetTotal,
                'iva' => $iva,
                'grand_total' => $grandTotal,
            ],
        ];

        $diskPath = 'public/subsidiary-'.$subsidiary->id.'/quotes';
        $filename = 'quote-'.$record->id.'.pdf';
        @\Storage::makeDirectory($diskPath);

        $pdfGenerated = false; $raw = null;
        try {
            if (class_exists('Barryvdh\\DomPDF\\Facade\\Pdf')) {
                $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('quotes.quote', $data);
                $pdf->setPaper('letter');
                $raw = $pdf->output();
                $pdfGenerated = true;
            }
        } catch (\Throwable $e) { Log::warning('Quote PDF dompdf failed', ['error' => $e->getMessage()]); }

        if (!$pdfGenerated) {
            // Fallback a HTML-to-PDF si tienes otro generador; guardamos HTML mientras tanto
            $raw = view('quotes.quote', $data)->render();
        }

        \Storage::put($diskPath.'/'.$filename, $raw);

        return response()->json([
            'quote_id' => $record->id,
            'storage_relative' => $diskPath.'/'.$filename,
        ]);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/quotes/{quote}/convert-to-sale
     * Crea una venta basada en la cotización y marca la cotización como convertida.
     */
    public function convertToSale(Subsidiary $subsidiary, int $quote)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        /** @var Quote $record */
        $record = Quote::with(['items', 'customer'])
            ->where('subsidiary_id', $subsidiary->id)
            ->findOrFail($quote);

        if ($record->is_converted_to_sale) {
            return response()->json(['message' => 'La cotización ya fue convertida anteriormente'], 409);
        }

        $taxRate = (float) ($record->tax_rate ?? 0.19);
        if ($taxRate <= 0) { $taxRate = 0.19; }

        $sale = DB::transaction(function () use ($record, $subsidiary, $taxRate) {
            $itemsNetTotal = 0.0;
            foreach ($record->items as $it) {
                $qty = max(1, (int) $it->quantity);
                // Los precios guardados en la cotización incluyen IVA
                // Fallbacks: total/qty, subtotal/qty o precio producto
                $unitGross = (float) ($it->unit_price ?? 0);
                if ($unitGross <= 0) {
                    $lineTotal = (float) ($it->total ?? 0);
                    $lineSubtotal = (float) ($it->subtotal ?? 0);
                    if ($lineTotal > 0 && $qty > 0) {
                        $unitGross = round($lineTotal / $qty, 2);
                    } elseif ($lineSubtotal > 0 && $qty > 0) {
                        $unitGross = round($lineSubtotal / $qty, 2);
                    } elseif ($it->product) {
                        $unitGross = (float) ($it->product->offer_price ?: $it->product->price ?: 0);
                    }
                }
                $unitNet = round($unitGross / (1.0 + $taxRate), 2);
                $itemsNetTotal += round($unitNet * $qty, 2);
            }
            $iva = round($itemsNetTotal * $taxRate, 2);
            $grandTotal = round($itemsNetTotal + $iva, 2);

            $sale = Sale::create([
                'subsidiary_id' => $subsidiary->id,
                'customer_id' => $record->customer_id,
                'wc_order_id' => null,
                'wc_order_number' => null,
                'sale_number' => 'Q'.$record->id,
                'status' => 'confirmed',
                'salesperson_id' => $record->salesperson_id,
                'sale_date' => $record->quote_date?->toDateString() ?: now()->toDateString(),
                'subtotal' => $itemsNetTotal,
                'discount_amount' => (float) ($record->discount_amount ?? 0),
                'tax_amount' => $iva,
                'shipping_amount' => 0.0,
                'total_amount' => $grandTotal,
                'paid_amount' => 0.0,
                'pending_amount' => $grandTotal,
                'currency' => 'CLP',
                'billing_snapshot' => null,
                'shipping_snapshot' => null,
                'payment_method' => null,
                'payment_method_title' => null,
                'woo_metadata' => null,
                'documents_metadata' => null,
                'notes' => $record->notes,
                'internal_notes' => $record->internal_notes,
            ]);

            foreach ($record->items as $it) {
                $qty = max(1, (int) $it->quantity);
                // Convertir precio bruto a neto para crear los items de venta (con fallbacks)
                $unitGross = (float) ($it->unit_price ?? 0);
                if ($unitGross <= 0) {
                    $lineTotal = (float) ($it->total ?? 0);
                    $lineSubtotal = (float) ($it->subtotal ?? 0);
                    if ($lineTotal > 0 && $qty > 0) {
                        $unitGross = round($lineTotal / $qty, 2);
                    } elseif ($lineSubtotal > 0 && $qty > 0) {
                        $unitGross = round($lineSubtotal / $qty, 2);
                    } elseif ($it->product) {
                        $unitGross = (float) ($it->product->offer_price ?: $it->product->price ?: 0);
                    }
                }
                $unitNet = round($unitGross / (1.0 + $taxRate), 2);
                SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $it->product_id,
                    'quantity' => $qty,
                    'unit_price' => $unitNet,
                    'subtotal' => round($unitNet * $qty, 2),
                    'total' => round($unitNet * $qty, 2),
                    'discount_amount' => (float) ($it->discount_amount ?? 0),
                    'meta_json' => [
                        'name' => $it->product?->name ?: ($it->customer_name ?? null),
                        'mapping' => ['sku' => $it->product?->sku ?: ($it->customer_sku ?? null)],
                    ],
                ]);
            }

            // Marcar cotización como convertida
            $record->update([
                'is_converted_to_sale' => true,
                'converted_at' => now(),
                'status' => 'converted',
            ]);

            return $sale;
        });

        return response()->json([
            'message' => 'Cotización convertida en venta',
            'sale' => [
                'id' => $sale->id,
                'sale_number' => $sale->sale_number,
                'status' => $sale->status,
                'total_amount' => $sale->total_amount,
                'created_at' => $sale->created_at?->toISOString(),
            ],
        ], 201);
    }
}
