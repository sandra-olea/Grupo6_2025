<?php

namespace App\Http\Controllers;

use App\Models\Region;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class RegionController extends Controller
{
    /**
     * Eager-load whitelist for Region.
     * Ajusta según tus relaciones reales del modelo Region.
     * Ejemplos típicos en Chile: Region -> provinces -> communes
     */
    private const ALLOWED_WITH = [
        'provinces',
        'provinces.communes',
        // 'communes', // habilítalo solo si tienes hasManyThrough en Region
    ];

    private function parseWith(Request $request): array
    {
        return collect(explode(',', (string) $request->query('with')))
            ->map('trim')
            ->filter()            // elimina vacíos
            ->unique()            // evita repetidos
            ->filter(fn ($rel) => in_array($rel, self::ALLOWED_WITH, true))
            ->values()
            ->all();
    }

    public function index(Request $request)
    {
        $with = $this->parseWith($request);
        // Permitir bypass cache con ?no_cache=1
        if ($request->boolean('no_cache')) {
            $query = Region::query()->orderBy('geographic_order');
            if (!empty($with)) $query->with($with);
            return $query->get();
        }

        $key = 'locations:regions:index:with=' . (empty($with) ? 'none' : implode(',', $with));
        return Cache::remember($key, now()->addDay(), function () use ($with) {
            $q = Region::query()->orderBy('geographic_order');
            if (!empty($with)) $q->with($with);
            return $q->get();
        });
    }

    public function show(Request $request, int $id)
    {
        $with = $this->parseWith($request);

        if ($request->boolean('no_cache')) {
            $q = Region::query();
            if (!empty($with)) $q->with($with);
            return $q->findOrFail($id);
        }

        $key = 'locations:regions:show:' . $id . ':with=' . (empty($with) ? 'none' : implode(',', $with));
        return Cache::remember($key, now()->addDay(), function () use ($with, $id) {
            $q = Region::query();
            if (!empty($with)) $q->with($with);
            return $q->findOrFail($id);
        });
    }
}
