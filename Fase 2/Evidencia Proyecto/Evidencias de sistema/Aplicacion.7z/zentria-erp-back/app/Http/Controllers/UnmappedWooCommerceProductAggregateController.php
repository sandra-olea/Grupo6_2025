<?php

namespace App\Http\Controllers;

use App\Models\Integration;
use App\Models\Subsidiary;
use App\Models\UnmappedWooCommerceProduct;
use App\Http\Resources\UnmappedWooCommerceProductResource;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UnmappedWooCommerceProductAggregateController extends Controller
{
    /**
     * GET /api/subsidiaries/{subsidiary}/integrations/unmapped-products
     * Aggregated pending (unmapped) records across all integrations under the subsidiary.
     */
    public function unmapped(Request $request, Subsidiary $subsidiary): JsonResponse
    {
        $this->authorize('viewAny', UnmappedWooCommerceProduct::class);

        $integrationIds = Integration::query()
            ->where('subsidiary_id', $subsidiary->id)
            ->pluck('id');

        $query = UnmappedWooCommerceProduct::query()
            ->whereIn('integration_id', $integrationIds)
            ->pending()
            ->with(['integration', 'sale', 'mappedProduct']);

        if ($request->filled('search')) {
            $search = (string) $request->get('search');
            $query->where(function ($q) use ($search) {
                $q->where('sku', 'ILIKE', "%{$search}%")
                  ->orWhere('name', 'ILIKE', "%{$search}%");
            });
        }

        // Optional filters
        if ($request->filled('wc_order_id')) {
            $query->where('wc_order_id', (int) $request->get('wc_order_id'));
        }

        $sortBy = (string) $request->get('sort_by', 'created_at');
        $sortDirection = (string) $request->get('sort_direction', 'desc');
        $query->orderBy($sortBy, $sortDirection);

        $perPage = min((int) $request->get('per_page', 15), 100);
        $unmapped = $query->paginate($perPage);

        $data = [];
        foreach ($unmapped->items() as $item) {
            $item->loadMissing('integration');
            $resource = (new UnmappedWooCommerceProductResource($item))->toArray($request);
            $resource['source'] = [
                'id' => $item->integration->id ?? null,
                'name' => $item->integration->name ?? null,
                'provider' => $item->integration->provider ?? null,
            ];
            $data[] = $resource;
        }

        return response()->json([
            'data' => $data,
            'meta' => [
                'current_page' => $unmapped->currentPage(),
                'last_page' => $unmapped->lastPage(),
                'per_page' => $unmapped->perPage(),
                'total' => $unmapped->total(),
            ],
        ]);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/integrations/unmapped-products/mapped
     * Aggregated mapped records across all integrations under the subsidiary.
     */
    public function mapped(Request $request, Subsidiary $subsidiary): JsonResponse
    {
        $this->authorize('viewAny', UnmappedWooCommerceProduct::class);

        $integrationIds = Integration::query()
            ->where('subsidiary_id', $subsidiary->id)
            ->pluck('id');

        $query = UnmappedWooCommerceProduct::query()
            ->whereIn('integration_id', $integrationIds)
            ->mapped()
            ->with(['integration', 'sale', 'mappedProduct']);

        if ($request->filled('search')) {
            $search = (string) $request->get('search');
            $query->where(function ($q) use ($search) {
                $q->where('sku', 'ILIKE', "%{$search}%")
                  ->orWhere('name', 'ILIKE', "%{$search}%");
            });
        }

        if ($request->filled('mapped_from')) {
            $query->where('mapped_at', '>=', $request->get('mapped_from'));
        }
        if ($request->filled('mapped_to')) {
            $query->where('mapped_at', '<=', $request->get('mapped_to'));
        }

        $sortBy = (string) $request->get('sort_by', 'mapped_at');
        $sortDirection = (string) $request->get('sort_direction', 'desc');
        $query->orderBy($sortBy, $sortDirection);

        $perPage = min((int) $request->get('per_page', 15), 100);
        $mapped = $query->paginate($perPage);

        $data = [];
        foreach ($mapped->items() as $item) {
            $item->loadMissing('integration');
            $resource = (new UnmappedWooCommerceProductResource($item))->toArray($request);
            $resource['source'] = [
                'id' => $item->integration->id ?? null,
                'name' => $item->integration->name ?? null,
                'provider' => $item->integration->provider ?? null,
            ];
            $data[] = $resource;
        }

        return response()->json([
            'data' => $data,
            'meta' => [
                'current_page' => $mapped->currentPage(),
                'last_page' => $mapped->lastPage(),
                'per_page' => $mapped->perPage(),
                'total' => $mapped->total(),
            ],
        ]);
    }
}
