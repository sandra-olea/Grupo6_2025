<?php

namespace App\Http\Controllers\Notifications;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Notifications\DeliverNotificationsRequest;
use App\Models\Notifications\UserNotification;

class NotificationController extends BaseController
{
    public function index(Request $request)
    {
        $user = Auth::user();

        $policy = app(\App\Services\Notifications\NotificationPolicyService::class);
        $allowedTypeIds = $policy->allowedTypeIdsForUser($user);

        $query = UserNotification::with(['event.type'])
            ->where('user_id', $user->id)
            ->whereHas('event', function ($q) use ($allowedTypeIds) {
                if (!empty($allowedTypeIds)) {
                    $q->whereIn('type_id', $allowedTypeIds);
                }
            })
            ->orderByDesc('created_at');

        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }
        if ($priority = $request->query('priority')) {
            $query->whereHas('event', fn($q) => $q->where('priority', $priority));
        }
        if ($module = $request->query('module')) {
            $query->whereHas('event.type', fn($q) => $q->where('module', $module));
        }
        if ($branchId = $request->query('branch_id')) {
            $query->whereHas('event', fn($q) => $q->where('branch_id', $branchId));
        }

        $paginator = $query->paginate((int) $request->query('per_page', 15));

        $msg = app(\App\Services\Notifications\NotificationMessageService::class);
        $data = collect($paginator->items())->filter(function (UserNotification $n) use ($user, $policy) {
            // Seguridad adicional: filtrar por alcance y roles
            $ev = $n->event;
            if (!$ev || !$ev->type) return false;
            if (! $policy->userCanReceive($user, [
                'company_id' => $ev->company_id,
                'subsidiary_id' => $ev->subsidiary_id,
                'branch_id' => $ev->branch_id,
            ])) return false;
            if (! $policy->isRoleEligibleForType($user, $ev->type)) return false;
            return true;
        })->map(function (UserNotification $n) use ($user, $policy, $msg) {
            $type = optional($n->event)->type;
            $effective = $type ? $policy->resolveEffective($user, $type, [
                'company_id' => $n->event->company_id ?? null,
                'subsidiary_id' => $n->event->subsidiary_id ?? null,
                'branch_id' => $n->event->branch_id ?? null,
            ]) : ['origin' => 'global'];

            return [
                'id' => $n->id,
                'status' => $n->status,
                'bucket' => optional($type)->bucket, // Important | Archived | Pending (desde BD)
                'title' => optional($type)->description ?? optional($type)->display_name,
                'assigned_to' => $n->assigned_to,
                'delivered_channels' => $n->delivered_channels ?? [],
                'aggregate_count' => $n->aggregate_count ?? 1,
                'read_at' => optional($n->read_at)->toIso8601String(),
                'ack_at' => optional($n->ack_at)->toIso8601String(),
                'created_at' => optional($n->created_at)->toIso8601String(),
                'event' => [
                    'id' => optional($n->event)->id,
                    'type_key' => optional($type)->key,
                    'type_label' => optional($type)->display_name,
                    'module' => optional($type)->module,
                    'module_label' => optional($type)->module_label,
                    'priority' => optional($n->event)->priority,
                    'payload' => optional($n->event)->payload,
                    'scope' => [
                        'company_id' => optional($n->event)->company_id,
                        'subsidiary_id' => optional($n->event)->subsidiary_id,
                        'branch_id' => optional($n->event)->branch_id,
                    ],
                ],
                'origin' => $effective['origin'] ?? 'global',
                'message' => $msg->format($n->event),
                    'delivered_to_user' => (bool) $n->delivered_to_user,
            ];
        });

        return response()->json([
            'data' => $data->values(),
            'meta' => [
                'current_page' => $paginator->currentPage(),
                'last_page' => $paginator->lastPage(),
                'per_page' => $paginator->perPage(),
                'total' => $paginator->total(),
            ],
        ]);
    }

    public function markRead(string $id)
    {
        $user = Auth::user();
        $notif = UserNotification::where('id', $id)->where('user_id', $user->id)->firstOrFail();
        $notif->status = 'read';
        $notif->read_at = now();
        $notif->save();
        return response()->json(['ok' => true]);
    }

    public function markUnread(string $id)
    {
        $user = Auth::user();
        $notif = UserNotification::where('id', $id)->where('user_id', $user->id)->firstOrFail();
        $notif->status = 'unread';
        $notif->read_at = null;
        $notif->save();
        return response()->json(['ok' => true]);
    }

        public function markDelivered(DeliverNotificationsRequest $request)
        {
            $user = Auth::user();
            if (! $user->can('deliver-own-notifications')) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No estás autorizado para realizar esta acción.',
                ], 403);
            }
            $ids = $request->notificationIds();

            $now = now();
            $foundIds = UserNotification::where('user_id', $user->id)
                ->whereIn('id', $ids)
                ->pluck('id')
                ->all();

            sort($foundIds);
            $expected = $ids;
            sort($expected);

            if ($foundIds !== $expected) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No estás autorizado para modificar alguna de las notificaciones solicitadas.',
                ], 403);
            }

            $updated = UserNotification::where('user_id', $user->id)
                ->whereIn('id', $ids)
                ->update(['delivered_to_user' => true, 'updated_at' => $now]);

            return response()->json(['ok' => true, 'updated' => $updated]);
        }

        public function markAllDelivered(Request $request)
        {
            $user = Auth::user();
            if (! $user->can('deliver-all-own-notifications')) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No estás autorizado para realizar esta acción.',
                ], 403);
            }
            $now = now();

            $updated = UserNotification::where('user_id', $user->id)
                ->where('delivered_to_user', false)
                ->update(['delivered_to_user' => true, 'updated_at' => $now]);

            return response()->json(['ok' => true, 'updated' => $updated]);
        }

    public function ack(string $id)
    {
        $user = Auth::user();
        $notif = UserNotification::where('id', $id)->where('user_id', $user->id)->firstOrFail();
        $notif->status = 'ack';
        $notif->ack_at = now();
        $notif->save();
        return response()->json(['ok' => true]);
    }

    public function assign(string $id, Request $request)
    {
        $request->validate(['user_id' => 'required|integer']);
        $current = Auth::user();

        if (!$current->hasAnyRole(['super-admin','company-admin','subsidiary-admin','branch-admin'])) {
            return response()->json(['message' => 'No estás autorizado para realizar esta acción'], 403);
        }

        $notif = UserNotification::with('event')->findOrFail($id);

        // Scope enforcement: current user must access event scope
        $event = $notif->event;
        $scope = ['company_id' => $event->company_id, 'subsidiary_id' => $event->subsidiary_id, 'branch_id' => $event->branch_id];

        $canAccess = $current->canAccessEntity(
            $scope['branch_id'] ? 'branch' : ($scope['subsidiary_id'] ? 'subsidiary' : 'company'),
            $scope['branch_id'] ?? ($scope['subsidiary_id'] ?? $scope['company_id'])
        );
        if (!$canAccess) {
            return response()->json(['message' => 'No estás autorizado para realizar esta acción'], 403);
        }

        $assigneeId = (int) $request->input('user_id');
        $notif->assigned_to = $assigneeId;
        $notif->status = 'assigned';
        $notif->save();
        return response()->json(['ok' => true]);
    }

    public function destroy(string $id)
    {
        $user = Auth::user();
        $notif = UserNotification::where('id', $id)->where('user_id', $user->id)->firstOrFail();
        $notif->delete(); // soft delete
        return response()->json(['ok' => true]);
    }

    public function markAllRead(Request $request)
    {
        $user = Auth::user();
        $now = now();

        $updated = UserNotification::where('user_id', $user->id)
            ->where('status', 'unread')
            ->update(['status' => 'read', 'read_at' => $now, 'updated_at' => $now]);

        return response()->json(['ok' => true, 'updated' => $updated]);
    }

    public function markAllUnread(Request $request)
    {
        $user = Auth::user();
        $now = now();

        // Solo revertimos las que están en estado 'read'
        $updated = UserNotification::where('user_id', $user->id)
            ->where('status', 'read')
            ->update(['status' => 'unread', 'read_at' => null, 'updated_at' => $now]);

        return response()->json(['ok' => true, 'updated' => $updated]);
    }

    public function purge(string $id)
    {
        $user = Auth::user();
        $notif = UserNotification::withTrashed()
            ->where('id', $id)
            ->where('user_id', $user->id)
            ->firstOrFail();

        if (! $notif->trashed()) {
            return response()->json([
                'ok' => false,
                'message' => 'Primero envía la notificación a la papelera (DELETE /notifications/{id}).',
            ], 409);
        }

        $notif->forceDelete(); // borra definitivamente y cascada delivery_logs
        return response()->json(['ok' => true]);
    }
}
