<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Concerns\TogglesActiveFlag;
use App\Http\Requests\Category\StoreCategoryRequest;
use App\Http\Requests\Category\UpdateCategoryRequest;
use App\Http\Resources\CategoryResource;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Traits\DispatchesNotifications;

class CategoriesController extends Controller
{
    use TogglesActiveFlag;
    use DispatchesNotifications;

    public function index(Request $request)
    {
        $this->authorize('viewAny', Category::class);
        $q = Category::query();
        if ($s = trim((string)$request->get('q'))) {
            $q->whereRaw('name ILIKE ?', ['%'.$s.'%']);
        }
        if (!is_null($request->get('parent_id'))) {
            $q->where('parent_id', $request->integer('parent_id'));
        }
        $q->withCount([
                'children',
                // Contar productos asociados (excluyendo pivotes soft-deleted)
                'products as associated_products' => function($q){
                    $q->whereNull('product_category.deleted_at');
                }
            ])
            ->orderBy('name');
        return CategoryResource::collection(
            $q->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }

    public function tree(Request $request)
    {
        $this->authorize('viewAny', Category::class);
        $roots = Category::with(['children' => function($q){ $q->with('children'); }])
            ->whereNull('parent_id')->orderBy('name')->get();
        return CategoryResource::collection($roots);
    }

    public function store(StoreCategoryRequest $request)
    {
        $category = Category::create($request->validated());

        // Notificación: category.created (scope empresa del usuario)
        $user = Auth::user();
        $branch = $user?->primaryBranch;
        
        $this->dispatchNotification(
            typeKey: 'category.created',
            entityType: 'category',
            entityId: $category->id,
            scope: $this->currentUserBranchScope(),
            payload: array_merge(
                [
                    'category_name' => $category->name,
                    'branch_name' => $branch?->branch_name,
                ],
                $this->currentUserPayload('created_by')
            )
        );

        return CategoryResource::make($category);
    }

    public function show(Category $category)
    {
        $this->authorize('view', $category);
        return CategoryResource::make(
            $category->loadCount([
                'children',
                'products as associated_products' => function($q){
                    $q->whereNull('product_category.deleted_at');
                }
            ])
        );
    }

    public function update(UpdateCategoryRequest $request, Category $category)
    {
        $category->update($request->validated());

        // Notificación: category.updated (scope empresa del usuario)
        $user = Auth::user();
        $branch = $user?->primaryBranch;
        
        $this->dispatchNotification(
            typeKey: 'category.updated',
            entityType: 'category',
            entityId: $category->id,
            scope: $this->currentUserBranchScope(),
            payload: array_merge(
                [
                    'category_name' => $category->name,
                    'branch_name' => $branch?->branch_name,
                ],
                $this->currentUserPayload('updated_by')
            )
        );

        return CategoryResource::make($category->loadCount('children'));
    }

    public function destroy(Category $category)
    {
        $this->authorize('delete', $category);

        // Notificación: category.deleted (scope granular: branch si existe primaryBranch del actor)
        $user = Auth::user();
        $branch = $user?->primaryBranch;
        
        $this->dispatchNotification(
            typeKey: 'category.deleted',
            entityType: 'category',
            entityId: $category->id,
            scope: $this->currentUserBranchScope(),
            payload: array_merge(
                [
                    'category_name' => $category->name,
                    'branch_name' => $branch?->branch_name,
                ],
                $this->currentUserPayload('updated_by')
            )
        );

        $category->delete();
        return response()->json(['deleted'=>true]);
    }

    public function toggleStatus(Category $category)
    {
        return $this->toggleModelActive($category, 'Categoría');
    }
}
