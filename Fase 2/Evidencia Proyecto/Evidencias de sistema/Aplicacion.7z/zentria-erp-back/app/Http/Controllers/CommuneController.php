<?php

namespace App\Http\Controllers;

use App\Models\Commune;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class CommuneController extends Controller
{
    public function index(Request $request)
    {
        $with = array_filter(explode(',', (string) $request->query('with')));
        if ($request->boolean('no_cache')) {
            $q = Commune::query()->orderBy('name');
            if ($request->filled('province_id')) $q->where('province_id', (int) $request->query('province_id'));
            if (!empty($with)) $q->with($with);
            return $q->get();
        }

        $provinceFilter = $request->filled('province_id') ? (int) $request->query('province_id') : 'any';
        $key = 'locations:communes:index:province=' . $provinceFilter . ':with=' . (empty($with) ? 'none' : implode(',', $with));
        return Cache::remember($key, now()->addDay(), function () use ($with, $provinceFilter) {
            $q = Commune::query()->orderBy('name');
            if ($provinceFilter !== 'any') $q->where('province_id', (int) $provinceFilter);
            if (!empty($with)) $q->with($with);
            return $q->get();
        });
    }

    public function show(Request $request, int $id)
    {
        $with = array_filter(explode(',', (string) $request->query('with')));
        if ($request->boolean('no_cache')) {
            $q = Commune::query();
            if (!empty($with)) $q->with($with);
            return $q->findOrFail($id);
        }

        $key = 'locations:communes:show:' . $id . ':with=' . (empty($with) ? 'none' : implode(',', $with));
        return Cache::remember($key, now()->addDay(), function () use ($with, $id) {
            $q = Commune::query();
            if (!empty($with)) $q->with($with);
            return $q->findOrFail($id);
        });
    }
}
