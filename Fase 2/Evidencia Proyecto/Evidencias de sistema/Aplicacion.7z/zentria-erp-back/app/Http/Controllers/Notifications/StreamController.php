<?php

namespace App\Http\Controllers\Notifications;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\Notifications\UserNotification;

class StreamController extends BaseController
{
    public function stream(Request $request): StreamedResponse
    {
        // Try auth via middleware; if not present, accept access_token query param
        $user = Auth::user();
        if (!$user && $token = $request->query('access_token')) {
            try {
                $user = JWTAuth::setToken($token)->authenticate();
                Auth::setUser($user);
            } catch (\Throwable $e) {
                abort(401, 'Invalid token');
            }
        }

        if (!$user) {
            abort(401, 'Unauthorized');
        }

        $lastEventId = (int) ($request->headers->get('Last-Event-ID') ?? $request->query('lastEventId', 0));
        $history = max(0, (int) $request->query('history', 0));
        // Si NO piden historial y no viene lastEventId, comenzar desde el ÃƒÂºltimo para no enviar backlog
        if ($history === 0 && $lastEventId === 0) {
            $lastEventId = (int) (\App\Models\Notifications\UserNotification::where('user_id', $user->id)->max('id') ?? 0);
        }

        return response()->stream(function () use ($user, $lastEventId, $history) {
            @ini_set('output_buffering', 'off');
            @ini_set('zlib.output_compression', 0);
            @ini_set('implicit_flush', 1);
            ignore_user_abort(true);
            set_time_limit(0);

            $this->sseEcho("retry: 3000\n\n"); // 3s client retry

            $currentLastId = $lastEventId;
            $policy = app(\App\Services\Notifications\NotificationPolicyService::class);
            $msg = app(\App\Services\Notifications\NotificationMessageService::class);

            // Enviar historial inicial si se solicita (ÃƒÂºltimos N, en orden ascendente, incrementales)
            if ($history > 0) {
                $allowedTypeIds = $policy->allowedTypeIdsForUser($user);
                $histQuery = \App\Models\Notifications\UserNotification::with(['event.type'])
                    ->where('user_id', $user->id)
                    ->orderBy('id', 'desc');
                if (!empty($allowedTypeIds)) {
                    $histQuery->whereHas('event', fn($q) => $q->whereIn('type_id', $allowedTypeIds));
                }
                if ($lastEventId > 0) {
                    $histQuery->where('id', '>', $lastEventId);
                }
                $histItems = $histQuery->limit($history)->get()->reverse()->values();
                foreach ($histItems as $n) {
                    $ev = $n->event;
                    if (!$ev || !$ev->type) { continue; }
                    if (! $policy->userCanReceive($user, [
                        'company_id' => $ev->company_id,
                        'subsidiary_id' => $ev->subsidiary_id,
                        'branch_id' => $ev->branch_id,
                    ])) continue;
                    if (! $policy->isRoleEligibleForType($user, $ev->type)) continue;

                    $createdByName = $ev->payload['created_by'] ?? ($ev->payload['updated_by'] ?? 'Sistema');
                    $createdById = $ev->payload['created_by_id'] ?? ($ev->payload['updated_by_id'] ?? null);

                    $type = optional($n->event)->type;
                    $payload = [
                        'id' => $n->id,
                        'title' => $type?->description ?? $type?->display_name ?? ($type?->key ?? 'Notificación'),
                        'type_key' => $type?->key,
                        'type_label' => $type?->display_name,
                        'module' => $type?->module,
                        'module_label' => $type?->module_label,
                        'is_read' => ($n->status === 'read' || $n->read_at !== null),
                        'bucket' => optional(optional($ev)->type)->bucket ?? null,
                        'priority' => optional($n->event)->priority,
                        'created_at' => $n->created_at ? $n->created_at->toIso8601String() : null,
                        'aggregate_count' => $n->aggregate_count ?? 1,
                        'delivered_to_user' => (bool) $n->delivered_to_user,
                        'payload' => $ev->payload ?? [],
                        'message' => $msg->format($ev),
                        
                        
                        'created_by' => $createdByName,
                        'created_by_id' => $createdById,
                        'updated_by' => $ev->payload['updated_by'] ?? null,
                        'updated_by_id' => $ev->payload['updated_by_id'] ?? null,
                    ];

                    $this->sseEcho('id: '.$n->id."\n");
                    $this->sseEcho('event: notification' . "\n");
                    $this->sseEcho('data: '.json_encode($payload)."\n\n");
                    $currentLastId = max($currentLastId, (int) $n->id);
                }
                @ob_flush();
                @flush();
            }
            $start = time();
            while (!connection_aborted() && (time() - $start) < 60) { // ventana ~60s
                // lightweight heartbeat every loop
                $this->sseEcho(": ping\n\n");

                // Fetch new notifications for this user since last id
                $query = UserNotification::with(['event.type'])
                    ->where('user_id', $user->id)
                    ->orderBy('id', 'asc');
                if ($currentLastId > 0) {
                    $query->where('id', '>', $currentLastId);
                }

                $newOnes = $query->limit(50)->get();
                $policy = $policy ?? app(\App\Services\Notifications\NotificationPolicyService::class);
                $msg = $msg ?? app(\App\Services\Notifications\NotificationMessageService::class);
                foreach ($newOnes as $n) {
                    $ev = $n->event;
                    if (!$ev || !$ev->type) { continue; }
                    // Filtra por alcance y roles
                    if (! $policy->userCanReceive($user, [
                        'company_id' => $ev->company_id,
                        'subsidiary_id' => $ev->subsidiary_id,
                        'branch_id' => $ev->branch_id,
                    ])) continue;
                    if (! $policy->isRoleEligibleForType($user, $ev->type)) continue;

                    // Fallbacks para creador/actualizador si faltan en payload
                    $createdByName = $ev->payload['created_by'] ?? ($ev->payload['updated_by'] ?? 'Sistema');
                    $createdById = $ev->payload['created_by_id'] ?? ($ev->payload['updated_by_id'] ?? null);

                    $type = optional($n->event)->type;
                    $payload = [
                        'id' => $n->id,
                        'title' => $type?->description ?? $type?->display_name ?? ($type?->key ?? 'Notificación'),
                        'type_key' => $type?->key,
                        'type_label' => $type?->display_name,
                        'module' => $type?->module,
                        'module_label' => $type?->module_label,
                        'is_read' => ($n->status === 'read' || $n->read_at !== null),
                        'bucket' => optional(optional($ev)->type)->bucket ?? null,
                        'priority' => optional($n->event)->priority,
                        'created_at' => $n->created_at ? $n->created_at->toIso8601String() : null,
                        'aggregate_count' => $n->aggregate_count ?? 1,
                        'delivered_to_user' => (bool) $n->delivered_to_user,
                        'payload' => $ev->payload ?? [],
                        'message' => $msg->format($ev),
                        
                        
                        // atributos directos Ãºtiles en el front
                        'created_by' => $createdByName,
                        'created_by_id' => $createdById,
                        'updated_by' => $ev->payload['updated_by'] ?? null,
                        'updated_by_id' => $ev->payload['updated_by_id'] ?? null,
                    ];

                    $this->sseEcho('id: '.$n->id."\n");
                    $this->sseEcho('event: notification' . "\n");
                    $this->sseEcho('data: '.json_encode($payload)."\n\n");
                    $currentLastId = max($currentLastId, (int) $n->id);
                }

                @ob_flush();
                @flush();
                usleep(500000); // 0.5s
            }
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache',
            'Connection' => 'keep-alive',
            'X-Accel-Buffering' => 'no',
        ]);
    }

    private function sseEcho(string $data): void
    {
        echo $data;
    }
}

