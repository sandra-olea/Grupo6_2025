<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\Subsidiary;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class ReportsController extends Controller
{
    /**
     * GET /api/reports
     * Lista de reportes disponibles para el usuario.
     */
    public function index(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view-reports'), 403);
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $available = [
            [ 'key' => 'sales',     'name' => 'Ventas',    'formats' => ['pdf','xlsx'] ],
            [ 'key' => 'stock',     'name' => 'Stock',     'formats' => ['pdf','xlsx'] ],
            [ 'key' => 'users',     'name' => 'Usuarios',  'formats' => ['pdf','xlsx'] ],
            [ 'key' => 'movements', 'name' => 'Movimientos de Equipo', 'formats' => ['pdf','xlsx'] ],
        ];

        return response()->json(['data' => $available]);
    }

    /**
     * GET /api/reports/{type}
     * Devuelve resultados con filtros aplicados (CU034).
     */
    public function results(Request $request, Subsidiary $subsidiary, string $type)
    {
        abort_unless(Gate::allows('view-reports'), 403);
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $validated = $request->validate([
            'date_from' => ['nullable','date'],
            'date_to'   => ['nullable','date','after_or_equal:date_from'],
            'subsidiary_id' => ['nullable','integer'],
            'branch_id' => ['nullable','integer'],
            'customer_id' => ['nullable','integer'],
            'price_min' => ['nullable','numeric'],
            'price_max' => ['nullable','numeric'],
            'status'    => ['nullable','string'],
            'per_page'  => ['nullable','integer','min:1','max:200'],
            'q'         => ['nullable','string'],
            // When all=1, return the full dataset as before (no default status narrowing)
            'all'       => ['nullable','boolean'],
        ]);

        switch ($type) {
            case 'sales':
                $q = Sale::query()->with(['customer','subsidiary'])
                    ->where('subsidiary_id', $subsidiary->id);
                if (!empty($validated['customer_id'])) { $q->where('customer_id', (int)$validated['customer_id']); }
                // Default: show only paid, partially_paid, and refunded unless all=1 provided
                $includeAll = (bool)($validated['all'] ?? false);
                if (!empty($validated['status'])) {
                    $q->where('status', $validated['status']);
                } elseif (!$includeAll) {
                    $q->whereIn('status', ['paid','partially_paid','refunded']);
                }
                if (!empty($validated['date_from'])) { $q->whereDate('sale_date', '>=', $validated['date_from']); }
                if (!empty($validated['date_to'])) { $q->whereDate('sale_date', '<=', $validated['date_to']); }
                if (!empty($validated['price_min'])) { $q->where('total_amount', '>=', (float)$validated['price_min']); }
                if (!empty($validated['price_max'])) { $q->where('total_amount', '<=', (float)$validated['price_max']); }
                if (!empty($validated['q'])) {
                    $search = trim($validated['q']);
                    $q->where(function($w) use ($search) {
                        $w->where('sale_number', 'ILIKE', "%{$search}%")
                          ->orWhere('wc_order_number', 'ILIKE', "%{$search}%");
                    });
                }
                $q->orderByDesc('sale_date')->orderByDesc('id');
                $perPage = (int)($validated['per_page'] ?? 20);
                $page = $q->paginate($perPage)->appends($request->query());

                // Modo por defecto: simplificado; con raw=1|true|on|yes -> data completa (sin mapear)
                $rawParam = strtolower((string) $request->query('raw', '0'));
                $rawFull = in_array($rawParam, ['1', 'true', 'on', 'yes'], true);
                if (! $rawFull) {
                    $page->setCollection(
                        $page->getCollection()->map(function ($sale) {
                            return $this->mapSaleRowSimplified($sale);
                        })
                    );
                }

                Log::info('Reports results fetched', [ 'type' => $type, 'user_id' => $request->user('api')?->id, 'filters' => $validated ]);
                return response()->json($page);

            case 'stock':
                // Replicar lógica del export: agrupar hijos bajo su padre y sumar stock
                $rows = $this->buildStockAggregatedRows($subsidiary, $validated);
                // Paginación manual sobre arreglo agregado
                $perPage = (int)($validated['per_page'] ?? 20);
                $currentPage = (int)$request->integer('page', 1);
                $total = count($rows);
                $offset = max(0, ($currentPage - 1) * $perPage);
                $items = array_slice($rows, $offset, $perPage);
                $paginator = new \Illuminate\Pagination\LengthAwarePaginator($items, $total, $perPage, $currentPage, [
                    'path' => $request->url(),
                    'query' => $request->query(),
                ]);

                Log::info('Reports results fetched', [ 'type' => $type, 'user_id' => $request->user('api')?->id, 'filters' => $validated, 'aggregated' => true ]);
                return response()->json($paginator);

            case 'users':
                // Usuarios visibles en el alcance de la subsidiary
                $q = User::query()->with(['roles'])
                    ->where(function($w) use ($subsidiary) {
                        $w->whereExists(function($sq) use ($subsidiary) {
                            $sq->select(DB::raw(1))
                                ->from('branch_user as bu')
                                ->join('branches as b', 'b.id', '=', 'bu.branch_id')
                                ->whereColumn('bu.user_id', 'users.id')
                                ->where('b.subsidiary_id', $subsidiary->id);
                        })
                        ->orWhereExists(function($sq) use ($subsidiary) {
                            $sq->select(DB::raw(1))
                                ->from('scope_roles as sr')
                                ->whereColumn('sr.user_id', 'users.id')
                                ->where('sr.scope_type', 'subsidiary')
                                ->where('sr.scope_id', $subsidiary->id);
                        })
                        ->orWhereExists(function($sq) use ($subsidiary) {
                            $sq->select(DB::raw(1))
                                ->from('scope_roles as sr')
                                ->whereColumn('sr.user_id', 'users.id')
                                ->where('sr.scope_type', 'company')
                                ->where('sr.scope_id', $subsidiary->company_id);
                        });
                    });
                if (!empty($validated['q'])) {
                    $search = trim($validated['q']);
                    $q->where(function($w) use ($search) {
                        $w->where('first_name', 'ILIKE', "%{$search}%")
                          ->orWhere('last_name', 'ILIKE', "%{$search}%")
                          ->orWhere('email', 'ILIKE', "%{$search}%")
                          ->orWhereRaw("concat_ws(' ', first_name, middle_name, last_name, second_last_name) ILIKE ?", ["%{$search}%"]);
                    });
                }
                $q->orderBy('first_name')->orderBy('last_name')->orderBy('email');
                $perPage = (int)($validated['per_page'] ?? 20);
                $page = $q->paginate($perPage)->appends($request->query());
                Log::info('Reports results fetched', [ 'type' => $type, 'user_id' => $request->user('api')?->id, 'filters' => $validated ]);
                return response()->json($page);

            case 'movements':
                // Movimientos de equipos desde equipment_movements
                $q = DB::table('equipment_movements as m')
                    ->join('equipment_traceability as t', 't.id', '=', 'm.traceability_id')
                    ->join('technical_review_items as i', 'i.id', '=', 't.review_item_id')
                    ->leftJoin('branches as b', 'b.id', '=', 'i.branch_id')
                    ->selectRaw('m.id, m.movement_type, 1 as quantity, m.metadata, m.created_at, i.serial_number, i.equipment_type, b.id as branch_id, b.subsidiary_id');
                $q->where('b.subsidiary_id', $subsidiary->id);
                if (!empty($validated['branch_id'])) { $q->where('b.id', (int)$validated['branch_id']); }
                if (!empty($validated['date_from'])) { $q->whereDate('m.created_at', '>=', $validated['date_from']); }
                if (!empty($validated['date_to'])) { $q->whereDate('m.created_at', '<=', $validated['date_to']); }
                if (!empty($validated['q'])) {
                    $search = trim($validated['q']);
                    $q->where(function($w) use ($search) {
                        $w->where('i.serial_number', 'ILIKE', "%{$search}%");
                    });
                }
                $q->orderByDesc('m.created_at');
                $perPage = (int)($validated['per_page'] ?? 20);
                $page = $q->paginate($perPage)->appends($request->query());
                Log::info('Reports results fetched', [ 'type' => $type, 'user_id' => $request->user('api')?->id, 'filters' => $validated ]);
                return response()->json($page);

            default:
                return response()->json(['message' => 'Reporte no soportado'], 400);
        }
    }

    /**
     * GET /api/reports/{type}/export?format=pdf|xlsx
     * Exporta el reporte en el formato solicitado (CU033).
     */
    public function export(Request $request, Subsidiary $subsidiary, string $type)
    {
        abort_unless(Gate::allows('export-reports'), 403);
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $format = strtolower((string) $request->query('format', 'pdf'));
        if (!in_array($format, ['pdf','xlsx'], true)) {
            return response()->json(['message' => 'Formato no soportado'], 422);
        }

        // Validar filtros y construir dataset por subsidiary
        $validated = $request->validate([
            'date_from' => ['nullable','date'],
            'date_to'   => ['nullable','date','after_or_equal:date_from'],
            'branch_id' => ['nullable','integer'],
            'customer_id' => ['nullable','integer'],
            'price_min' => ['nullable','numeric'],
            'price_max' => ['nullable','numeric'],
            'status'    => ['nullable','string'],
            'q'         => ['nullable','string'],
        ]);

        $rows = [];
        if ($type === 'stock') {
            // Construir filas agregadas por producto (agrupa hijos en el padre)
            $rows = $this->buildStockAggregatedRows($subsidiary, $validated);
        } else {
            $q = $this->buildBaseQuery($subsidiary, $type, $validated);
            if ($q === null) {
                return response()->json(['message' => 'Reporte no soportado'], 400);
            }
            $rowsRaw = $q->limit(10000)->get();
            $rows = json_decode(json_encode($rowsRaw), true) ?: [];
        }

        // Nombre legible del reporte (ES) y slug para archivos
        $reportDisplay = $this->reportDisplayName($type);
        $reportSlug = $this->reportFileSlug($type);

        if ($format === 'xlsx') {
            // Excel con PhpSpreadsheet
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            // Título + Empresa
            $sheet->setCellValue('A1', 'Reporte: '.$reportDisplay.' - '.now()->format('d/m/Y H:i'));
            $sheet->setCellValue('A2', 'Empresa: '.($subsidiary->subsidiary_name ?? ''));
            // Encabezados dinámicos según reporte
            [$headers, $mapped] = $this->mapRowsForType($type, $rows);
            // Escribir encabezados (desde fila 4)
            $col = 1; foreach ($headers as $h) { $sheet->setCellValue($this->excelCol($col++) . '4', $h); }
            // Escribir filas (desde fila 5)
            $r = 5;
            foreach ($mapped as $row) {
                $c = 1; foreach ($row as $cell) { $sheet->setCellValue($this->excelCol($c++) . $r, $cell); }
                $r++;
            }
            $fileName = sprintf('reporte-%s-%s.xlsx', $reportSlug, now()->format('Ymd_His'));
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            ob_start();
            $writer->save('php://output');
            $content = ob_get_clean();

            Log::info('Report exported', [ 'type' => $type, 'format' => 'xlsx', 'user_id' => $request->user('api')?->id, 'filters' => $request->query(), 'subsidiary_id' => $subsidiary->id ]);
            return Response::make($content, 200, [
                'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'Content-Disposition' => 'attachment; filename="'.$fileName.'"',
            ]);
        }

        // PDF con mPDF
        $html = $this->renderHtmlTable($type, $rows);
        $mpdf = new \Mpdf\Mpdf(['tempDir' => storage_path('app/tmp')]);
        $mpdf->WriteHTML('<h2>Reporte: '.htmlspecialchars($reportDisplay).' - '.now()->format('d/m/Y H:i').'</h2>');
        $mpdf->WriteHTML('<div style="margin:6px 0 14px 0; font-size: 12px;">Empresa: '.htmlspecialchars((string)($subsidiary->subsidiary_name ?? '')).'.</div>');
        $mpdf->WriteHTML($html);
        $fileName = sprintf('reporte-%s-%s.pdf', $reportSlug, now()->format('Ymd_His'));

        Log::info('Report exported', [ 'type' => $type, 'format' => 'pdf', 'user_id' => $request->user('api')?->id, 'filters' => $request->query(), 'subsidiary_id' => $subsidiary->id ]);
        return Response::make($mpdf->Output($fileName, 'S'), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="'.$fileName.'"',
        ]);
    }

    private function buildBaseQuery(Subsidiary $subsidiary, string $type, array $validated)
    {
        switch ($type) {
            case 'sales':
                $q = Sale::query()->with(['customer','subsidiary'])
                    ->where('subsidiary_id', $subsidiary->id);
                if (!empty($validated['customer_id'])) { $q->where('customer_id', (int)$validated['customer_id']); }
                if (!empty($validated['status'])) { $q->where('status', $validated['status']); }
                if (!empty($validated['date_from'])) { $q->whereDate('sale_date', '>=', $validated['date_from']); }
                if (!empty($validated['date_to'])) { $q->whereDate('sale_date', '<=', $validated['date_to']); }
                if (!empty($validated['price_min'])) { $q->where('total_amount', '>=', (float)$validated['price_min']); }
                if (!empty($validated['price_max'])) { $q->where('total_amount', '<=', (float)$validated['price_max']); }
                if (!empty($validated['q'])) {
                    $search = trim($validated['q']);
                    $q->where(function($w) use ($search) {
                        $w->where('sale_number', 'ILIKE', "%{$search}%")
                          ->orWhere('wc_order_number', 'ILIKE', "%{$search}%");
                    });
                }
                $q->orderByDesc('sale_date')->orderByDesc('id');
                return $q;
            case 'stock':
                // Para resultados (no export), mantenemos dataset base por ahora.
                $q = DB::table('products as p')
                    ->join('branches as b', 'b.id', '=', 'p.branch_id')
                    ->selectRaw('p.id as product_id, p.sku, p.name as product_name, p.updated_at')
                    ->where('b.subsidiary_id', $subsidiary->id);
                if (!empty($validated['branch_id'])) { $q->where('b.id', (int)$validated['branch_id']); }
                if (!empty($validated['q'])) {
                    $search = trim($validated['q']);
                    $q->where(function($w) use ($search) {
                        $w->where('p.sku', 'ILIKE', "%{$search}%")
                          ->orWhere('p.name', 'ILIKE', "%{$search}%");
                    });
                }
                $q->orderBy('p.name');
                return $q;
            case 'users':
                $q = User::query()->with(['roles'])
                    ->where(function($w) use ($subsidiary) {
                        $w->whereExists(function($sq) use ($subsidiary) {
                            $sq->select(DB::raw(1))
                                ->from('branch_user as bu')
                                ->join('branches as b', 'b.id', '=', 'bu.branch_id')
                                ->whereColumn('bu.user_id', 'users.id')
                                ->where('b.subsidiary_id', $subsidiary->id);
                        })
                        ->orWhereExists(function($sq) use ($subsidiary) {
                            $sq->select(DB::raw(1))
                                ->from('scope_roles as sr')
                                ->whereColumn('sr.user_id', 'users.id')
                                ->where('sr.scope_type', 'subsidiary')
                                ->where('sr.scope_id', $subsidiary->id);
                        })
                        ->orWhereExists(function($sq) use ($subsidiary) {
                            $sq->select(DB::raw(1))
                                ->from('scope_roles as sr')
                                ->whereColumn('sr.user_id', 'users.id')
                                ->where('sr.scope_type', 'company')
                                ->where('sr.scope_id', $subsidiary->company_id);
                        });
                    });
                if (!empty($validated['q'])) {
                    $search = trim($validated['q']);
                    $q->where(function($w) use ($search) {
                        $w->where('first_name', 'ILIKE', "%{$search}%")
                          ->orWhere('last_name', 'ILIKE', "%{$search}%")
                          ->orWhere('email', 'ILIKE', "%{$search}%")
                          ->orWhereRaw("concat_ws(' ', first_name, middle_name, last_name, second_last_name) ILIKE ?", ["%{$search}%"]);
                    });
                }
                $q->orderBy('first_name')->orderBy('last_name')->orderBy('email');
                return $q;
            case 'movements':
                $q = DB::table('equipment_movements as m')
                    ->join('equipment_traceability as t', 't.id', '=', 'm.traceability_id')
                    ->join('technical_review_items as i', 'i.id', '=', 't.review_item_id')
                    ->leftJoin('branches as b', 'b.id', '=', 'i.branch_id')
                    ->selectRaw('m.id, m.movement_type, 1 as quantity, m.metadata, m.created_at, i.serial_number, i.equipment_type, b.id as branch_id, b.subsidiary_id')
                    ->where('b.subsidiary_id', $subsidiary->id);
                if (!empty($validated['date_from'])) { $q->whereDate('m.created_at', '>=', $validated['date_from']); }
                if (!empty($validated['date_to'])) { $q->whereDate('m.created_at', '<=', $validated['date_to']); }
                if (!empty($validated['q'])) {
                    $search = trim($validated['q']);
                    $q->where(function($w) use ($search) {
                        $w->where('i.serial_number', 'ILIKE', "%{$search}%");
                    });
                }
                $q->orderByDesc('m.created_at');
                return $q;
            default:
                return null;
        }
    }

    private function mapRowsForType(string $type, array $rows): array
    {
        switch ($type) {
            case 'sales':
                $headers = ['ID','N° VENTA','FECHA','CLIENTE','SUBTOTAL','IVA','TOTAL','ESTADO'];
                $mapped = array_map(function($r) {
                    $fecha = $this->formatDate($r['sale_date'] ?? null, false);
                    $cliente = $this->formatCustomerName($r);
                    $rate = isset($r['tax_rate']) ? (float)$r['tax_rate'] : 0.19;
                    $total = isset($r['total_amount']) ? (float)$r['total_amount'] : 0.0;
                    $subtotalField = isset($r['subtotal']) ? (float)$r['subtotal'] : null;
                    $ivaField = isset($r['tax_amount']) ? (float)$r['tax_amount'] : null;
                    if ($total > 0) {
                        $subtotal = round($total / (1.0 + $rate));
                        $iva = round($total - $subtotal);
                    } else {
                        $subtotal = round((float)($subtotalField ?? 0));
                        $iva = round((float)($ivaField ?? 0));
                        $total = round($subtotal + $iva);
                    }
                    $estado = $this->translateStatus('sales', (string)($r['status'] ?? ''));
                    return [
                        $r['id'] ?? null,
                        $r['sale_number'] ?? ($r['wc_order_number'] ?? ''),
                        $fecha,
                        $cliente,
                        $this->formatMoneyCLP($subtotal),
                        $this->formatMoneyCLP($iva),
                        $this->formatMoneyCLP($total),
                        $estado,
                    ];
                }, $rows);
                return [$headers, $mapped];
            case 'stock':
                // Para export: agregamos por producto (hijos -> padre). Mostrar sucursal.
                $headers = ['SKU','Producto','Sucursal','Cantidad','Actualizado'];
                $mapped = array_map(function($r) {
                    // Solo fecha (sin hora)
                    $updated = $this->formatDate($r['updated_at'] ?? null, false);
                    return [
                        $r['sku'] ?? '',
                        $r['product_name'] ?? '',
                        $r['branch_name'] ?? '',
                        $r['quantity'] ?? 0,
                        $updated,
                    ];
                }, $rows);
                return [$headers, $mapped];
            case 'users':
                $headers = ['ID','Nombre','Email','Roles'];
                $mapped = array_map(function($r) {
                    $roles = collect($r['roles'] ?? [])->pluck('name')->join(', ');
                    $fullName = trim(implode(' ', array_filter([
                        $r['first_name'] ?? null,
                        $r['middle_name'] ?? null,
                        $r['last_name'] ?? null,
                        $r['second_last_name'] ?? null,
                    ])));
                    return [ $r['id'] ?? null, $fullName, $r['email'] ?? '', $roles ];
                }, $rows);
                return [$headers, $mapped];
            case 'movements':
                $headers = ['ID','Tipo','Serie','Cantidad','Fecha'];
                $mapped = array_map(function($r) {
                    $fecha = $this->formatDate($r['created_at'] ?? null, true);
                    $tipo = $this->translateStatus('movement', (string)($r['movement_type'] ?? ''));
                    return [
                        $r['id'] ?? null,
                        $tipo,
                        $r['serial_number'] ?? '',
                        $r['quantity'] ?? 0,
                        $fecha,
                    ];
                }, $rows);
                return [$headers, $mapped];
            default:
                return [['Col1'], []];
        }
    }

    /**
     * Mapea una venta al formato simplificado (crudo) para resultados JSON.
     * - Montos como enteros (CLP) sin formato
     * - Estado original (sin traducción)
     * - Fecha ISO simple (YYYY-MM-DD)
     */
    private function mapSaleRowSimplified($sale): array
    {
        // Acepta modelo Eloquent o array
        $row = is_array($sale) ? $sale : $sale->toArray();

        $rate = isset($row['tax_rate']) ? (float)$row['tax_rate'] : 0.19;
        $total = isset($row['total_amount']) ? (float)$row['total_amount'] : (float)($row['subtotal'] ?? 0) + (float)($row['tax_amount'] ?? 0);
        if ($total > 0) {
            $subtotal = (int) round($total / (1.0 + (float)$rate));
            $iva = (int) round($total - $subtotal);
            $totalInt = (int) round($total);
        } else {
            $subtotal = (int) round((float)($row['subtotal'] ?? 0));
            $iva = (int) round((float)($row['tax_amount'] ?? 0));
            $totalInt = (int) round($subtotal + $iva);
        }

        $saleNumber = $row['sale_number'] ?? ($row['wc_order_number'] ?? null);
        $customer = $this->formatCustomerName($row);
        $dateIso = '';
        try {
            $dateIso = !empty($row['sale_date']) ? Carbon::parse((string)$row['sale_date'])->format('Y-m-d') : '';
        } catch (\Throwable $e) {
            $dateIso = (string)($row['sale_date'] ?? '');
        }

        return [
            'id'          => $row['id'] ?? null,
            'sale_number' => $saleNumber,
            'date'        => $dateIso,
            'customer'    => $customer,
            'subtotal'    => $subtotal,
            'iva'         => $iva,
            'total'       => $totalInt,
            'status'      => (string)($row['status'] ?? ''),
        ];
    }

    private function renderHtmlTable(string $type, array $rows): string
    {
        [$headers, $mapped] = $this->mapRowsForType($type, $rows);
        $thead = '<tr>'.implode('', array_map(fn($h) => '<th style="text-align:left;padding:6px;border-bottom:1px solid #ccc;">'.htmlspecialchars($h).'</th>', $headers)).'</tr>';
        $tbody = '';
        foreach ($mapped as $row) {
            $tbody .= '<tr>'.implode('', array_map(fn($c) => '<td style="padding:4px 6px;">'.htmlspecialchars((string)$c).'</td>', $row)).'</tr>';
        }
        return '<table width="100%" cellspacing="0" cellpadding="0">'.'<thead>'.$thead.'</thead>'.'<tbody>'.$tbody.'</tbody>'.'</table>';
    }

    /**
     * Construye filas agregadas de stock por producto (hijos sumados en padre).
     */
    private function buildStockAggregatedRows(Subsidiary $subsidiary, array $validated): array
    {
        // Cargar productos de la subsidiaria, con relaciones necesarias
        $query = \App\Models\Product::query()
            ->select('products.*')
            ->join('branches as b', 'b.id', '=', 'products.branch_id')
            ->where('b.subsidiary_id', $subsidiary->id)
            ->with(['children', 'parent', 'branch']);

        if (!empty($validated['branch_id'])) {
            $query->where('products.branch_id', (int)$validated['branch_id']);
        }
        if (!empty($validated['q'])) {
            $search = trim($validated['q']);
            $query->where(function($w) use ($search) {
                $w->where('products.sku', 'ILIKE', "%{$search}%")
                  ->orWhere('products.name', 'ILIKE', "%{$search}%");
            });
        }

        $all = $query->get();
        // Índice rápido por id
        $byId = $all->keyBy('id');
        // Filtrar a padres dentro del conjunto actual
        $parents = $all->filter(fn($p) => !$p->parent_product_id);
        $rows = [];

        foreach ($parents as $parent) {
            $children = $parent->children ?? collect();
            if ($children->isNotEmpty()) {
                $qty = 0;
                $updated = $parent->updated_at;
                foreach ($children as $child) {
                    $qty += (int) $child->stock; // usa accessor para serial/no-serial
                    if ($child->updated_at && (!$updated || $child->updated_at->gt($updated))) {
                        $updated = $child->updated_at;
                    }
                }
                $rows[] = [
                    'sku' => $parent->sku,
                    'product_name' => $parent->name,
                    'branch_name' => $parent->branch?->branch_name,
                    'quantity' => $qty,
                    'updated_at' => $updated,
                ];
            } else {
                $rows[] = [
                    'sku' => $parent->sku,
                    'product_name' => $parent->name,
                    'branch_name' => $parent->branch?->branch_name,
                    'quantity' => (int) $parent->stock,
                    'updated_at' => $parent->updated_at,
                ];
            }
        }

        // Ordenar por nombre de producto
        usort($rows, function($a, $b) {
            return strcasecmp((string)($a['product_name'] ?? ''), (string)($b['product_name'] ?? ''));
        });
        return $rows;
    }

    private function formatDate($value, bool $withTime): string
    {
        if (empty($value)) return '';
        try {
            $dt = $value instanceof \DateTimeInterface ? Carbon::instance($value) : Carbon::parse((string)$value);
            return $withTime ? $dt->format('d/m/Y H:i') : $dt->format('d/m/Y');
        } catch (\Throwable $e) {
            return (string) $value; // fallback
        }
    }

    private function formatCustomerName(array $row): string
    {
        $c = $row['customer'] ?? [];
        $snap = $row['billing_snapshot'] ?? [];
        $company = trim((string)($c['billing_company'] ?? ''));
        if ($company !== '') return $company;
        $contact = trim((string)($c['contact_name'] ?? ''));
        if ($contact !== '') return $contact;
        $first = trim((string)($snap['first_name'] ?? ''));
        $last  = trim((string)($snap['last_name'] ?? ''));
        $full  = trim($first.' '.$last);
        if ($full !== '') return $full;
        $email = trim((string)($c['email'] ?? ($snap['email'] ?? '')));
        return $email !== '' ? $email : 'N/A';
    }

    private function formatMoneyCLP(float $value): string
    {
        // CLP sin decimales, separador de miles con punto
        return '$'.number_format((float)round($value), 0, ',', '.');
    }

    private function excelCol(int $col): string
    {
        // 1 -> A, 26 -> Z, 27 -> AA, etc.
        $s = '';
        while ($col > 0) {
            $m = ($col - 1) % 26;
            $s = chr(65 + $m) . $s;
            $col = intdiv($col - 1, 26);
        }
        return $s;
    }

    private function translateStatus(string $context, string $value): string
    {
        $value = strtolower(trim($value));
        // Normalizar prefijos/separadores comunes (WooCommerce: wc-*)
        if (str_starts_with($value, 'wc-')) {
            $value = substr($value, 3);
        }
        if (str_starts_with($value, 'order-')) {
            $value = substr($value, 6);
        }
        $value = str_replace(['_', '  '], ['-', ' '], $value);
        $value = str_replace(' ', '-', $value);
        $maps = [
            'sales' => [
                'draft' => 'Borrador',
                'pending' => 'Pendiente',
                'pending-payment' => 'Pago Pendiente',
                'processing' => 'En Proceso',
                'on-hold' => 'En Espera',
                'completed' => 'Completada',
                'cancelled' => 'Cancelada',
                'canceled' => 'Cancelada',
                'refunded' => 'Reembolsada',
                'partially-refunded' => 'Parcialmente Reembolsada',
                'confirmed' => 'Confirmada',
                'paid' => 'Pagada',
                'partially-paid' => 'Parcialmente Pagada',
                'failed' => 'Fallida',
                'sent' => 'Enviado',
                'approved' => 'Aprobado',
                'converted' => 'Convertido',
                'rejected' => 'Rechazado',
                'expired' => 'Expirado',
            ],
            'movement' => [
                'entry' => 'Entrada',
                'status_change' => 'Cambio de Estado',
                'warehouse_transfer' => 'Transferencia de Bodega',
                'sale' => 'Venta',
                'return' => 'Devolución',
            ],
        ];
        $map = $maps[$context] ?? [];
        if (isset($map[$value])) { return $map[$value]; }
        // Capitalizar por defecto en español (primera mayúscula)
        return $value !== '' ? mb_convert_case($value, MB_CASE_TITLE, 'UTF-8') : '';
    }

    private function reportDisplayName(string $type): string
    {
        return match ($type) {
            'sales' => 'Ventas',
            'stock' => 'Stock',
            'users' => 'Usuarios',
            'movements' => 'Movimientos de Equipo',
            default => ucfirst($type),
        };
    }

    private function reportFileSlug(string $type): string
    {
        return match ($type) {
            'sales' => 'ventas',
            'stock' => 'stock',
            'users' => 'usuarios',
            'movements' => 'movimientos',
            default => strtolower(preg_replace('/[^a-z0-9]+/i', '-', $type)),
        };
    }
}
