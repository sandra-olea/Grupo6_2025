<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Concerns\TogglesActiveFlag;
use App\Http\Requests\Product\StoreProductRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Http\Resources\ProductResource;
use App\Models\Branch;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Traits\DispatchesNotifications;

class BranchProductsController extends Controller
{
    use TogglesActiveFlag;
    use DispatchesNotifications;

    public function index(Request $request, Branch $branch)
    {
        $this->authorize('viewAny', [Product::class, $branch]);

        $q = Product::query()->fromBranch($branch->id)->with(['brand','categories','children','parent']);

        // Por defecto, mostrar solo productos padre (no variantes por grado)
        $includeChildren = filter_var($request->get('include_children'), FILTER_VALIDATE_BOOL);
        $onlyChildren = filter_var($request->get('only_children'), FILTER_VALIDATE_BOOL);
        if ($onlyChildren) {
            $q->whereNotNull('parent_product_id');
        } elseif (!$includeChildren) {
            $q->whereNull('parent_product_id');
        }

        // Texto
        if ($s = $request->get('q')) $q->search($s);
        // Filtros básicos
        if ($brandId = $request->integer('brand_id')) $q->where('brand_id', $brandId);
        if (!is_null($request->get('is_active'))) $q->where('is_active', filter_var($request->get('is_active'), FILTER_VALIDATE_BOOL));
        if ($type = $request->get('product_type')) $q->where('product_type', $type);
        if (!is_null($request->get('serial_tracking'))) $q->where('serial_tracking', filter_var($request->get('serial_tracking'), FILTER_VALIDATE_BOOL));
        if ($min = $request->get('min_price')) $q->where('price', '>=', (float)$min);
        if ($max = $request->get('max_price')) $q->where('price', '<=', (float)$max);
        if ($cat = $request->integer('category_id')) $q->whereHas('categories', fn($w)=>$w->where('categories.id',$cat));
        // Filtros por atributos JSONB: attr[color]=black → WHERE attributes_json->>'color' = 'black'
        // filtros por atributos exactos (ya tenías)
        if (is_array($request->get('attr'))) {
            foreach ($request->get('attr') as $k => $v) {
                $q->whereRaw('(attributes_json::jsonb)->> ? = ?', [$k, (string)$v]);
            }
        }

        // parciales por clave
        if (is_array($request->get('attr_like'))) {
            foreach ($request->get('attr_like') as $path => $val) {
                $q->whereRaw(
                    '(attributes_json::jsonb #>> string_to_array(?, \'.\')) ILIKE ?',
                    [$path, '%'.$val.'%']
                );
            }
        }

        // parcial en cualquier valor del JSON (elige una de las dos variantes):
        if ($term = $request->get('attr_any_like')) {
            // Variante A (simple, con trigram index opcional)
            $q->whereRaw('(attributes_json::text) ILIKE ?', ['%'.$term.'%']);
        }

        $q->orderBy($request->get('order_by','name'), $request->get('order_dir','asc'));

        return ProductResource::collection(
            $q->paginate($request->integer('per_page', 15))->appends($request->query())
        );
    }

    public function store(StoreProductRequest $request, Branch $branch)
    {
        $data = $request->validated();
        $data['branch_id'] = $branch->id;
        $product = Product::create($data);

        // ⬇️ asigna categorías si vinieron
        if (!empty($data['category_ids'])) {
            $ids = collect($data['category_ids'])
                ->mapWithKeys(fn($id) => [$id => ['assigned_at' => now()]])
                ->all();

            $product->categories()->sync($ids);
        }

        // Notificación: product.created (scope sucursal)
        $this->dispatchNotification(
            typeKey: 'product.created',
            entityType: 'product',
            entityId: $product->id,
            scope: $this->branchScope($branch),
            payload: array_merge(
                [
                    'product_name' => $product->name,
                    'sku' => $product->sku,
                    'branch_name' => $branch->branch_name,
                    'serial_tracking' => (bool) $product->serial_tracking,
                    'is_parent' => $product->parent_product_id === null,
                ],
                $this->currentUserPayload('created_by')
            )
        );

        return ProductResource::make($product->load(['brand','categories','children','parent']));
    }

    public function show(Branch $branch, Product $product)
    {
        $this->authorize('view', $product);
        if ($product->branch_id !== $branch->id) abort(404);
        // Incluir 'parent' para que en hijos se exponga el padre heredado en el detalle
        return ProductResource::make($product->load(['brand','categories','parent']));
    }

    public function update(UpdateProductRequest $request, Branch $branch, Product $product)
    {
        $this->authorize('update', $product);
        if ($product->branch_id !== $branch->id) abort(404);

        $product->update($request->validated());

        // ⬇️ si enviaron category_ids, sincroniza
        if ($request->has('category_ids')) {
            $ids = collect($request->input('category_ids', []))
                ->mapWithKeys(fn($id) => [$id => ['assigned_at' => now()]])
                ->all();

            $product->categories()->sync($ids);
        }

        // Notificación: product.updated (scope sucursal)
        $this->dispatchNotification(
            typeKey: 'product.updated',
            entityType: 'product',
            entityId: $product->id,
            scope: $this->branchScope($branch),
            payload: array_merge(
                [
                    'product_name' => $product->name,
                    'sku' => $product->sku,
                    'branch_name' => $branch->branch_name,
                ],
                $this->currentUserPayload('updated_by')
            )
        );

        return ProductResource::make($product->load(['brand','categories']));
    }

    public function destroy(Branch $branch, Product $product)
    {
        $this->authorize('delete', $product);
        if ($product->branch_id !== $branch->id) abort(404);

        // Notificación: product.deleted (antes de eliminar)
        $this->dispatchNotification(
            typeKey: 'product.deleted',
            entityType: 'product',
            entityId: $product->id,
            scope: $this->branchScope($branch),
            payload: array_merge(
                [
                    'product_name' => $product->name,
                    'sku' => $product->sku,
                ],
                $this->currentUserPayload('updated_by')
            )
        );

        $product->delete();
        return response()->json(['deleted'=>true]);
    }

    public function toggleStatus(Branch $branch, Product $product)
    {
        return $this->toggleModelActive($product, 'Producto');
    }

    /**
     * Remove WooCommerce synchronization from a product.
     * Deletes the marketplace_external_ids.woocommerce data.
     * Only accessible to super_admin.
     */
    public function removeWooCommerceSync(Branch $branch, Product $product)
    {
        $this->authorize('update', $product);
        
        // Verify user has the specific permission
        if (!Auth::user()->hasPermissionTo('products.remove-marketplace-sync')) {
            abort(403, 'Unauthorized to remove marketplace synchronization');
        }

        if ($product->branch_id !== $branch->id) {
            abort(404);
        }

        $meta = $product->marketplace_external_ids ?? [];
        
        if (!isset($meta['woocommerce'])) {
            return response()->json([
                'message' => 'Product does not have WooCommerce synchronization',
            ], 404);
        }

        // Remove WooCommerce sync data
        unset($meta['woocommerce']);
        $product->marketplace_external_ids = empty($meta) ? null : $meta;
        $product->save();

        return response()->json([
            'message' => 'WooCommerce synchronization removed successfully',
            'product' => new ProductResource($product->fresh(['brand', 'categories'])),
        ]);
    }

    /**
     * GET /api/branches/{branch}/products/saleables
     * Lista productos válidos para venta de una sucursal específica (precio > 0 y stock > 0)
     */
    public function saleables(Request $request, Branch $branch)
    {
        $this->authorize('view', $branch);

        $perPage = max(1, min(200, (int) $request->query('per_page', 20)));
        $search = trim((string) $request->query('q', ''));

        $query = Product::query()
            ->select(['id','branch_id','sku','name','offer_price','price','serial_tracking','parent_product_id','stock'])
            ->where('branch_id', $branch->id)
            ->whereRaw('COALESCE(offer_price, price) > 0');

        // Opcional: filtrar solo activos (comentado para debug)
        // $query->where('is_active', true);

        if ($search !== '') {
            $query->where(function($w) use ($search) {
                $w->where('sku', 'ILIKE', "%{$search}%")
                  ->orWhere('name', 'ILIKE', "%{$search}%");
            });
        }

        $items = [];
        $totalChecked = 0;
        $withStock = 0;
        $withPrice = 0;
        
        $query->orderBy('id')->chunk(500, function ($chunk) use (&$items, &$totalChecked, &$withStock, &$withPrice) {
            foreach ($chunk as $p) {
                $totalChecked++;
                
                // Calcular stock usando el accessor del modelo
                $stock = (int) $p->stock;
                if ($stock > 0) {
                    $withStock++;
                }
                
                $gross = (float) ($p->offer_price ?: $p->price ?: 0);
                if ($gross > 0) {
                    $withPrice++;
                }
                
                // Solo incluir si tiene stock Y precio
                if ($stock <= 0 || $gross <= 0) {
                    continue;
                }
                
                // Calcular precio neto: precio bruto / 1.19 (quitar IVA)
                $net = round($gross / 1.19, 2);
                $items[] = [
                    'id' => $p->id,
                    'sku' => $p->sku,
                    'name' => $p->name,
                    'stock' => $stock,
                    'unit_price_gross' => $gross,
                    'unit_price_net' => $net,
                ];
            }
        });

        // Log para debug
        \Illuminate\Support\Facades\Log::info('Branch saleables', [
            'branch_id' => $branch->id,
            'total_checked' => $totalChecked,
            'with_stock' => $withStock,
            'with_price' => $withPrice,
            'final_items' => count($items),
            'search' => $search,
        ]);

        // Paginar manualmente sobre la colección filtrada
        $total = count($items);
        $page = max(1, (int) $request->query('page', 1));
        $offset = ($page - 1) * $perPage;
        $slice = array_slice($items, $offset, $perPage);
        
        $paginator = new \Illuminate\Pagination\LengthAwarePaginator($slice, $total, $perPage, $page, [
            'path' => $request->url(),
            'query' => $request->query(),
        ]);

        return response()->json($paginator);
    }
}
