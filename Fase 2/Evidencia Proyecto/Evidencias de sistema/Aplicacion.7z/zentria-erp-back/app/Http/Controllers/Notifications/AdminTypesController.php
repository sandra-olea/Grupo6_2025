<?php

namespace App\Http\Controllers\Notifications;

use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Notifications\NotificationType;

class AdminTypesController extends BaseController
{
    /**
     * PATCH /api/admin/notification-types/{id}/bucket
     * Body: { bucket: "Important"|"Archived"|"Pending" }
     */
    public function updateBucket(string $id, Request $request)
    {
        // Autenticación ya es exigida por middleware auth:api en la ruta

        $data = $request->validate([
            'bucket' => ['required','string','in:Important,Archived,Pending'],
        ]);

        $type = NotificationType::findOrFail($id);
        $type->bucket = $data['bucket'];
        $type->save();

        return response()->json([
            'id' => $type->id,
            'key' => $type->key,
            'module' => $type->module,
            'module_label' => $type->module_label,
            'bucket' => $type->bucket,
        ]);
    }
}
