<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Branch;
use App\Http\Resources\BranchResource;
use Illuminate\Support\Facades\Auth;
use App\Traits\DispatchesNotifications;

class BranchController extends Controller
{
    use DispatchesNotifications;
    public function index(Request $request)
    {
        $this->authorize('viewAny', Branch::class);

        $query = Branch::visibleTo(Auth::user());

        // Filtros opcionales
        if ($request->filled('subsidiary_id')) {
            $query->where('subsidiary_id', (int) $request->query('subsidiary_id'));
        }

        // Eager loading opcional: ?with=commune,subsidiary,manager
        $with = array_filter(explode(',', (string) $request->query('with')));
        if (!empty($with)) {
            $query->with($with);
        }

        return BranchResource::collection($query->get());
    }

    public function show($id)
    {
        $branch = Branch::with(['commune', 'manager'])->findOrFail($id);
        $this->authorize('view', $branch);

        return new BranchResource($branch);
    }

    /* Se agrega para dar solución a error al hacer un post a branch, en caso de no necesitarse se elimina método + endpoint */
    public function store(Request $request)
    {
        $this->authorize('create', Branch::class);

        $validated = $request->validate([
            'subsidiary_id' => 'required|exists:subsidiaries,id',
            'branch_name' => 'required|string|max:255',
            'branch_address' => 'nullable|string|max:500',
            'commune_id' => 'nullable|integer|exists:communes,id',
            'branch_phone' => 'nullable|string|max:50',
            'branch_email' => 'nullable|email|max:255',
            'branch_status' => 'nullable|string|max:50',
            'manager_id' => 'nullable|integer|exists:users,id',
            'branch_opening_hours' => 'nullable|string|max:255',
            'branch_location' => 'nullable|string|max:255',
        ]);

        $branch = Branch::create($validated);
        $branch->load(['commune', 'manager']);

        // Disparar evento de notificación: branch.created
        $this->dispatchNotification(
            typeKey: 'branch.created',
            entityType: 'branch',
            entityId: $branch->id,
            scope: $this->branchScope($branch),
            payload: array_merge(
                ['branch_name' => $branch->branch_name],
                $this->currentUserPayload('created_by')
            )
        );

        return (new BranchResource($branch))
            ->response()
            ->setStatusCode(201);
    }

    public function update(Request $request, $id)
    {
        $branch = Branch::findOrFail($id);
        $this->authorize('update', $branch);

        $validated = $request->validate([
            'subsidiary_id' => 'sometimes|exists:subsidiaries,id',
            'branch_name' => 'sometimes|string|max:255',
            'branch_address' => 'sometimes|nullable|string|max:500',
            'commune_id' => 'sometimes|nullable|integer|exists:communes,id',
            'branch_phone' => 'sometimes|nullable|string|max:50',
            'branch_email' => 'sometimes|nullable|email|max:255',
            'branch_status' => 'sometimes|nullable|string|max:50',
            'manager_id' => 'sometimes|nullable|integer|exists:users,id',
            'branch_opening_hours' => 'sometimes|nullable|string|max:255',
            'branch_location' => 'sometimes|nullable|string|max:255',
        ]);

        $branch->update($validated);
        $branch->load(['commune', 'manager']);

        // Disparar evento de notificación: branch.updated
        $this->dispatchNotification(
            typeKey: 'branch.updated',
            entityType: 'branch',
            entityId: $branch->id,
            scope: $this->branchScope($branch),
            payload: array_merge(
                ['branch_name' => $branch->branch_name],
                $this->currentUserPayload('updated_by')
            )
        );

        return new BranchResource($branch);
    }

    public function destroy($id)
    {
        $branch = Branch::findOrFail($id);
        $this->authorize('delete', $branch);

        // Notificación: branch.deleted (antes de eliminar)
        $this->dispatchNotification(
            typeKey: 'branch.deleted',
            entityType: 'branch',
            entityId: $branch->id,
            scope: $this->branchScope($branch),
            payload: array_merge(
                ['branch_name' => $branch->branch_name],
                $this->currentUserPayload('updated_by')
            )
        );

        $branch->delete();

        return response()->json(['message' => 'Sucursal eliminada.']);
    }
    
    /**
     * Actualizar solo la comuna de la sucursal
     */
    public function updateCommune(Request $request, int $id)
    {
        $branch = Branch::findOrFail($id);
        $this->authorize('update', $branch);

        $data = $request->validate([
            'commune_id' => 'nullable|integer|exists:communes,id',
        ]);

        $branch->commune_id = $data['commune_id'] ?? null;
        $branch->save();

        $with = array_filter(explode(',', (string) $request->query('with')));
        if (!empty($with)) {
            $branch->load($with);
        } else {
            $branch->load('commune');
        }

        return new BranchResource($branch);
    }
}
