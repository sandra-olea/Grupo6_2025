<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\Warehouse\StoreWarehouseRequest;
use App\Http\Requests\Warehouse\UpdateWarehouseRequest;
use App\Http\Requests\Warehouse\AttachProductToWarehouseRequest;
use App\Http\Requests\Warehouse\DetachProductFromWarehouseRequest;
use App\Http\Resources\WarehouseResource;
use App\Http\Resources\WarehouseDetailResource;
use App\Models\Branch;
use App\Models\Warehouse;
use Illuminate\Http\Request;
use App\Traits\DispatchesNotifications;

class BranchWarehousesController extends Controller
{
    use DispatchesNotifications;

    public function index(Request $request, Branch $branch)
    {
        $this->authorize('viewAny', [Warehouse::class, $branch]);
        $q = Warehouse::query()
            ->where('branch_id', $branch->id)
            ->with(['branch', 'commune', 'manager']);
        if ($s = trim((string) $request->get('q'))) {
            $q->where(function($w) use ($s) {
                $w->where('name','ILIKE',"%{$s}%")
                  ->orWhere('code','ILIKE',"%{$s}%");
            });
        }
        $q->orderBy('name','asc');
        return WarehouseResource::collection(
            $q->paginate($request->integer('per_page', 15))->appends($request->query())
        );
    }

    public function store(StoreWarehouseRequest $request, Branch $branch)
    {
        $data = $request->validated();
        $data['branch_id'] = $branch->id;
        $warehouse = Warehouse::create($data);

        // Notificación: warehouse.created
        $this->dispatchNotification(
            typeKey: 'warehouse.created',
            entityType: 'warehouse',
            entityId: $warehouse->id,
            scope: $this->branchScope($branch),
            payload: $this->currentUserPayload('created_by') + [
                'warehouse_name' => $warehouse->name,
                'branch_name' => $branch->branch_name,
            ]
        );

        $warehouse->load(['branch', 'commune', 'manager']);
        return WarehouseResource::make($warehouse);
    }

    public function show(Branch $branch, Warehouse $warehouse)
    {
        $this->authorize('view', $warehouse);
        if ($warehouse->branch_id !== $branch->id) abort(404);
        $warehouse->load(['branch', 'commune', 'manager']);
        return WarehouseResource::make($warehouse);
    }

    public function update(UpdateWarehouseRequest $request, Branch $branch, Warehouse $warehouse)
    {
        if ($warehouse->branch_id !== $branch->id) abort(404);
        $warehouse->update($request->validated());

        // Notificación: warehouse.updated
        $this->dispatchNotification(
            typeKey: 'warehouse.updated',
            entityType: 'warehouse',
            entityId: $warehouse->id,
            scope: $this->branchScope($branch),
            payload: $this->currentUserPayload('updated_by') + [
                'warehouse_name' => $warehouse->name,
                'branch_name' => $branch->branch_name,
            ]
        );

        $warehouse->load(['branch', 'commune', 'manager']);
        return WarehouseResource::make($warehouse->fresh());
    }

    public function destroy(Branch $branch, Warehouse $warehouse)
    {
        $this->authorize('delete', $warehouse);
        if ($warehouse->branch_id !== $branch->id) abort(404);

        // Verificar que la bodega no tenga productos asociados
        if ($warehouse->products()->exists()) {
            return response()->json([
                'message' => 'No se puede eliminar la bodega porque tiene productos asociados.',
                'error' => 'WAREHOUSE_HAS_PRODUCTS',
                'products_count' => $warehouse->products()->count(),
            ], 422);
        }

        // Notificación: warehouse.deleted
        $this->dispatchNotification(
            typeKey: 'warehouse.deleted',
            entityType: 'warehouse',
            entityId: $warehouse->id,
            scope: $this->branchScope($branch),
            payload: $this->currentUserPayload('updated_by') + [
                'warehouse_name' => $warehouse->name,
                'branch_name' => $branch->branch_name,
            ]
        );

        $warehouse->delete();
        return response()->json(['deleted' => true]);
    }

    public function detail(Branch $branch, Warehouse $warehouse)
    {
        $this->authorize('viewDetail', $warehouse);
        if ($warehouse->branch_id !== $branch->id) abort(404);
        
        $warehouse->load(['branch', 'commune', 'manager', 'products.brand']);
        return WarehouseDetailResource::make($warehouse);
    }

    public function attachProduct(AttachProductToWarehouseRequest $request, Branch $branch, Warehouse $warehouse)
    {
        if ($warehouse->branch_id !== $branch->id) abort(404);
        
        $validated = $request->validated();
        $productsData = $request->getProductsData();

        foreach ($productsData as $productData) {
            $warehouse->products()->attach($productData['product_id'], [
                'quantity' => $productData['final_quantity'],
                'sync_stock' => $productData['sync_stock'],
            ]);

            $this->dispatchNotification(
                typeKey: 'warehouse.product.attached',
                entityType: 'warehouse',
                entityId: $warehouse->id,
                scope: $this->branchScope($branch),
                payload: $this->currentUserPayload('attached_by') + [
                    'warehouse_name' => $warehouse->name,
                    'product_id' => $productData['product_id'],
                    'product_name' => $productData['product']->name ?? null,
                    'quantity' => $productData['final_quantity'],
                    'sync_stock' => $productData['sync_stock'],
                    'branch_name' => $branch->branch_name,
                ]
            );
        }

        $warehouse->load(['branch', 'commune', 'manager', 'products.brand']);
        return WarehouseDetailResource::make($warehouse);
    }

    public function detachProduct(DetachProductFromWarehouseRequest $request, Branch $branch, Warehouse $warehouse)
    {
        if ($warehouse->branch_id !== $branch->id) abort(404);
        
        $validated = $request->validated();
        $productIds = $request->getProductIds();

        foreach ($productIds as $productId) {
            // Obtener la cantidad antes de desasociar para la notificación
            $product = $warehouse->products()->where('product_id', $productId)->first();
            $quantity = $product?->pivot->quantity ?? 0;
            
            // Desasociar el producto
            $warehouse->products()->detach($productId);

            // Notificación: warehouse.product.detached
            $this->dispatchNotification(
                typeKey: 'warehouse.product.detached',
                entityType: 'warehouse',
                entityId: $warehouse->id,
                scope: $this->branchScope($branch),
                payload: $this->currentUserPayload('detached_by') + [
                    'warehouse_name' => $warehouse->name,
                    'product_id' => $productId,
                    'product_name' => $product?->name ?? null,
                    'quantity' => $quantity,
                    'branch_name' => $branch->branch_name,
                ]
            );
        }

        $warehouse->load(['branch', 'commune', 'manager', 'products.brand']);
        return WarehouseDetailResource::make($warehouse);
    }
}
