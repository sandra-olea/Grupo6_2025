<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Subsidiary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Pagination\LengthAwarePaginator;

class SubsidiaryProductsController extends Controller
{
    /**
     * GET /api/subsidiaries/{subsidiary}/products/saleables
     * Lista productos válidos para venta (precio > 0 y stock > 0) con precio neto = precio * 0.81
     */
    public function saleables(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $perPage = max(1, min(200, (int) $request->query('per_page', 20)));
        $page = max(1, (int) $request->query('page', 1));
        $search = trim((string) $request->query('q', ''));

        $base = Product::query()
            ->select(['products.id','products.branch_id','products.sku','products.name','products.offer_price','products.price','products.serial_tracking','products.parent_product_id'])
            ->join('branches as b', 'b.id', '=', 'products.branch_id')
            ->where('b.subsidiary_id', $subsidiary->id)
            ->whereRaw('COALESCE(products.offer_price, products.price) > 0');

        if ($search !== '') {
            $base->where(function($w) use ($search) {
                $w->where('products.sku','ILIKE',"%{$search}%")
                  ->orWhere('products.name','ILIKE',"%{$search}%");
            });
        }

        // Procesar en chunks por ID para abarcar todos los productos de TODAS las branches de la subsidiary
        $items = [];
        $base->orderBy('products.id')->chunkById(1000, function ($chunk) use (&$items) {
            foreach ($chunk as $p) {
                $stock = (int) $p->stock; // usa accessor (serial/no-serial)
                if ($stock <= 0) { continue; }
                $gross = (float) ($p->offer_price ?: $p->price ?: 0);
                if ($gross <= 0) { continue; }
                $net = round($gross * 0.81, 2);
                $items[] = [
                    'id' => $p->id,
                    'sku' => $p->sku,
                    'name' => $p->name,
                    'stock' => $stock,
                    // unit_price requerido: precio * 0.81, como string con 2 decimales
                    'unit_price' => number_format($net, 2, '.', ''),
                    'unit_price_gross' => $gross,
                    'unit_price_net' => $net,
                ];
            }
        });

        // Paginar manualmente sobre la colección filtrada
        $total = count($items);
        $offset = ($page - 1) * $perPage;
        $slice = array_slice($items, $offset, $perPage);
        $paginator = new LengthAwarePaginator($slice, $total, $perPage, $page, [
            'path' => $request->url(),
            'query' => $request->query(),
        ]);

        Log::info('Subsidiary saleables fetched', [ 'subsidiary_id' => $subsidiary->id, 'q' => $search, 'count' => count($slice), 'total' => $total ]);
        return response()->json($paginator);
    }
}
