<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use App\Models\Branch;
use App\Models\Transfer;
use App\Models\Product;
use App\Http\Resources\TransferResource;
use App\Http\Requests\Transfer\StoreTransferRequest;
use App\Traits\DispatchesNotifications;

class BranchTransfersController extends Controller
{
    use DispatchesNotifications;

    /**
     * GET /api/branches/{branch}/transfers
     * Listado paginado con filtros básicos.
     */
    public function index(Request $request, Branch $branch): JsonResponse
    {
        $this->authorize('viewAny', [Transfer::class, $branch]);

        $q = Transfer::query()->byBranch($branch->id)
            ->with(['fromBranch', 'toBranch', 'fromWarehouse', 'toWarehouse', 'responsible'])
            ->orderByDesc('id');

        $direction = strtolower((string) $request->input('direction', 'all'));
        if ($direction === 'sent') {
            $q->where('from_branch_id', $branch->id);
        } elseif ($direction === 'received') {
            $q->where('to_branch_id', $branch->id);
        }

        if ($s = trim((string) $request->input('q'))) {
            $q->where(function ($w) use ($s, $branch) {
                $w->where('notes', 'ILIKE', "%{$s}%")
                  ->orWhere('id', (int) $s);
            });
        }

        $perPage = (int) $request->input('per_page', 15);
        $page = $q->paginate($perPage)->appends($request->query());
        return response()->json(TransferResource::collection($page));
    }

    /**
     * GET /api/branches/{branch}/transfers/{transfer}
     */
    public function show(Branch $branch, Transfer $transfer): JsonResponse
    {
        $this->authorize('view', $transfer);
        if ($transfer->from_branch_id !== $branch->id && $transfer->to_branch_id !== $branch->id) {
            abort(404);
        }

        $transfer->load(['fromBranch', 'toBranch', 'fromWarehouse', 'toWarehouse', 'responsible', 'items.originProduct', 'items.destinationProduct']);
        return response()->json(TransferResource::make($transfer));
    }

    /**
     * POST /api/branches/{branch}/transfers
     * Ejecuta transferencia atómica entre sucursales para productos sin serie.
     */
    public function store(StoreTransferRequest $request, Branch $branch): JsonResponse
    {
        $this->authorize('create', [Transfer::class, $branch]);

        $toBranch = $request->destinationBranch();
        $items = $request->normalizedItems();

        // Resolver bodegas por defecto si no se envían
        $fromWarehouse = $request->resolvedFromWarehouse();
        $toWarehouse = $request->resolvedToWarehouse();

        if (!$fromWarehouse) {
            $fromWarehouse = $this->findDefaultWarehouse($branch->id);
        }
        if (!$toWarehouse) {
            $toWarehouse = $this->findDefaultWarehouse($toBranch->id);
        }

        try {
            $transfer = DB::transaction(function () use ($branch, $toBranch, $items, $fromWarehouse, $toWarehouse, $request) {
                $totalItems = 0;
                $totalQty = 0;
                $itemsData = [];

                // Validar stock y aplicar ajustes
                foreach ($items as $entry) {
                /** @var Product $origin */
                $origin = Product::where('id', $entry['origin']->id)->lockForUpdate()->first();
                // Ensure destination product exists (auto-create if needed)
                if (!empty($entry['destination'])) {
                    /** @var Product $dest */
                    $dest = Product::where('id', $entry['destination']->id)->lockForUpdate()->first();
                } else {
                    $dest = $this->replicateProductToBranch($origin, $toBranch, $toWarehouse);
                }

                $qty = (int) $entry['quantity'];

                if ($origin->branch_id !== $branch->id || $dest->branch_id !== $toBranch->id) {
                    throw new \RuntimeException('Inconsistencia de sucursal en productos.');
                }
                if ($origin->serial_tracking || $dest->serial_tracking) {
                    throw new \RuntimeException('Productos con tracking por serie no están permitidos en este endpoint.');
                }

                $available = (int) $origin->stock;
                if ($available < $qty) {
                    throw new \RuntimeException("Stock insuficiente para el producto {$origin->sku}. Disponible: {$available}, requerido: {$qty}");
                }

                // Aplicar cambios para disparar observer y sync de bodegas
                $origin->stock = $available - $qty;
                $origin->save();

                $dest->stock = (int) $dest->stock + $qty;
                $dest->save();

                $totalItems += 1;
                $totalQty += $qty;
                $itemsData[] = [
                    'origin_id' => $origin->id,
                    'destination_id' => $dest->id,
                    'quantity' => $qty,
                ];
            }

            // Crear registro de transferencia
            $transfer = new Transfer();
            $transfer->fill([
                'from_branch_id' => $branch->id,
                'to_branch_id' => $toBranch->id,
                'from_warehouse_id' => $fromWarehouse?->id,
                'to_warehouse_id' => $toWarehouse?->id,
                'responsible_id' => auth()->id(),
                'status' => 'completed',
                'total_items' => $totalItems,
                'total_quantity' => $totalQty,
                'notes' => $request->input('notes'),
            ]);
            $transfer->save();

            // Items
            foreach ($itemsData as $row) {
                $transfer->items()->create([
                    'origin_product_id' => $row['origin_id'],
                    'destination_product_id' => $row['destination_id'],
                    'quantity' => (int) $row['quantity'],
                ]);
            }

                return $transfer->fresh(['fromBranch','toBranch','fromWarehouse','toWarehouse','responsible','items.originProduct','items.destinationProduct']);
            });
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }

        // Notificación: transfer.sent (scope de la sucursal origen)
        $maxItems = 20;
        $itemsList = $transfer->items->take($maxItems)->map(function ($it) {
            return [
                'origin_product_id' => $it->originProduct?->id,
                'origin_sku' => $it->originProduct?->sku,
                'origin_name' => $it->originProduct?->name,
                'destination_product_id' => $it->destinationProduct?->id,
                'destination_sku' => $it->destinationProduct?->sku,
                'destination_name' => $it->destinationProduct?->name,
                'quantity' => (int) $it->quantity,
            ];
        })->values()->all();

        $payload = $this->currentUserPayload('created_by') + [
            'transfer_id' => $transfer->id,
            'from_branch' => [
                'id' => $transfer->from_branch_id,
                'name' => $transfer->fromBranch?->branch_name,
            ],
            'to_branch' => [
                'id' => $transfer->to_branch_id,
                'name' => $transfer->toBranch?->branch_name,
            ],
            'from_warehouse' => $transfer->fromWarehouse ? [
                'id' => $transfer->fromWarehouse->id,
                'name' => $transfer->fromWarehouse->name,
            ] : null,
            'to_warehouse' => $transfer->toWarehouse ? [
                'id' => $transfer->toWarehouse->id,
                'name' => $transfer->toWarehouse->name,
            ] : null,
            'total_items' => (int) $transfer->total_items,
            'total_quantity' => (int) $transfer->total_quantity,
            'items' => $itemsList,
            'items_truncated' => $transfer->items->count() > $maxItems,
            'message' => sprintf(
                'Transferencia #%d: %d uds en %d ítems de %s a %s',
                $transfer->id,
                (int) $transfer->total_quantity,
                (int) $transfer->total_items,
                (string) ($transfer->fromBranch?->branch_name ?? 'Origen'),
                (string) ($transfer->toBranch?->branch_name ?? 'Destino')
            ),
        ];

        $this->dispatchNotification(
            typeKey: 'transfer.sent',
            entityType: 'transfer',
            entityId: $transfer->id,
            scope: $this->branchScope($branch),
            payload: $payload
        );

        return response()->json(TransferResource::make($transfer), 201);
    }

    private function findDefaultWarehouse(int $branchId)
    {
        return \App\Models\Warehouse::query()
            ->where('branch_id', $branchId)
            ->where('is_active', true)
            ->orderByRaw("CASE WHEN warehouse_type = 'general' THEN 0 ELSE 1 END")
            ->orderBy('name','asc')
            ->first();
    }

    private function replicateProductToBranch(Product $origin, Branch $toBranch, ?\App\Models\Warehouse $toWarehouse = null): Product
    {
        // Try existing by SKU again (idempotent in repeated calls)
        $existing = Product::query()
            ->where('branch_id', $toBranch->id)
            ->where('sku', $origin->sku)
            ->first();
        if ($existing) {
            return $existing;
        }

        // Cargar relaciones necesarias del origen para clonar correctamente
        $origin->loadMissing('brand', 'categories');

        // Map/replicate brand scoped to destination branch
        $brandId = null;
        if ($origin->brand) {
            $brandName = $origin->brand->name;
            $destBrand = \App\Models\Brand::query()
                ->where('branch_id', $toBranch->id)
                ->whereRaw('LOWER(name) = ?', [mb_strtolower($brandName)])
                ->first();
            if (!$destBrand) {
                $destBrand = \App\Models\Brand::create([
                    'branch_id' => $toBranch->id,
                    'name' => $brandName,
                ]);
            }
            $brandId = $destBrand->id;
        }

        $payload = [
            'branch_id' => $toBranch->id,
            'sku' => $origin->sku,
            'commercial_sku' => $origin->commercial_sku,
            'barcode' => $origin->barcode,
            'name' => $origin->name,
            'brand_id' => $brandId,
            'product_type' => $origin->product_type,
            'serial_tracking' => false,
            'warranty_months' => $origin->warranty_months,
            'cost' => $origin->cost,
            'price' => $origin->price,
            'offer_price' => $origin->offer_price,
            'product_status' => $origin->product_status,
            'attributes_json' => $origin->attributes_json,
            'marketplace_external_ids' => null,
            'is_active' => $origin->is_active,
            'short_description' => $origin->short_description,
            'long_description' => $origin->long_description,
            'snippet_description' => $origin->snippet_description,
            'stock' => 0,
        ];

        $dest = new Product();
        $dest->fill($payload);
        $dest->save();

        // Attach to destination warehouse for stock sync if available
        if ($toWarehouse) {
            $toWarehouse->products()->syncWithoutDetaching([
                $dest->id => ['quantity' => 0, 'sync_stock' => true]
            ]);
        }

        // Clone categories from origin to destination product
        if ($origin->relationLoaded('categories')) {
            $pivotData = [];
            foreach ($origin->categories as $category) {
                // Si existiera soporte de soft-delete en el pivot, omitimos los eliminados
                if (!empty($category->pivot?->deleted_at)) {
                    continue;
                }
                $pivotData[$category->id] = [
                    'assigned_at' => $category->pivot?->assigned_at ?: now(),
                ];
            }

            if (!empty($pivotData)) {
                $dest->categories()->sync($pivotData);
            }
        }

        return $dest;
    }
}
