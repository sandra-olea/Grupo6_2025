<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PayslipController extends Controller
{
    /**
     * Mostrar listado de liquidaciones.
     */
    public function index()
    {
        //
    }

    /**
     * Almacenar una nueva liquidación.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Mostrar una liquidación específica.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Actualizar una liquidación específica.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Eliminar una liquidación específica.
     */
    public function destroy(string $id)
    {
        //
    }
}
