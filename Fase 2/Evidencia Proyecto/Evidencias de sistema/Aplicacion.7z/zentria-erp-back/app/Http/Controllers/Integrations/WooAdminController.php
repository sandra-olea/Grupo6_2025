<?php

namespace App\Http\Controllers\Integrations;

use App\Http\Controllers\Controller;
use App\Models\Integration;
use App\Models\Sale;
use App\Models\Subsidiary;
use App\Services\Integrations\WooIncrementalImportService;
use App\Services\Integrations\WooStockSyncService;
use App\Services\Integrations\WooApiService;
use App\Services\Integrations\WooOrderIngestService;
use Illuminate\Support\Facades\Bus;
use App\Jobs\ImportWooOrdersPage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Traits\DispatchesNotifications;

class WooAdminController extends Controller
{
    use DispatchesNotifications;
    public function importMissingOrders(Request $request, Subsidiary $subsidiary, WooIncrementalImportService $svc)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $integration = $this->resolveIntegration($request, $subsidiary);
        if (!$integration) return response()->json(['message' => 'WooCommerce integration not found'], 404);
        
        // Run as background batch with progress, leaving resources for others
        try {
            $state = \App\Models\WooSyncState::firstOrCreate(
                ['integration_id' => $integration->id],
                ['subsidiary_id' => $integration->subsidiary_id]
            );

            // Determine cursor (import orders strictly after this date)
            $after = $state->last_order_created_at?->toIso8601String();

            // First page fetch to know total pages from headers (created cursor)
            $api = app(WooApiService::class);
            $meta = $api->listOrdersWithMeta($integration, array_filter([
                'page' => 1,
                'per_page' => 50,
                'after' => $after,
            ]));

            $headers = array_change_key_case($meta['headers'] ?? [], CASE_LOWER);
            $totalPages = (int) ($headers['x-wp-totalpages'][0] ?? $headers['x-wp-totalpages'] ?? 0);
            $dataFirst = $meta['data'] ?? [];
            if ($totalPages === 0 && empty($dataFirst)) {
                $this->markSuccess($integration);
                return response()->json([
                    'message' => 'No missing orders to import',
                    'result' => ['imported' => 0, 'after' => $after, 'new_cursor' => $after],
                ], 200);
            }

            // Build jobs for created (include page 1 so processing is uniform)
            $jobs = [];
            for ($p = 1; $p <= max(1, $totalPages); $p++) {
                $jobs[] = (new ImportWooOrdersPage($integration->id, $p, $after, 50, 'created'))->onQueue('imports');
            }

            // Second cursor: modified-after (solo si ya tenemos cursor de modificado)
            $modifiedAfter = $state->last_order_modified_at?->toIso8601String();
            if ($modifiedAfter) {
                $metaMod = $api->listOrdersWithMeta($integration, array_filter([
                    'page' => 1,
                    'per_page' => 50,
                    'orderby' => 'modified',
                    'order' => 'asc',
                    'modified_after' => $modifiedAfter,
                    'after' => $modifiedAfter,
                ]));
                $headersMod = array_change_key_case($metaMod['headers'] ?? [], CASE_LOWER);
                $totalPagesMod = (int) ($headersMod['x-wp-totalpages'][0] ?? $headersMod['x-wp-totalpages'] ?? 0);
                $dataFirstMod = $metaMod['data'] ?? [];
                if (!($totalPagesMod === 0 && empty($dataFirstMod))) {
                    for ($p = 1; $p <= max(1, $totalPagesMod); $p++) {
                        $jobs[] = (new ImportWooOrdersPage($integration->id, $p, $modifiedAfter, 50, 'modified'))->onQueue('imports');
                    }
                }
            }

            // Notificación: inicio de importación masiva
            try {
                $this->dispatchNotification(
                    typeKey: 'woocommerce.import.started',
                    entityType: 'subsidiary',
                    entityId: $subsidiary->id,
                    scope: ['company_id' => null, 'subsidiary_id' => $subsidiary->id, 'branch_id' => null],
                    payload: [
                        'integration_id' => $integration->id,
                        'integration_name' => $integration->name,
                        'subsidiary_id' => $subsidiary->id,
                        'subsidiary_name' => $subsidiary->subsidiary_name ?? null,
                        'started_at' => now()->toIso8601String(),
                    ]
                );
            } catch (\Throwable $e) {}

            $batch = Bus::batch($jobs)
                ->onQueue('imports')
                ->name('Woo Import Missing Orders: '.$integration->id)
                ->then(function ($batch) use ($integration) {
                    // Mark finished in state
                    try {
                        $st = \App\Models\WooSyncState::find($integration->id);
                        if ($st) {
                            $st->current_batch_status = 'finished';
                            $st->current_batch_finished_at = now();
                            $st->save();
                        }
                    } catch (\Throwable $e) {}
                    $this->markSuccess($integration);
                    // Notificación: término de importación masiva
                    try {
                        $st = \App\Models\WooSyncState::find($integration->id);
                        $this->dispatchNotification(
                            typeKey: 'woocommerce.import.finished',
                            entityType: 'subsidiary',
                            entityId: (int) $integration->subsidiary_id,
                            scope: ['company_id' => null, 'subsidiary_id' => $integration->subsidiary_id, 'branch_id' => null],
                            payload: [
                                'integration_id' => $integration->id,
                                'integration_name' => $integration->name,
                                'subsidiary_id' => $integration->subsidiary_id,
                                'finished_at' => now()->toIso8601String(),
                                'pages_total' => (int) ($st?->current_batch_total ?? 0),
                                'pages_processed' => (int) ($st?->current_batch_processed ?? 0),
                                'orders_imported' => (int) ($st?->orders_imported_count ?? 0),
                                'orders_updated' => (int) ($st?->orders_updated_count ?? 0),
                            ]
                        );
                    } catch (\Throwable $e) {}
                })
                ->catch(function ($batch, $e) use ($integration) {
                    try {
                        $st = \App\Models\WooSyncState::find($integration->id);
                        if ($st) {
                            $st->current_batch_status = 'failed';
                            $st->current_batch_finished_at = now();
                            $st->save();
                        }
                    } catch (\Throwable $ex) {}
                    $this->markError($integration, 'importMissingOrders(batch): '.$e->getMessage());
                    // Notificación: término con error
                    try {
                        $this->dispatchNotification(
                            typeKey: 'woocommerce.import.finished',
                            entityType: 'subsidiary',
                            entityId: (int) $integration->subsidiary_id,
                            scope: ['company_id' => null, 'subsidiary_id' => $integration->subsidiary_id, 'branch_id' => null],
                            payload: [
                                'integration_id' => $integration->id,
                                'integration_name' => $integration->name,
                                'subsidiary_id' => $integration->subsidiary_id,
                                'finished_at' => now()->toIso8601String(),
                                'error' => $e->getMessage(),
                            ]
                        );
                    } catch (\Throwable $ex) {}
                })
                ->dispatch();

            // Save batch info in state for quick lookup
            $state->current_batch_id = $batch->id;
            $state->current_batch_total = count($jobs);
            $state->current_batch_processed = 0;
            $state->current_batch_status = 'queued';
            $state->current_batch_started_at = now();
            $state->orders_imported_count = 0;
            $state->orders_updated_count = 0;
            $state->save();

            return response()->json([
                'message' => 'Import scheduled',
                'batch_id' => $batch->id,
                'pages_total' => max(1, $totalPages),
                'per_page' => 50,
                'after' => $after,
                'status_url' => route('subsidiaries.integrations.woocommerce.import-missing-orders-status', ['subsidiary' => $subsidiary->id]) . '?batch_id=' . $batch->id,
            ], 202);
        } catch (\Throwable $e) {
            $this->markError($integration, 'importMissingOrders(schedule): '.$e->getMessage());
            return response()->json([
                'message' => 'Failed to schedule import',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function syncStock(Request $request, Subsidiary $subsidiary, WooStockSyncService $svc)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $integration = $this->resolveIntegration($request, $subsidiary);
        if (!$integration) return response()->json(['message' => 'WooCommerce integration not found'], 404);

        try {
            $skus = $request->input('skus');
            $skus = is_array($skus) ? array_values(array_filter($skus)) : null;
            $res = $svc->syncSubsidiaryStock($integration, $skus);
            $this->markSuccess($integration);
            return response()->json(['message' => 'Stock sync completed', 'result' => $res]);
        } catch (\Throwable $e) {
            $this->markError($integration, 'syncStock: '.$e->getMessage());
            return response()->json([
                'message' => 'Stock sync failed',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Check if a specific WooCommerce order exists, or import it if not.
     * 
     * GET /api/subsidiaries/{subsidiary}/integrations/woocommerce/orders/{wc_order_id}/check-or-import
     */
    public function checkOrImportOrder(
        Request $request, 
        Subsidiary $subsidiary, 
        int $wc_order_id,
        WooApiService $apiService,
        WooOrderIngestService $ingestService
    ) {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $integration = $this->resolveIntegration($request, $subsidiary);
        if (!$integration) {
            return response()->json(['message' => 'WooCommerce integration not found'], 404);
        }

        // Check if order already exists in our database
        $existingSale = Sale::where('subsidiary_id', $subsidiary->id)
            ->where('wc_order_id', $wc_order_id)
            ->with(['items.product', 'customer'])
            ->first();

        // Siempre consultar a Woo para reflejar cambios de estado
        try {
            $response = $apiService->getOrder($integration, $wc_order_id);
            
            if (!$response || empty($response)) {
                return response()->json([
                    'message' => 'Order not found in WooCommerce',
                    'exists' => false,
                    'wc_order_id' => $wc_order_id,
                ], 404);
            }

            // Upsert (crea o actualiza) la venta con la orden actual de Woo
            $result = $ingestService->ingest($subsidiary->id, $integration->id, $response);

            // Recuperar la venta actualizada
            $newSale = Sale::where('id', $result['sale_id'])
                ->with(['items.product', 'customer'])
                ->first();

            $this->markSuccess($integration);
            return response()->json([
                'message' => $existingSale ? 'Order updated from WooCommerce' : 'Order imported successfully',
                'exists' => (bool) $existingSale,
                'imported' => !$existingSale,
                'updated' => $existingSale ? ($result['old_status'] !== $result['new_status']) : false,
                'old_status' => $result['old_status'],
                'new_status' => $result['new_status'],
                'sale' => [
                    'id' => $newSale->id,
                    'sale_number' => $newSale->sale_number,
                    'wc_order_id' => $newSale->wc_order_id,
                    'wc_order_number' => $newSale->wc_order_number,
                    'status' => $newSale->status,
                    'woo_status' => is_array($newSale->woo_metadata ?? null) ? ($newSale->woo_metadata['status'] ?? null) : null,
                    'total_amount' => $newSale->total_amount,
                    'customer' => $newSale->customer ? [
                        'id' => $newSale->customer->id,
                        'name' => $newSale->customer->first_name . ' ' . $newSale->customer->last_name,
                        'rut' => $newSale->customer->rut,
                    ] : null,
                    'items_count' => $newSale->items->count(),
                    'created_at' => $newSale->created_at?->toISOString(),
                ],
            ], $existingSale ? 200 : 201);

        } catch (\Throwable $e) {
            $this->markError($integration, 'checkOrImportOrder: '.$e->getMessage());
            return response()->json([
                'message' => 'Failed to import order from WooCommerce',
                'error' => $e->getMessage(),
                'wc_order_id' => $wc_order_id,
            ], 500);
        }
    }

    private function markSuccess(Integration $integration): void
    {
        try {
            $integration->last_success_at = now();
            $integration->last_error_at = null;
            $integration->last_error_msg = null;
            $integration->save();
        } catch (\Throwable $e) {}
    }

    private function markError(Integration $integration, string $message): void
    {
        try {
            $integration->last_error_at = now();
            $integration->last_error_msg = $message;
            $integration->save();
        } catch (\Throwable $e) {}
    }

    private function resolveIntegration(Request $request, Subsidiary $subsidiary): ?Integration
    {
        $id = (string) $request->query('integration_id', '');
        if ($id) {
            $i = Integration::where('id', $id)->where('subsidiary_id', $subsidiary->id)->where('provider', 'woocommerce')->first();
            if ($i && $i->is_active) return $i; else return null;
        }
        return Integration::where('subsidiary_id', $subsidiary->id)
            ->where('provider', 'woocommerce')
            ->where('is_active', true)
            ->orderByDesc('updated_at')
            ->first();
    }

    /**
     * GET status for the import-missing-orders batch
     */
    public function importMissingOrdersStatus(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $integration = $this->resolveIntegration($request, $subsidiary);
        if (!$integration) {
            return response()->json(['message' => 'WooCommerce integration not found'], 404);
        }

        $batchId = (string) $request->query('batch_id', '');
        $state = \App\Models\WooSyncState::find($integration->id);
        if (!$batchId) {
            $batchId = (string) ($state?->current_batch_id ?? '');
        }
        if (!$batchId) {
            return response()->json(['message' => 'No batch in progress'], 404);
        }

        $batch = Bus::findBatch($batchId);
        if (!$batch) {
            return response()->json(['message' => 'Batch not found', 'batch_id' => $batchId], 404);
        }

        return response()->json([
            'batch_id' => $batch->id,
            'name' => $batch->name,
            'total_jobs' => $batch->totalJobs,
            'pending_jobs' => $batch->pendingJobs,
            'processed_jobs' => $batch->processedJobs(),
            'failed_jobs' => $batch->failedJobs,
            'progress' => $batch->progress(),
            'cancelled' => $batch->cancelled(),
            'created_at' => optional($batch->createdAt)->toIso8601String(),
            'finished_at' => optional($batch->finishedAt)->toIso8601String(),
            'state' => [
                'current_batch_status' => $state?->current_batch_status,
                'current_batch_total' => (int) ($state?->current_batch_total ?? 0),
                'current_batch_processed' => (int) ($state?->current_batch_processed ?? 0),
                'last_order_created_at' => optional($state?->last_order_created_at)->toIso8601String(),
                'last_order_modified_at' => optional($state?->last_order_modified_at)->toIso8601String(),
            ],
        ]);
    }
}
