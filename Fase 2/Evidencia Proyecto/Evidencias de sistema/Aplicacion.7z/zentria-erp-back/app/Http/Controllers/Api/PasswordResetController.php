<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Notifications\PasswordResetLinkNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Notification;
use Illuminate\Validation\ValidationException;

class PasswordResetController extends Controller
{
    /**
     * POST /api/auth/forgot-password
     * Body: { email }
     */
    public function requestReset(Request $request)
    {
        $data = $request->validate([
            'email' => ['required','email'],
        ]);

        $email = strtolower(trim($data['email']));

        // Look up user case-insensitively
        $user = User::whereRaw('LOWER(email) = ?', [$email])->first();

        // Always respond 200 to avoid account enumeration
        if (! $user) {
            return response()->json(['message' => 'Si el correo existe, se enviará un enlace para restablecer.']);
        }

        // Create a broker token and build the frontend URL
        $token = Password::broker()->createToken($user);

        $resetUrl = $this->buildResetUrl($token, $user->id);

        // Send notification email
        $fullName = trim($user->first_name . ' ' . $user->last_name) ?: null;
        $expiresMinutes = (int) (config('auth.passwords.users.expire') ?? 60);
        Notification::route('mail', $user->email)
            ->notify(new PasswordResetLinkNotification($resetUrl, $fullName, $expiresMinutes));

        return response()->json(['message' => 'Si el correo existe, se enviará un enlace para restablecer.']);
    }

    /**
     * POST /api/auth/reset-password
     * Body: { token, uid, password, password_confirmation }
     */
    public function resetPassword(Request $request)
    {
        $data = $request->validate([
            'token' => ['required','string'],
            'uid' => ['required','integer'],
            'password' => ['required','string','min:8','confirmed'],
        ]);

        $user = User::find($data['uid']);
        if (! $user) {
            throw ValidationException::withMessages(['uid' => 'Usuario no encontrado.']);
        }

        $status = Password::broker()->reset(
            [
                'email' => strtolower(trim($user->email)),
                'password' => $data['password'],
                'password_confirmation' => $request->input('password_confirmation'),
                'token' => $data['token'],
            ],
            function ($user, $password) {
                $user->forceFill([
                    'password' => Hash::make($password),
                ])->save();
            }
        );

        if ($status === Password::PASSWORD_RESET) {
            return response()->json(['message' => 'Contraseña restablecida correctamente.']);
        }

        throw ValidationException::withMessages([
            'token' => __($status),
        ]);
    }

    private function buildResetUrl(string $token, int $uid): string
    {
        // FRONTEND_PASSWORD_RESET_URL can be a full URL or base path
        $base = config('app.frontend_password_reset_url');
        if ($base) {
            $base = rtrim($base, '/ ');
            // Required pattern: {BASE}?token=...&uid=...
            $query = http_build_query(['token' => $token, 'uid' => $uid]);
            return $base . (str_contains($base, '?') ? '&' : '?') . $query;
        }

        // Backend fallback route
        return url('/reset-password?token=' . urlencode($token) . '&uid=' . urlencode((string) $uid));
    }
}
