<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QueuesController extends Controller
{
    // Lista de tareas/batches recientes y activos (visible para cualquier usuario autenticado)
    public function index(Request $request)
    {
        $limit = (int) $request->query('limit', 50);
        $batches = DB::table('job_batches')
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get();

        $now = now()->getTimestamp();

        $items = $batches->map(function ($b) use ($now) {
            $processed = max(0, (int)$b->total_jobs - (int)$b->pending_jobs);
            $progress = (int)$b->total_jobs > 0 ? (int) floor(($processed / (int)$b->total_jobs) * 100) : 0;

            $createdAt = (int) $b->created_at;
            $elapsed = max(1, $now - $createdAt);
            $rate = $processed > 0 ? ($processed / $elapsed) : null; // jobs per second
            $remaining = ($rate && (int)$b->total_jobs > 0)
                ? max(0, (int) round(((int)$b->total_jobs - $processed) / $rate))
                : null;

            // Enlazar con estados conocidos (Woo)
            $state = DB::table('woo_sync_states')->where('current_batch_id', $b->id)->first();

            return [
                'id' => $b->id,
                'name' => $b->name,
                'total_jobs' => (int) $b->total_jobs,
                'pending_jobs' => (int) $b->pending_jobs,
                'failed_jobs' => (int) $b->failed_jobs,
                'processed_jobs' => $processed,
                'progress_percent' => $progress,
                'progress_ratio' => $processed.'/'.((int)$b->total_jobs),
                'created_at' => $createdAt ? date(DATE_ISO8601, $createdAt) : null,
                'finished_at' => $b->finished_at ? date(DATE_ISO8601, (int)$b->finished_at) : null,
                'eta_seconds' => $remaining,
                'eta_human' => $remaining !== null ? $this->humanSeconds($remaining) : null,
                'namespace' => $state ? 'woocommerce.import.orders' : null,
                'state' => $state ? [
                    'pages_total' => (int) ($state->current_batch_total ?? 0),
                    'pages_processed' => (int) ($state->current_batch_processed ?? 0),
                    'orders_imported' => (int) ($state->orders_imported_count ?? 0),
                    'orders_updated' => (int) ($state->orders_updated_count ?? 0),
                    'last_order_created_at' => $state->last_order_created_at,
                    'last_order_modified_at' => $state->last_order_modified_at,
                ] : null,
            ];
        });

        return response()->json(['data' => $items]);
    }

    // Detalle de una tarea/batch por id
    public function show(Request $request, string $id)
    {
        $b = DB::table('job_batches')->where('id', $id)->first();
        if (!$b) return response()->json(['message' => 'Batch not found'], 404);

        $now = now()->getTimestamp();
        $processed = max(0, (int)$b->total_jobs - (int)$b->pending_jobs);
        $progress = (int)$b->total_jobs > 0 ? (int) floor(($processed / (int)$b->total_jobs) * 100) : 0;
        $createdAt = (int) $b->created_at;
        $elapsed = max(1, $now - $createdAt);
        $rate = $processed > 0 ? ($processed / $elapsed) : null; // jobs per second
        $remaining = ($rate && (int)$b->total_jobs > 0)
            ? max(0, (int) round(((int)$b->total_jobs - $processed) / $rate))
            : null;

        $state = DB::table('woo_sync_states')->where('current_batch_id', $b->id)->first();

        return response()->json([
            'id' => $b->id,
            'name' => $b->name,
            'total_jobs' => (int) $b->total_jobs,
            'pending_jobs' => (int) $b->pending_jobs,
            'failed_jobs' => (int) $b->failed_jobs,
            'processed_jobs' => $processed,
            'progress_percent' => $progress,
            'progress_ratio' => $processed.'/'.((int)$b->total_jobs),
            'created_at' => $createdAt ? date(DATE_ISO8601, $createdAt) : null,
            'finished_at' => $b->finished_at ? date(DATE_ISO8601, (int)$b->finished_at) : null,
            'eta_seconds' => $remaining,
            'eta_human' => $remaining !== null ? $this->humanSeconds($remaining) : null,
            'namespace' => $state ? 'woocommerce.import.orders' : null,
            'state' => $state ? [
                'pages_total' => (int) ($state->current_batch_total ?? 0),
                'pages_processed' => (int) ($state->current_batch_processed ?? 0),
                'orders_imported' => (int) ($state->orders_imported_count ?? 0),
                'orders_updated' => (int) ($state->orders_updated_count ?? 0),
                'last_order_created_at' => $state->last_order_created_at,
                'last_order_modified_at' => $state->last_order_modified_at,
            ] : null,
        ]);
    }

    private function humanSeconds(int $seconds): string
    {
        $units = [
            'd' => 86400,
            'h' => 3600,
            'm' => 60,
            's' => 1,
        ];
        $parts = [];
        foreach ($units as $label => $unit) {
            if ($seconds >= $unit) {
                $val = intdiv($seconds, $unit);
                $seconds -= $val * $unit;
                $parts[] = $val.$label;
            }
        }
        return $parts ? implode(' ', array_slice($parts, 0, 2)) : '0s';
    }
}
