<?php

namespace App\Http\Controllers;

use App\Http\Resources\SaleItemResource;
use App\Http\Resources\SaleResource;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\TechnicalReviewItem;
use App\Models\Subsidiary;
use App\Services\EquipmentTraceabilityService;
use App\Enums\EquipmentStatus;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use App\Models\Quote;
use App\Models\QuoteItem;
use App\Models\CustomerSale;

class SubsidiarySalesController extends Controller
{
    /**
     * GET /api/subsidiaries/{subsidiary}/sales
     */
    public function index(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $q = Sale::query()
            ->where('subsidiary_id', $subsidiary->id)
            ->withCount('items');

        if ($request->filled('wc_order_id')) {
            $q->where('wc_order_id', (int)$request->query('wc_order_id'));
        }
        if ($request->filled('status')) {
            $q->where('status', (string)$request->query('status'));
        }
        if ($search = trim((string)$request->query('q'))) {
            $q->where(function ($w) use ($search) {
                $w->where('sale_number', 'ILIKE', "%{$search}%")
                  ->orWhere('wc_order_number', 'ILIKE', "%{$search}%");
            });
        }

        // Optional eager loads
        if ($request->boolean('with_customer')) {
            $q->with('customer');
        }

        $q->orderByDesc('id');

        return SaleResource::collection(
            $q->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/sales/{sale}
     */
    public function show(Subsidiary $subsidiary, int $sale)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $record = Sale::where('subsidiary_id', $subsidiary->id)
            ->with('customer')
            ->findOrFail($sale);

        return SaleResource::make($record);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/sales/{sale}/items
     */
    public function items(Subsidiary $subsidiary, int $sale)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $record = Sale::where('subsidiary_id', $subsidiary->id)->findOrFail($sale);
        $items = $record->items()->with(['product','sale'])->orderBy('id')->get();

        return SaleItemResource::collection($items);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/sales/{sale}/close
     * Cierra la venta: valida series y las marca como VENDIDAS, libera soft-holds y bloquea re-mutas posteriores.
     * Body esperado:
     * {
     *   "items": [
     *     { "sale_item_id": 10, "serial_numbers": ["SN001","SN002"] },
     *     ...
     *   ]
     * }
     */
    public function close(
        Request $request,
        Subsidiary $subsidiary,
        int $sale,
        EquipmentTraceabilityService $traceability
    ) {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        /** @var Sale $saleModel */
        $saleModel = Sale::with(['items.product'])->where('subsidiary_id', $subsidiary->id)->findOrFail($sale);

        // Si ya está finalizada, no permitir doble cierre
        $docMeta = (array) ($saleModel->documents_metadata ?? []);
        if (!empty($docMeta['inventory_finalized']) || $saleModel->inventory_delivered) {
            return response()->json([
                'message' => 'La venta ya fue finalizada. No se puede cerrar nuevamente.',
                'sale_id' => $saleModel->id,
            ], 409);
        }

        $payloadItems = (array) $request->input('items', []);
        if (empty($payloadItems)) {
            return response()->json([
                'message' => 'Debes indicar las series para los items con seguimiento por serie.',
                'required' => $saleModel->items->filter(fn($it) => $it->product && $it->product->serial_tracking)
                    ->map(fn($it) => [
                        'sale_item_id' => $it->id,
                        'product_id' => $it->product_id,
                        'sku' => $it->product?->sku,
                        'grade' => $it->product?->grade?->value,
                        'quantity' => (int) $it->quantity,
                    ])->values(),
            ], 422);
        }

        // Indexar input por sale_item_id y validar estructura
        $byItem = [];
        foreach ($payloadItems as $entry) {
            $sid = (int) Arr::get($entry, 'sale_item_id');
            $sns = array_values(array_filter((array) Arr::get($entry, 'serial_numbers', []), fn($s) => is_string($s) && trim($s) !== ''));
            if ($sid <= 0 || empty($sns)) {
                return response()->json([
                    'message' => 'Formato inválido: cada item requiere sale_item_id y serial_numbers[]',
                ], 422);
            }
            $byItem[$sid] = $sns;
        }

        // Validar series requeridas para cada item con serial_tracking
        $errors = [];
        $allSN = [];
        foreach ($saleModel->items as $it) {
            if (!$it->product || !$it->product->serial_tracking) continue;
            $need = (int) $it->quantity;
            $sns = $byItem[$it->id] ?? null;
            if (!$sns) {
                $errors[$it->id][] = 'Faltan seriales para este item.';
                continue;
            }
            if (count($sns) !== $need) {
                $errors[$it->id][] = "Cantidad de series distinta a la requerida ({$need}).";
            }
            foreach ($sns as $sn) {
                $snN = trim($sn);
                if (isset($allSN[$snN])) {
                    $errors[$it->id][] = "Serie duplicada en la solicitud: {$snN}.";
                }
                $allSN[$snN] = true;
            }
        }
        if (!empty($errors)) {
            return response()->json([
                'message' => 'Errores de validación en seriales.',
                'errors' => $errors,
            ], 422);
        }

        // Validar existencia, correspondencia al producto del ítem y estado disponible para cada serie
        $validationErrors = [];
        foreach ($saleModel->items as $it) {
            if (!$it->product || !$it->product->serial_tracking) continue;
            $sns = $byItem[$it->id] ?? [];
            if (empty($sns)) continue;

            $parentId = $it->product->parent_product_id ?: $it->product->id;
            $grade = $it->product->grade?->value;

            foreach ($sns as $sn) {
                $triQ = TechnicalReviewItem::query()
                    ->where('serial_number', trim($sn))
                    ->where('product_id', $parentId)
                    ->where('review_status', 'approved')
                    ->where('current_status', EquipmentStatus::AVAILABLE_FOR_SALE);
                if ($grade) { $triQ->where('grade', $grade); }
                $tri = $triQ->first();
                if (!$tri) {
                    $validationErrors[$it->id][] = "Serie no válida/no disponible o no corresponde al producto del ítem: {$sn}.";
                    continue;
                }
                // Defensa adicional: la serie debe pertenecer al mismo modelo (padre) y grado del ítem
                if ((int) $tri->product_id !== (int) $parentId) {
                    $validationErrors[$it->id][] = "La serie {$sn} no corresponde al producto (modelo) del ítem.";
                    continue;
                }
                if ($grade && (($tri->grade?->value) !== $grade)) {
                    $validationErrors[$it->id][] = "La serie {$sn} no corresponde al grado del ítem.";
                }
            }
        }
        if (!empty($validationErrors)) {
            return response()->json([
                'message' => 'Validación fallida: series inexistentes o no disponibles para venta.',
                'errors' => $validationErrors,
            ], 422);
        }

        // Ejecutar cierre: marcar SOLD y liberar soft-holds
        DB::transaction(function () use ($saleModel, $byItem, $traceability) {
            foreach ($saleModel->items as $it) {
                if (!$it->product || !$it->product->serial_tracking) continue;
                $sns = $byItem[$it->id] ?? [];
                if (empty($sns)) continue;

                $parentId = $it->product->parent_product_id ?: $it->product->id;
                $grade = $it->product->grade?->value;

                foreach ($sns as $sn) {
                    $tri = TechnicalReviewItem::query()
                        ->where('serial_number', trim($sn))
                        ->where('product_id', $parentId)
                        ->when($grade, fn($q) => $q->where('grade', $grade))
                        ->first();

                    if ($tri) {
                        if ($tri->traceability) {
                            // Marca vendido con trazabilidad completa
                            $traceability->markAsSold($tri->traceability, $saleModel->id, (int) $saleModel->customer_id);
                        } else {
                            // Fallback mínimo
                            $tri->update([
                                'current_status' => EquipmentStatus::SOLD,
                                'sale_id' => $saleModel->id,
                            ]);
                        }
                    }
                }

                // Liberar soft-hold del item y poner cantidad en 0
                \App\Models\ProductSoftHold::query()
                    ->where('sale_id', $saleModel->id)
                    ->where('sale_item_id', $it->id)
                    ->update(['status' => 'released', 'quantity' => 0]);

                // Marcar meta del item
                $meta = $it->meta_json ?? [];
                $res = $meta['reservation'] ?? [];
                Arr::set($res, 'hold_qty', 0);
                Arr::set($res, 'sold_serials', $byItem[$it->id]);
                Arr::set($res, 'checked_at', now()->toISOString());
                Arr::set($meta, 'reservation', $res);
                $it->meta_json = $meta;
                $it->save();
            }

            // Bloquear futuras mutaciones de stock por webhooks
            $docMeta = (array) ($saleModel->documents_metadata ?? []);
            $docMeta['inventory_finalized'] = true;
            $saleModel->documents_metadata = $docMeta;
            $saleModel->inventory_delivered = true; // Consideramos inventario finalizado
            $saleModel->inventory_delivered_at = now();
            // Marcar estado final de la venta: siempre 'delivered' (Finalizada)
            $saleModel->status = 'delivered';
            // Timestamp de finalización
            $saleModel->completed_at = $saleModel->completed_at ?? now();
            $saleModel->save();
        });

        return response()->json([
            'message' => 'Venta cerrada correctamente',
            'sale_id' => $saleModel->id,
        ]);
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/sales/{sale}
     * Elimina una venta (solo si no está finalizada/entregada) y sus items.
     */
    public function destroy(Subsidiary $subsidiary, int $sale)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        /** @var Sale $saleModel */
        $saleModel = Sale::withCount('items')
            ->where('subsidiary_id', $subsidiary->id)
            ->findOrFail($sale);

        // No permitir eliminar ventas entregadas o finalizadas
        $docMeta = (array) ($saleModel->documents_metadata ?? []);
        if (!empty($docMeta['inventory_finalized']) || $saleModel->inventory_delivered) {
            return response()->json([
                'message' => 'No se puede eliminar una venta ya entregada/finalizada.',
            ], 409);
        }

        DB::transaction(function () use ($saleModel) {
            // Eliminar items y liberar soft-holds asociados
            foreach ($saleModel->items as $it) {
                \App\Models\ProductSoftHold::query()
                    ->where('sale_id', $saleModel->id)
                    ->where('sale_item_id', $it->id)
                    ->update(['status' => 'released', 'quantity' => 0]);
                $it->delete();
            }
            $saleModel->delete();
        });

        return response()->json([
            'deleted' => true,
        ], 200);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/sales/{sale}/create-quote
     * Crea una cotización basada en una venta y genera un PDF en
     * storage/app/public/subsidiary-{ID}/quotes/quote-{quoteId}.pdf
     */
    public function createQuote(Request $request, Subsidiary $subsidiary, int $sale)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        /** @var Sale $saleModel */
        $saleModel = Sale::with(['items.product', 'customer.commune.province.region', 'customer.shippingCommune.province.region'])
            ->where('subsidiary_id', $subsidiary->id)
            ->findOrFail($sale);

        /** @var CustomerSale|null $customer */
        $customer = $saleModel->customer;

        $taxRate = (float) ($saleModel->tax_rate ?? 0.19);
        if ($taxRate <= 0) { $taxRate = 0.19; }

        $assumeGross = ((float) ($saleModel->tax_amount ?? 0)) <= 0.0; // Si impuestos vienen en 0, asumimos valores con IVA incluido

        // Preparar ítems calculados con estrategia robusta
        $rawItems = $saleModel->items;
        $totalQty = (int) $rawItems->sum(fn($it) => (int) $it->quantity ?: 0);

        $computed = [];
        $grossItemsSum = 0.0;
        foreach ($rawItems as $it) {
            $qty = max(1, (int) $it->quantity);
            $unitPrice = (float) ($it->unit_price ?? 0);
            $lineTotal = (float) ($it->total ?? 0);
            $lineSubtotal = (float) ($it->subtotal ?? 0);

            // Determinar precio base bruto estimado por unidad
            $unitGross = 0.0;
            if ($assumeGross) {
                if ($unitPrice > 0) {
                    $unitGross = $unitPrice;
                } elseif ($lineTotal > 0) {
                    $unitGross = $lineTotal / $qty;
                } elseif ($lineSubtotal > 0) {
                    $unitGross = $lineSubtotal / $qty;
                }
                $unitNet = round($unitGross / (1.0 + $taxRate), 2);
            } else {
                // Valores netos desde Woo
                $unitNet = 0.0;
                if ($lineTotal > 0) {
                    $unitNet = round($lineTotal / $qty, 2);
                } elseif ($lineSubtotal > 0) {
                    $unitNet = round($lineSubtotal / $qty, 2);
                } elseif ($unitPrice > 0) {
                    $unitNet = round($unitPrice, 2);
                }
                $unitGross = round($unitNet * (1.0 + $taxRate), 2);
            }

            $totalNetLine = round($unitNet * $qty, 2);
            $grossItemsSum += round($unitGross * $qty, 2);

            $computed[] = [
                'model' => $it,
                'qty' => $qty,
                'sku' => $it->product?->sku ?: ($it->meta_json['mapping']['sku'] ?? ''),
                'name' => $it->product?->name ?: ($it->meta_json['name'] ?? 'Producto'),
                'unit_net' => $unitNet,
                'total_net' => $totalNetLine,
                'discount_amount' => (float) ($it->discount_amount ?? 0),
            ];
        }

        // Si no logramos calcular nada útil y hay total de venta, distribuir en base a cantidades
        $itemsNetTotal = (float) array_sum(array_column($computed, 'total_net'));
        $shippingAmount = (float) ($saleModel->shipping_amount ?? 0);
        $saleGrandTotal = (float) ($saleModel->total_amount ?? 0);
        
        // Calcular fee_lines netos desde metadata de WooCommerce (algunos pedidos lo traen)
        $feeLines = (array) ($saleModel->woo_metadata['fee_lines'] ?? []);
        $feeNetTotal = 0.0;
        if (!empty($feeLines)) {
            foreach ($feeLines as $fee) {
                $feeTotal = (float) ($fee['total'] ?? 0);
                $feeTotalTax = (float) ($fee['total_tax'] ?? 0);
                if ($feeTotal == 0.0) { continue; }
                // Si total_tax = 0, el fee viene con IVA incluido (bruto); si > 0, ya es neto
                $feeNet = $feeTotalTax <= 0 ? round($feeTotal / (1.0 + $taxRate), 2) : round($feeTotal, 2);
                $feeNetTotal += $feeNet;
            }
        }
        if ($itemsNetTotal <= 0 && $saleGrandTotal > 0 && $totalQty > 0) {
            // Distribuir bruto de ítems como total - envío
            $grossForItems = max(0.0, $saleGrandTotal - $shippingAmount);
            $unitGrossEven = $grossForItems / $totalQty;
            $itemsNetTotal = 0.0;
            foreach ($computed as &$c) {
                $c['unit_net'] = $assumeGross ? round($unitGrossEven / (1.0 + $taxRate), 2) : round($unitGrossEven, 2);
                $c['total_net'] = round($c['unit_net'] * $c['qty'], 2);
                $itemsNetTotal += $c['total_net'];
            }
            unset($c);
        } else {
            $itemsNetTotal = round($itemsNetTotal, 2);
        }

        // Envío neto
        $shippingNet = $assumeGross ? round($shippingAmount / (1.0 + $taxRate), 2) : round($shippingAmount, 2);
        // Incluir fees netos opcionales para cuadrar con total de WooCommerce
        $totalNet = round($itemsNetTotal + $feeNetTotal + $shippingNet, 2);

        if ($assumeGross) {
            $grandTotal = $saleGrandTotal; // viene con IVA
            $iva = round($grandTotal - $totalNet, 2);
        } else {
            $ivaFromSale = (float) ($saleModel->tax_amount ?? 0);
            $iva = $ivaFromSale > 0 ? round($ivaFromSale, 2) : round($totalNet * $taxRate, 2);
            $grandTotal = round($totalNet + $iva, 2);
        }

        // Ajuste por diferencias de redondeo para cuadrar con total de venta cuando está disponible
        if ($saleGrandTotal > 0) {
            $diff = round(($totalNet + $iva) - $saleGrandTotal, 2);
            if (abs($diff) >= 0.01) {
                $iva = round($saleGrandTotal - $totalNet, 2);
            }
            $grandTotal = $saleGrandTotal;
        }

        // Crear cotización + items (sin "envío" como item por restricción de FK)
        $quote = DB::transaction(function () use ($subsidiary, $saleModel, $computed, $taxRate, $itemsNetTotal, $feeNetTotal, $shippingNet, $iva, $grandTotal) {
            $tmpNumber = 'TMP-'.Str::uuid()->toString();
            $quote = Quote::create([
                'subsidiary_id' => $subsidiary->id,
                'customer_id' => (int) $saleModel->customer_id,
                'quote_number' => $tmpNumber,
                'status' => 'draft',
                'salesperson_id' => $saleModel->salesperson_id,
                'quote_date' => $saleModel->sale_date?->toDateString() ?: now()->toDateString(),
                'expiry_date' => now()->addDays(15)->toDateString(),
                // Subtotal considera ítems, fees y envío (neto)
                'subtotal' => round($itemsNetTotal + $feeNetTotal + $shippingNet, 2),
                'tax_amount' => round($iva, 2),
                'discount_amount' => (float) ($saleModel->discount_amount ?? 0),
                'total_amount' => round($grandTotal, 2),
                'tax_rate' => $taxRate,
                'discount_rate' => (float) ($saleModel->discount_rate ?? 0),
                'notes' => 'Cotización generada desde venta #'.$saleModel->id,
            ]);

            // Ajustar número de cotización al ID incremental (requisito de negocio)
            $quote->quote_number = (string) $quote->id;
            $quote->save();

            foreach ($computed as $c) {
                /** @var \App\Models\SaleItem $it */
                $it = $c['model'];
                $qty = $c['qty'];
                $unitNet = $c['unit_net'];
                $totalNetLine = $c['total_net'];
                
                // Si product_id es 0 o null, no lo asignamos (quedará null)
                $productId = (int) $it->product_id;
                $productId = ($productId > 0) ? $productId : null;
                
                // Extract add-ons from meta_json
                $productName = $it->product?->name ?: ($it->meta_json['name'] ?? null);
                $metaData = $it->meta_json['meta_data'] ?? [];
                $addonsDescription = $this->extractAddonsDescription($metaData);
                
                // If addons exist, append them to customer_name
                if ($addonsDescription) {
                    $productName .= "\n" . $addonsDescription;
                }
                
                QuoteItem::create([
                    'quote_id' => $quote->id,
                    'product_id' => $productId,
                    'quantity' => $qty,
                    'unit_price' => $unitNet,
                    'discount_rate' => 0,
                    'discount_amount' => (float) ($it->discount_amount ?? 0),
                    'subtotal' => round($unitNet * $qty, 2),
                    'total' => $totalNetLine,
                    'customer_sku' => $it->product?->sku ?: ($it->meta_json['mapping']['sku'] ?? null),
                    'customer_name' => $productName,
                    'description' => null,
                    'notes' => null,
                    'product_attributes' => $it->product?->attributes_json,
                ]);
            }

            // Add fee_lines as additional quote items (without product_id)
            $feeLines = $saleModel->woo_metadata['fee_lines'] ?? [];
            if (is_array($feeLines) && !empty($feeLines)) {
                foreach ($feeLines as $fee) {
                    $feeName = $fee['name'] ?? 'Cargo adicional';
                    $feeTotal = (float) ($fee['total'] ?? 0);
                    $feeTotalTax = (float) ($fee['total_tax'] ?? 0);
                    
                    if ($feeTotal != 0) { // Include both positive and negative fees
                        // Si total_tax = 0, el fee viene con IVA incluido (bruto), necesitamos convertir a neto
                        // Si total_tax > 0, el fee ya viene neto y WooCommerce calculó el IVA aparte
                        if ($feeTotalTax <= 0) {
                            // Viene bruto, convertir a neto
                            $feeNet = round($feeTotal / (1.0 + $taxRate), 2);
                        } else {
                            // Ya viene neto, usar directamente
                            $feeNet = round($feeTotal, 2);
                        }
                        
                        QuoteItem::create([
                            'quote_id' => $quote->id,
                            'product_id' => null, // Fee lines don't have product_id
                            'quantity' => 1,
                            'unit_price' => $feeNet,
                            'discount_rate' => 0,
                            'discount_amount' => 0,
                            'subtotal' => $feeNet,
                            'total' => $feeNet,
                            'customer_sku' => null,
                            'customer_name' => $feeName,
                            'description' => null,
                            'notes' => 'Fee line de WooCommerce',
                            'product_attributes' => null,
                        ]);
                    }
                }
            }

            return $quote;
        });

        // Armar datos para PDF
        $billingCommune = $customer?->commune;
        $billingProvince = $billingCommune?->province;
        $billingRegion = $billingProvince?->region;

        $fullAddressParts = array_filter([
            $customer?->billing_address_1,
            $customer?->billing_address_2,
            $customer?->billing_city,
            $billingCommune?->name,
            $billingRegion?->name,
            $customer?->billing_postcode,
        ], fn($v) => $v && trim((string)$v) !== '');
        $fullAddress = implode(', ', $fullAddressParts);

        $docType = $customer?->default_document_type ?: ($saleModel->documents_metadata['document_type'] ?? 'boleta');
        $paymentTitle = $saleModel->payment_method_title ?: $saleModel->payment_method ?: 'N/A';
        $poNumber = $customer?->purchase_order_number ?: null;

        // Preferir nombre y apellido del comprador desde billing_snapshot
        $billingSnap = (array) ($saleModel->billing_snapshot ?? []);
        $contactFull = trim(((string)($billingSnap['first_name'] ?? '')) . ' ' . ((string)($billingSnap['last_name'] ?? '')));
        $buyerDisplay = $customer?->billing_company ?: ($contactFull ?: ($customer?->contact_name ?: 'N/A'));

        // Items para la vista (SKU, nombre, qty, unit_net, total_net) + add-ons opcionales
        $viewItems = array_map(function ($c) {
            /** @var \App\Models\SaleItem $model */
            $model = $c['model'];
            $addons = null;
            try { $addons = $this->extractAddonsDescription((array) ($model->meta_json['meta_data'] ?? [])); } catch (\Throwable $e) { $addons = null; }
            return [
                'quantity' => $c['qty'],
                'sku' => $c['sku'],
                'name' => $c['name'],
                'addons' => $addons,
                'unit_net' => $c['unit_net'],
                'total_net' => $c['total_net'],
                'has_discount' => ($c['discount_amount'] ?? 0) > 0,
                'original_unit' => null,
                'discount_amount' => (float) ($c['discount_amount'] ?? 0),
            ];
        }, $computed);

        // Agregar fee_lines como filas en el PDF (cuando existan)
        if (!empty($feeLines)) {
            foreach ($feeLines as $fee) {
                $feeName = $fee['name'] ?? 'Cargo adicional';
                $feeTotal = (float) ($fee['total'] ?? 0);
                $feeTotalTax = (float) ($fee['total_tax'] ?? 0);
                if ($feeTotal == 0.0) { continue; }
                $feeNet = $feeTotalTax <= 0 ? round($feeTotal / (1.0 + $taxRate), 2) : round($feeTotal, 2);
                $viewItems[] = [
                    'quantity' => 1,
                    'sku' => '',
                    'name' => $feeName,
                    'addons' => null,
                    'unit_net' => $feeNet,
                    'total_net' => $feeNet,
                    'has_discount' => false,
                    'original_unit' => null,
                    'discount_amount' => 0.0,
                ];
            }
        }

        $data = [
            'quote' => $quote,
            'sale' => $saleModel,
            'customer' => $customer,
            'quote_number_display' => (string) $quote->id,
            'buyer_name' => $buyerDisplay,
            'rut' => $customer?->rut ?: 'N/A',
            'giro' => $customer?->trade_activity ?: 'N/A',
            'address' => $fullAddress ?: 'N/A',
            'contact_name' => $contactFull ?: ($customer?->contact_name ?: 'N/A'),
            'email' => $customer?->email ?: 'N/A',
            'po_number' => $poNumber,
            'date_display' => ($saleModel->sale_date?->format('d-m-Y')) ?: now()->format('d-m-Y'),
            'payment_title' => $paymentTitle,
            'document_type' => $docType,
            'items' => $viewItems,
            'totals' => [
                'items_net' => round($itemsNetTotal + $feeNetTotal, 2),
                'shipping_net' => round($shippingNet, 2),
                'total_net' => round($totalNet, 2),
                'iva' => round($iva, 2),
                'grand_total' => round($grandTotal, 2),
            ],
        ];

        // Render PDF (Dompdf si disponible); fallback a HTML
        // Asegurar carpeta de vistas compiladas para Blade
        try {
            $compiledPath = config('view.compiled') ?: storage_path('framework/views');
            if (!is_dir($compiledPath)) {
                @mkdir($compiledPath, 0775, true);
            }
        } catch (\Throwable $e) {}

        $diskPath = 'public/subsidiary-'.$subsidiary->id.'/quotes';
        $filename = 'quote-'.$quote->id.'.pdf';
        $absDir = storage_path('app/'.$diskPath);
        if (!is_dir($absDir)) { @mkdir($absDir, 0775, true); }

        // Asegurar carpeta temporal para mPDF (evita errores de permisos en vendor/mpdf/tmp)
        $mpdfTmpDir = storage_path('app/mpdf/tmp');
        if (!is_dir($mpdfTmpDir)) { @mkdir($mpdfTmpDir, 0775, true); }

        $pdfGenerated = false;
        try {
            if (class_exists(\Barryvdh\DomPDF\Facade\Pdf::class)) {
                Log::info('Quote PDF: using barryvdh/laravel-dompdf');
                $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('quotes.quote_from_sale', $data);
                $pdf->setPaper('letter');
                $raw = $pdf->output();
                file_put_contents($absDir.DIRECTORY_SEPARATOR.$filename, $raw);
                $pdfGenerated = true;
            } elseif (class_exists(\Dompdf\Dompdf::class)) {
                Log::info('Quote PDF: using dompdf/dompdf');
                $html = view('quotes.quote_from_sale', $data)->render();
                $dompdf = new \Dompdf\Dompdf();
                $dompdf->loadHtml($html);
                $dompdf->setPaper('letter');
                $dompdf->render();
                file_put_contents($absDir.DIRECTORY_SEPARATOR.$filename, $dompdf->output());
                $pdfGenerated = true;
            } elseif (class_exists(\Mpdf\Mpdf::class)) {
                Log::info('Quote PDF: using mpdf/mpdf');
                // Usar plantilla específica para mPDF (HTML + estilos inline)
                $html = view('quotes.quote_from_sale_mpdf', $data)->render();
                $mpdf = new \Mpdf\Mpdf([
                    'mode' => 'utf-8',
                    'format' => 'Letter',
                    'tempDir' => $mpdfTmpDir,
                    'margin_top' => 12,
                    'margin_bottom' => 12,
                    'margin_left' => 10,
                    'margin_right' => 10,
                    'default_font_size' => 11,
                    'default_font' => 'dejavusans',
                    'autoScriptToLang' => true,
                    'autoLangToFont' => true,
                ]);
                $mpdf->simpleTables = true;
                $mpdf->use_kwt = false;
                $mpdf->WriteHTML($html, \Mpdf\HTMLParserMode::DEFAULT_MODE);
                $mpdf->Output($absDir.DIRECTORY_SEPARATOR.$filename, \Mpdf\Output\Destination::FILE);
                $pdfGenerated = true;
            } else {
                Log::warning('Quote PDF: no PDF engine available');
            }
        } catch (\Throwable $e) {
            Log::error('Quote PDF generation failed', ['error' => $e->getMessage()]);
            $pdfGenerated = false;
        }

        // Fallback: guardar HTML si no hay motor PDF disponible
        if (!$pdfGenerated) {
            $html = view('quotes.quote_from_sale', $data)->render();
            file_put_contents($absDir.DIRECTORY_SEPARATOR.'quote-'.$quote->id.'.html', $html);
        }

        return response()->json([
            'message' => $pdfGenerated ? 'Cotización creada y PDF generado' : 'Cotización creada (PDF no disponible, se guardó HTML)',
            'quote_id' => $quote->id,
            'quote_number' => (string) $quote->id,
            'pdf_path' => $pdfGenerated ? (storage_path('app/'.$diskPath.'/'.$filename)) : null,
            'storage_relative' => $diskPath.'/'.$filename,
        ], 201);
    }

    /**
     * Extract and format add-ons from WooCommerce line item meta_data
     * Returns formatted string like "8 GB RAM / 256 GB SSD (M.2) / Agregar Office Instalado"
    */
    private function extractAddonsDescription(array $metaData): ?string
    {
        // Find _ywapo_meta_data
        $ywapoData = null;
        foreach ($metaData as $meta) {
            if (($meta['key'] ?? '') === '_ywapo_meta_data') {
                $ywapoData = $meta['value'] ?? null;
                break;
            }
        }

        if (!$ywapoData || !is_array($ywapoData)) {
            return null;
        }

        $parts = [];
        foreach ($ywapoData as $addon) {
            if (!is_array($addon)) continue;
            
            // Each addon is an associative array with addon_id as key
            foreach ($addon as $addonId => $addonDetails) {
                if (!is_array($addonDetails)) continue;
                
                $displayLabel = $addonDetails['display_label'] ?? '';
                $displayValue = $addonDetails['display_value'] ?? '';
                $addonValue = $addonDetails['addon_value'] ?? $displayValue;
                
                // Skip empty values
                if (empty($displayValue) && empty($addonValue)) continue;
                
                // Format specific add-ons
                if (stripos($displayLabel, 'ram') !== false) {
                    // RAM: "8 GB" -> "8 GB RAM"
                    $val = trim($addonValue ?: $displayValue);
                    if ($val !== '') { $parts[] = $val . ' RAM'; }
                } elseif (stripos($displayLabel, 'almacenamiento') !== false || stripos($displayLabel, 'storage') !== false) {
                    // Storage: keep as is
                    $val = trim($addonValue ?: $displayValue);
                    if ($val !== '') { $parts[] = $val; }
                } elseif (stripos($displayValue, 'office') !== false || stripos($addonValue, 'office') !== false) {
                    // Office: preserve base label (e.g., "Agregar Office") and add "Instalado" if priced
                    $base = trim($addonValue ?: $displayValue);
                    if ($base === '') { $base = 'Office'; }
                    $priced = (strpos($displayValue, '(+') !== false || strpos($displayValue, '+$') !== false);
                    $parts[] = $priced ? ($base . ' Instalado') : $base;
                } else {
                    // Other add-ons: use display_value
                    $val = trim($addonValue ?: $displayValue);
                    if ($val !== '') { $parts[] = $val; }
                }
            }
        }

        return empty($parts) ? null : implode(' / ', $parts);
    }
}
