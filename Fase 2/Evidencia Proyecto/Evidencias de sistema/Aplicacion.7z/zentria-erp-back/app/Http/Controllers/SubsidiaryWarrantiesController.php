<?php

namespace App\Http\Controllers;

use App\Enums\EquipmentStatus;
use App\Http\Requests\Warranty\StoreWarrantyRequest;
use App\Http\Requests\Warranty\UpdateWarrantyRequest;
use App\Http\Resources\WarrantyResource;
use App\Models\CustomerSale;
use App\Models\EquipmentTraceability;
use App\Models\Product;
use App\Models\Sale;
use App\Models\Subsidiary;
use App\Models\TechnicalReviewItem;
use App\Models\Warranty;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class SubsidiaryWarrantiesController extends Controller
{
    /**
     * GET /api/subsidiaries/{subsidiary}/warranties
     */
    public function index(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $q = Warranty::query()->where('subsidiary_id', $subsidiary->id);

        if ($search = trim((string) $request->get('q'))) {
            $q->where(function ($w) use ($search) {
                $w->where('serial_number', 'ILIKE', "%{$search}%")
                  ->orWhere('status', 'ILIKE', "%{$search}%")
                  ->orWhere('notes', 'ILIKE', "%{$search}%");
            });
        }
        if ($status = $request->get('status')) {
            $q->where('status', $status);
        }
        if ($request->filled('sale_id')) {
            $q->where('sale_id', (int) $request->get('sale_id'));
        }
        if ($request->filled('customer_id')) {
            $q->where('customer_id', (int) $request->get('customer_id'));
        }
        if ($request->filled('product_id')) {
            $q->where('product_id', (int) $request->get('product_id'));
        }

        if ($request->boolean('with_product')) $q->with('product');
        if ($request->boolean('with_customer')) $q->with('customer');
        if ($request->boolean('with_sale')) $q->with('sale');

        $q->orderByDesc('id');

        return WarrantyResource::collection(
            $q->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/warranties
     * Si se envía serial_number, autocompleta datos desde trazabilidad (venta/client/producto/fechas)
     */
    public function store(StoreWarrantyRequest $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $data = $request->validated();
        $data['subsidiary_id'] = $subsidiary->id;

        if (!empty($data['serial_number'])) {
            $this->fillFromSerial($data, $subsidiary);
        }
        // Si viene sale_id y no customer_id, derivar del pedido
        if (!empty($data['sale_id']) && empty($data['customer_id'])) {
            $sale = Sale::where('id', (int)$data['sale_id'])->first();
            if (!$sale) abort(422, 'La venta indicada no existe.');
            if ((int)$sale->subsidiary_id !== (int)$subsidiary->id) {
                abort(422, 'La venta no pertenece a esta subempresa.');
            }
            $data['customer_id'] = (int) $sale->customer_id;
        }

        // Si faltan fechas sin serie, exigirlas
        if (empty($data['serial_number'])) {
            if (empty($data['start_date']) || empty($data['end_date'])) {
                abort(422, 'start_date y end_date son obligatorias si no indicas serial_number');
            }
        }
        // Derivar estado si no viene
        if (empty($data['status']) && !empty($data['end_date'])) {
            $data['status'] = Carbon::parse($data['end_date'])->isPast() ? 'Expirada' : 'Activa';
        }

        $warranty = Warranty::create($data);
        return WarrantyResource::make($warranty->load(['product','customer','sale']))->response()->setStatusCode(201);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/warranties/{warranty}
     */
    public function show(Subsidiary $subsidiary, Warranty $warranty)
    {
        abort_if($warranty->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('view', $subsidiary), 403);
        return WarrantyResource::make($warranty->load(['product','customer','sale']));
    }

    /**
     * PATCH /api/subsidiaries/{subsidiary}/warranties/{warranty}
     */
    public function update(UpdateWarrantyRequest $request, Subsidiary $subsidiary, Warranty $warranty)
    {
        abort_if($warranty->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $data = $request->validated();

        if (!empty($data['serial_number'])) {
            // Si cambiaron la serie, recalcular campos relacionados
            $this->fillFromSerial($data, $subsidiary);
        }

        if (isset($data['start_date']) || isset($data['end_date'])) {
            $start = isset($data['start_date']) ? Carbon::parse($data['start_date']) : $warranty->start_date;
            $end = isset($data['end_date']) ? Carbon::parse($data['end_date']) : $warranty->end_date;
            if (empty($data['status'])) {
                $data['status'] = $end->isPast() ? 'Expirada' : 'Activa';
            }
            $data['start_date'] = $start->toDateString();
            $data['end_date'] = $end->toDateString();
        }

        $warranty->update($data);
        return WarrantyResource::make($warranty->load(['product','customer','sale']));
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/warranties/{warranty}
     */
    public function destroy(Subsidiary $subsidiary, Warranty $warranty)
    {
        abort_if($warranty->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('delete', $subsidiary), 403);
        $warranty->delete();
        return response()->json(['deleted' => true]);
    }

    /**
     * Rellenar datos de garantía en base a número de serie (requisitos: SOLD y misma subsidiary).
     * Modifica $data por referencia.
     */
    private function fillFromSerial(array & $data, Subsidiary $subsidiary): void
    {
        $serial = trim((string) ($data['serial_number'] ?? ''));
        if ($serial === '') return;

        $trace = EquipmentTraceability::where('serial_number', $serial)->first();
        if (!$trace) {
            abort(422, 'La serie indicada no existe.');
        }
        if ($trace->status !== EquipmentStatus::SOLD) {
            abort(422, 'La serie no está en estado vendido.');
        }

        // Validar subsidiary por la venta
        $sale = $trace->sale;
        if (!$sale || (int)$sale->subsidiary_id !== (int)$subsidiary->id) {
            abort(422, 'La serie no pertenece a una venta de esta subempresa.');
        }

        // Datos asociados
        $data['sale_id'] = $sale->id;
        $data['customer_id'] = $trace->customer_id;

        // Producto asociado desde item de revisión técnica
        $reviewItem = $trace->reviewItem; // belongsTo via review_item_id
        if ($reviewItem) {
            // En TechnicalReviewItem, product_id apunta al PADRE y grade indica el grado.
            // La garantía debe apuntar al HIJO correspondiente al grado.
            $parentId = (int) $reviewItem->product_id;
            $gradeVal = $reviewItem->grade?->value; // enum -> value (string) o null

            $child = Product::query()
                ->where('parent_product_id', $parentId)
                ->when(!is_null($gradeVal) && $gradeVal !== '', fn($q) => $q->where('grade', $gradeVal))
                ->first();

            if ($child) {
                $data['product_id'] = $child->id; // hijo por grado
            } else {
                // Fallback: si no hay hijo con ese grado, usar el padre
                $data['product_id'] = $parentId;
            }
        }

        // Fechas de garantía en función de sold_at + warranty_months del producto (default 6)
        $soldAt = $trace->sold_at ?: now();
        $start = Carbon::parse($soldAt)->startOfDay();
        $months = 6;
        if (!empty($data['product_id'])) {
            $prod = Product::find($data['product_id']);
            $months = $this->resolveWarrantyMonths($prod) ?? 6;
        }
        // Evitar meses inválidos (0 o negativos)
        if ($months <= 0) { $months = 6; }
        $end = (clone $start)->addMonths($months);
        $data['start_date'] = $start->toDateString();
        $data['end_date'] = $end->toDateString();

        // Estado por defecto
        $data['status'] = $end->isPast() ? 'Expirada' : 'Activa';
    }

    private function resolveWarrantyMonths(?Product $product): ?int
    {
        if (!$product) return null;
        // 1) Campo directo warranty_months
        $wm = $product->warranty_months ?? null;
        if (is_numeric($wm) && (int)$wm > 0) {
            return (int) $wm;
        }
        // 2) Buscar en attributes_json posibles claves
        $attrs = (array) ($product->attributes_json ?? []);
        $cands = ['warranty_months','warranty','garantia','garantía'];
        foreach ($cands as $k) {
            if (array_key_exists($k, $attrs) && is_numeric($attrs[$k])) {
                $val = (int) $attrs[$k];
                if ($val > 0) return $val;
            }
        }
        // 3) Si el producto tiene padre, intentar con el padre
        if ($product->parent_product_id) {
            $parent = Product::find($product->parent_product_id);
            if ($parent) {
                $val = $this->resolveWarrantyMonths($parent);
                if (is_numeric($val) && (int)$val > 0) return (int)$val;
            }
        }
        return null;
    }
}
