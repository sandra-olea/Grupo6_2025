<?php

namespace App\Http\Controllers\Notifications;

use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\UserNotificationPreference;
use App\Services\Notifications\NotificationPolicyService;

class PreferencesController extends BaseController
{
    public function index()
    {
        $user = Auth::user();
        $types = NotificationType::orderBy('module')->get();
        $policy = app(NotificationPolicyService::class);

        $data = $types->map(function ($type) use ($user, $policy) {
            $effective = $policy->resolveEffective($user, $type, []);
            return [
                'type_id' => $type->id,
                'key' => $type->key,
                'module' => $type->module,
                'module_label' => $type->module_label,
                'display_name' => $type->display_name,
                'description' => $type->description,
                'effective' => $effective,
            ];
        });

        return response()->json($data);
    }

    public function update(Request $request)
    {
        $user = Auth::user();
        $items = $request->input('items', []);
        if (!is_array($items)) {
            return response()->json(['message' => 'Invalid payload'], 422);
        }

        $policy = app(NotificationPolicyService::class);

        foreach ($items as $item) {
            $type = NotificationType::find($item['type_id'] ?? 0);
            if (!$type) continue;
            $effective = $policy->resolveEffective($user, $type, []);
            if ($effective['locked']) {
                // Skip locked (P1)
                continue;
            }
            UserNotificationPreference::updateOrCreate(
                ['user_id' => $user->id, 'notification_type_id' => $type->id],
                [
                    'allowed' => isset($item['allowed']) ? (bool) $item['allowed'] : true,
                    'channels' => $item['channels'] ?? null,
                ]
            );
        }

        return response()->json(['ok' => true]);
    }
}
