<?php

namespace App\Http\Controllers;

use App\Services\ExcelReaderService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ExcelTestController extends Controller
{
    protected ExcelReaderService $excelService;

    public function __construct(ExcelReaderService $excelService)
    {
        $this->excelService = $excelService;
    }

    /**
     * Lee y muestra la información de la plantilla ECOPC
     *
     * @return JsonResponse
     */
    public function readEcopcTemplate(): JsonResponse
    {
        try {
            $data = $this->excelService->readEcopcTemplate();
            
            return response()->json([
                'success' => true,
                'message' => 'Plantilla ECOPC leída exitosamente',
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al leer la plantilla',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Lee solo los encabezados de la plantilla ECOPC (primera hoja)
     *
     * @return JsonResponse
     */
    public function readEcopcHeaders(): JsonResponse
    {
        try {
            $templatePath = public_path('templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx');
            $data = $this->excelService->readHeaders($templatePath, 0); // Primera hoja
            
            return response()->json([
                'success' => true,
                'message' => 'Encabezados leídos exitosamente',
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al leer los encabezados',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Lee los encabezados de TODAS las hojas de la plantilla ECOPC
     *
     * @return JsonResponse
     */
    public function readEcopcAllHeaders(): JsonResponse
    {
        try {
            $templatePath = public_path('templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx');
            $data = $this->excelService->readHeaders($templatePath, null); // Todas las hojas
            
            return response()->json([
                'success' => true,
                'message' => 'Encabezados de todas las hojas leídos exitosamente',
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al leer los encabezados',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Obtiene la lista de todas las hojas de la plantilla ECOPC
     *
     * @return JsonResponse
     */
    public function getEcopcSheetsList(): JsonResponse
    {
        try {
            $templatePath = public_path('templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx');
            $data = $this->excelService->getSheetsList($templatePath);
            
            return response()->json([
                'success' => true,
                'message' => 'Lista de hojas obtenida exitosamente',
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener la lista de hojas',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Lee una hoja específica por nombre
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function readEcopcSheetByName(Request $request): JsonResponse
    {
        $request->validate([
            'sheet_name' => 'required|string'
        ]);
        
        try {
            $templatePath = public_path('templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx');
            $sheetName = $request->input('sheet_name');
            $data = $this->excelService->readSheetByName($templatePath, $sheetName);
            
            return response()->json([
                'success' => true,
                'message' => "Hoja '{$sheetName}' leída exitosamente",
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al leer la hoja',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Lee cualquier archivo Excel subido
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function readUploadedFile(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls|max:10240'
        ]);

        try {
            $file = $request->file('file');
            $data = $this->excelService->readExcelFile($file->getRealPath());
            
            return response()->json([
                'success' => true,
                'message' => 'Archivo leído exitosamente',
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al leer el archivo',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Valida los encabezados de un archivo subido
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function validateFileHeaders(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls|max:10240',
            'required_headers' => 'required|array'
        ]);

        try {
            $file = $request->file('file');
            $requiredHeaders = $request->input('required_headers');
            
            $validation = $this->excelService->validateHeaders(
                $file->getRealPath(),
                $requiredHeaders
            );
            
            return response()->json([
                'success' => true,
                'message' => $validation['valid'] ? 'Validación exitosa' : 'Validación fallida',
                'data' => $validation
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al validar el archivo',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
