<?php

namespace App\Http\Controllers;

use App\Http\Resources\DocumentTypeResource;
use App\Models\DocumentType;
use Illuminate\Http\Request;

class DocumentTypesController extends Controller
{
    public function index(Request $request)
    {
        $q = DocumentType::query();
        if ($s = trim((string) $request->get('q'))) {
            $q->where(function($w) use ($s){
                $w->where('code', 'ILIKE', "%{$s}%")
                  ->orWhere('name', 'ILIKE', "%{$s}%");
            });
        }
        if (!is_null($request->get('is_active'))) {
            $q->where('is_active', filter_var($request->get('is_active'), FILTER_VALIDATE_BOOL));
        }
        $q->orderBy('name');
        return DocumentTypeResource::collection(
            $q->paginate($request->integer('per_page', 15))->appends($request->query())
        );
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code' => ['required','string','max:100','unique:document_types,code'],
            'name' => ['required','string','max:100'],
            'description' => ['nullable','string'],
            'is_active' => ['sometimes','boolean'],
        ]);

        $type = DocumentType::create($data);
        return DocumentTypeResource::make($type)->response()->setStatusCode(201);
    }

    public function show(DocumentType $documentType)
    {
        return DocumentTypeResource::make($documentType);
    }

    public function update(Request $request, DocumentType $documentType)
    {
        $data = $request->validate([
            'code' => ['sometimes','string','max:100','unique:document_types,code,'.$documentType->id],
            'name' => ['sometimes','string','max:100'],
            'description' => ['nullable','string'],
            'is_active' => ['sometimes','boolean'],
        ]);
        $documentType->update($data);
        return DocumentTypeResource::make($documentType);
    }

    public function destroy(DocumentType $documentType)
    {
        $documentType->delete();
        return response()->json(['deleted' => true]);
    }
}
