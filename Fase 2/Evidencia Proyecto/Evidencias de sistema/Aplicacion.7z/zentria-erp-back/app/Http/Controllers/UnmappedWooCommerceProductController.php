<?php

namespace App\Http\Controllers;

use App\Models\UnmappedWooCommerceProduct;
use App\Models\Product;
use App\Models\Subsidiary;
use App\Models\Integration;
use App\Http\Resources\UnmappedWooCommerceProductResource;
use App\Http\Requests\UnmappedWooCommerce\MapUnmappedProductRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class UnmappedWooCommerceProductController extends Controller
{
    /**
     * Display a listing of unmapped WooCommerce products for a specific integration.
     * 
     * @param Subsidiary $subsidiary
     * @param Integration $integration
     * @return JsonResponse
     */
    public function index(Request $request, Subsidiary $subsidiary, Integration $integration): JsonResponse
    {
        $this->authorize('viewAny', UnmappedWooCommerceProduct::class);
        
        // Verify integration belongs to subsidiary
        if ($integration->subsidiary_id !== $subsidiary->id) {
            abort(404, 'Integration not found for this subsidiary');
        }

        $query = UnmappedWooCommerceProduct::query()
            ->where('integration_id', $integration->id)
            ->with(['integration', 'sale', 'mappedProduct']);

        // Filter by status
        if ($request->has('status')) {
            $query->where('resolution_status', $request->status);
        } else {
            // Default: only show pending
            $query->pending();
        }

        // Search by SKU or name
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('sku', 'ILIKE', "%{$search}%")
                  ->orWhere('name', 'ILIKE', "%{$search}%");
            });
        }

        // Sort
        $sortBy = $request->get('sort_by', 'created_at');
        $sortDirection = $request->get('sort_direction', 'desc');
        $query->orderBy($sortBy, $sortDirection);

        $perPage = min((int) $request->get('per_page', 15), 100);
        $unmapped = $query->paginate($perPage);

        // Build plain array to avoid serialization quirks when wrapping ResourceCollection
        $data = [];
        foreach ($unmapped->items() as $item) {
            $data[] = (new UnmappedWooCommerceProductResource($item))->toArray($request);
        }

        return response()->json([
            'data' => $data,
            'meta' => [
                'current_page' => $unmapped->currentPage(),
                'last_page' => $unmapped->lastPage(),
                'per_page' => $unmapped->perPage(),
                'total' => $unmapped->total(),
            ],
        ]);
    }

    /**
     * Display a listing of mapped WooCommerce products for a specific integration.
     * 
     * @param Request $request
     * @param Subsidiary $subsidiary
     * @param Integration $integration
     * @return JsonResponse
     */
    public function mapped(Request $request, Subsidiary $subsidiary, Integration $integration): JsonResponse
    {
        $this->authorize('viewAny', UnmappedWooCommerceProduct::class);
        
        // Verify integration belongs to subsidiary
        if ($integration->subsidiary_id !== $subsidiary->id) {
            abort(404, 'Integration not found for this subsidiary');
        }

        $query = UnmappedWooCommerceProduct::query()
            ->where('integration_id', $integration->id)
            ->where('resolution_status', 'mapped')
            ->with(['integration', 'sale', 'mappedProduct']);

        // Search by SKU or name
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('sku', 'ILIKE', "%{$search}%")
                  ->orWhere('name', 'ILIKE', "%{$search}%");
            });
        }

        // Filter by date range
        if ($request->has('mapped_from')) {
            $query->where('mapped_at', '>=', $request->mapped_from);
        }
        if ($request->has('mapped_to')) {
            $query->where('mapped_at', '<=', $request->mapped_to);
        }

        // Sort
        $sortBy = $request->get('sort_by', 'mapped_at');
        $sortDirection = $request->get('sort_direction', 'desc');
        $query->orderBy($sortBy, $sortDirection);

        $perPage = min((int) $request->get('per_page', 15), 100);
        $mapped = $query->paginate($perPage);

        $data = [];
        foreach ($mapped->items() as $item) {
            $data[] = (new UnmappedWooCommerceProductResource($item))->toArray($request);
        }

        return response()->json([
            'data' => $data,
            'meta' => [
                'current_page' => $mapped->currentPage(),
                'last_page' => $mapped->lastPage(),
                'per_page' => $mapped->perPage(),
                'total' => $mapped->total(),
            ],
        ]);
    }

    /**
     * List all ERP products that have WooCommerce synchronization.
     * This shows products from the Products table that have marketplace_external_ids.woocommerce set.
     * 
     * @param Request $request
     * @param Subsidiary $subsidiary
     * @param Integration $integration
     * @return JsonResponse
     */
    public function syncedProducts(Request $request, Subsidiary $subsidiary, Integration $integration): JsonResponse
    {
        $this->authorize('viewAny', UnmappedWooCommerceProduct::class);
        
        // Verify integration belongs to subsidiary
        if ($integration->subsidiary_id !== $subsidiary->id) {
            abort(404, 'Integration not found for this subsidiary');
        }

        // Get all products from branches of this subsidiary that have WooCommerce sync
        $query = Product::query()
            ->whereHas('branch', function ($q) use ($subsidiary) {
                $q->where('subsidiary_id', $subsidiary->id);
            })
            ->whereNotNull('marketplace_external_ids')
            ->whereRaw("marketplace_external_ids::jsonb ?? 'woocommerce'")
            ->with(['branch.subsidiary', 'brand', 'category']);

        // Filter by integration (using integration_hint in metadata)
        if ($request->get('filter_by_integration', true)) {
            $query->whereRaw(
                "(marketplace_external_ids::jsonb -> 'woocommerce' ->> 'integration_hint') = ?",
                [(string) $integration->id]
            );
        }

        // Search by SKU or name
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('sku', 'ILIKE', "%{$search}%")
                  ->orWhere('name', 'ILIKE', "%{$search}%");
            });
        }

        // Filter by external_product_id
        if ($request->has('external_product_id')) {
            $query->whereRaw(
                "marketplace_external_ids::jsonb -> 'woocommerce' ->> 'external_product_id' = ?",
                [(string) $request->external_product_id]
            );
        }

        // Sort
        $sortBy = $request->get('sort_by', 'updated_at');
        $sortDirection = $request->get('sort_direction', 'desc');
        $query->orderBy($sortBy, $sortDirection);

        $perPage = min((int) $request->get('per_page', 15), 100);
        $products = $query->paginate($perPage);

        return response()->json([
            'data' => $products->items(),
            'meta' => [
                'current_page' => $products->currentPage(),
                'last_page' => $products->lastPage(),
                'per_page' => $products->perPage(),
                'total' => $products->total(),
            ],
        ]);
    }

    /**
     * Display the specified unmapped product.
     * 
     * @param Subsidiary $subsidiary
     * @param Integration $integration
     * @param UnmappedWooCommerceProduct $unmappedProduct
     * @return JsonResponse
     */
    public function show(Subsidiary $subsidiary, Integration $integration, UnmappedWooCommerceProduct $unmappedProduct): JsonResponse
    {
        $this->authorize('view', $unmappedProduct);
        
        // Verify relationships
        if ($integration->subsidiary_id !== $subsidiary->id) {
            abort(404, 'Integration not found for this subsidiary');
        }
        
        if ($unmappedProduct->integration_id !== $integration->id) {
            abort(404, 'Unmapped product not found for this integration');
        }

        $unmappedProduct->load(['integration', 'sale', 'mappedProduct']);

        return response()->json([
            'data' => new UnmappedWooCommerceProductResource($unmappedProduct),
        ]);
    }

    /**
     * Map an unmapped product to an existing product.
     * 
     * @param MapUnmappedProductRequest $request
     * @param Subsidiary $subsidiary
     * @param Integration $integration
     * @param UnmappedWooCommerceProduct $unmappedProduct
     * @return JsonResponse
     */
    public function map(MapUnmappedProductRequest $request, Subsidiary $subsidiary, Integration $integration, UnmappedWooCommerceProduct $unmappedProduct): JsonResponse
    {
        $this->authorize('map', $unmappedProduct);
        
        // Verify relationships
        if ($integration->subsidiary_id !== $subsidiary->id) {
            abort(404, 'Integration not found for this subsidiary');
        }
        
        if ($unmappedProduct->integration_id !== $integration->id) {
            abort(404, 'Unmapped product not found for this integration');
        }

        return DB::transaction(function () use ($request, $unmappedProduct, $subsidiary) {
            $productId = $request->validated('product_id');
            
            /** @var Product $product */
            $product = Product::findOrFail($productId);
            
            // Verify product belongs to a branch of this subsidiary
            $productBranch = $product->branch;
            if (!$productBranch || $productBranch->subsidiary_id !== $subsidiary->id) {
                abort(422, 'Product must belong to a branch of this subsidiary');
            }

            // Update product's marketplace_external_ids
            $meta = $product->marketplace_external_ids ?? [];
            $woo = $meta['woocommerce'] ?? [];
            
            if ($unmappedProduct->external_product_id) {
                $woo['external_product_id'] = $unmappedProduct->external_product_id;
            }
            if ($unmappedProduct->external_variation_id) {
                $woo['external_variation_id'] = $unmappedProduct->external_variation_id;
            }
            
            $woo['last_seen_at'] = now()->toISOString();
            $woo['integration_hint'] = $unmappedProduct->integration_id;
            $meta['woocommerce'] = $woo;
            
            $product->marketplace_external_ids = $meta;
            $product->save();

            // Update unmapped record status
            $unmappedProduct->update([
                'resolution_status' => 'mapped',
                'mapped_product_id' => $product->id,
                'mapped_at' => now(),
            ]);

            // Update ALL related unmapped products with the same external IDs for this integration
            $relatedQuery = UnmappedWooCommerceProduct::where('integration_id', $unmappedProduct->integration_id)
                ->where('resolution_status', 'pending')
                ->where('id', '!=', $unmappedProduct->id);

            if ($unmappedProduct->external_product_id) {
                $relatedQuery->where('external_product_id', $unmappedProduct->external_product_id);
            }
            if ($unmappedProduct->external_variation_id) {
                $relatedQuery->where('external_variation_id', $unmappedProduct->external_variation_id);
            }

            $relatedUnmapped = $relatedQuery->get();
            $relatedCount = $relatedUnmapped->count();

            // Mark all related as mapped
            foreach ($relatedUnmapped as $related) {
                $related->update([
                    'resolution_status' => 'mapped',
                    'mapped_product_id' => $product->id,
                    'mapped_at' => now(),
                ]);

                // Update their sale_items too
                if ($related->sale_id && $related->external_line_id) {
                    DB::table('sale_items')
                        ->where('sale_id', $related->sale_id)
                        ->where('external_line_id', $related->external_line_id)
                        ->update(['product_id' => $product->id]);
                }
            }

            // Update the current sale item
            if ($unmappedProduct->sale_id && $unmappedProduct->external_line_id) {
                DB::table('sale_items')
                    ->where('sale_id', $unmappedProduct->sale_id)
                    ->where('external_line_id', $unmappedProduct->external_line_id)
                    ->update(['product_id' => $product->id]);
            }

            return response()->json([
                'message' => 'Product mapped successfully',
                'related_updated' => $relatedCount,
                'data' => new UnmappedWooCommerceProductResource($unmappedProduct->fresh(['integration', 'sale', 'mappedProduct'])),
            ]);
        });
    }

    /**
     * Unmap a previously mapped product, returning it to pending status.
     * This allows re-mapping the product to a different ERP product.
     * 
     * @param Subsidiary $subsidiary
     * @param Integration $integration
     * @param UnmappedWooCommerceProduct $unmappedProduct
     * @return JsonResponse
     */
    public function unmap(Subsidiary $subsidiary, Integration $integration, UnmappedWooCommerceProduct $unmappedProduct): JsonResponse
    {
        $this->authorize('map', $unmappedProduct); // Using map permission since it's a mapping operation
        
        // Verify relationships
        if ($integration->subsidiary_id !== $subsidiary->id) {
            abort(404, 'Integration not found for this subsidiary');
        }
        
        if ($unmappedProduct->integration_id !== $integration->id) {
            abort(404, 'Unmapped product not found for this integration');
        }

        // Verify product is actually mapped
        if ($unmappedProduct->resolution_status !== 'mapped') {
            abort(422, 'Product is not currently mapped');
        }

        return DB::transaction(function () use ($unmappedProduct) {
            $previousProductId = $unmappedProduct->mapped_product_id;
            
            // Reset unmapped record to pending
            $unmappedProduct->update([
                'resolution_status' => 'pending',
                'mapped_product_id' => null,
                'mapped_at' => null,
            ]);

            // Optional: Remove marketplace_external_ids from the previously mapped product
            if ($previousProductId) {
                /** @var Product|null $product */
                $product = Product::find($previousProductId);
                if ($product) {
                    $meta = $product->marketplace_external_ids ?? [];
                    if (isset($meta['woocommerce'])) {
                        // Only remove if the integration_hint matches
                        if (($meta['woocommerce']['integration_hint'] ?? null) === $unmappedProduct->integration_id) {
                            unset($meta['woocommerce']);
                            $product->marketplace_external_ids = empty($meta) ? null : $meta;
                            $product->save();
                        }
                    }
                }
            }

            // Reset sale_item product_id back to null
            if ($unmappedProduct->sale_id && $unmappedProduct->external_line_id) {
                DB::table('sale_items')
                    ->where('sale_id', $unmappedProduct->sale_id)
                    ->where('external_line_id', $unmappedProduct->external_line_id)
                    ->where('product_id', $previousProductId) // Only if it still points to the old product
                    ->update(['product_id' => null]);
            }

            return response()->json([
                'message' => 'Product unmapped successfully and returned to pending status',
                'data' => new UnmappedWooCommerceProductResource($unmappedProduct->fresh(['integration', 'sale', 'mappedProduct'])),
            ]);
        });
    }

    /**
     * Remove the specified unmapped product (mark as ignored or delete).
     * 
     * @param Subsidiary $subsidiary
     * @param Integration $integration
     * @param UnmappedWooCommerceProduct $unmappedProduct
     * @return JsonResponse
     */
    public function destroy(Subsidiary $subsidiary, Integration $integration, UnmappedWooCommerceProduct $unmappedProduct): JsonResponse
    {
        $this->authorize('delete', $unmappedProduct);
        
        // Verify relationships
        if ($integration->subsidiary_id !== $subsidiary->id) {
            abort(404, 'Integration not found for this subsidiary');
        }
        
        if ($unmappedProduct->integration_id !== $integration->id) {
            abort(404, 'Unmapped product not found for this integration');
        }

        // Mark as ignored instead of deleting
        $unmappedProduct->update([
            'resolution_status' => 'ignored',
        ]);

        return response()->json([
            'message' => 'Unmapped product marked as ignored',
        ]);
    }
}
