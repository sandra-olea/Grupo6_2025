<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\TechnicalReview\StoreTechnicalReviewItemRequest;
use App\Http\Requests\TechnicalReview\ApproveTechnicalReviewItemRequest;
use App\Http\Resources\TechnicalReviewItemResource;
use App\Models\Branch;
use App\Models\Product;
use App\Models\TechnicalReviewItem;
use App\Models\TechnicalReviewBatch;
use App\Services\TechnicalReviewScoringService;
use App\Services\EquipmentTraceabilityService;
use App\Models\EquipmentMovement;
use App\Enums\ReviewStatus;
use App\Enums\EquipmentStatus;
use App\Enums\EquipmentType;
use App\Enums\EquipmentGrade;
use App\Enums\MovementType;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use App\Traits\DispatchesNotifications;

class TechnicalReviewItemController extends Controller
{
    use DispatchesNotifications;
    public function __construct(
        protected TechnicalReviewScoringService $scoringService,
        protected EquipmentTraceabilityService $traceabilityService
    ) {}

    /**
     * Display a listing of items
     */
    public function index(Request $request, Branch $branch): JsonResponse
    {
        $this->authorize('viewAny', TechnicalReviewItem::class);

        $query = TechnicalReviewItem::with([
            'batch',
            'batch.branch',
            'batch.customerSupplier',
            'branch',
            'customerSupplier',
            'warehouse',
            'product',
            'traceability.warehouse',
            'createdBy',
            'reviewedBy',
            'approvedBy',
        ])->byBranch($branch->id);

        // Filtros
        if ($request->filled('batch_id')) {
            $query->where('batch_id', $request->batch_id);
        }

        if ($request->filled('warehouse_id')) {
            $query->where('warehouse_id', $request->warehouse_id);
        }

        if ($request->filled('equipment_type')) {
            try {
                $query->byEquipmentType(EquipmentType::from($request->equipment_type));
            } catch (\ValueError $e) {
                // Ignorar filtros inválidos
            }
        }

        if ($request->filled('review_status')) {
            try {
                $query->byReviewStatus(ReviewStatus::from($request->review_status));
            } catch (\ValueError $e) {
                // Ignorar filtros inválidos
            }
        }

        if ($request->filled('current_status')) {
            try {
                $status = EquipmentStatus::from($request->current_status);
                $query->where('current_status', $status->value);
            } catch (\ValueError $e) {
                // Ignorar filtros inválidos
            }
        }

        if ($request->filled('grade')) {
            try {
                $query->byGrade(EquipmentGrade::from($request->grade));
            } catch (\ValueError $e) {
                // Ignorar filtros inválidos
            }
        }

        if ($request->filled('serial_number')) {
            $query->bySerialNumber($request->serial_number);
        }

        // Búsqueda por texto
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('serial_number', 'ILIKE', "%{$search}%")
                  ->orWhereHas('product', function ($q) use ($search) {
                      $q->where('name', 'ILIKE', "%{$search}%");
                  });
            });
        }

        $items = $query->latest()->paginate($request->get('per_page', 15));

        // Cargar relaciones de detalles específicas según tipo de equipo
        $items->getCollection()->each(function ($item) {
            $detailsRelation = $this->getDetailsRelationName($item->equipment_type);
            if ($detailsRelation) {
                $item->load($detailsRelation);
            }
        });

        return response()->json([
            'success' => true,
            'data' => TechnicalReviewItemResource::collection($items),
            'meta' => [
                'current_page' => $items->currentPage(),
                'last_page' => $items->lastPage(),
                'per_page' => $items->perPage(),
                'total' => $items->total(),
            ],
        ]);
    }

    /**
     * Store a newly created item
     */
    public function store(StoreTechnicalReviewItemRequest $request, Branch $branch): JsonResponse
    {
        $this->authorize('create', TechnicalReviewItem::class);

        DB::beginTransaction();
        try {
            $batch = TechnicalReviewBatch::where('branch_id', $branch->id)->findOrFail($request->batch_id);

            $product = null;
            $equipmentTypeValue = $request->equipment_type;

            if ($request->filled('product_id')) {
                $product = Product::where('branch_id', $branch->id)
                    ->find($request->product_id);

                if (! $product) {
                    throw ValidationException::withMessages([
                        'product_id' => ['El producto seleccionado no pertenece a la sucursal indicada.'],
                    ]);
                }

                if (! $product->serial_tracking) {
                    throw ValidationException::withMessages([
                        'product_id' => ['El producto seleccionado no permite seguimiento por serie y no puede asociarse a una revisión técnica.'],
                    ]);
                }

                $resolvedType = $this->resolveEquipmentTypeFromProduct($product);

                if (! $resolvedType) {
                    throw ValidationException::withMessages([
                        'product_id' => ['El producto seleccionado no tiene configurado un tipo de equipo compatible para revisión técnica.'],
                    ]);
                }

                $equipmentTypeValue = $resolvedType->value;
            }

            $item = TechnicalReviewItem::create([
                'batch_id' => $batch->id,
                'branch_id' => $batch->branch_id,
                'warehouse_id' => $batch->warehouse_id,
                'customer_supplier_id' => $batch->customer_supplier_id,
                'serial_number' => strtoupper($request->serial_number),
                'product_id' => $product?->id ?? $request->product_id,
                'equipment_type' => $equipmentTypeValue,
                // Al crear el ítem queda Pendiente de revisión. El cambio a EN REVISIÓN
                // ocurre explícitamente vía startReview(), según el flujo requerido.
                'review_status' => ReviewStatus::PENDING,
                'current_status' => EquipmentStatus::RECEIVED,
                'review_started_at' => null,
                'created_by' => auth()->id(),
            ]);

            // Inicializar trazabilidad en estado RECEIVED. No mover a IN_REVIEW
            // hasta que se ejecute startReview() manualmente.
            $this->traceabilityService->initializeTraceability($item);

            DB::commit();

            $item = $this->loadItemWithRelations($item);

            return response()->json([
                'success' => true,
                'message' => 'Equipo agregado exitosamente',
                'data' => new TechnicalReviewItemResource($item),
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al agregar equipo: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Display the specified item
     */
    public function show(Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('view', $item);

        $item = $this->loadItemWithRelations($item);

        return response()->json([
            'success' => true,
            'data' => new TechnicalReviewItemResource($item),
        ]);
    }

    public function indexByBatch(Request $request, Branch $branch, TechnicalReviewBatch $batch): JsonResponse
    {
        $batch = $this->ensureBatchBelongsToBranch($branch, $batch);
        $request->merge(['batch_id' => $batch->id]);

        return $this->index($request, $branch);
    }

    /**
     * Update the specified item
     */
    public function update(Request $request, Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('update', $item);

        $validated = $request->validate([
            'product_id' => 'sometimes|exists:products,id',
        ]);

        $item->update([
            ...$validated,
            'updated_by' => auth()->id(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Equipo actualizado exitosamente',
            'data' => new TechnicalReviewItemResource($this->loadItemWithRelations($item->fresh())),
        ]);
    }

    /**
     * Remove the specified item
     */
    public function destroy(Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('delete', $item);

        if ($item->review_status !== ReviewStatus::PENDING) {
            return response()->json([
                'success' => false,
                'message' => 'No se puede eliminar un equipo que ya está en revisión o aprobado',
            ], 422);
        }

        DB::beginTransaction();
        try {
            // Eliminar trazabilidad
            $item->traceability?->delete();

            $item->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Equipo eliminado exitosamente',
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al eliminar equipo: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Start technical review for an item
     */
    public function startReview(Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('review', $item);

        if ($item->review_status !== ReviewStatus::PENDING) {
            return response()->json([
                'success' => false,
                'message' => 'Este equipo ya está en revisión o fue aprobado',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $item->update([
                'review_status' => ReviewStatus::IN_REVIEW,
                'reviewed_by' => auth()->id(),
                'review_started_at' => $item->review_started_at ?? now(),
                'updated_by' => auth()->id(),
            ]);

            // Cambiar estado de trazabilidad
            if ($item->traceability) {
                $this->traceabilityService->changeStatus(
                    $item->traceability,
                    EquipmentStatus::IN_REVIEW,
                    'Revisión técnica iniciada'
                );
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Revisión técnica iniciada',
                'data' => new TechnicalReviewItemResource($this->loadItemWithRelations($item->fresh())),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al iniciar revisión: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Update technical details for an item
     */
    public function updateDetails(Request $request, Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('review', $item);

        if ($item->review_status === ReviewStatus::APPROVED) {
            return response()->json([
                'success' => false,
                'message' => 'No se pueden modificar los detalles de un equipo aprobado',
            ], 422);
        }

        DB::beginTransaction();
        try {
            // Obtener el modelo de detalles según el tipo
            $detailsModel = $item->details();

            if (!$detailsModel) {
                return response()->json([
                    'success' => false,
                    'message' => 'Tipo de equipo no válido',
                ], 422);
            }

            // Validación dinámica según tipo de equipo
            $rules = $this->getValidationRulesForEquipmentType($item->equipment_type->value);

            // Normalizaciones previas del payload (alias y formatos comunes)
            $payload = $request->all();
            // Aceptar alias mal tipeado 'proccessor' -> 'processor'
            if (isset($payload['proccessor']) && !isset($payload['processor'])) {
                $payload['processor'] = $payload['proccessor'];
            }
            // Normalizar charger_status según tipo: AIO (top-level EN), Notebook (extra_attributes ES)
            if (isset($payload['charger_status'])) {
                $raw = $this->toSnakeLower((string) $payload['charger_status']);
                if (in_array($item->equipment_type->value, ['aio','desktop'], true)) {
                    // Mapear ES->EN para AIO
                    $mapEsToEn = [
                        'buen_estado' => 'good_condition',
                        'cable_en_mal_estado' => 'damaged_cable',
                        'no_corresponde_a_equipo' => 'not_matching_equipment',
                        'no_incluye' => 'not_included',
                    ];
                    $payload['charger_status'] = $mapEsToEn[$raw] ?? $raw;
                } else {
                    // Mapear EN->ES y mover a extra_attributes para notebooks (y otros no-AIO)
                    $mapEnToEs = [
                        'good_condition' => 'buen_estado',
                        'damaged_cable' => 'cable_en_mal_estado',
                        'not_matching_equipment' => 'no_corresponde_a_equipo',
                        'not_included' => 'no_incluye',
                    ];
                    $valueEs = $mapEnToEs[$raw] ?? $raw;
                    $payload['extra_attributes'] = $payload['extra_attributes'] ?? [];
                    $payload['extra_attributes']['charger_status'] = $valueEs;
                    unset($payload['charger_status']);
                }
            }
            // (power_cable_status ya no se utiliza)

            $validator = Validator::make($payload, $rules);
            $hasFailures = $validator->fails();
            $errorsBag = $validator->errors();
            // Tomar solo campos válidos
            $validated = $validator->safe()->only(array_keys($rules));

            // Normalizar battery_status permitido como porcentaje ("85" o "85%")
            if (array_key_exists('battery_status', $payload)) {
                $raw = $payload['battery_status'];
                $percent = $this->parseBatteryPercentage($raw);
                if ($percent !== null) {
                    $validated['battery_percentage'] = $percent;
                    $validated['battery_status'] = $this->batteryStatusFromPercentage($percent);
                }
            }

            // Asignar charger_status validado si corresponde (AIO top-level)
            if (isset($payload['charger_status'])) {
                $allowedCharger = ['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'];
                if (in_array($payload['charger_status'], $allowedCharger, true)) {
                    $validated['charger_status'] = $payload['charger_status'];
                }
            }
            // Normalizar extra_attributes.charger_status (Notebook) a tokens ES válidos
            if (data_get($payload, 'extra_attributes.charger_status') !== null) {
                $rawCharger = (string) data_get($payload, 'extra_attributes.charger_status');
                $normalizedCharger = $this->toSnakeLower($rawCharger);
                $allowedEs = ['buen_estado', 'cable_en_mal_estado', 'no_corresponde_a_equipo', 'no_incluye'];
                if (in_array($normalizedCharger, $allowedEs, true)) {
                    $extra = (array) ($validated['extra_attributes'] ?? data_get($payload, 'extra_attributes', []));
                    $extra['charger_status'] = $normalizedCharger;
                    $validated['extra_attributes'] = $extra;
                }
            }
            // (power_cable_status ya no se utiliza)

            // Aliases específicos por tipo de equipo
            $equipmentTypeValue = $item->equipment_type->value;
            if ($equipmentTypeValue === 'aio') {
                // includes_charger -> includes_power_adapter
                if (array_key_exists('includes_charger', $payload)) {
                    $validated['includes_power_adapter'] = (bool) $payload['includes_charger'];
                }
                // usb_a_ports -> usb_ports_count
                if (array_key_exists('usb_a_ports', $payload)) {
                    $validated['usb_ports_count'] = (int) $payload['usb_a_ports'];
                }
            }

            // Normalizar keyboard_layout a minúsculas (acepta ES/US/LATAM)
            if ($request->has('keyboard_layout')) {
                $layout = strtolower((string) $request->input('keyboard_layout'));
                $allowedLayouts = ['es', 'us', 'latam'];
                if (in_array($layout, $allowedLayouts, true)) {
                    $validated['keyboard_layout'] = $layout;
                }
            }

            // Normalizar storage_technology (acepta "M.2" -> "M2", case-insensitive)
            if (isset($payload['storage_technology'])) {
                $rawTech = (string) $payload['storage_technology'];
                $normTech = strtoupper(str_replace(['.', ' '], '', trim($rawTech)));
                $allowedTech = ['HDD', 'SSD', 'M2', 'NVME', 'HYBRID'];
                if (in_array($normTech, $allowedTech, true)) {
                    $validated['storage_technology'] = $normTech;
                }
            }

            // Crear o actualizar detalles de forma robusta
            $existing = $detailsModel->first();
            if (!$existing) {
                $existing = $detailsModel->create(['review_item_id' => $item->id]);
            }
            if (!empty($validated)) {
                $existing->fill($validated);
                $existing->save();
            }

            DB::commit();

            // Recargar el item con todas sus relaciones, incluyendo los detalles específicos
            $item = $this->loadItemWithRelations($item->fresh());

            $payload = [
                'success' => true,
                'message' => 'Detalles técnicos actualizados exitosamente',
                'data' => new TechnicalReviewItemResource($item),
            ];

            if ($hasFailures) {
                $allMessages = $errorsBag->all();
                $firstMessage = $allMessages[0] ?? 'Algunos campos no se pudieron validar';
                $remaining = max(count($allMessages) - 1, 0);
                $summary = $remaining > 0
                    ? $firstMessage . ' (y ' . $remaining . ' errores más)'
                    : $firstMessage;

                $availableOptions = $this->getAvailableOptionsForEquipmentType($item->equipment_type->value);
                // Indicar formatos aceptados para battery_status
                if (!isset($availableOptions['battery_status_formats'])) {
                    $availableOptions['battery_status_formats'] = [
                        'enum' => ['excellent', 'good', 'fair', 'poor', 'no_battery'],
                        'percentage' => '0-100 o "NN%"',
                    ];
                }

                $payload['warnings'] = [
                    'message' => $summary,
                    'errors' => $errorsBag->toArray(),
                    'available_options' => $availableOptions,
                ];
            }

            return response()->json($payload);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al actualizar detalles: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Calculate suggested grade for an item
     */
    public function calculateSuggestedGrade(Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('review', $item);

        if (!$item->details) {
            return response()->json([
                'success' => false,
                'message' => 'Debe completar los detalles técnicos antes de calcular el grado',
            ], 422);
        }

        $result = $this->scoringService->calculateGrade($item);

        return response()->json([
            'success' => true,
            'data' => $result,
        ]);
    }

    /**
     * Complete review and mark as reviewed
     */
    public function completeReview(Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('review', $item);

        if ($item->review_status !== ReviewStatus::IN_REVIEW) {
            return response()->json([
                'success' => false,
                'message' => 'Este equipo no está en revisión',
            ], 422);
        }

        if (!$item->details) {
            return response()->json([
                'success' => false,
                'message' => 'Debe completar los detalles técnicos antes de finalizar la revisión',
            ], 422);
        }

        DB::beginTransaction();
        try {
            // Calcular grado sugerido
            $scoring = $this->scoringService->calculateGrade($item);

            $item->update([
                'review_status' => ReviewStatus::REVIEWED,
                'suggested_grade' => $scoring['suggested_grade'],
                'scoring_confidence' => $scoring['confidence'],
                'scoring_breakdown' => $scoring['breakdown'],
                'reviewed_at' => now(),
                'updated_by' => auth()->id(),
            ]);

            $item->batch?->increment('completed_quantity');

            // Cambiar estado de trazabilidad
            if ($item->traceability) {
                $this->traceabilityService->changeStatus(
                    $item->traceability,
                    EquipmentStatus::REVIEWED,
                    'Revisión técnica completada - Grado sugerido: ' . $scoring['suggested_grade']
                );
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Revisión completada exitosamente',
                'data' => new TechnicalReviewItemResource($this->loadItemWithRelations($item->fresh())),
                'scoring' => $scoring,
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al completar revisión: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Approve item with final grade
     */
    public function approve(ApproveTechnicalReviewItemRequest $request, Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('approve', $item);

        if ($item->review_status !== ReviewStatus::REVIEWED) {
            return response()->json([
                'success' => false,
                'message' => 'El equipo debe estar revisado antes de aprobar',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $override = $request->boolean('override_suggestion', false)
                || ($item->suggested_grade !== null && $request->grade !== $item->suggested_grade);

            $item->update([
                'review_status' => ReviewStatus::APPROVED,
                'grade' => $request->grade,
                'override_suggestion' => $override,
                'override_reason' => $override ? $request->override_reason : null,
                'approved_by' => auth()->id(),
                'approved_at' => now(),
                'updated_by' => auth()->id(),
            ]);

            // Asegurar consistencia de catálogo por grados: crear hijos A/B/C/M si faltan
            try {
                if ($item->product && $item->product->serial_tracking && !$item->product->parent_product_id) {
                    $item->product->ensureGradeChildren();
                }
            } catch (\Throwable $e) {
                // No bloquear aprobación si falla la generación de hijos
            }

            // Política: al aprobar, el equipo queda disponible para venta (incrementa stock del hijo por grado)
            // Preferimos trazabilidad; si no existe, hacemos fallback directo en el ítem.
            try {
                if ($item->traceability) {
                    // Cambiar a AVAILABLE_FOR_SALE solo si no está reservado/en cotización/vendido
                    $blocked = [EquipmentStatus::RESERVED, EquipmentStatus::IN_QUOTATION, EquipmentStatus::SOLD];
                    if (!in_array($item->traceability->status, $blocked, true)) {
                        $this->traceabilityService->changeStatus(
                            $item->traceability,
                            EquipmentStatus::AVAILABLE_FOR_SALE,
                            'Revisión aprobada: disponible para venta'
                        );
                    }
                } else {
                    // Fallback: actualizar estado actual del ítem si no hay trazabilidad y no está reservado/vendido
                    $blocked = ['reserved','in_quotation','sold'];
                    if (!in_array((string)$item->current_status, $blocked, true)) {
                        $item->update(['current_status' => EquipmentStatus::AVAILABLE_FOR_SALE]);
                    }
                }
            } catch (\Throwable $e) {
                // En caso de error, como último recurso dejar el ítem disponible
                try {
                    $item->update(['current_status' => EquipmentStatus::AVAILABLE_FOR_SALE]);
                } catch (\Throwable $e2) {}
            }

            DB::commit();

            // Si la trazabilidad fue reabierta desde otro estado, restaurarlo
            try {
                if ($item->traceability && $item->traceability->status === EquipmentStatus::IN_REVIEW) {
                    $movement = EquipmentMovement::where('traceability_id', $item->traceability->id)
                        ->where('movement_type', MovementType::STATUS_CHANGE)
                        ->whereNotNull('metadata->resume_to')
                        ->orderByDesc('movement_date')
                        ->first();
                    if ($movement) {
                        $target = EquipmentStatus::from($movement->metadata['resume_to']);
                        if ($target && $item->traceability->status->canTransitionTo($target)) {
                            $this->traceabilityService->changeStatus(
                                $item->traceability,
                                $target,
                                'Revisión aprobada (restaurado estado previo)'
                            );
                        }
                    }
                }
            } catch (\Throwable $e) {
                // No interrumpir la aprobación si falla la restauración
            }

            $this->dispatchNotification(
                typeKey: 'technical-review.item-approved',
                entityType: 'technical-review-item',
                entityId: $item->id,
                scope: $this->branchScope($branch),
                payload: array_merge(
                    [
                        'batch_code' => optional($item->batch)->code,
                        'equipment_type' => $item->equipment_type?->value,
                        'grade' => $item->grade?->value ?? $request->grade,
                        'serial_number' => $item->serial_number,
                        'warehouse_name' => optional($item->warehouse)->name,
                    ],
                    $this->currentUserPayload('approved_by')
                )
            );

            return response()->json([
                'success' => true,
                'message' => 'Equipo aprobado exitosamente',
                'data' => new TechnicalReviewItemResource($this->loadItemWithRelations($item->fresh())),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al aprobar equipo: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Reopen a completed/approved review setting it back to pending
     */
    public function reopenReview(Branch $branch, TechnicalReviewItem $item): JsonResponse
    {
        $item = $this->ensureItemBelongsToBranch($branch, $item);
        $this->authorize('review', $item);

        if (!in_array($item->review_status, [ReviewStatus::REVIEWED, ReviewStatus::APPROVED], true)) {
            return response()->json([
                'success' => false,
                'message' => 'Solo puedes reabrir equipos con revisión completada (Revisado o Aprobado).',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $wasCountedAsCompleted = in_array($item->review_status, [ReviewStatus::REVIEWED, ReviewStatus::APPROVED], true);

            // Solo cambiamos el estado y el updated_by; mantenemos el resto intacto
            $item->update([
                'review_status' => ReviewStatus::IN_REVIEW,
                'updated_by' => auth()->id(),
            ]);

            if ($wasCountedAsCompleted && $item->batch && ($item->batch->completed_quantity ?? 0) > 0) {
                $item->batch->decrement('completed_quantity');
            }

            // Cambiar estado de trazabilidad a IN_REVIEW y registrar movimiento con 'resume_to'
            if ($item->traceability) {
                $previousTraceStatus = $item->traceability->status;
                $this->traceabilityService->changeStatus(
                    $item->traceability,
                    EquipmentStatus::IN_REVIEW,
                    'Revisión reabierta',
                    ['resume_to' => $previousTraceStatus?->value]
                );
            }
            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Revisión reabierta y equipo marcado como En Revisión',
                'data' => new TechnicalReviewItemResource($this->loadItemWithRelations($item->fresh())),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al reabrir la revisión: ' . $e->getMessage(),
            ], 500);
        }
    }

    private function ensureItemBelongsToBranch(Branch $branch, TechnicalReviewItem $item): TechnicalReviewItem
    {
        if ((int) $item->branch_id !== (int) $branch->id) {
            abort(404);
        }

        $item->loadMissing('batch');

        return $item;
    }

    private function ensureBatchBelongsToBranch(Branch $branch, TechnicalReviewBatch $batch): TechnicalReviewBatch
    {
        if ($batch->branch_id !== $branch->id) {
            abort(404);
        }

        return $batch;
    }

    private function itemRelations(): array
    {
        return [
            'batch',
            'batch.branch',
            'batch.customerSupplier',
            'branch',
            'customerSupplier',
            'warehouse',
            'product',
            'traceability',
            'traceability.currentResponsible',
            'traceability.sale',
            'traceability.customer',
            'traceability.warehouse',
            'traceability.movements.performedBy',
            'createdBy',
            'reviewedBy',
            'approvedBy',
        ];
    }

    /**
     * Load item relations including polymorphic details based on equipment type
     */
    private function loadItemWithRelations($item)
    {
        $item->load($this->itemRelations());
        
        // Cargar la relación de detalles específica según el tipo de equipo
        $detailsRelation = $this->getDetailsRelationName($item->equipment_type);
        if ($detailsRelation) {
            $item->load($detailsRelation);
        }
        
        return $item;
    }

    /**
     * Get the specific details relation name based on equipment type
     */
    private function getDetailsRelationName($equipmentType): ?string
    {
        if (!$equipmentType instanceof EquipmentType) {
            return null;
        }

        return match($equipmentType) {
            EquipmentType::NOTEBOOK => 'notebookDetails',
            EquipmentType::DESKTOP => 'desktopDetails',
            EquipmentType::DOCKING => 'dockingDetails',
            EquipmentType::AIO => 'aioDetails',
            EquipmentType::MONITOR => 'monitorDetails',
            default => null,
        };
    }

    private function resolveEquipmentTypeFromProduct(Product $product): ?EquipmentType
    {
        $kind = strtolower((string) data_get($product->attributes_json, 'product_kind', ''));

        return match ($kind) {
            'desktop_pc' => EquipmentType::DESKTOP,
            'notebook' => EquipmentType::NOTEBOOK,
            'aio' => EquipmentType::AIO,
            'docking' => EquipmentType::DOCKING,
            'monitor' => EquipmentType::MONITOR,
            default => null,
        };
    }

    /**
     * Get validation rules based on equipment type
     */
    protected function getValidationRulesForEquipmentType(string $equipmentType): array
    {
        $generalConditionRule = ['nullable', 'string', Rule::in(['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'])];
        $componentConditionRule = ['nullable', 'string', Rule::in(['ok', 'worn', 'missing_pieces', 'broken'])];
        $componentConditionWithScratched = ['nullable', 'string', Rule::in(['ok', 'worn', 'missing_pieces', 'scratched', 'broken'])];
        $desktopCoverConditionRule = ['nullable', 'string', Rule::in(['ok', 'good_condition', 'light_scratches', 'noticeable_wear', 'broken'])];
        $screenConditionRule = ['nullable', 'string', Rule::in(['ok', 'minor_wear', 'worn', 'missing_pieces', 'dead_pixels', 'broken'])];
        $coverConditionRule = ['nullable', 'string', Rule::in(['ok', 'minor_wear', 'worn', 'missing_pieces', 'scratched', 'broken'])];
        $standConditionRule = ['nullable', 'string', Rule::in(['ok', 'worn', 'missing_pieces', 'scratched', 'broken', 'no_stand'])];
        $batteryConditionRule = ['nullable', 'string', Rule::in(['excellent', 'good', 'fair', 'regular', 'poor', 'bad', 'no_battery'])];
        // Acepta valores Dell (excellent/good/fair/poor/no_battery) o porcentajes numéricos (0-100 o "NN%")
        $batteryStatusRule = ['nullable'];

        $commonRules = [
            'brand' => 'nullable|string|max:255',
            'model' => 'nullable|string|max:255',
            'general_condition' => $generalConditionRule,
            'observations' => 'nullable|string',
            'extra_attributes' => 'nullable|array',
        ];

        $specificRules = match ($equipmentType) {
            'notebook' => [
                'line' => 'nullable|string',
                'processor' => 'nullable|string',
                'ram_size' => 'nullable|string',
                'ram_slots' => 'nullable|string',
                'ram_type' => 'nullable|string',
                'storage_size' => 'nullable|string',
                'storage_technology' => 'nullable|string',
                'includes_charger' => 'sometimes|boolean',
                'charger_watts' => 'nullable|string',
                // Estado del cargador (en extra_attributes) con tokens en minúscula
                'extra_attributes.charger_status' => ['nullable', 'string', Rule::in(['buen_estado', 'cable_en_mal_estado', 'no_corresponde_a_equipo', 'no_incluye'])],
                'screen_inches' => 'nullable|string',
                'screen_condition' => $screenConditionRule,
                'cover_condition' => $coverConditionRule,
                'keyboard_condition' => $componentConditionRule,
                'keyboard_layout' => 'nullable|string',
                'hinge_condition' => $componentConditionRule,
                'battery_health' => 'nullable|string',
                'battery_condition' => $batteryConditionRule,
                'battery_status' => $batteryStatusRule,
                'battery_percentage' => 'nullable|integer|min:0|max:100',
                'operating_system' => 'nullable|string',
                // Puertos como cantidades
                'vga_ports' => 'nullable|integer|min:0',
                'hdmi_ports' => 'nullable|integer|min:0',
                'displayport_ports' => 'nullable|integer|min:0',
                'usb_c_ports' => 'nullable|integer|min:0',
                'sd_readers' => 'nullable|integer|min:0',
                'rj45_ports' => 'nullable|integer|min:0',
                'usb_a_ports' => 'nullable|integer|min:0',
                'has_biometric' => 'nullable|boolean',
                'has_wifi' => 'nullable|boolean',
                'has_bluetooth' => 'nullable|boolean',
                'all_ports_functional' => 'nullable|boolean',
                'defective_ports_count' => 'nullable|integer|min:0|max:10',
                'is_touchscreen' => 'nullable|boolean',
                'touchpad_condition' => $componentConditionRule,
                'bottom_condition' => $componentConditionWithScratched,
                'has_numeric_keypad' => 'nullable|boolean',
                'has_backlit_keyboard' => 'nullable|boolean',
            ],
            'desktop' => [
                'line' => 'nullable|string',
                'processor' => 'nullable|string',
                'ram_size' => 'nullable|string',
                'ram_slots' => 'nullable|string',
                'ram_type' => 'nullable|string',
                'storage_size' => 'nullable|string',
                'storage_technology' => 'nullable|string',
                'includes_charger' => 'nullable|boolean',
                'charger_status' => ['nullable', 'string', Rule::in(['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'])],
                'cover_condition' => $desktopCoverConditionRule,
                // Puertos como cantidades
                'vga_ports' => 'nullable|integer|min:0',
                'hdmi_ports' => 'nullable|integer|min:0',
                'displayport_ports' => 'nullable|integer|min:0',
                'usb_c_ports' => 'nullable|integer|min:0',
                'sd_readers' => 'nullable|integer|min:0',
                'rj45_ports' => 'nullable|integer|min:0',
                'usb_a_ports' => 'nullable|integer|min:0',
                'has_wifi' => 'nullable|boolean',
                'has_bluetooth' => 'nullable|boolean',
                'all_ports_functional' => 'nullable|boolean',
                'defective_ports_count' => 'nullable|integer|min:0|max:10',
                'has_cd_drive' => 'nullable|boolean',
                'operating_system' => 'nullable|string',
            ],
            'docking' => [
                'line' => 'nullable|string',
                'includes_power_adapter' => 'nullable|boolean',
                // Puertos como cantidades
                'vga_ports' => 'nullable|integer|min:0',
                'hdmi_ports' => 'nullable|integer|min:0',
                'displayport_ports' => 'nullable|integer|min:0',
                'usb_c_ports' => 'nullable|integer|min:0',
                'sd_readers' => 'nullable|integer|min:0',
                'has_wifi' => 'nullable|boolean',
                'all_ports_functional' => 'nullable|boolean',
                'defective_ports_count' => 'nullable|integer|min:0|max:10',
                'rj45_ports' => 'nullable|integer|min:0',
                'usb_a_ports' => 'nullable|integer|min:0',
                'cover_condition' => $componentConditionWithScratched,
            ],
            'aio' => [
                'line' => 'nullable|string',
                'processor' => 'nullable|string',
                'ram_size' => 'nullable|string',
                'ram_slots' => 'nullable|string',
                'ram_type' => 'nullable|string',
                'storage_size' => 'nullable|string',
                'storage_technology' => 'nullable|string',
                'screen_inches' => 'nullable|string',
                'screen_condition' => $screenConditionRule,
                'stand_condition' => $standConditionRule,
                'includes_power_adapter' => 'nullable|boolean',
                'includes_charger' => 'nullable|boolean',
                'charger_status' => ['nullable', 'string', Rule::in(['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'])],
                // Puertos como cantidades
                'vga_ports' => 'nullable|integer|min:0',
                'hdmi_ports' => 'nullable|integer|min:0',
                'displayport_ports' => 'nullable|integer|min:0',
                'usb_a_ports' => 'nullable|integer|min:0',
                'usb_c_ports' => 'nullable|integer|min:0',
                'sd_readers' => 'nullable|integer|min:0',
                'rj45_ports' => 'nullable|integer|min:0',
                // Conectividad/otros
                'has_touch' => 'nullable|boolean',
                'has_wifi' => 'nullable|boolean',
                'has_bluetooth' => 'nullable|boolean',
                'all_ports_functional' => 'nullable|boolean',
                'defective_ports_count' => 'nullable|integer|min:0|max:10',
                'cover_condition' => $componentConditionWithScratched,
                'operating_system' => 'nullable|string',
            ],
            'monitor' => [
                'line' => 'nullable|string',
                'screen_inches' => 'nullable|string',
                'screen_condition' => $screenConditionRule,
                'stand_condition' => $standConditionRule,
                'includes_power_cable' => 'nullable|boolean',
                'includes_video_cable' => 'nullable|boolean',
                'includes_stand' => 'nullable|boolean',
                'has_usb_hub' => 'nullable|boolean',
                // Puertos como cantidades
                'vga_ports' => 'nullable|integer|min:0',
                'hdmi_ports' => 'nullable|integer|min:0',
                'displayport_ports' => 'nullable|integer|min:0',
                'dvi_ports' => 'nullable|integer|min:0',
                'usb_hub_ports' => 'nullable|integer|min:0',
                'all_ports_functional' => 'nullable|boolean',
                'defective_ports_count' => 'nullable|integer|min:0|max:10',
                'defective_ports_critical_count' => 'nullable|integer|min:0|max:10',
                'frame_condition' => $componentConditionWithScratched,
                'screen_resolution' => 'nullable|string',
            ],
            default => [],
        };

        return array_merge($commonRules, $specificRules);
    }

    // Extra: helpers de batería
    private function parseBatteryPercentage(mixed $value): ?int
    {
        if ($value === null || $value === '') return null;
        if (is_numeric($value)) {
            $n = (int) $value;
            return max(0, min(100, $n));
        }
        if (is_string($value) && preg_match('/^\s*(\d{1,3})\s*%\s*$/', $value, $m)) {
            $n = (int) $m[1];
            return max(0, min(100, $n));
        }
        return null;
    }

    private function batteryStatusFromPercentage(int $percent): string
    {
        if ($percent <= 0) return 'no_battery';
        if ($percent >= 80) return 'excellent';
        if ($percent >= 60) return 'good';
        if ($percent >= 40) return 'fair';
        return 'poor';
    }

    private function toSnakeLower(string $value): string
    {
        $v = trim($value);
        if ($v === '') {
            return $v;
        }
        // Convertir a minúsculas con soporte UTF-8
        $v = function_exists('mb_strtolower') ? mb_strtolower($v, 'UTF-8') : strtolower($v);
        // Reemplazar cualquier separador/no alfanumérico por guión bajo
        $v = preg_replace('/[^a-z0-9]+/u', '_', $v) ?? $v;
        // Quitar guiones bajos sobrantes al inicio/fin
        return trim($v, '_');
    }

    /**
     * List required fields per equipment type.
     */
    protected function getRequiredFieldsForEquipmentType(string $equipmentType): array
    {
        return match ($equipmentType) {
            'notebook' => [
                'processor',
                'ram_size',
                'ram_slots',
                'ram_type',
                'storage_size',
                'storage_technology',
                'screen_inches',
                'keyboard_layout',
            ],
            'desktop' => [
                'processor',
                'ram_size',
                'ram_type',
                'storage_size',
                'storage_technology',
            ],
            'aio' => [
                'processor',
                'ram_size',
                'ram_type',
                'storage_size',
                'storage_technology',
                'screen_inches',
            ],
            'monitor' => [
                'screen_inches',
            ],
            default => [],
        };
    }

    /**
     * Provide available options (enums, booleans) for fields by equipment type.
     */
    protected function getAvailableOptionsForEquipmentType(string $equipmentType): array
    {
        $options = [
            'general_condition' => ['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'],
            'component_condition' => ['ok', 'worn', 'missing_pieces', 'broken'],
            'component_condition_with_scratched' => ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'],
            'screen_condition' => ['ok', 'worn', 'missing_pieces', 'dead_pixels', 'broken'],
            'cover_condition' => ['ok', 'minor_wear', 'worn', 'missing_pieces', 'scratched', 'broken'],
            'stand_condition' => ['ok', 'worn', 'missing_pieces', 'broken', 'no_stand'],
            'battery_status' => ['excellent', 'good', 'fair', 'poor', 'no_battery'],
            'boolean' => [true, false],
            'storage_technology' => ['HDD', 'SSD', 'M2', 'NVME', 'HYBRID'],
            'keyboard_layout' => ['es', 'us', 'latam'],
        ];

        $base = [
            'general_condition' => $options['general_condition'],
        ];

        return match ($equipmentType) {
            'notebook' => $base + [
                'screen_condition' => $options['screen_condition'],
                'cover_condition' => $options['cover_condition'],
                'keyboard_condition' => $options['component_condition'],
                'hinge_condition' => $options['component_condition'],
                'battery_status' => $options['battery_status'],
                'storage_technology' => $options['storage_technology'],
                'keyboard_layout' => $options['keyboard_layout'],
                'touchpad_condition' => $options['component_condition'],
                'bottom_condition' => $options['component_condition_with_scratched'],
                // Puertos: ejemplos de cantidades
                'vga_ports' => [0,1,2,3],
                'hdmi_ports' => [0,1,2,3],
                'displayport_ports' => [0,1,2,3],
                'usb_c_ports' => [0,1,2,3],
                'sd_readers' => [0,1,2],
                'rj45_ports' => [0,1,2],
                'usb_a_ports' => [0,1,2,3,4],
                'defective_ports_count' => [0,1,2,3],
                'has_biometric' => $options['boolean'],
                'has_wifi' => $options['boolean'],
                'has_bluetooth' => $options['boolean'],
                'all_ports_functional' => $options['boolean'],
                'is_touchscreen' => $options['boolean'],
                'has_numeric_keypad' => $options['boolean'],
                'has_backlit_keyboard' => $options['boolean'],
                'includes_charger' => $options['boolean'],
                'extra_attributes.charger_status' => ['buen_estado', 'cable_en_mal_estado', 'no_corresponde_a_equipo', 'no_incluye'],
            ],
            'docking' => $base + [
                'cover_condition' => $options['component_condition_with_scratched'],
                'includes_power_adapter' => $options['boolean'],
                'vga_ports' => [0,1,2,3],
                'hdmi_ports' => [0,1,2,3],
                'displayport_ports' => [0,1,2,3],
                'usb_c_ports' => [0,1,2,3],
                'sd_readers' => [0,1,2],
                'rj45_ports' => [0,1,2],
                'usb_a_ports' => [0,1,2,3,4,6,8],
                'has_wifi' => $options['boolean'],
                'all_ports_functional' => $options['boolean'],
            ],
            'desktop' => $base + [
                'line' => [],
                'cover_condition' => ['ok','good_condition','light_scratches','noticeable_wear','broken'],
                'includes_charger' => $options['boolean'],
                'charger_status' => ['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'],
                'storage_technology' => $options['storage_technology'],
                'ram_slots' => ['4x1','4x2','8x1','8x2','16x1','16x2'],
                'vga_ports' => [0,1,2,3],
                'hdmi_ports' => [0,1,2,3],
                'displayport_ports' => [0,1,2,3],
                'usb_c_ports' => [0,1,2,3],
                'sd_readers' => [0,1,2],
                'rj45_ports' => [0,1,2],
                'usb_a_ports' => [0,1,2,3,4,6,8],
                'has_wifi' => $options['boolean'],
                'has_bluetooth' => $options['boolean'],
                'all_ports_functional' => $options['boolean'],
                'has_cd_drive' => $options['boolean'],
            ],
            'aio' => $base + [
                'screen_condition' => $options['screen_condition'],
                'stand_condition' => $options['stand_condition'],
                'storage_technology' => $options['storage_technology'],
                'includes_power_adapter' => $options['boolean'],
                'includes_charger' => $options['boolean'],
                'charger_status' => ['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'],
                // Puertos: ejemplos de cantidades
                'vga_ports' => [0,1,2,3],
                'hdmi_ports' => [0,1,2,3],
                'displayport_ports' => [0,1,2,3],
                'usb_a_ports' => [0,1,2,3,4,6,8],
                'usb_c_ports' => [0,1,2,3],
                'sd_readers' => [0,1,2],
                'rj45_ports' => [0,1,2],
                // Otros
                'has_touch' => $options['boolean'],
                'has_wifi' => $options['boolean'],
                'has_bluetooth' => $options['boolean'],
                'all_ports_functional' => $options['boolean'],
                'cover_condition' => $options['component_condition_with_scratched'],
            ],
            'monitor' => $base + [
                'screen_condition' => $options['screen_condition'],
                'stand_condition' => $options['stand_condition'],
                'includes_power_cable' => $options['boolean'],
                'includes_video_cable' => $options['boolean'],
                'includes_stand' => $options['boolean'],
                'has_usb_hub' => $options['boolean'],
                'vga_ports' => [0,1,2,3],
                'hdmi_ports' => [0,1,2,3],
                'displayport_ports' => [0,1,2,3],
                'dvi_ports' => [0,1,2],
                'usb_hub_ports' => [0,2,4],
                'all_ports_functional' => $options['boolean'],
                'defective_ports_count' => [0,1,2,3],
                'defective_ports_critical_count' => [0,1,2,3],
                'frame_condition' => $options['component_condition_with_scratched'],
                'screen_resolution' => ['1366x768', '1920x1080', '2560x1440', '3840x2160'],
            ],
            default => $base,
        };
    }
}
