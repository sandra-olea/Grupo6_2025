<?php

namespace App\Http\Controllers\Notifications;

use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\RoleNotificationDefault;

class AdminRoleBundlesController extends BaseController
{
    public function show(string $roleId)
    {
        $user = Auth::user();
        if (!$user->hasRole('super-admin')) {
            return response()->json(['message' => 'No estás autorizado para realizar esta acción'], 403);
        }
        $types = NotificationType::orderBy('module')->get();
        $defaults = RoleNotificationDefault::where('role_id', $roleId)->get()->keyBy('notification_type_id');

        $data = $types->map(function ($type) use ($defaults) {
            $def = $defaults->get($type->id);
            return [
                'type_id' => $type->id,
                'key' => $type->key,
                'module' => $type->module,
                'module_label' => $type->module_label,
                'display_name' => $type->display_name,
                'allowed' => $def->allowed ?? true,
                'channels' => $def->channels ?? null,
                'priority_override' => $def->priority_override ?? null,
            ];
        });

        return response()->json($data);
    }

    public function update(string $roleId, Request $request)
    {
        $user = Auth::user();
        if (!$user->hasRole('super-admin')) {
            return response()->json(['message' => 'No estás autorizado para realizar esta acción'], 403);
        }

        $items = $request->input('items', []);
        if (!is_array($items)) {
            return response()->json(['message' => 'Invalid payload'], 422);
        }

        DB::transaction(function () use ($items, $roleId) {
            foreach ($items as $item) {
                $typeId = (int) ($item['type_id'] ?? 0);
                if (!$typeId) continue;
                RoleNotificationDefault::updateOrCreate(
                    ['role_id' => $roleId, 'notification_type_id' => $typeId],
                    [
                        'allowed' => isset($item['allowed']) ? (bool) $item['allowed'] : true,
                        'channels' => $item['channels'] ?? null,
                        'priority_override' => $item['priority_override'] ?? null,
                    ]
                );
            }
        });

        return response()->json(['ok' => true]);
    }
}
