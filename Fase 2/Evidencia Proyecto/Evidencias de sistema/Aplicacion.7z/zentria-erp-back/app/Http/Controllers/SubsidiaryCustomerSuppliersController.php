<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\CustomerSupplier\StoreCustomerSupplierRequest;
use App\Http\Requests\CustomerSupplier\UpdateCustomerSupplierRequest;
use App\Http\Resources\CustomerSupplierResource;
use App\Models\Subsidiary;
use App\Models\CustomerSupplier;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\NotificationEvent;
use App\Services\Notifications\NotificationRouter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class SubsidiaryCustomerSuppliersController extends Controller
{
    /**
     * GET /api/subsidiaries/{subsidiary}/customer-suppliers
     * Listar todos los clientes-proveedores de una subsidiary
     */
    public function index(Request $request, Subsidiary $subsidiary)
    {
        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $query = CustomerSupplier::query()
            ->where('subsidiary_id', $subsidiary->id)
            ->withCount('suppliers'); // Siempre incluir count

        // Búsqueda
        if ($search = trim((string)$request->get('q'))) {
            $query->where('name', 'ILIKE', "%{$search}%");
        }

        // Solo incluir proveedores si se solicita explícitamente
        if ($request->boolean('with_suppliers')) {
            // Limitar cantidad para evitar sobrecarga
            $limit = min($request->integer('suppliers_limit', 10), 50); // Máximo 50
            
            $query->with(['suppliers' => function($q) use ($limit) {
                $q->select('suppliers.id', 'suppliers.name', 'suppliers.subsidiary_id')
                  ->orderBy('suppliers.name', 'asc')
                  ->limit($limit);
            }]);
        }

        // Incluir relaciones opcionales adicionales
        if ($request->boolean('with_subsidiary')) {
            $query->with('subsidiary');
        }

        $query->orderBy('name', 'asc');

        return CustomerSupplierResource::collection(
            $query->paginate($request->integer('per_page', 15))->appends($request->query())
        );
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/customer-suppliers
     * Crear un nuevo cliente-proveedor
     */
    public function store(StoreCustomerSupplierRequest $request, Subsidiary $subsidiary)
    {
        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $customerSupplier = $subsidiary->customerSuppliers()->create([
            'name' => $request->string('name')->toString(),
        ]);

        // Notificación: customer-supplier.created
        try {
            $type = NotificationType::where('key', 'customer-supplier.created')->first();
            if ($type) {
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'customer_supplier',
                    'entity_id' => $customerSupplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'customer_supplier_name' => $customerSupplier->name,
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'creado',
                        'created_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'created_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'customer-supplier.created:'.$customerSupplier->id,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        return CustomerSupplierResource::make($customerSupplier)->response()->setStatusCode(201);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/customer-suppliers/{customerSupplier}
     * Mostrar un cliente-proveedor específico
     */
    public function show(Subsidiary $subsidiary, CustomerSupplier $customerSupplier)
    {
        // Verificar que el cliente pertenece a la subsidiary
        abort_if($customerSupplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('view', $subsidiary), 403);

        // Cargar count siempre
        $customerSupplier->loadCount('suppliers');
        $customerSupplier->load('subsidiary');

        // Solo cargar proveedores si se solicita y con límite
        if (request()->boolean('with_suppliers')) {
            $limit = min(request()->integer('suppliers_limit', 10), 50);
            $customerSupplier->load(['suppliers' => function($q) use ($limit) {
                $q->select('suppliers.id', 'suppliers.name', 'suppliers.subsidiary_id')
                  ->orderBy('suppliers.name', 'asc')
                  ->limit($limit);
            }]);
        }

        return CustomerSupplierResource::make($customerSupplier);
    }

    /**
     * PATCH /api/subsidiaries/{subsidiary}/customer-suppliers/{customerSupplier}
     * Actualizar un cliente-proveedor
     */
    public function update(UpdateCustomerSupplierRequest $request, Subsidiary $subsidiary, CustomerSupplier $customerSupplier)
    {
        // Verificar que el cliente pertenece a la subsidiary
        abort_if($customerSupplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $customerSupplier->update([
            'name' => $request->string('name')->toString(),
        ]);

        // Notificación: customer-supplier.updated
        try {
            $type = NotificationType::where('key', 'customer-supplier.updated')->first();
            if ($type) {
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'customer_supplier',
                    'entity_id' => $customerSupplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'customer_supplier_name' => $customerSupplier->name,
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'actualizado',
                        'updated_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'updated_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'customer-supplier.updated:'.$customerSupplier->id,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        return CustomerSupplierResource::make($customerSupplier->fresh());
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/customer-suppliers/{customerSupplier}
     * Eliminar un cliente-proveedor
     */
    public function destroy(Subsidiary $subsidiary, CustomerSupplier $customerSupplier)
    {
        // Verificar que el cliente pertenece a la subsidiary
        abort_if($customerSupplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('delete', $subsidiary), 403);

        // Notificación: customer-supplier.deleted (antes de eliminar)
        try {
            $type = NotificationType::where('key', 'customer-supplier.deleted')->first();
            if ($type) {
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'customer_supplier',
                    'entity_id' => $customerSupplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'customer_supplier_name' => $customerSupplier->name,
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'eliminado',
                        'deleted_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'deleted_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'customer-supplier.deleted:'.$customerSupplier->id,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        $customerSupplier->delete();

        return response()->json([
            'message' => 'Cliente-proveedor eliminado exitosamente.'
        ], 200);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/customer-suppliers/{customerSupplier}/attach-suppliers
     * Asociar proveedores a un cliente-proveedor
     */
    public function attachSuppliers(Request $request, Subsidiary $subsidiary, CustomerSupplier $customerSupplier)
    {
        // Verificar que el cliente pertenece a la subsidiary
        abort_if($customerSupplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $validated = $request->validate([
            'supplier_ids' => ['required', 'array', 'min:1'],
            'supplier_ids.*' => ['integer', 'exists:suppliers,id'],
        ]);

        // Verificar que todos los proveedores pertenecen a la misma subsidiary
        $invalidSuppliers = \App\Models\Supplier::whereIn('id', $validated['supplier_ids'])
            ->where('subsidiary_id', '!=', $subsidiary->id)
            ->exists();

        abort_if($invalidSuppliers, 422, 'Algunos proveedores no pertenecen a esta subsidiary.');

        // Asociar (sin duplicar)
        $customerSupplier->suppliers()->syncWithoutDetaching($validated['supplier_ids']);

        // Obtener los nombres de los proveedores asociados para la notificación
        $suppliers = \App\Models\Supplier::whereIn('id', $validated['supplier_ids'])->get();
        
        // Notificación: proveedores asociados a customer-supplier
        try {
            $type = NotificationType::where('key', 'customer-supplier.suppliers-attached')->first();
            if ($type) {
                $supplierNames = $suppliers->pluck('name')->join(', ');
                
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'customer_supplier',
                    'entity_id' => $customerSupplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'customer_supplier_name' => $customerSupplier->name,
                        'supplier_names' => $supplierNames,
                        'suppliers_count' => count($suppliers),
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'proveedores_asociados',
                        'updated_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'updated_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'customer-supplier.attach-suppliers:'.$customerSupplier->id.':'.now()->timestamp,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        return response()->json([
            'message' => 'Proveedores asociados exitosamente.',
            'customer_supplier' => CustomerSupplierResource::make($customerSupplier->load('suppliers')),
        ]);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/customer-suppliers/{customerSupplier}/detach-suppliers
     * Desasociar proveedores de un cliente-proveedor
     */
    public function detachSuppliers(Request $request, Subsidiary $subsidiary, CustomerSupplier $customerSupplier)
    {
        // Verificar que el cliente pertenece a la subsidiary
        abort_if($customerSupplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $validated = $request->validate([
            'supplier_ids' => ['required', 'array', 'min:1'],
            'supplier_ids.*' => ['integer', 'exists:suppliers,id'],
        ]);

        // Desasociar
        $customerSupplier->suppliers()->detach($validated['supplier_ids']);

        // Notificación: proveedores desasociados de customer-supplier
        try {
            $type = NotificationType::where('key', 'customer-supplier.suppliers-detached')->first();
            if ($type) {
                $suppliers = \App\Models\Supplier::whereIn('id', $validated['supplier_ids'])->get();
                $supplierNames = $suppliers->pluck('name')->join(', ');
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'customer_supplier',
                    'entity_id' => $customerSupplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'customer_supplier_name' => $customerSupplier->name,
                        'supplier_names' => $supplierNames,
                        'suppliers_count' => count($suppliers),
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'proveedores_desasociados',
                        'updated_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'updated_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'customer-supplier.detach-suppliers:'.$customerSupplier->id.':'.now()->timestamp,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        return response()->json([
            'message' => 'Proveedores desasociados exitosamente.',
        ]);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/customer-suppliers/{customerSupplier}/suppliers
     * Obtener lista paginada de proveedores de un cliente
     */
    public function getSuppliers(Request $request, Subsidiary $subsidiary, CustomerSupplier $customerSupplier)
    {
        // Verificar que el cliente pertenece a la subsidiary
        abort_if($customerSupplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $query = $customerSupplier->suppliers()
            ->select('suppliers.id', 'suppliers.name', 'suppliers.subsidiary_id', 'suppliers.created_at', 'suppliers.updated_at');

        // Búsqueda
        if ($search = trim((string)$request->get('q'))) {
            $query->where('suppliers.name', 'ILIKE', "%{$search}%");
        }

        $query->orderBy('suppliers.name', 'asc');

        return \App\Http\Resources\SupplierResource::collection(
            $query->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }
}
