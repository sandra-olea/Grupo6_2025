<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\EquipmentTraceabilityResource;
use App\Models\Branch;
use App\Models\EquipmentTraceability;
use App\Models\TechnicalReviewItem;
use App\Services\EquipmentTraceabilityService;
use App\Enums\EquipmentStatus;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class EquipmentTraceabilityController extends Controller
{
    public function __construct(
        protected EquipmentTraceabilityService $traceabilityService
    ) {}

    /**
     * Get traceability history by serial number
     */
    public function history(Branch $branch, string $serialNumber): JsonResponse
    {
        $item = TechnicalReviewItem::bySerialNumber($serialNumber)
            ->byBranch($branch->id)
            ->firstOrFail();

        $this->authorize('view', $item);

        $traceability = $item->traceability()->with([
            'warehouse',
            'quotation',
            'sale',
            'customer',
            'movements.fromWarehouse',
            'movements.toWarehouse',
            'movements.performedBy',
            'movements.relatedDocument',
        ])->first();

        if (!$traceability) {
            return response()->json([
                'success' => false,
                'message' => 'No se encontró información de trazabilidad para este equipo',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'item' => [
                    'serial_number' => $item->serial_number,
                    'equipment_type' => $item->equipment_type->label(),
                    'grade' => $item->grade?->label(),
                    'review_status' => $item->review_status->label(),
                ],
                'traceability' => new EquipmentTraceabilityResource($traceability),
                'history' => $this->traceabilityService->getHistory($traceability->serial_number),
            ],
        ]);
    }

    /**
     * Change equipment status
     */
    public function changeStatus(Request $request, Branch $branch, EquipmentTraceability $traceability): JsonResponse
    {
        $validated = $request->validate([
            'new_status' => 'required|string',
            'reason' => 'required|string|max:500',
        ]);

        $traceability = $this->ensureTraceabilityBelongsToBranch($branch, $traceability);
        $item = $traceability->reviewItem;
        $this->authorize('update', $item);

        try {
            $newStatus = EquipmentStatus::from($validated['new_status']);
        } catch (\ValueError $e) {
            return response()->json([
                'success' => false,
                'message' => 'Estado no válido',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $this->traceabilityService->changeStatus(
                $traceability,
                $newStatus,
                $validated['reason']
            );

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Estado actualizado exitosamente',
                'data' => new EquipmentTraceabilityResource($traceability->load([
                    'warehouse',
                    'movements.performedBy',
                ])),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Transfer equipment to another warehouse
     */
    public function transfer(Request $request, Branch $branch, EquipmentTraceability $traceability): JsonResponse
    {
        $validated = $request->validate([
            'to_warehouse_id' => 'required|exists:warehouses,id',
            'reason' => 'required|string|max:500',
        ]);

        $traceability = $this->ensureTraceabilityBelongsToBranch($branch, $traceability);
        $item = $traceability->reviewItem;
        $this->authorize('update', $item);

        if ($validated['to_warehouse_id'] === $traceability->warehouse_id) {
            return response()->json([
                'success' => false,
                'message' => 'La bodega destino debe ser distinta a la actual',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $this->traceabilityService->transferWarehouse(
                $traceability,
                $validated['to_warehouse_id'],
                $validated['reason']
            );

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Equipo transferido exitosamente',
                'data' => new EquipmentTraceabilityResource($traceability->load([
                    'warehouse',
                    'movements.fromWarehouse',
                    'movements.toWarehouse',
                    'movements.performedBy',
                ])),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Bulk transfer equipment (serials) to another warehouse.
     * Also allows replicating the product in the destination branch if missing.
     */
    public function bulkTransfer(Request $request, Branch $branch): JsonResponse
    {
        $validated = $request->validate([
            'to_warehouse_id' => 'required|exists:warehouses,id',
            'traceability_ids' => 'required|array|min:1',
            'traceability_ids.*' => 'integer|exists:equipment_traceability,id',
            'reason' => 'nullable|string|max:500',
            'auto_create_destination_product' => 'sometimes|boolean',
        ]);

        $toWarehouse = \App\Models\Warehouse::findOrFail($validated['to_warehouse_id']);
        $toBranch = $toWarehouse->branch; // branch destino
        $autoCreate = filter_var($request->input('auto_create_destination_product'), FILTER_VALIDATE_BOOL);

        $results = [
            'transferred' => 0,
            'queued_replications' => 0,
            'errors' => [],
        ];

        DB::beginTransaction();
        try {
            foreach ($validated['traceability_ids'] as $id) {
                /** @var EquipmentTraceability $tr */
                $tr = EquipmentTraceability::with(['reviewItem.product.brand','reviewItem.batch'])
                    ->lockForUpdate()
                    ->findOrFail($id);

                // Validar pertenencia al branch del path
                $this->ensureTraceabilityBelongsToBranch($branch, $tr);

                // Ejecutar transferencia
                $this->traceabilityService->transferWarehouse(
                    $tr,
                    $toWarehouse->id,
                    $validated['reason'] ?? null
                );
                $results['transferred']++;

                // Replicar producto en branch destino (catálogo) en background
                if ($autoCreate) {
                    $p = $tr->reviewItem?->product;
                    if ($p) {
                        \App\Jobs\ReplicateProductToBranchJob::dispatch($p->id, $toBranch->id, $toWarehouse->id)->onQueue('default');
                        $results['queued_replications']++;
                    }
                }
            }

            DB::commit();
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'results' => $results,
            ], 422);
        }

        return response()->json([
            'success' => true,
            'message' => 'Series transferidas exitosamente',
            'results' => $results,
        ]);
    }

    // Replication now handled asynchronously by ReplicateProductToBranchJob

    /**
     * Reserve equipment for quotation
     */
    public function reserve(Request $request, Branch $branch, EquipmentTraceability $traceability): JsonResponse
    {
        $validated = $request->validate([
            'quotation_id' => 'required|exists:quotations,id',
        ]);

        $traceability = $this->ensureTraceabilityBelongsToBranch($branch, $traceability);
        $item = $traceability->reviewItem;
        $this->authorize('update', $item);

        if ($traceability->status !== EquipmentStatus::AVAILABLE_FOR_SALE) {
            return response()->json([
                'success' => false,
                'message' => 'El equipo debe estar disponible para venta para poder reservarlo',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $this->traceabilityService->changeStatus(
                $traceability,
                EquipmentStatus::RESERVED,
                'Reservado para cotización #' . $validated['quotation_id']
            );

            $traceability->update([
                'quotation_id' => $validated['quotation_id'],
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Equipo reservado exitosamente',
                'data' => new EquipmentTraceabilityResource($traceability->load([
                    'warehouse',
                    'quotation',
                ])),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Mark equipment as sold
     */
    public function markAsSold(Request $request, Branch $branch, EquipmentTraceability $traceability): JsonResponse
    {
        $validated = $request->validate([
            'sale_id' => 'required|exists:sales,id',
            'customer_id' => 'required|exists:customers,id',
        ]);

        $traceability = $this->ensureTraceabilityBelongsToBranch($branch, $traceability);
        $item = $traceability->reviewItem;
        $this->authorize('update', $item);

        DB::beginTransaction();
        try {
            $this->traceabilityService->markAsSold(
                $traceability,
                $validated['sale_id'],
                $validated['customer_id']
            );

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Equipo marcado como vendido exitosamente',
                'data' => new EquipmentTraceabilityResource($traceability->load([
                    'warehouse',
                    'sale',
                    'customer',
                ])),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Release reservation
     */
    public function releaseReservation(Branch $branch, EquipmentTraceability $traceability): JsonResponse
    {
        $traceability = $this->ensureTraceabilityBelongsToBranch($branch, $traceability);
        $item = $traceability->reviewItem;
        $this->authorize('update', $item);

        if ($traceability->status !== EquipmentStatus::RESERVED) {
            return response()->json([
                'success' => false,
                'message' => 'El equipo no está reservado',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $this->traceabilityService->changeStatus(
                $traceability,
                EquipmentStatus::AVAILABLE_FOR_SALE,
                'Reserva liberada'
            );

            $traceability->update([
                'quotation_id' => null,
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Reserva liberada exitosamente',
                'data' => new EquipmentTraceabilityResource($traceability->load(['warehouse'])),
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Get available equipment for sale
     */
    public function availableForSale(Request $request, Branch $branch): JsonResponse
    {
        $query = EquipmentTraceability::availableForSale()
            ->with([
                'reviewItem.product',
                'reviewItem.details',
                'warehouse',
            ])
            ->whereHas('reviewItem.batch', function ($q) use ($branch) {
                $q->where('branch_id', $branch->id);
            });

        // Filtros
        if ($request->filled('warehouse_id')) {
            $query->inWarehouse($request->warehouse_id);
        }

        if ($request->filled('equipment_type')) {
            $query->whereHas('reviewItem', function ($q) use ($request) {
                $q->byEquipmentType($request->equipment_type);
            });
        }

        if ($request->filled('grade')) {
            $query->whereHas('reviewItem', function ($q) use ($request) {
                $q->where('grade', $request->grade);
            });
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('serial_number', 'ILIKE', "%{$search}%")
                  ->orWhereHas('reviewItem.product', function ($q) use ($search) {
                      $q->where('name', 'ILIKE', "%{$search}%");
                  });
            });
        }

        $items = $query->latest()->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => EquipmentTraceabilityResource::collection($items),
            'meta' => [
                'current_page' => $items->currentPage(),
                'last_page' => $items->lastPage(),
                'per_page' => $items->perPage(),
                'total' => $items->total(),
            ],
        ]);
    }

    private function ensureTraceabilityBelongsToBranch(Branch $branch, EquipmentTraceability $traceability): EquipmentTraceability
    {
        $traceability->loadMissing('reviewItem.batch');

        if ($traceability->reviewItem?->batch?->branch_id !== $branch->id) {
            abort(404);
        }

        return $traceability;
    }
}
