<?php

namespace App\Http\Controllers;

use App\Http\Requests\Integration\StoreIntegrationRequest;
use App\Http\Requests\Integration\UpdateIntegrationRequest;
use App\Http\Resources\IntegrationResource;
use App\Models\Integration;
use App\Models\Subsidiary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;

class SubsidiaryIntegrationsController extends Controller
{
    private function ensureSuperAdmin(): void
    {
        $user = auth('api')->user();
        abort_unless($user && $user->hasRole('super-admin'), 403, 'Solo Super Admin');
    }

    public function index(Request $request, Subsidiary $subsidiary)
    {
        $this->ensureSuperAdmin();
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $q = Integration::where('subsidiary_id', $subsidiary->id);

        if ($provider = $request->query('provider')) {
            $q->where('provider', $provider);
        }
        if (!is_null($request->query('active'))) {
            $q->where('is_active', filter_var($request->query('active'), FILTER_VALIDATE_BOOL));
        }

        $q->orderBy('provider')->orderBy('name');

        return IntegrationResource::collection(
            $q->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }

    public function store(StoreIntegrationRequest $request, Subsidiary $subsidiary)
    {
        $this->ensureSuperAdmin();
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $data = $request->validated();
        $apiKeyPlain = $data['api_key_plain'] ?? null;
        unset($data['api_key_plain']);
        $providedSecret = $data['webhook_secret'] ?? null;

        $integration = new Integration($data);
        $integration->subsidiary_id = $subsidiary->id;
        $integration->id = (string) \Illuminate\Support\Str::uuid();

        // Generar API key automáticamente si no viene
        if (!$apiKeyPlain) {
            $apiKeyPlain = bin2hex(random_bytes(32)); // URL-safe, 64 hex chars
        }
        $integration->api_key_prefix = substr($apiKeyPlain, 0, 16);
        $integration->api_key_hash = Hash::make($apiKeyPlain);

        // Generar webhook_secret si no viene, y siempre guardar encriptado
        $secretPlain = $providedSecret ?: bin2hex(random_bytes(32));
        $integration->webhook_secret = Crypt::encryptString($secretPlain);

        $integration->save();

        $response = [
            'message' => 'Integración creada correctamente',
            'data' => IntegrationResource::make($integration),
            // Mostrar secretos en claro solo una vez
            'webhook_secret' => $secretPlain,
        ];
        $response['api_key'] = $apiKeyPlain; // Mostrar solo una vez
        
        return response()->json($response, 201);
    }

    public function show(Subsidiary $subsidiary, string $integration)
    {
        $this->ensureSuperAdmin();
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $record = Integration::where('subsidiary_id', $subsidiary->id)->findOrFail($integration);
        return IntegrationResource::make($record);
    }

    public function update(UpdateIntegrationRequest $request, Subsidiary $subsidiary, string $integration)
    {
        $this->ensureSuperAdmin();
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $record = Integration::where('subsidiary_id', $subsidiary->id)->findOrFail($integration);
        $data = $request->validated();
        $apiKeyPlain = $data['api_key_plain'] ?? null;
        unset($data['api_key_plain']);
        $providedSecret = $data['webhook_secret'] ?? null;

        $record->fill($data);
        $apiRotated = false;
        if ($apiKeyPlain || $request->boolean('rotate_api_key')) {
            if (!$apiKeyPlain) {
                $apiKeyPlain = bin2hex(random_bytes(32));
            }
            $record->api_key_prefix = substr($apiKeyPlain, 0, 16);
            $record->api_key_hash = Hash::make($apiKeyPlain);
            $apiRotated = true;
        }
        $secretRotated = false;
        $secretPlain = null;
        if (array_key_exists('webhook_secret', $data) || $request->boolean('rotate_webhook_secret')) {
            // Si el caller pide rotar o envía explícito, generar (preferimos generar nosotros)
            $secretPlain = $providedSecret ?: bin2hex(random_bytes(32));
            $record->webhook_secret = Crypt::encryptString($secretPlain);
            $secretRotated = true;
        }
        $record->save();

        $response = ['message' => 'Integración actualizada correctamente', 'data' => IntegrationResource::make($record)];
        if ($apiRotated && $apiKeyPlain) { $response['api_key'] = $apiKeyPlain; }
        if ($secretRotated && $secretPlain) { $response['webhook_secret'] = $secretPlain; }
        return response()->json($response);
    }

    public function destroy(Subsidiary $subsidiary, string $integration)
    {
        $this->ensureSuperAdmin();
        abort_unless(Gate::allows('delete', $subsidiary), 403);

        $record = Integration::where('subsidiary_id', $subsidiary->id)->findOrFail($integration);
        $record->delete();

        return response()->json(['message' => 'Integración eliminada correctamente']);
    }
}
