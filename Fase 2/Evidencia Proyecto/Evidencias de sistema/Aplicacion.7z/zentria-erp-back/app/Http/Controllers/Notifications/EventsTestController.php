<?php

namespace App\Http\Controllers\Notifications;

use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\NotificationEvent;
use App\Services\Notifications\NotificationRouter;

class EventsTestController extends BaseController
{
    public function store(Request $request)
    {
        $this->authorizeDev();

        $typeKey = $request->input('type_key', 'system.sync-failed');
        $type = NotificationType::where('key', $typeKey)->first();
        if (!$type) {
            return response()->json(['message' => 'Unknown type_key'], 422);
        }

        $event = NotificationEvent::create([
            'type_id' => $type->id,
            'entity_type' => $request->input('entity_type', 'system'),
            'entity_id' => $request->input('entity_id', 0),
            'company_id' => $request->input('company_id'),
            'subsidiary_id' => $request->input('subsidiary_id'),
            'branch_id' => $request->input('branch_id'),
            'priority' => $request->input('priority', $type->default_priority),
            'payload' => $request->input('payload', ['demo' => true]),
            'dedup_key' => $request->input('dedup_key', 'test:'.$typeKey.':'.uniqid()),
            'occurred_at' => now(),
        ]);

        app(NotificationRouter::class)->route($event);

        return response()->json(['message' => 'Event dispatched', 'event_id' => $event->id], 201);
    }

    public function examples(Request $request)
    {
        $this->authorizeDev();

        // Optionally accept specific scope IDs
        $companyId = $request->input('company_id');
        $subsidiaryId = $request->input('subsidiary_id');
        $branchId = $request->input('branch_id');

        $types = [
            'system.sync-failed',
            'payment.confirmed',
            'quote.expiring-soon',
        ];

        $created = [];
        foreach ($types as $key) {
            $type = NotificationType::where('key', $key)->first();
            if (! $type) continue;
            $event = NotificationEvent::create([
                'type_id' => $type->id,
                'entity_type' => explode('.', $key)[0],
                'entity_id' => rand(1000,999999),
                'company_id' => $companyId,
                'subsidiary_id' => $subsidiaryId,
                'branch_id' => $branchId,
                'priority' => $type->default_priority,
                'payload' => ['demo' => true, 'key' => $key],
                'dedup_key' => $key.':demo:'.uniqid(),
                'occurred_at' => now(),
            ]);
            app(NotificationRouter::class)->route($event);
            $created[] = $event->id;
        }

        return response()->json(['message' => 'Examples dispatched', 'event_ids' => $created], 201);
    }
    protected function authorizeDev(): void
    {
        // Simple gate for dev/testing environments
        if (!app()->environment(['local', 'development', 'testing'])) {
            abort(403, 'Only allowed in dev/testing');
        }
    }
}
