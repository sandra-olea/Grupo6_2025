<?php

namespace App\Http\Controllers;

use App\Http\Resources\CustomerSaleResource;
use App\Models\CustomerSale;
use App\Models\Subsidiary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use App\Traits\DispatchesNotifications;

class SubsidiaryCustomerSalesController extends Controller
{
    use DispatchesNotifications;
    /**
     * GET /api/subsidiaries/{subsidiary}/customer-sales
     */
    public function index(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $query = CustomerSale::query()->where('subsidiary_id', $subsidiary->id);

        if ($q = trim((string) $request->get('q'))) {
            $query->where(function ($qq) use ($q) {
                $qq->where('billing_company', 'ILIKE', "%{$q}%")
                   ->orWhere('contact_name', 'ILIKE', "%{$q}%")
                   ->orWhere('rut', 'ILIKE', "%{$q}%")
                   ->orWhere('email', 'ILIKE', "%{$q}%");
            });
        }

        if ($request->boolean('with_relations')) {
            $query->with(['subsidiary', 'commune', 'shippingCommune']);
        }

        $query->orderBy('billing_company')->orderBy('contact_name');

        return CustomerSaleResource::collection(
            $query->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/customer-sales/overview
     * Devuelve: id, nombre creado, contacto (si aplica), RUT, fidelidad (#compras), total_ventas y activo/inactivo.
     * Parámetros opcionales:
     * - q: búsqueda por nombre/email/rut
     * - st: lista de estados de venta separados por coma (por defecto: confirmed,partially_paid,paid,delivered,completed)
     * - date_from, date_to: filtrar ventas por fecha (sale_date)
     * - min_loyalty: mínimo de compras (>=)
     * - strict: 1/0. Si 1 (default), excluye clientes con datos no normalizables (sin rut o nombre válido, o rut guest-)
     */
    public function overview(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $validated = $request->validate([
            'q' => 'sometimes|nullable|string',
            'st' => 'sometimes|nullable|string',
            'date_from' => 'sometimes|nullable|date',
            'date_to' => 'sometimes|nullable|date|after_or_equal:date_from',
            'min_loyalty' => 'sometimes|nullable|integer|min:0',
            'strict' => 'sometimes|nullable|boolean',
            // sin límite superior para per_page
            'per_page' => 'sometimes|nullable|integer|min:1',
            // Normalización de loyalty 1..100: max = frecuencia que mapea a 100 (por defecto 10)
            'max' => 'sometimes|nullable|integer|min:1'
        ]);

        $perPage = (int)($validated['per_page'] ?? 20);
        $statuses = array_filter(array_map('trim', explode(',', (string)($validated['st'] ?? 'confirmed,partially_paid,paid,delivered,completed'))));
        if (empty($statuses)) { $statuses = ['confirmed','partially_paid','paid','delivered','completed']; }
        $minLoyalty = (int)($validated['min_loyalty'] ?? 0);
        $strict = array_key_exists('strict', $validated) ? (bool)$validated['strict'] : true;

        // Subconsulta: fidelidad y total ventas por cliente
        $agg = \DB::table('sales as s')
            ->selectRaw('s.customer_id, COUNT(*)::int as purchase_count, COALESCE(SUM(s.total_amount),0) as total_sales')
            ->where('s.subsidiary_id', $subsidiary->id)
            ->whereIn('s.status', $statuses)
            ->when(!empty($validated['date_from']), fn($q) => $q->whereDate('s.sale_date','>=',$validated['date_from']))
            ->when(!empty($validated['date_to']), fn($q) => $q->whereDate('s.sale_date','<=',$validated['date_to']))
            ->groupBy('s.customer_id');

        $query = CustomerSale::query()
            ->from('customer_sale as c')
            ->leftJoinSub($agg, 'a', 'a.customer_id', '=', 'c.id')
            ->where('c.subsidiary_id', $subsidiary->id)
            ->selectRaw(
                'c.id,
                 c.billing_company,
                 c.contact_name,
                 c.primary_contact_name,
                 c.primary_contact_email,
                 c.primary_contact_phone,
                 c.email,
                 c.phone,
                 c.rut,
                 c.is_active,
                 COALESCE(a.purchase_count, 0) as purchase_count,
                 COALESCE(a.total_sales, 0) as total_sales'
            );

        if ($q = trim((string)($validated['q'] ?? ''))) {
            $query->where(function($w) use ($q){
                $w->where('c.billing_company','ILIKE',"%{$q}%")
                  ->orWhere('c.contact_name','ILIKE',"%{$q}%")
                  ->orWhere('c.rut','ILIKE',"%{$q}%")
                  ->orWhere('c.email','ILIKE',"%{$q}%");
            });
        }

        if ($minLoyalty > 0) {
            $query->whereRaw('COALESCE(a.purchase_count,0) >= ?', [$minLoyalty]);
        }

        if ($strict) {
            // Excluir registros sin RUT válido o con guest- y sin nombre utilizable
            $query->whereNotNull('c.rut')
                ->whereRaw("trim(c.rut) <> ''")
                ->whereRaw("LOWER(c.rut) NOT LIKE 'guest-%'")
                ->where(function($w){
                    $w->whereRaw("trim(COALESCE(c.billing_company, '')) <> ''")
                      ->orWhereRaw("trim(COALESCE(c.contact_name, '')) <> ''");
                });
        }

        $query->orderByRaw('COALESCE(a.purchase_count,0) DESC')->orderBy('c.billing_company')->orderBy('c.contact_name');

        $page = $query->paginate($perPage)->appends($request->query());

        // Filtrar RUTs inválidos (sólo mostrar clientes con RUT válido en overview)
        $rutRule = new \App\Rules\ChileanRut('rut');
        $collection = $page->getCollection()
            ->filter(function($row) use ($rutRule) {
                $rut = (string) ($row->rut ?? '');
                return $rutRule->passes('rut', $rut);
            })
            ->values();

        // Mapear a estructura compacta
        $maxFreq = (int)($validated['max'] ?? 10);
        if ($maxFreq < 1) { $maxFreq = 10; }

        $page->setCollection($collection->map(function($row) use ($maxFreq){
            $name = $row->billing_company ?: $row->contact_name;
            // Formatear RUT como 12345678-9 (sin puntos, DV al final)
            $rutRaw = (string) ($row->rut ?? '');
            $clean = strtoupper(preg_replace('/[^0-9K]/', '', $rutRaw));
            if (strlen($clean) >= 2) {
                $rutOut = substr($clean, 0, -1) . '-' . substr($clean, -1);
            } else {
                $rutOut = $rutRaw;
            }
            $contact = [
                'name' => $row->primary_contact_name ?: ($row->contact_name ?: ($row->billing_company ?: null)),
                'email' => $row->primary_contact_email ?: $row->email,
                'phone' => $row->primary_contact_phone ?: $row->phone,
            ];
            if (!($contact['name'] || $contact['email'] || $contact['phone'])) { $contact = null; }
            $pc = (int) ($row->purchase_count ?? 0);
            $loyaltyScore = (int) max(1, min(100, round(($pc / $maxFreq) * 100)));
            return [
                'id' => (int) $row->id,
                'name' => $name,
                'rut' => $rutOut,
                'contact' => $contact,
                'loyalty' => $loyaltyScore,
                'total_sales' => (float) ($row->total_sales ?? 0),
                'is_active' => (bool) $row->is_active,
            ];
        }));

        return $page;
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/customer-sales
     * Si no se envía body, devolver los campos rellenables para guiar.
     */
    public function store(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        if (empty($request->all())) {
            return response()->json($this->hintPayload($subsidiary, 'Datos faltantes. Envía al menos los campos requeridos.'), 422);
        }

        try {
            $validated = $request->validate([
                // Nuevos campos del flujo
                'customer_code' => 'sometimes|nullable|string|max:100',
                'document_type' => 'sometimes|nullable|in:rut,passport,id,dni',
                'document_number' => ['sometimes','nullable','string','max:20', new \App\Rules\ChileanRut($request->input('document_type','rut'))],

                // Compat (existente)
                'type' => 'sometimes|nullable|in:natural,company',
                'rut' => ['sometimes','nullable','string','max:20', new \App\Rules\ChileanRut($request->input('document_type','rut'))],
                'billing_company' => 'sometimes|nullable|string|max:255',
                'trade_activity' => 'sometimes|nullable|string|max:255',
                'giro' => 'sometimes|nullable|string|max:255',
                'contact_name' => 'sometimes|nullable|string|max:255',
                'email' => 'required|email|max:255',
                'phone' => 'sometimes|nullable|string|max:50',
                'address' => 'sometimes|nullable|string|max:255',
                'billing_address_1' => 'sometimes|nullable|string|max:255',
                'billing_address_2' => 'sometimes|nullable|string|max:255',
                'billing_city' => 'sometimes|nullable|string|max:255',
                'commune_id' => 'sometimes|nullable|integer|exists:communes,id',
                'billing_state_code' => 'sometimes|nullable|string|max:10',
                'billing_postcode' => 'sometimes|nullable|string|max:20',
                'billing_country_code' => 'sometimes|nullable|string|size:2',
                'shipping_address_1' => 'sometimes|nullable|string|max:255',
                'shipping_address_2' => 'sometimes|nullable|string|max:255',
                'shipping_city' => 'sometimes|nullable|string|max:255',
                'shipping_commune_id' => 'sometimes|nullable|integer|exists:communes,id',
                'shipping_state_code' => 'sometimes|nullable|string|max:10',
                'shipping_postcode' => 'sometimes|nullable|string|max:20',
                'shipping_country_code' => 'sometimes|nullable|string|size:2',
                'default_document_type' => 'sometimes|nullable|in:factura,boleta',
                'preferred_payment_method' => 'sometimes|nullable|in:transferencia,tarjetas',
                'purchase_order_number' => 'sometimes|nullable|string|max:100',
                'commercial_data' => 'sometimes|nullable|array',
                'notes' => 'sometimes|nullable|string',
                'is_active' => 'sometimes|boolean',

                // Contacto principal opcional: si viene uno, deben venir los 3
                'primary_contact_name' => 'sometimes|nullable|string|max:255',
                'primary_contact_email' => 'sometimes|nullable|email|max:255',
                'primary_contact_phone' => 'sometimes|nullable|string|max:50',
            ]);
        } catch (ValidationException $e) {
            return response()->json(array_merge([
                'message' => $e->getMessage(),
                'errors' => $e->errors(),
            ], $this->hintPayload($subsidiary)), 422);
        }

        // Normalizar campos del nuevo flujo
        $docType = $validated['document_type'] ?? 'rut';
        $rut = $validated['rut'] ?? ($validated['document_number'] ?? null);
        if (!$rut) {
            return response()->json(['message' => 'El número de documento (RUT) es requerido.','errors'=>['document_number'=>['Requerido']]], 422);
        }
        // Unicidad por subsidiary
        $exists = CustomerSale::where('subsidiary_id', $subsidiary->id)
            ->whereRaw('LOWER(rut) = ?', [mb_strtolower($rut)])
            ->exists();
        if ($exists) {
            return response()->json(['message'=>'El RUT ya existe para esta subsidiary.','errors'=>['document_number'=>['Duplicado']]], 422);
        }

        // Map alias
        $validated['rut'] = $rut;
        $validated['document_type'] = $docType;
        if (!empty($validated['giro'])) { $validated['trade_activity'] = $validated['giro']; }
        if (!empty($validated['address'])) { $validated['billing_address_1'] = $validated['address']; }
        if (empty($validated['type'])) { $validated['type'] = 'natural'; }

        // Contacto principal: si no vienen, usar los superiores
        $pcName = $validated['primary_contact_name'] ?? null;
        $pcEmail = $validated['primary_contact_email'] ?? null;
        $pcPhone = $validated['primary_contact_phone'] ?? null;
        $anyPc = $pcName || $pcEmail || $pcPhone;
        if ($anyPc && (!$pcName || !$pcEmail || !$pcPhone)) {
            return response()->json(['message' => 'Contacto principal incompleto.','errors'=>['primary_contact'=>['Debe incluir nombre, email y teléfono']]], 422);
        }
        if (!$anyPc) {
            $validated['primary_contact_name'] = $validated['contact_name'] ?? ($validated['billing_company'] ?? null);
            $validated['primary_contact_email'] = $validated['email'] ?? null;
            $validated['primary_contact_phone'] = $validated['phone'] ?? null;
        }

        $customer = CustomerSale::create(array_merge($validated, [
            'subsidiary_id' => $subsidiary->id,
        ]));

        // Notificación: customer-sale.created
        $this->dispatchNotification(
            typeKey: 'customer-sale.created',
            entityType: 'customer_sale',
            entityId: $customer->id,
            scope: $this->subsidiaryScope($subsidiary),
            payload: array_merge([
                'customer_name' => $customer->billing_company ?: $customer->contact_name,
                'subsidiary_name' => $subsidiary->subsidiary_name,
                'action' => 'creado',
            ], $this->currentUserPayload('created_by'))
        );

        return CustomerSaleResource::make($customer->load(['subsidiary']))
            ->response()
            ->setStatusCode(201);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/customer-sales/{customer}
     */
    public function show(Subsidiary $subsidiary, int $customer)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $record = CustomerSale::where('subsidiary_id', $subsidiary->id)
            ->with(['subsidiary', 'commune', 'shippingCommune'])
            ->findOrFail($customer);

        return CustomerSaleResource::make($record);
    }

    /**
     * PATCH /api/subsidiaries/{subsidiary}/customer-sales/{customer}
     */
    public function update(Request $request, Subsidiary $subsidiary, int $customer)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $customer = CustomerSale::where('subsidiary_id', $subsidiary->id)->findOrFail($customer);

        $validated = $request->validate([
            'customer_code' => 'sometimes|nullable|string|max:100',
            'document_type' => 'sometimes|nullable|in:rut,passport,id,dni',
            'document_number' => ['sometimes','nullable','string','max:20', new \App\Rules\ChileanRut($request->input('document_type','rut'))],
            'type' => 'sometimes|nullable|in:natural,company',
            'rut' => ['sometimes','nullable','string','max:20', new \App\Rules\ChileanRut($request->input('document_type','rut'))],
            'billing_company' => 'sometimes|nullable|string|max:255',
            'trade_activity' => 'sometimes|nullable|string|max:255',
            'giro' => 'sometimes|nullable|string|max:255',
            'contact_name' => 'sometimes|nullable|string|max:255',
            'email' => 'sometimes|nullable|email|max:255',
            'phone' => 'sometimes|nullable|string|max:50',
            'address' => 'sometimes|nullable|string|max:255',
            'billing_address_1' => 'sometimes|nullable|string|max:255',
            'billing_address_2' => 'sometimes|nullable|string|max:255',
            'billing_city' => 'sometimes|nullable|string|max:255',
            'commune_id' => 'sometimes|nullable|integer|exists:communes,id',
            'billing_state_code' => 'sometimes|nullable|string|max:10',
            'billing_postcode' => 'sometimes|nullable|string|max:20',
            'billing_country_code' => 'sometimes|nullable|string|size:2',
            'shipping_address_1' => 'sometimes|nullable|string|max:255',
            'shipping_address_2' => 'sometimes|nullable|string|max:255',
            'shipping_city' => 'sometimes|nullable|string|max:255',
            'shipping_commune_id' => 'sometimes|nullable|integer|exists:communes,id',
            'shipping_state_code' => 'sometimes|nullable|string|max:10',
            'shipping_postcode' => 'sometimes|nullable|string|max:20',
            'shipping_country_code' => 'sometimes|nullable|string|size:2',
            'default_document_type' => 'sometimes|nullable|in:factura,boleta',
            'preferred_payment_method' => 'sometimes|nullable|in:transferencia,tarjetas',
            'purchase_order_number' => 'sometimes|nullable|string|max:100',
            'commercial_data' => 'sometimes|nullable|array',
            'notes' => 'sometimes|nullable|string',
            'is_active' => 'sometimes|boolean',
            'primary_contact_name' => 'sometimes|nullable|string|max:255',
            'primary_contact_email' => 'sometimes|nullable|email|max:255',
            'primary_contact_phone' => 'sometimes|nullable|string|max:50',
        ]);

        // Map alias
        if (!empty($validated['giro'])) { $validated['trade_activity'] = $validated['giro']; unset($validated['giro']); }
        if (!empty($validated['address'])) { $validated['billing_address_1'] = $validated['address']; unset($validated['address']); }

        // Actualizar RUT si enviaron document_number
        $newRut = $validated['document_number'] ?? null;
        if ($newRut && mb_strtolower($newRut) !== mb_strtolower((string)$customer->rut)) {
            $exists = CustomerSale::where('subsidiary_id', $subsidiary->id)
                ->where('id', '!=', $customer->id)
                ->whereRaw('LOWER(rut) = ?', [mb_strtolower($newRut)])
                ->exists();
            if ($exists) {
                return response()->json(['message'=>'El RUT ya existe para esta subsidiary.','errors'=>['document_number'=>['Duplicado']]], 422);
            }
            $validated['rut'] = $newRut;
        }

        // Validar grupo de contacto principal si alguno viene
        $pcName = $validated['primary_contact_name'] ?? null;
        $pcEmail = $validated['primary_contact_email'] ?? null;
        $pcPhone = $validated['primary_contact_phone'] ?? null;
        $anyPc = $pcName || $pcEmail || $pcPhone;
        if ($anyPc && (!$pcName || !$pcEmail || !$pcPhone)) {
            return response()->json(['message' => 'Contacto principal incompleto.','errors'=>['primary_contact'=>['Debe incluir nombre, email y teléfono']]], 422);
        }

        $customer->update($validated);

        // Notificación: customer-sale.updated
        $this->dispatchNotification(
            typeKey: 'customer-sale.updated',
            entityType: 'customer_sale',
            entityId: $customer->id,
            scope: $this->subsidiaryScope($subsidiary),
            payload: array_merge([
                'customer_name' => $customer->billing_company ?: $customer->contact_name,
                'subsidiary_name' => $subsidiary->subsidiary_name,
                'action' => 'actualizado',
            ], $this->currentUserPayload('updated_by'))
        );

        return response()->json([
            'message' => 'Cliente venta actualizado correctamente',
            'data' => CustomerSaleResource::make($customer->fresh(['subsidiary']))
        ]);
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/customer-sales/{customer}
     */
    public function destroy(Subsidiary $subsidiary, int $customer)
    {
        abort_unless(Gate::allows('delete', $subsidiary), 403);

        $customer = CustomerSale::where('subsidiary_id', $subsidiary->id)->findOrFail($customer);

        // Notificación: customer-sale.deleted (antes de eliminar)
        $this->dispatchNotification(
            typeKey: 'customer-sale.deleted',
            entityType: 'customer_sale',
            entityId: $customer->id,
            scope: $this->subsidiaryScope($subsidiary),
            payload: array_merge([
                'customer_name' => $customer->billing_company ?: $customer->contact_name,
                'subsidiary_name' => $subsidiary->subsidiary_name,
                'action' => 'eliminado',
            ], $this->currentUserPayload('updated_by'))
        );

        $customer->delete();

        return response()->json(['message' => 'Cliente de ventas eliminado.']);
    }

    /**
     * Estructura de hint para respuestas 422 con los campos requeridos/opcionales.
     */
    private function hintPayload(Subsidiary $subsidiary, string $message = 'Revisa los campos requeridos.'): array
    {
        return [
            'message' => $message,
            'hint' => 'Campos esperados para crear un cliente (customer_sale)',
            'required' => [
                'subsidiary_id' => $subsidiary->id,
                'document_type' => 'rut (por defecto)',
                'document_number' => '12345678-9 (RUT)',
                'email' => 'cliente@ejemplo.cl',
            ],
            'optional' => [
                'customer_code' => 'C-001',
                'type' => 'company | natural (por defecto: natural)',
                'billing_company' => 'Empresa S.A.',
                'giro' => 'Comercial',
                'contact_name' => 'Juan Pérez',
                'phone' => '+56 9 1234 5678',
                'address' => 'Calle 123',
                'commune_id' => 1,
                'primary_contact_name' => 'María Pérez',
                'primary_contact_email' => 'maria@ejemplo.cl',
                'primary_contact_phone' => '+56 9 1111 2222',
                'default_document_type' => 'factura | boleta',
                'preferred_payment_method' => 'transferencia | tarjetas',
                'billing_state_code' => 'RM',
                'billing_postcode' => '8320000',
                'billing_country_code' => 'CL',
                'billing_address_2' => null,
                'billing_city' => 'Santiago',
                'shipping_address_1' => null,
                'shipping_address_2' => null,
                'shipping_city' => null,
                'shipping_commune_id' => null,
                'shipping_state_code' => null,
                'shipping_postcode' => null,
                'shipping_country_code' => null,
                'purchase_order_number' => null,
                'commercial_data' => ['notas' => 'cliente preferente'],
                'notes' => 'Observaciones internas',
                'is_active' => true,
            ],
        ];
    }
}
