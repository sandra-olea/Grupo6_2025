<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\TechnicalReview\StoreTechnicalReviewBatchRequest;
use App\Http\Resources\TechnicalReviewBatchResource;
use App\Models\Branch;
use App\Models\CustomerSupplier;
use App\Models\TechnicalReviewBatch;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Str;

class TechnicalReviewBatchController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
    }

    /**
     * Display a listing of batches
     */
    public function index(Request $request, Branch $branch): JsonResponse
    {
        $this->authorize('viewAny', TechnicalReviewBatch::class);

        $query = TechnicalReviewBatch::with(['branch', 'warehouse', 'customerSupplier', 'supplier', 'creator', 'updater'])
            ->withCount('items')
            ->byBranch($branch->id);

        // Filtros
        if ($request->filled('warehouse_id')) {
            $query->byWarehouse((int) $request->warehouse_id);
        }

        if ($request->filled('status')) {
            $query->byStatus((string) $request->status);
        }

        // Filtro por cliente/proveedor (customer_supplier)
        if ($request->filled('customer_supplier_id')) {
            $query->where('customer_supplier_id', (int) $request->customer_supplier_id);
        }

        // Filtro por año del entry_date
        if ($request->filled('year')) {
            $query->whereYear('entry_date', (int) $request->year);
        }

        // Rango de fechas de entry_date (acepta start_date/end_date o date_from/date_to)
        $dateFrom = $request->input('start_date') ?? $request->input('date_from');
        $dateTo   = $request->input('end_date') ?? $request->input('date_to');
        if (!empty($dateFrom)) {
            $query->whereDate('entry_date', '>=', $dateFrom);
        }
        if (!empty($dateTo)) {
            $query->whereDate('entry_date', '<=', $dateTo);
        }

        // Búsqueda general: por código de lote o por serie de items
        if ($term = trim((string) ($request->input('search') ?? $request->input('q') ?? ''))) {
            $query->where(function ($w) use ($term) {
                $w->where('code', 'ILIKE', "%{$term}%")
                  ->orWhereHas('items', function ($qi) use ($term) {
                      $qi->where('serial_number', 'ILIKE', "%{$term}%");
                  });
            });
        }

        $batches = $query->latest()->paginate($request->per_page ?? 15);

        return response()->json([
            'success' => true,
            'data' => TechnicalReviewBatchResource::collection($batches),
            'meta' => [
                'current_page' => $batches->currentPage(),
                'last_page' => $batches->lastPage(),
                'per_page' => $batches->perPage(),
                'total' => $batches->total(),
            ],
        ]);
    }

    /**
     * Store a newly created batch
     */
    public function store(StoreTechnicalReviewBatchRequest $request, Branch $branch): JsonResponse
    {
        $payload = [
            ...$request->safe()->except(['branch_id']),
            'branch_id' => $branch->id,
            'created_by' => auth()->id(),
        ];

        // Generamos el código con la data completa para reflejar el cliente y la fecha
        $payload['code'] = $this->generateBatchCode(
            $branch,
            $payload['customer_supplier_id'] ?? null,
            $payload['entry_date']
        );

        $batch = TechnicalReviewBatch::create($payload);

        $batch->load(['branch', 'warehouse', 'customerSupplier', 'supplier', 'creator', 'updater'])
            ->loadCount('items');

        return response()->json([
            'success' => true,
            'message' => 'Lote creado exitosamente',
            'data' => new TechnicalReviewBatchResource($batch),
        ], 201);
    }

    /**
     * Display the specified batch
     */
    public function show(Branch $branch, int $id): JsonResponse
    {
        $batch = $this->findBatchForBranchOrFail($branch, $id, ['branch', 'warehouse', 'customerSupplier', 'supplier', 'items', 'documents', 'creator', 'updater']);

        $this->authorize('view', $batch);

        return response()->json([
            'success' => true,
            'data' => new TechnicalReviewBatchResource($batch),
        ]);
    }

    /**
     * Update the specified batch
     */
    public function update(StoreTechnicalReviewBatchRequest $request, Branch $branch, int $id): JsonResponse
    {
        $batch = $this->findBatchForBranchOrFail($branch, $id);
        $this->authorize('update', $batch);

        $originalBranchId = $batch->branch_id;
        $originalCustomerSupplierId = $batch->customer_supplier_id;
        $originalEntryDate = optional($batch->entry_date)->format('Y-m-d');

        $batch->update([
            ...$request->safe()->except(['branch_id']),
            'branch_id' => $branch->id,
            'updated_by' => auth()->id(),
        ]);

        $branchChanged = $batch->wasChanged('branch_id');
        $customerSupplierChanged = $batch->wasChanged('customer_supplier_id');
        $warehouseChanged = $batch->wasChanged('warehouse_id');

        $batch->refresh();

        if ($branchChanged) {
            $batch->items()->update(['branch_id' => $batch->branch_id]);
        }

        if ($customerSupplierChanged) {
            $batch->items()->update(['customer_supplier_id' => $batch->customer_supplier_id]);
        }

        if ($warehouseChanged) {
            $batch->items()->update(['warehouse_id' => $batch->warehouse_id]);
        }

        $newEntryDate = optional($batch->entry_date)->format('Y-m-d');

        if (
            $originalBranchId !== $batch->branch_id ||
            $originalCustomerSupplierId !== $batch->customer_supplier_id ||
            $originalEntryDate !== $newEntryDate
        ) {
            $batch->loadMissing(['branch', 'customerSupplier']);

            $newCode = $this->generateBatchCode(
                $batch->branch ?? $branch,
                $batch->customer_supplier_id,
                $newEntryDate,
                $batch->id
            );

            if ($batch->code !== $newCode) {
                $batch->code = $newCode;
                $batch->save();
            }
        }

        $refreshed = $batch->fresh(['branch', 'warehouse', 'customerSupplier', 'supplier', 'creator', 'updater']);
        $refreshed->loadCount('items');

        return response()->json([
            'success' => true,
            'message' => 'Lote actualizado exitosamente',
            'data' => new TechnicalReviewBatchResource($refreshed),
        ]);
    }

    /**
     * Remove the specified batch
     */
    public function destroy(Branch $branch, int $id): JsonResponse
    {
        $batch = $this->findBatchForBranchOrFail($branch, $id);
        $this->authorize('delete', $batch);

        $batch->delete();

        return response()->json([
            'success' => true,
            'message' => 'Lote eliminado exitosamente',
        ]);
    }

    /**
     * Generate unique batch code
     */
    private function generateBatchCode(Branch $branch, ?int $customerSupplierId, ?string $entryDate, ?int $batchId = null): string
    {
        $branchName = strtoupper(preg_replace('/\s+/', ' ', Str::slug($branch->branch_name, ' ')));

        $customerName = '';
        if ($customerSupplierId) {
            $customer = CustomerSupplier::find($customerSupplierId);
            $customerName = $customer?->name ? ' '.Str::upper($customer->name) : '';
        }

        $date = $entryDate ? Carbon::parse($entryDate) : Carbon::now();
        $year = $date->format('Y');
        $dateFormatted = $date->format('Y-m-d');

        // Usamos el ID actual si está disponible, en otro caso calculamos el siguiente potencial
        $idForCode = $batchId ?? (TechnicalReviewBatch::max('id') ?? 0) + 1;

        $baseCode = sprintf('%d - Revision %s %s%s %s',
            $idForCode,
            $branchName,
            $year,
            $customerName,
            $dateFormatted
        );

        $code = trim(preg_replace('/\s+/', ' ', $baseCode));

        // Evitar duplicados: si existe, agregamos sufijo incremental
        $suffix = 1;
        $uniqueCode = $code;
        while (
            TechnicalReviewBatch::where('code', $uniqueCode)
                ->when($batchId, fn($query) => $query->where('id', '!=', $batchId))
                ->exists()
        ) {
            $suffix++;
            $uniqueCode = $code.' #'.$suffix;
        }

        return $uniqueCode;
    }

    private function findBatchForBranchOrFail(Branch $branch, int $id, array $relations = []): TechnicalReviewBatch
    {
        $query = TechnicalReviewBatch::where('branch_id', $branch->id)
            ->withCount('items');

        if (!empty($relations)) {
            $query->with($relations);
        }

        return $query->findOrFail($id);
    }
}
