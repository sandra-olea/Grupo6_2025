<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TechnicalReviewItem;
use App\Models\TechnicalReviewValidationRule;
use App\Models\TechnicalReviewErrorLog;
use App\Services\TechnicalReviewScoringService;
use App\Enums\EquipmentGrade;
use App\Models\Branch;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class TechnicalReviewValidationController extends Controller
{
    public function __construct(
        protected TechnicalReviewScoringService $scoringService
    ) {}

    /**
     * Validate a single field in real-time
     */
    public function validateField(Request $request, Branch $branch): JsonResponse
    {
        $validated = $request->validate([
            'equipment_type' => 'required|string',
            'field_name' => 'required|string',
            'field_value' => 'required',
        ]);

        // Buscar regla de validación activa para este campo
        $rule = TechnicalReviewValidationRule::active()
            ->where('equipment_type', $validated['equipment_type'])
            ->where('field_name', $validated['field_name'])
            ->first();

        if (!$rule) {
            return response()->json([
                'success' => true,
                'valid' => true,
                'message' => 'No hay reglas de validación específicas para este campo',
            ]);
        }

        $isValid = true;
        $errors = [];
        $warnings = [];

        $config = $rule->rule_config ?? [];
        $value = $this->normalizeFieldValue($validated['field_value']);

        // Validar formato
        if (!empty($config['pattern']) && !preg_match($config['pattern'], (string) $value)) {
            $isValid = false;
            $errors[] = $rule->error_message ?? "El formato no es válido para {$rule->field_name}";
        }

        // Validar rango numérico
        $numericValue = $this->extractNumericValue($value);
        $min = $config['min'] ?? $config['min_value'] ?? null;
        $max = $config['max'] ?? $config['max_value'] ?? null;

        if ($numericValue !== null) {
            if ($min !== null && $numericValue < $min) {
                $isValid = false;
                $errors[] = "El valor debe ser mayor o igual a {$min}";
            }

            if ($max !== null && $numericValue > $max) {
                $isValid = false;
                $errors[] = "El valor debe ser menor o igual a {$max}";
            }
        }

        // Validar valores permitidos
        if (!empty($config['allowed_values']) && is_array($config['allowed_values'])) {
            $allowed = array_map([$this, 'normalizeFieldValue'], $config['allowed_values']);
            if (!in_array($value, $allowed, true)) {
                $isValid = false;
                $errors[] = "Valor no permitido. Opciones válidas: " . implode(', ', $config['allowed_values']);
            }
        }

        // Validar dependencias
        $dependencyConfig = $config['depends_on'] ?? null;
        if (!$dependencyConfig && isset($config['depends_on_field'])) {
            $dependencyConfig = [
                'field' => $config['depends_on_field'],
                'value' => $config['depends_on_value'] ?? null,
            ];
        }

        if ($dependencyConfig && isset($dependencyConfig['field'])) {
            $relatedField = $dependencyConfig['field'];
            $expectedValue = $dependencyConfig['value'] ?? null;
            if ($request->has($relatedField)) {
                $currentDependency = $this->normalizeFieldValue($request->input($relatedField));
                if ($expectedValue !== null && $currentDependency !== $this->normalizeFieldValue($expectedValue)) {
                    $warnings[] = "Este campo depende de {$relatedField} = {$expectedValue}";
                }
            }
        }

        $suggestion = !$isValid
            ? ($config['suggested_value'] ?? null)
            : null;

        return response()->json([
            'success' => true,
            'valid' => $isValid,
            'errors' => $errors,
            'warnings' => $warnings,
            'suggestion' => $suggestion,
            'help_text' => $rule->help_text,
        ]);
    }

    /**
     * Get suggested grade preview without saving
     */
    public function suggestGrade(Request $request, Branch $branch): JsonResponse
    {
        $validated = $request->validate([
            'item_id' => 'required|exists:technical_review_items,id',
        ]);

        $item = TechnicalReviewItem::with('batch')
            ->whereHas('batch', function ($query) use ($branch) {
                $query->where('branch_id', $branch->id);
            })
            ->findOrFail($validated['item_id']);

        $this->authorize('review', $item);

        // Cargar la relación de detalles específica según el tipo de equipo
        $detailsRelationMap = [
            'notebook' => 'notebookDetails',
            'desktop' => 'desktopDetails',
            'docking' => 'dockingDetails',
            'aio' => 'aioDetails',
            'monitor' => 'monitorDetails',
        ];
        
        $equipmentType = $item->equipment_type?->value;
        $detailsRelation = $detailsRelationMap[$equipmentType] ?? null;
        
        if ($detailsRelation) {
            $item->load($detailsRelation);
        }

        if (!$item->details) {
            return response()->json([
                'success' => false,
                'message' => 'Debe completar los detalles técnicos antes de obtener sugerencia de grado',
            ], 422);
        }

        $scoring = $this->scoringService->calculateGrade($item);
        $gradeValue = $scoring['suggested_grade'];
        $gradeEnum = EquipmentGrade::tryFrom((string) $gradeValue);

        return response()->json([
            'success' => true,
            'data' => [
                'suggested_grade' => $gradeValue,
                'grade_label' => $gradeEnum?->label() ?? (string) $gradeValue,
                'grade_description' => $gradeEnum?->description(),
                'confidence' => $scoring['confidence'],
                'total_score' => $scoring['total_score'],
                'breakdown' => $scoring['breakdown'],
                'reasoning' => $scoring['reasoning'],
                'is_auto_assignable' => $scoring['is_auto_assignable'],
                'warnings' => $this->getGradeWarnings($scoring, $item),
            ],
        ]);
    }

    /**
     * Get common errors made by current user
     */
    public function myCommonErrors(Branch $branch): JsonResponse
    {
        $errors = TechnicalReviewErrorLog::where('user_id', auth()->id())
            ->select('field_name', 'error_type', 'error_message')
            ->selectRaw('COUNT(*) as occurrences')
            ->groupBy('field_name', 'error_type', 'error_message')
            ->orderByDesc('occurrences')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'data' => $errors->map(function ($error) {
                return [
                    'field_name' => $error->field_name,
                    'error_type' => $error->error_type,
                    'message' => $error->error_message,
                    'occurrences' => $error->occurrences,
                    'suggestion' => $this->getSuggestionForError($error),
                ];
            }),
        ]);
    }

    /**
     * Get validation rules for equipment type
     */
    public function getValidationRules(Branch $branch, string $equipmentType): JsonResponse
    {
        $types = $this->buildRulesSchema();
        // Normalizar para aceptar mayúsculas/minúsculas (ej.: AIO, Notebook, etc.)
        $key = strtolower($equipmentType);
        $typeSchema = $types[$key] ?? [];
        $data = array_merge($this->buildCommonFieldsSchema(), $typeSchema);

        return response()->json([
            'success' => true,
            'data' => $data,
        ]);
    }

    /**
     * Get full validation rules schema for all equipment types, including common fields.
     */
    public function getAllValidationRules(Branch $branch): JsonResponse
    {
        $schema = $this->buildRulesSchema();
        $common = $this->buildCommonFieldsSchema();

        return response()->json([
            'success' => true,
            'data' => [
                'common' => $common,
                'types' => $schema,
            ],
        ]);
    }

    /**
     * Build the rules schema used by validation endpoints.
     * All fields are optional; the schema acts as guía.
     */
    protected function buildRulesSchema(): array
    {
        $componentCondition = ['ok', 'worn', 'missing_pieces', 'broken'];
        $componentConditionWithScratched = ['ok', 'worn', 'missing_pieces', 'scratched', 'broken'];
        $screenCondition = ['ok', 'minor_wear', 'worn', 'missing_pieces', 'dead_pixels', 'broken'];
        $coverCondition = ['ok', 'minor_wear', 'worn', 'missing_pieces', 'scratched', 'broken'];
        $standCondition = ['ok', 'worn', 'missing_pieces', 'broken', 'no_stand'];
        $batteryStatus = ['excellent', 'good', 'fair', 'poor', 'no_battery'];

        // Etiquetas en español para UI
        $conditionLabels = [
            'ok' => 'Funciona sin problemas',
            'minor_wear' => 'Detalles leves',
            'worn' => 'Desgastado',
            'missing_pieces' => 'Faltan piezas',
            'broken' => 'Roto',
            'scratched' => 'Rayado',
            'dead_pixels' => 'Píxeles muertos',
            'no_stand' => 'Sin base',
            'like_new' => 'Como nuevo',
            'good_shape' => 'Buen estado',
            'visible_wear' => 'Desgaste visible',
            'needs_repair' => 'Requiere reparación',
            'scrap' => 'Solo repuestos',
        ];
        $batteryStatusLabels = [
            'excellent' => 'Excelente',
            'good' => 'Bueno',
            'fair' => 'Aceptable',
            'poor' => 'Pobre',
            'no_battery' => 'Sin batería',
        ];
        $chargerStatusValues = ['buen_estado', 'cable_en_mal_estado', 'no_corresponde_a_equipo', 'no_incluye'];
        $chargerStatusLabels = [
            'buen_estado' => 'Buen estado',
            'cable_en_mal_estado' => 'Cable en mal estado',
            'no_corresponde_a_equipo' => 'No corresponde al equipo',
            'no_incluye' => 'No incluye',
        ];
        // Estado del cable de alimentación (monitores) - tokens en inglés
        $powerCableStatusValues = ['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'];
        $powerCableStatusLabels = [
            'good_condition' => 'Buen estado',
            'damaged_cable' => 'Cable en mal estado',
            'not_matching_equipment' => 'No corresponde al equipo',
            'not_included' => 'No incluye',
        ];

        return [
            'notebook' => [
                'processor' => ['type' => 'string', 'label' => 'Procesador', 'group' => 'Hardware', 'hint' => 'Modelo de CPU (ej: Intel i5-8250U, Ryzen 5 3500U)', 'examples' => ['Intel Core i5-8250U', 'AMD Ryzen 5 3500U']],
                'ram_size' => ['type' => 'string', 'label' => 'RAM', 'group' => 'Hardware', 'hint' => 'Capacidad total de memoria RAM', 'examples' => ['8GB', '16GB']],
                'ram_slots' => ['type' => 'string', 'label' => 'Slots RAM', 'group' => 'Hardware', 'hint' => 'Formato cantidad x módulos (total x cantidad de módulos)', 'examples' => ['8x2', '16x1', '4x2']],
                'ram_type' => ['type' => 'string', 'label' => 'Tipo de RAM', 'group' => 'Hardware', 'hint' => 'Tecnología de RAM soportada', 'examples' => ['DDR4', 'DDR5', 'LPDDR4']],
                'storage_size' => ['type' => 'string', 'label' => 'Almacenamiento', 'group' => 'Hardware', 'hint' => 'Capacidad de almacenamiento principal', 'examples' => ['256GB', '512GB', '1TB']],
                'storage_technology' => [
                    'type' => 'string', 'label' => 'Tecnología de disco', 'group' => 'Hardware',
                    'allowed_values' => ['HDD','SSD','M2','NVME','HYBRID'],
                    'options' => $this->mapOptions(['HDD','SSD','M2','NVME','HYBRID'], [
                        'HDD' => 'Disco duro (HDD)',
                        'SSD' => 'Unidad sólida (SSD)',
                        'M2' => 'M.2',
                        'NVME' => 'NVMe',
                        'HYBRID' => 'Híbrido',
                    ]),
                    'also_accepts' => 'm.2 (se normaliza a M2)',
                    'hint' => 'Tipo de unidad de almacenamiento',
                    'examples' => ['SSD', 'NVME', 'HDD', 'M.2'],
                ],
                'includes_charger' => ['type' => 'boolean', 'label' => 'Incluye cargador', 'group' => 'Accesorios', 'hint' => 'Indica si se entrega con cargador'],
                'charger_watts' => ['type' => 'string', 'label' => 'Watts cargador', 'group' => 'Accesorios', 'hint' => 'Potencia del cargador recomendado', 'examples' => ['45W', '65W', '90W']],
                'charger_status' => [
                    'type' => 'string', 'label' => 'Estado cargador', 'group' => 'Accesorios',
                    'allowed_values' => $chargerStatusValues,
                    'options' => $this->mapOptions($chargerStatusValues, $chargerStatusLabels),
                    'hint' => 'Condición del cargador si se incluye (se almacena en extra_attributes)',
                ],
                'screen_inches' => ['type' => 'string', 'label' => 'Pulgadas pantalla', 'group' => 'Pantalla', 'hint' => 'Tamaño de la pantalla en pulgadas', 'examples' => ['14"', '15.6"']],
                'screen_condition' => [
                    'type' => 'string', 'label' => 'Condición de pantalla', 'group' => 'Pantalla',
                    'allowed_values' => $screenCondition,
                    'options' => [
                        ['value' => 'ok', 'label' => 'Sin observaciones'],
                        ['value' => 'minor_wear', 'label' => 'Detalles leves - pequeños signos de uso o marcas por suciedad (Permite: Grado A)'],
                        ['value' => 'worn', 'label' => 'Con Líneas / Desgaste visible / manchas blancas - máximo 1 mancha (Limita a: Máximo Grado B)'],
                        ['value' => 'dead_pixels', 'label' => 'Píxeles muertos'],
                        ['value' => 'broken', 'label' => 'Rota/Píxeles Muertos excesivos/Manchas excesivas (Limita a: Grado M - Malo)'],
                    ],
                    'hint' => 'Estado físico/visual del panel',
                ],
                'cover_condition' => [
                    'type' => 'string', 'label' => 'Tapa superior', 'group' => 'Carcasa',
                    'allowed_values' => $coverCondition,
                    'options' => [
                        ['value' => 'ok', 'label' => 'Sin daños'],
                        ['value' => 'minor_wear', 'label' => 'Daños leves - rayaduras menores poco visibles y signos de uso (no afecta apariencia general)'],
                        ['value' => 'worn', 'label' => 'Desgaste visible'],
                        ['value' => 'missing_pieces', 'label' => 'Con Piezas Faltantes (Limita a: Máximo Grado C)'],
                        ['value' => 'scratched', 'label' => 'Rayada'],
                        ['value' => 'broken', 'label' => 'Rota'],
                    ],
                    'hint' => 'Estado de la cubierta/tapa superior del equipo',
                ],
                'keyboard_condition' => [
                    'type' => 'string', 'label' => 'Teclado', 'group' => 'Carcasa',
                    'allowed_values' => $componentCondition,
                    'options' => [
                        ['value' => 'ok', 'label' => 'Funciona sin problemas'],
                        ['value' => 'worn', 'label' => 'Desgaste visible'],
                        ['value' => 'missing_pieces', 'label' => 'Con Piezas Faltantes (Faltan teclas o piezas del teclado) - ADVERTENCIA: Máximo Grado C (como máximo 1 tecla dañada o faltante)'],
                        ['value' => 'broken', 'label' => 'Roto'],
                    ],
                    'hint' => 'Estado del teclado. IMPORTANTE: Máximo 1 tecla dañada o faltante para Grado C; más de 1 tecla dañada = Grado M (Malo)',
                ],
                'keyboard_layout' => [
                    'type' => 'string', 'label' => 'Distribución teclado', 'group' => 'Carcasa',
                    'allowed_values' => ['es','us','latam'],
                    'options' => $this->mapOptions(['es','us','latam'], [
                        'es' => 'Español (ES)',
                        'us' => 'Inglés (US)',
                        'latam' => 'Latinoamericano',
                    ]),
                    'hint' => 'Layout físico del teclado (acepta ES/US/LATAM y se normaliza a minúsculas)',
                    'examples' => ['es', 'us', 'latam', 'ES', 'US'],
                ],
                'hinge_condition' => [
                    'type' => 'string', 'label' => 'Bisagras', 'group' => 'Carcasa',
                    'allowed_values' => $componentCondition,
                    'options' => $this->mapOptions($componentCondition, $conditionLabels),
                    'hint' => 'Estado de las bisagras de apertura/cierre',
                ],
                'battery_health' => ['type' => 'string', 'label' => 'Health batería', 'group' => 'Batería', 'hint' => 'Texto o porcentaje informado por el sistema (si aplica)'],
                'battery_status' => [
                    'type' => 'string|integer', 'label' => 'Estado batería', 'group' => 'Batería',
                    'allowed_values' => $batteryStatus,
                    'options' => $this->mapOptions($batteryStatus, $batteryStatusLabels),
                    'also_accepts' => '0-100 o "NN%"',
                    'hint' => 'Puedes ingresar porcentaje o categoría; se normaliza a ambos',
                ],
                'battery_percentage' => ['type' => 'integer', 'label' => 'Porcentaje batería', 'group' => 'Batería', 'min' => 0, 'max' => 100, 'hint' => 'Se llena automáticamente si envías battery_status como porcentaje'],
                // Puertos (cantidades)
                'vga_ports' => ['type' => 'integer', 'label' => 'Puertos VGA', 'group' => 'Puertos', 'min' => 0],
                'hdmi_ports' => ['type' => 'integer', 'label' => 'Puertos HDMI', 'group' => 'Puertos', 'min' => 0],
                'displayport_ports' => ['type' => 'integer', 'label' => 'Puertos DisplayPort', 'group' => 'Puertos', 'min' => 0],
                'usb_c_ports' => ['type' => 'integer', 'label' => 'Puertos USB-C', 'group' => 'Puertos', 'min' => 0],
                'sd_readers' => ['type' => 'integer', 'label' => 'Lectores SD', 'group' => 'Puertos', 'min' => 0],
                'rj45_ports' => ['type' => 'integer', 'label' => 'Puertos RJ45', 'group' => 'Puertos', 'min' => 0],
                'all_ports_functional' => ['type' => 'boolean', 'label' => 'Todos los puertos funcionales', 'group' => 'Puertos', 'hint' => 'Marca si todos los puertos probados funcionan correctamente'],
                'usb_a_ports' => ['type' => 'integer', 'label' => 'Puertos USB-A', 'group' => 'Puertos', 'min' => 0],
                // Otros
                'defective_ports_count' => [
                    'type' => 'integer', 'label' => 'Puertos defectuosos', 'group' => 'Puertos', 'min' => 0,
                    'hint' => 'IMPORTANTE: Solo 1 puerto dañado = Máximo Grado C. Más de 1 puerto dañado = Automáticamente M',
                    'warning' => 'Si tiene más de 1 puerto dañado, el equipo será categoría M independientemente de todo lo demás',
                ],
                'has_biometric' => ['type' => 'boolean', 'label' => 'Biométrico', 'group' => 'Otros', 'hint' => 'Incluye lector de huellas o cámara IR'],
                'has_wifi' => ['type' => 'boolean', 'label' => 'WiFi', 'group' => 'Otros'],
                'has_bluetooth' => ['type' => 'boolean', 'label' => 'Bluetooth', 'group' => 'Otros'],
                'is_touchscreen' => ['type' => 'boolean', 'label' => 'Pantalla táctil', 'group' => 'Pantalla'],
                'touchpad_condition' => [
                    'type' => 'string', 'label' => 'Touchpad', 'group' => 'Carcasa',
                    'allowed_values' => $componentCondition,
                    'options' => $this->mapOptions($componentCondition, $conditionLabels),
                ],
                'bottom_condition' => [
                    'type' => 'string', 'label' => 'Tapa inferior', 'group' => 'Carcasa',
                    'allowed_values' => $componentConditionWithScratched,
                    'options' => $this->mapOptions($componentConditionWithScratched, $conditionLabels),
                ],
                'has_numeric_keypad' => ['type' => 'boolean', 'label' => 'Teclado numérico', 'group' => 'Carcasa'],
                'has_backlit_keyboard' => ['type' => 'boolean', 'label' => 'Teclado retroiluminado', 'group' => 'Carcasa'],
                'operating_system' => [
                    'type' => 'string', 'label' => 'Sistema operativo', 'group' => 'Software',
                    'hint' => 'SO instalado o recomendado',
                    'suggested_values' => [
                        'Windows 10 Home', 'Windows 10 Pro', 'Windows 11 Home', 'Windows 11 Pro',
                    ],
                    'examples' => ['Windows 10 Pro'],
                ],
            ],
            'desktop' => [
                'line' => ['type' => 'string', 'label' => 'Línea', 'group' => 'Identificación'],
                'processor' => ['type' => 'string'],
                'ram_size' => ['type' => 'string'],
                'ram_slots' => ['type' => 'string'],
                'ram_type' => ['type' => 'string'],
                'storage_size' => ['type' => 'string'],
                'storage_technology' => [
                    'type' => 'string',
                    'allowed_values' => ['HDD','SSD','M2','NVME','HYBRID'],
                    'options' => $this->mapOptions(['HDD','SSD','M2','NVME','HYBRID'], [
                        'HDD' => 'Disco duro (HDD)',
                        'SSD' => 'Unidad sólida (SSD)',
                        'M2' => 'M.2',
                        'NVME' => 'NVMe',
                        'HYBRID' => 'Híbrido',
                    ]),
                    'also_accepts' => 'm.2 (se normaliza a M2)',
                ],
                'includes_charger' => ['type' => 'boolean', 'label' => 'Incluye cargador', 'group' => 'Accesorios'],
                'charger_status' => [
                    'type' => 'string', 'label' => 'Estado cargador', 'group' => 'Accesorios',
                    'allowed_values' => ['good_condition','damaged_cable','not_matching_equipment','not_included'],
                    'options' => $this->mapOptions(['good_condition','damaged_cable','not_matching_equipment','not_included'], [
                        'good_condition' => 'Buen estado', 'damaged_cable' => 'Cable en mal estado', 'not_matching_equipment' => 'No corresponde al equipo', 'not_included' => 'No incluye',
                    ]),
                ],
                'cover_condition' => [
                    'type' => 'string', 'label' => 'Carcasa', 'group' => 'Carcasa',
                    'allowed_values' => ['ok','good_condition','light_scratches','noticeable_wear','broken'],
                    'options' => $this->mapOptions(['ok','good_condition','light_scratches','noticeable_wear','broken'], [
                        'ok' => 'OK',
                        'good_condition' => 'Buen estado',
                        'light_scratches' => 'Rayas leves',
                        'noticeable_wear' => 'Desgaste notorio',
                        'broken' => 'Roto',
                    ]),
                ],
                // Puertos (cantidades)
                'vga_ports' => ['type' => 'integer', 'min' => 0],
                'hdmi_ports' => ['type' => 'integer', 'min' => 0],
                'displayport_ports' => ['type' => 'integer', 'min' => 0],
                'usb_c_ports' => ['type' => 'integer', 'min' => 0],
                'sd_readers' => ['type' => 'integer', 'min' => 0],
                'rj45_ports' => ['type' => 'integer', 'min' => 0],
                'usb_a_ports' => ['type' => 'integer', 'min' => 0],
                'all_ports_functional' => ['type' => 'boolean', 'label' => 'Todos los puertos funcionales', 'group' => 'Puertos'],
                'defective_ports_count' => [
                    'type' => 'integer', 'label' => 'Puertos defectuosos', 'group' => 'Puertos', 'min' => 0,
                    'hint' => 'IMPORTANTE: Solo 1 puerto dañado = Máximo Grado C. Más de 1 puerto dañado = Automáticamente M',
                    'warning' => 'Si tiene más de 1 puerto dañado, el equipo será categoría M independientemente de todo lo demás',
                ],
                // Otros
                'has_wifi' => ['type' => 'boolean'],
                'has_bluetooth' => ['type' => 'boolean'],
                'has_cd_drive' => ['type' => 'boolean'],
                'operating_system' => [
                    'type' => 'string', 'label' => 'Sistema operativo', 'group' => 'Software',
                    'hint' => 'SO instalado o recomendado',
                    'suggested_values' => [
                        'Windows 10 Home', 'Windows 10 Pro', 'Windows 11 Home', 'Windows 11 Pro',
                    ],
                    'examples' => ['Windows 11 Pro'],
                ],
            ],
            'docking' => [
                'line' => ['type' => 'string'],
                'includes_power_adapter' => ['type' => 'boolean'],
                // Puertos (cantidades)
                'vga_ports' => ['type' => 'integer', 'min' => 0],
                'hdmi_ports' => ['type' => 'integer', 'min' => 0],
                'displayport_ports' => ['type' => 'integer', 'min' => 0],
                'usb_c_ports' => ['type' => 'integer', 'min' => 0],
                'sd_readers' => ['type' => 'integer', 'min' => 0],
                'rj45_ports' => ['type' => 'integer', 'min' => 0],
                'usb_a_ports' => ['type' => 'integer', 'min' => 0],
                'all_ports_functional' => ['type' => 'boolean', 'label' => 'Todos los puertos funcionales', 'group' => 'Puertos'],
                'defective_ports_count' => [
                    'type' => 'integer', 'label' => 'Puertos defectuosos', 'group' => 'Puertos', 'min' => 0,
                    'hint' => 'IMPORTANTE: Solo 1 puerto dañado = Máximo Grado C. Más de 1 puerto dañado = Automáticamente M',
                    'warning' => 'Si tiene más de 1 puerto dañado, el equipo será categoría M independientemente de todo lo demás',
                ],
                'has_wifi' => ['type' => 'boolean'],
                'cover_condition' => ['type' => 'string', 'allowed_values' => $componentConditionWithScratched],
            ],
            'aio' => [
                'processor' => ['type' => 'string', 'label' => 'Procesador', 'group' => 'Hardware'],
                'ram_size' => ['type' => 'string', 'label' => 'RAM', 'group' => 'Hardware'],
                'ram_slots' => ['type' => 'string', 'label' => 'Slots RAM', 'group' => 'Hardware', 'examples' => ['8x1', '8x2']],
                'ram_type' => ['type' => 'string', 'label' => 'Tipo de RAM', 'group' => 'Hardware'],
                'storage_size' => ['type' => 'string', 'label' => 'Almacenamiento', 'group' => 'Hardware'],
                'storage_technology' => [
                    'type' => 'string', 'label' => 'Tecnología de disco', 'group' => 'Hardware',
                    'allowed_values' => ['HDD','SSD','M2','NVME','HYBRID'],
                    'options' => $this->mapOptions(['HDD','SSD','M2','NVME','HYBRID'], [
                        'HDD' => 'Disco duro (HDD)', 'SSD' => 'Unidad sólida (SSD)', 'M2' => 'M.2', 'NVME' => 'NVMe', 'HYBRID' => 'Híbrido',
                    ]),
                    'also_accepts' => 'm.2 (se normaliza a M2)',
                ],
                // Accesorios (AIO usa charger_status top-level en inglés; Notebook mantiene extra_attributes)
                'includes_power_adapter' => ['type' => 'boolean', 'label' => 'Incluye adaptador de poder', 'group' => 'Accesorios'],
                'includes_charger' => ['type' => 'boolean', 'label' => 'Incluye cargador', 'group' => 'Accesorios', 'hint' => 'Alias de adaptador de poder'],
                'charger_status' => [
                    'type' => 'string', 'label' => 'Estado cargador', 'group' => 'Accesorios',
                    'allowed_values' => ['good_condition', 'damaged_cable', 'not_matching_equipment', 'not_included'],
                    'options' => $this->mapOptions(['good_condition','damaged_cable','not_matching_equipment','not_included'], [
                        'good_condition' => 'Buen estado', 'damaged_cable' => 'Cable en mal estado', 'not_matching_equipment' => 'No corresponde al equipo', 'not_included' => 'No incluye',
                    ]),
                ],
                // Puertos (cantidades)
                'vga_ports' => ['type' => 'integer', 'label' => 'Puertos VGA', 'group' => 'Puertos', 'min' => 0],
                'hdmi_ports' => ['type' => 'integer', 'label' => 'Puertos HDMI', 'group' => 'Puertos', 'min' => 0],
                'displayport_ports' => ['type' => 'integer', 'label' => 'Puertos DisplayPort', 'group' => 'Puertos', 'min' => 0],
                'usb_a_ports' => ['type' => 'integer', 'label' => 'Puertos USB-A', 'group' => 'Puertos', 'min' => 0],
                'usb_c_ports' => ['type' => 'integer', 'label' => 'Puertos USB-C', 'group' => 'Puertos', 'min' => 0],
                'sd_readers' => ['type' => 'integer', 'label' => 'Lectores SD', 'group' => 'Puertos', 'min' => 0],
                'rj45_ports' => ['type' => 'integer', 'label' => 'Puertos RJ45', 'group' => 'Puertos', 'min' => 0],
                'all_ports_functional' => ['type' => 'boolean', 'label' => 'Todos los puertos funcionales', 'group' => 'Puertos'],
                'defective_ports_count' => [
                    'type' => 'integer', 'label' => 'Puertos defectuosos', 'group' => 'Puertos', 'min' => 0,
                    'hint' => 'IMPORTANTE: Solo 1 puerto dañado = Máximo Grado C. Más de 1 puerto dañado = Automáticamente M',
                    'warning' => 'Si tiene más de 1 puerto dañado, el equipo será categoría M independientemente de todo lo demás',
                ],
                // Conectividad/otros
                'has_wifi' => ['type' => 'boolean', 'label' => 'WiFi', 'group' => 'Otros'],
                'has_bluetooth' => ['type' => 'boolean', 'label' => 'Bluetooth', 'group' => 'Otros'],
                'has_cd_drive' => ['type' => 'boolean', 'label' => 'Unidad óptica', 'group' => 'Otros'],
                // Pantalla y base
                'screen_inches' => ['type' => 'string', 'label' => 'Pulgadas pantalla', 'group' => 'Pantalla'],
                'screen_condition' => ['type' => 'string', 'label' => 'Condición de pantalla', 'group' => 'Pantalla', 'allowed_values' => $screenCondition, 'options' => $this->mapOptions($screenCondition, [
                    'ok' => 'OK', 'worn' => 'Leve desgaste', 'missing_pieces' => 'Desgaste notorio', 'dead_pixels' => 'Píxeles muertos', 'broken' => 'Roto',
                ])],
                'stand_condition' => [
                    'type' => 'string', 'label' => 'Condición de base', 'group' => 'Base',
                    'allowed_values' => ['ok','worn','missing_pieces','scratched','broken','no_stand'],
                    'options' => [
                        ['value' => 'ok', 'label' => 'OK'],
                        ['value' => 'worn', 'label' => 'Leve desgaste'],
                        ['value' => 'missing_pieces', 'label' => 'Desgaste notorio'],
                        ['value' => 'scratched', 'label' => 'Rayado'],
                        ['value' => 'broken', 'label' => 'Base mala'],
                        ['value' => 'no_stand', 'label' => 'N/A (no aplica)'],
                    ],
                ],
                'is_touchscreen' => ['type' => 'boolean', 'label' => 'Pantalla táctil', 'group' => 'Pantalla'],
                'cover_condition' => ['type' => 'string', 'label' => 'Carcasa', 'group' => 'Carcasa', 'allowed_values' => $componentConditionWithScratched, 'options' => $this->mapOptions($componentConditionWithScratched, [
                    'ok' => 'OK', 'worn' => 'Leve desgaste', 'missing_pieces' => 'Faltan piezas', 'scratched' => 'Rayado', 'broken' => 'Roto',
                ])],
                // Software
                'operating_system' => ['type' => 'string', 'label' => 'Sistema operativo', 'group' => 'Software',
                    'hint' => 'SO instalado o recomendado',
                    'suggested_values' => ['Windows 10 Home', 'Windows 10 Pro', 'Windows 11 Home', 'Windows 11 Pro'],
                    'examples' => ['Windows 11 Pro'],
                ],
            ],
            'monitor' => [
                'line' => ['type' => 'string', 'label' => 'Línea', 'group' => 'Identificación'],
                'screen_inches' => ['type' => 'string'],
                'screen_condition' => ['type' => 'string', 'allowed_values' => $screenCondition],
                'stand_condition' => ['type' => 'string', 'allowed_values' => $standCondition],
                'includes_power_cable' => ['type' => 'boolean', 'label' => 'Incluye cable de poder', 'group' => 'Accesorios'],
                'includes_video_cable' => ['type' => 'boolean', 'label' => 'Incluye cable de video', 'group' => 'Accesorios'],
                'includes_stand' => ['type' => 'boolean', 'label' => 'Incluye base', 'group' => 'Accesorios'],
                'has_usb_hub' => ['type' => 'boolean', 'label' => 'Incluye hub USB', 'group' => 'Puertos'],
                // Puertos (cantidades)
                'vga_ports' => ['type' => 'integer', 'min' => 0],
                'hdmi_ports' => ['type' => 'integer', 'min' => 0],
                'displayport_ports' => ['type' => 'integer', 'min' => 0],
                'dvi_ports' => ['type' => 'integer', 'min' => 0],
                'usb_hub_ports' => ['type' => 'integer', 'min' => 0],
                'all_ports_functional' => ['type' => 'boolean', 'label' => 'Todos los puertos funcionales', 'group' => 'Puertos'],
                'defective_ports_count' => [
                    'type' => 'integer', 'label' => 'Puertos defectuosos', 'group' => 'Puertos', 'min' => 0,
                    'hint' => 'IMPORTANTE: Solo 1 puerto dañado = Máximo Grado C. Más de 1 puerto dañado = Automáticamente M',
                    'warning' => 'Si tiene más de 1 puerto dañado, el equipo será categoría M independientemente de todo lo demás',
                ],
                'defective_ports_critical_count' => [
                    'type' => 'integer', 'label' => 'Puertos críticos defectuosos', 'group' => 'Puertos', 'min' => 0,
                    'hint' => 'Puertos críticos como HDMI/DisplayPort. 1 puerto crítico dañado = Máximo C. Más de 1 = Automáticamente M',
                    'warning' => 'Registrar solo puertos esenciales para operaciones estándar',
                ],
                'frame_condition' => ['type' => 'string', 'allowed_values' => $componentConditionWithScratched],
                'screen_resolution' => ['type' => 'string'],
                'is_touchscreen' => ['type' => 'boolean'],
            ],
        ];
    }

    /**
     * Campos comunes presentes en todos los tipos.
     */
    protected function buildCommonFieldsSchema(): array
    {
        return [
            'brand' => [
                'type' => 'string', 'label' => 'Marca', 'group' => 'Identificación',
                'hint' => 'Fabricante del equipo (Dell, HP, Lenovo, etc.)',
            ],
            'model' => [
                'type' => 'string', 'label' => 'Modelo', 'group' => 'Identificación',
                'hint' => 'Modelo exacto del equipo para referencia y compatibilidad',
            ],
            'general_condition' => [
                'type' => 'string', 'label' => 'Condición general', 'group' => 'Condición',
                'allowed_values' => ['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'],
                'options' => $this->mapOptions(['like_new', 'good_shape', 'visible_wear', 'needs_repair', 'scrap'], [
                    'like_new' => 'Como nuevo',
                    'good_shape' => 'Buen estado',
                    'visible_wear' => 'Desgaste visible',
                    'needs_repair' => 'Requiere reparación',
                    'scrap' => 'Solo repuestos',
                ]),
                'hint' => 'Estado general del equipo considerando estética y funcionamiento global',
            ],
            'observations' => [
                'type' => 'string', 'label' => 'Observaciones', 'group' => 'Notas',
                'hint' => 'Notas libres relevantes encontradas durante la revisión',
                'examples' => [
                    'Teclado con dos teclas flojas',
                    'Bisagra izquierda con juego',
                    'Carcasa con rayón leve',
                ],
            ],
            'extra_attributes' => [
                'type' => 'object', 'label' => 'Atributos extra', 'group' => 'Extras',
                'hint' => 'Contenedor para atributos específicos no estandarizados',
            ],
        ];
    }

    /**
     * Convierte una lista de valores a una lista de opciones { value, label } usando etiquetas provistas.
     */
    protected function mapOptions(array $values, array $labels): array
    {
        $out = [];
        foreach ($values as $v) {
            $out[] = [
                'value' => $v,
                'label' => $labels[$v] ?? (string) $v,
            ];
        }
        return $out;
    }

    /**
     * Get statistics for validation errors
     */
    public function errorStatistics(Request $request, Branch $branch): JsonResponse
    {
        $baseQuery = TechnicalReviewErrorLog::query();

        // Filtrar por fecha
        if ($request->filled('start_date')) {
            $baseQuery->where('created_at', '>=', $request->start_date);
        }

        if ($request->filled('end_date')) {
            $baseQuery->where('created_at', '<=', $request->end_date);
        }

        // Filtrar por tipo de equipo
        if ($request->filled('equipment_type')) {
            $baseQuery->whereHas('reviewItem', function ($q) use ($request) {
                $q->where('equipment_type', $request->equipment_type);
            });
        }

        $errorsByField = (clone $baseQuery)->select('field_name', 'error_type')
            ->selectRaw('COUNT(*) as total')
            ->groupBy('field_name', 'error_type')
            ->orderByDesc('total')
            ->limit(20)
            ->get();

        $errorsByUser = (clone $baseQuery)->with('user:id,name')
            ->select('user_id')
            ->selectRaw('COUNT(*) as total')
            ->groupBy('user_id')
            ->orderByDesc('total')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'by_field' => $errorsByField,
                'by_user' => $errorsByUser->map(function ($item) {
                    return [
                        'user' => $item->user?->name ?? 'Usuario eliminado',
                        'total_errors' => $item->total,
                    ];
                }),
                'total_errors' => (clone $baseQuery)->count(),
            ],
        ]);
    }

    /**
     * Get warnings for grade calculation
     */
    protected function getGradeWarnings(array $scoring, TechnicalReviewItem $item): array
    {
        $warnings = [];

        // Advertencia de baja confianza
        if ($scoring['confidence'] < 70) {
            $warnings[] = [
                'type' => 'low_confidence',
                'message' => 'Confianza baja en el scoring automático. Se recomienda revisión manual.',
            ];
        }

        // Advertencia de grado bajo con batería buena
        $gradeValue = strtoupper((string) ($scoring['suggested_grade'] ?? ''));
        $batteryScore = $scoring['breakdown']['battery'] ?? null;
        if ($gradeValue === 'C' && $batteryScore !== null && $batteryScore > 15) {
            $warnings[] = [
                'type' => 'good_battery_low_grade',
                'message' => 'El equipo tiene buena batería pero bajo grado por otros factores.',
            ];
        }

        // Advertencia de override común
        $aestheticScore = $scoring['breakdown']['aesthetic'] ?? null;
        if ($item->equipment_type->value === 'notebook' && $aestheticScore !== null && $aestheticScore < 20) {
            $warnings[] = [
                'type' => 'aesthetic_issues',
                'message' => 'Problemas estéticos significativos detectados. Verificar si afecta la funcionalidad.',
            ];
        }

        return $warnings;
    }

    /**
     * Get suggestion for common error
     */
    protected function getSuggestionForError($error): ?string
    {
        return match($error->field_name) {
            'ram_size' => 'Use formato: 8GB, 16GB, etc.',
            'storage_size' => 'Use formato: 256GB, 512GB, 1TB, etc.',
            'processor' => 'Incluya generación y velocidad: i5-8250U 1.60GHz',
            'battery_health' => 'Use porcentaje: 75% o estado: GOOD, EXCELLENT',
            default => 'Revise las reglas de validación para este campo',
        };
    }

    /**
     * Normaliza valores para comparaciones consistentes
     */
    private function normalizeFieldValue(mixed $value): mixed
    {
        if (is_string($value)) {
            return trim($value);
        }

        if (is_numeric($value)) {
            return $value + 0;
        }

        return $value;
    }

    /**
     * Extrae un valor numérico de una cadena
     */
    private function extractNumericValue(mixed $value): ?float
    {
        if (is_numeric($value)) {
            return (float) $value;
        }

        if (is_string($value) && preg_match('/-?\d+(?:\.\d+)?/', $value, $matches)) {
            return (float) $matches[0];
        }

        return null;
    }
}
