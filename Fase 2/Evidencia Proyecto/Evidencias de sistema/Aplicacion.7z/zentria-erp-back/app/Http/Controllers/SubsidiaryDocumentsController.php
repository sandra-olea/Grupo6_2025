<?php

namespace App\Http\Controllers;

use App\Http\Resources\DocumentResource;
use App\Models\Document;
use App\Models\DocumentType;
use App\Models\Subsidiary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class SubsidiaryDocumentsController extends Controller
{
    private const RELATED_MODULES = [
        'CLIENTE', 'CLIENTE-PROVEEDOR', 'VENTAS', 'REVISIONES TÉCNICAS', 'PRODUCTO'
    ];

    public function index(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $q = Document::query()->where('subsidiary_id', $subsidiary->id);

        if ($s = trim((string) $request->get('q'))) {
            $q->where('name', 'ILIKE', "%{$s}%");
        }
        if ($module = $request->get('related_module')) {
            $q->where('related_module', $module);
        }
        if ($typeId = $request->integer('document_type_id')) {
            $q->where('document_type_id', $typeId);
        }
        if ($relId = $request->integer('related_id')) {
            $q->where('related_id', $relId);
        }
        if ($format = $request->get('output_format')) {
            $q->where('output_format', $format);
        }
        if (!is_null($request->get('is_active'))) {
            $q->where('is_active', filter_var($request->get('is_active'), FILTER_VALIDATE_BOOL));
        }

        if ($request->boolean('with_type')) $q->with('documentType');
        if ($request->boolean('with_subsidiary')) $q->with('subsidiary');
        // Load attachments by default to replicate with_attachments=1 behavior
        $q->with('media');

        $q->orderBy('name');
        return DocumentResource::collection(
            $q->paginate($request->integer('per_page', 15))->appends($request->query())
        );
    }

    public function store(Request $request, Subsidiary $subsidiary)
    {
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $data = $request->validate([
            'document_type_id' => ['required','integer','exists:document_types,id'],
            'name' => ['required','string','max:255'],
            'description' => ['nullable','string'],
            'output_format' => ['sometimes','string','max:16'],
            'related_module' => ['nullable','string','max:64','in:CLIENTE,CLIENTE-PROVEEDOR,VENTAS,REVISIONES TÉCNICAS,PRODUCTO'],
            'related_id' => ['nullable','integer'],
            'template_body' => ['nullable','string'],
            'metadata' => ['nullable','array'],
            'is_active' => ['sometimes','boolean'],
        ]);

        $data['subsidiary_id'] = $subsidiary->id;
        $document = Document::create($data);

        return DocumentResource::make($document->load(['documentType']))->response()->setStatusCode(201);
    }

    public function show(Subsidiary $subsidiary, Document $document)
    {
        abort_if($document->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('view', $subsidiary), 403);
        // Cargar 'media' para que el recurso incluya adjuntos por defecto en detalle
        return DocumentResource::make($document->load(['documentType','media']));
    }

    public function update(Request $request, Subsidiary $subsidiary, Document $document)
    {
        abort_if($document->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $data = $request->validate([
            'document_type_id' => ['sometimes','integer','exists:document_types,id'],
            'name' => ['sometimes','string','max:255'],
            'description' => ['nullable','string'],
            'output_format' => ['sometimes','string','max:16'],
            'related_module' => ['nullable','string','max:64','in:CLIENTE,CLIENTE-PROVEEDOR,VENTAS,REVISIONES TÉCNICAS,PRODUCTO'],
            'related_id' => ['nullable','integer'],
            'template_body' => ['nullable','string'],
            'metadata' => ['nullable','array'],
            'is_active' => ['sometimes','boolean'],
        ]);

        $document->update($data);
        return DocumentResource::make($document->load(['documentType']));
    }

    public function destroy(Subsidiary $subsidiary, Document $document)
    {
        abort_if($document->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('delete', $subsidiary), 403);
        $document->delete();
        return response()->json(['deleted' => true]);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/documents/{document}/attachments
     * Subir uno o varios archivos adjuntos al documento (cualquier tipo común)
     */
    public function uploadAttachments(Request $request, Subsidiary $subsidiary, Document $document)
    {
        abort_if($document->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('update', $subsidiary), 403);

        // Permitir subir 1 archivo (campo 'file') o múltiples (campo 'files[]' o 'files')
        $files = [];
        if ($request->hasFile('file')) {
            $request->validate([
                'file' => ['required','file','max:51200', 'mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,jpg,jpeg,png,webp,svg,txt,csv,zip,rar'],
                'collection' => ['nullable','string','max:50'],
            ]);
            $files = [ $request->file('file') ];
        } elseif ($request->hasFile('files')) {
            $raw = $request->file('files');
            if (is_array($raw)) {
                // Caso files[]
                $request->validate([
                    'files'   => ['required','array','min:1'],
                    'files.*' => ['file','max:51200', 'mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,jpg,jpeg,png,webp,svg,txt,csv,zip,rar'],
                    'collection' => ['nullable','string','max:50'],
                ]);
                $files = array_values($raw);
            } else {
                // Caso files (único archivo sin [])
                $request->validate([
                    'files' => ['required','file','max:51200', 'mimes:pdf,doc,docx,xls,xlsx,ppt,pptx,jpg,jpeg,png,webp,svg,txt,csv,zip,rar'],
                    'collection' => ['nullable','string','max:50'],
                ]);
                $files = [ $raw ];
            }
        } else {
            return response()->json([
                'message' => 'Debes enviar un archivo en el campo file o en files/files[]',
                'errors' => ['file' => ['Archivo requerido'], 'files' => ['Archivo(s) requerido(s)']],
            ], 422);
        }

        $collection = $request->string('collection')->toString() ?: 'files';

        $out = [];
        foreach ($files as $file) {
            $originalName = $file->getClientOriginalName() ?: $file->hashName();
            $unique = $this->makeUniqueFileNameForUpload($originalName);
            $u = auth('api')->user();
            $uploadedBy = $u ? trim(($u->first_name ?? $u->name ?? '').' '.($u->last_name ?? '')) ?: ($u->email ?? 'User') : null;
            $m = $document->addMedia($file)
                ->usingFileName($unique)
                ->withCustomProperties([
                    'original_name' => $originalName,
                    'uploaded_by' => $uploadedBy,
                ])
                ->toMediaCollection($collection);

            $out[] = [
                'id' => $m->id,
                'url' => $m->getUrl(),
                'file_name' => $m->file_name,
                'mime_type' => $m->mime_type,
                'size' => $m->size,
            ];
        }

        return response()->json(['uploaded' => count($out), 'items' => $out], 201);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/documents/{document}/attachments
     */
    public function listAttachments(Subsidiary $subsidiary, Document $document)
    {
        abort_if($document->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('view', $subsidiary), 403);
        // Return media from the known collections (files + attachments)
        $media = collect([])
            ->merge($document->getMedia('files'))
            ->merge($document->getMedia('attachments'));
        return response()->json([
            'data' => $media->map(fn($m) => [
                'id' => $m->id,
                'collection' => $m->collection_name,
                'url' => $m->getUrl(),
                'file_name' => $m->file_name,
                'mime_type' => $m->mime_type,
                // Report size in KB for consistency with list/detail
                'size' => (int) round($m->size / 1024),
                'original_name' => $m->getCustomProperty('original_name'),
                'uploaded_by' => $m->getCustomProperty('uploaded_by'),
                'uploaded_at' => $m->created_at,
            ]),
        ]);
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/documents/{document}/attachments/{media}
     */
    public function deleteAttachment(Subsidiary $subsidiary, Document $document, int $media)
    {
        abort_if($document->subsidiary_id !== $subsidiary->id, 404);
        abort_unless(Gate::allows('update', $subsidiary), 403);
        $m = \App\Models\Media\Media::where('model_type', Document::class)
            ->where('model_id', $document->id)
            ->findOrFail($media);
        $m->delete();
        return response()->json(['deleted' => true]);
    }

    private function makeUniqueFileNameForUpload(string $originalName): string
    {
        $name = trim($originalName);
        $name = str_replace(['\\', '/'], '-', $name);
        $name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? $name;
        $name = str_replace([':', '*', '?', '"', '<', '>', '|'], '-', $name);
        $pos = strrpos($name, '.');
        $base = $pos === false ? $name : substr($name, 0, $pos);
        $ext  = $pos === false ? '' : substr($name, $pos + 1);
        $base = preg_replace('/[^\w\-\_]/u', '-', $base);
        $base = preg_replace('/-+/', '-', $base);
        $base = trim($base, '-');
        if ($base === '' || $base === '.' || $base === '..') { $base = 'archivo'; }
        $timestamp = time();
        $random = substr(md5(uniqid('', true) . random_bytes(8)), 0, 6);
        return sprintf('%s_%d_%s%s', $base, $timestamp, $random, $ext !== '' ? '.' . $ext : '');
    }
}
