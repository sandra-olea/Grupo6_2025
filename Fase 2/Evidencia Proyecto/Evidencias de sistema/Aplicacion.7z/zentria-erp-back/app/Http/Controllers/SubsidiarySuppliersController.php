<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\Supplier\StoreSupplierRequest;
use App\Http\Requests\Supplier\UpdateSupplierRequest;
use App\Http\Resources\SupplierResource;
use App\Models\Subsidiary;
use App\Models\Supplier;
use App\Traits\DispatchesNotifications;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

class SubsidiarySuppliersController extends Controller
{
    use DispatchesNotifications;
    /**
     * GET /api/subsidiaries/{subsidiary}/suppliers
     * Listar todos los proveedores de una subsidiary
     */
    public function index(Request $request, Subsidiary $subsidiary)
    {
        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $query = Supplier::query()
            ->where('subsidiary_id', $subsidiary->id)
            ->withCount('customerSuppliers'); // Siempre incluir count

        // Búsqueda
        if ($search = trim((string)$request->get('q'))) {
            $query->where('name', 'ILIKE', "%{$search}%");
        }

        // Solo incluir clientes si se solicita explícitamente (para evitar sobrecarga)
        if ($request->boolean('with_customers')) {
            // Limitar a los primeros N clientes para evitar sobrecarga
            $limit = min($request->integer('customers_limit', 10), 50); // Máximo 50
            
            $query->with(['customerSuppliers' => function($q) use ($limit) {
                $q->select('customer_suppliers.id', 'customer_suppliers.name', 'customer_suppliers.subsidiary_id')
                  ->orderBy('customer_suppliers.name', 'asc')
                  ->limit($limit);
            }]);
        }

        // Incluir relaciones opcionales adicionales
        if ($request->boolean('with_subsidiary')) {
            $query->with('subsidiary');
        }

        $query->orderBy('name', 'asc');

        return SupplierResource::collection(
            $query->paginate($request->integer('per_page', 15))->appends($request->query())
        );
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/suppliers
     * Crear un nuevo proveedor
     */
    public function store(StoreSupplierRequest $request, Subsidiary $subsidiary)
    {
        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $supplier = $subsidiary->suppliers()->create([
            'name' => $request->string('name')->toString(),
        ]);

        // Notificación: supplier.created
        $this->dispatchNotification(
            typeKey: 'supplier.created',
            entityType: 'supplier',
            entityId: $supplier->id,
            scope: $this->subsidiaryScope($subsidiary),
            payload: array_merge(
                [
                    'supplier_name' => $supplier->name,
                    'subsidiary_name' => $subsidiary->subsidiary_name,
                    'action' => 'creado',
                ],
                $this->currentUserPayload('created_by')
            )
        );

        return SupplierResource::make($supplier)->response()->setStatusCode(201);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/suppliers/{supplier}
     * Mostrar un proveedor específico
     */
    public function show(Subsidiary $subsidiary, Supplier $supplier)
    {
        // Verificar que el proveedor pertenece a la subsidiary
        abort_if($supplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('view', $subsidiary), 403);

        // Cargar count siempre
        $supplier->loadCount('customerSuppliers');
        $supplier->load('subsidiary');

        // Solo cargar clientes si se solicita y con límite
        if (request()->boolean('with_customers')) {
            $limit = min(request()->integer('customers_limit', 10), 50);
            $supplier->load(['customerSuppliers' => function($q) use ($limit) {
                $q->select('customer_suppliers.id', 'customer_suppliers.name', 'customer_suppliers.subsidiary_id')
                  ->orderBy('customer_suppliers.name', 'asc')
                  ->limit($limit);
            }]);
        }

        return SupplierResource::make($supplier);
    }

    /**
     * PATCH /api/subsidiaries/{subsidiary}/suppliers/{supplier}
     * Actualizar un proveedor
     */
    public function update(UpdateSupplierRequest $request, Subsidiary $subsidiary, Supplier $supplier)
    {
        // Verificar que el proveedor pertenece a la subsidiary
        abort_if($supplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $supplier->update([
            'name' => $request->string('name')->toString(),
        ]);

        // Notificación: supplier.updated
        try {
            $type = NotificationType::where('key', 'supplier.updated')->first();
            if ($type) {
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'supplier',
                    'entity_id' => $supplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'supplier_name' => $supplier->name,
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'actualizado',
                        'updated_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'updated_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'supplier.updated:'.$supplier->id,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        return SupplierResource::make($supplier->fresh());
    }

    /**
     * DELETE /api/subsidiaries/{subsidiary}/suppliers/{supplier}
     * Eliminar un proveedor
     */
    public function destroy(Subsidiary $subsidiary, Supplier $supplier)
    {
        // Verificar que el proveedor pertenece a la subsidiary
        abort_if($supplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('delete', $subsidiary), 403);

        // Notificación: supplier.deleted (antes de eliminar)
        try {
            $type = NotificationType::where('key', 'supplier.deleted')->first();
            if ($type) {
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'supplier',
                    'entity_id' => $supplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'supplier_name' => $supplier->name,
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'eliminado',
                        'deleted_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'deleted_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'supplier.deleted:'.$supplier->id,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        $supplier->delete();

        return response()->json([
            'message' => 'Proveedor eliminado exitosamente.'
        ], 200);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/suppliers/{supplier}/attach-customers
     * Asociar clientes-proveedores a un proveedor
     */
    public function attachCustomers(Request $request, Subsidiary $subsidiary, Supplier $supplier)
    {
        // Verificar que el proveedor pertenece a la subsidiary
        abort_if($supplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $validated = $request->validate([
            'customer_supplier_ids' => ['required', 'array', 'min:1'],
            'customer_supplier_ids.*' => ['integer', 'exists:customer_suppliers,id'],
        ]);

        // Verificar que todos los clientes pertenecen a la misma subsidiary
        $invalidCustomers = \App\Models\CustomerSupplier::whereIn('id', $validated['customer_supplier_ids'])
            ->where('subsidiary_id', '!=', $subsidiary->id)
            ->exists();

        abort_if($invalidCustomers, 422, 'Algunos clientes no pertenecen a esta subsidiary.');

        // Asociar (sin duplicar)
        $supplier->customerSuppliers()->syncWithoutDetaching($validated['customer_supplier_ids']);

        // Obtener los nombres de los clientes asociados para la notificación
        $customers = \App\Models\CustomerSupplier::whereIn('id', $validated['customer_supplier_ids'])->get();
        
        // Notificación: asociación de clientes a un proveedor
        try {
            $type = NotificationType::where('key', 'supplier.customers-attached')->first();
            if ($type) {
                $customerNames = $customers->pluck('name')->join(', ');
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'supplier',
                    'entity_id' => $supplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'supplier_name' => $supplier->name,
                        'customer_names' => $customerNames,
                        'customers_count' => count($customers),
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'clientes_asociados',
                        'updated_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'updated_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'supplier.attach-customers:'.$supplier->id.':'.now()->timestamp,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        return response()->json([
            'message' => 'Clientes asociados exitosamente.',
            'supplier' => SupplierResource::make($supplier->load('customerSuppliers')),
        ]);
    }

    /**
     * POST /api/subsidiaries/{subsidiary}/suppliers/{supplier}/detach-customers
     * Desasociar clientes-proveedores de un proveedor
     */
    public function detachCustomers(Request $request, Subsidiary $subsidiary, Supplier $supplier)
    {
        // Verificar que el proveedor pertenece a la subsidiary
        abort_if($supplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('update', $subsidiary), 403);

        $validated = $request->validate([
            'customer_supplier_ids' => ['required', 'array', 'min:1'],
            'customer_supplier_ids.*' => ['integer', 'exists:customer_suppliers,id'],
        ]);

        // Desasociar
        $supplier->customerSuppliers()->detach($validated['customer_supplier_ids']);

        // Notificación: desasociación de clientes de un proveedor
        try {
            $type = NotificationType::where('key', 'supplier.customers-detached')->first();
            if ($type) {
                $customers = \App\Models\CustomerSupplier::whereIn('id', $validated['customer_supplier_ids'])->get();
                $customerNames = $customers->pluck('name')->join(', ');
                $event = NotificationEvent::create([
                    'type_id' => $type->id,
                    'entity_type' => 'supplier',
                    'entity_id' => $supplier->id,
                    'company_id' => $subsidiary->company_id,
                    'subsidiary_id' => $subsidiary->id,
                    'branch_id' => null,
                    'priority' => $type->default_priority,
                    'payload' => [
                        'supplier_name' => $supplier->name,
                        'customer_names' => $customerNames,
                        'customers_count' => count($customers),
                        'subsidiary_name' => $subsidiary->subsidiary_name,
                        'action' => 'clientes_desasociados',
                        'updated_by' => (function(){ $u=Auth::user(); return trim(($u->first_name??'').' '.($u->last_name??'')) ?: ($u->email ?? 'Usuario'); })(),
                        'updated_by_id' => Auth::id(),
                    ],
                    'dedup_key' => 'supplier.detach-customers:'.$supplier->id.':'.now()->timestamp,
                    'occurred_at' => now(),
                ]);
                app(NotificationRouter::class)->route($event);
            }
        } catch (\Throwable $e) {}

        return response()->json([
            'message' => 'Clientes desasociados exitosamente.',
        ]);
    }

    /**
     * GET /api/subsidiaries/{subsidiary}/suppliers/{supplier}/customers
     * Obtener lista paginada de clientes de un proveedor
     */
    public function getCustomers(Request $request, Subsidiary $subsidiary, Supplier $supplier)
    {
        // Verificar que el proveedor pertenece a la subsidiary
        abort_if($supplier->subsidiary_id !== $subsidiary->id, 404);

        // Verificar acceso a la subsidiary
        abort_unless(Gate::allows('view', $subsidiary), 403);

        $query = $supplier->customerSuppliers()
            ->select('customer_suppliers.id', 'customer_suppliers.name', 'customer_suppliers.subsidiary_id', 'customer_suppliers.created_at', 'customer_suppliers.updated_at');

        // Búsqueda
        if ($search = trim((string)$request->get('q'))) {
            $query->where('customer_suppliers.name', 'ILIKE', "%{$search}%");
        }

        $query->orderBy('customer_suppliers.name', 'asc');

        return \App\Http\Resources\CustomerSupplierResource::collection(
            $query->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }
}
