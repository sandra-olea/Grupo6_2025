<?php

namespace App\Http\Controllers;

use App\Services\ProductImportService;
use App\Services\ProductAttributesValidator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Gate;
use App\Models\Branch as BranchModel;
use App\Models\Product as ProductModel;

class ProductImportController extends Controller
{
    protected ProductImportService $importService;
    protected ProductAttributesValidator $attributesValidator;

    public function __construct(
        ProductImportService $importService,
        ProductAttributesValidator $attributesValidator
    ) {
        $this->importService = $importService;
        $this->attributesValidator = $attributesValidator;
    }

    /**
     * Importa productos desde archivo Excel
     *
     * @param Request $request
     * @param int $branch ID de la branch desde la URL
     * @return JsonResponse
     */
    public function importFromExcel(Request $request, int $branch): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv|max:10240',
            'update_existing' => 'nullable|boolean',
        ]);

        // Validar que la branch exista y permisos de creación en contexto
        $branchModel = BranchModel::find($branch);
        if (!$branchModel) {
            return response()->json([
                'success' => false,
                'message' => 'Branch no encontrada'
            ], 404);
        }
        if (!Gate::allows('create', [ProductModel::class, $branchModel])) {
            return response()->json([
                'success' => false,
                'message' => 'No autorizado para importar productos en esta branch'
            ], 403);
        }

        try {
            $file = $request->file('file');
            $options = [
                'update_existing' => $request->input('update_existing', true),
            ];

            // Guardar archivo temporalmente
            $tempPath = $file->store('temp', 'local');
            $fullPath = storage_path('app/' . $tempPath);

            // Importar productos
            $results = $this->importService->importFromExcel($fullPath, $branch, $options);

            // Limpiar archivo temporal
            Storage::disk('local')->delete($tempPath);

            return response()->json([
                'success' => true,
                'message' => "Importación completada: {$results['successful']} productos importados exitosamente, {$results['failed']} fallidos",
                'data' => $results
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error en la importación',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Importa la plantilla ECOPC
     *
     * @param Request $request
     * @param int $branch ID de la branch desde la URL
     * @return JsonResponse
     */
    public function importEcopcTemplate(Request $request, int $branch): JsonResponse
    {
        $request->validate([
            'update_existing' => 'nullable|boolean',
        ]);

        // Validar que la branch exista y permisos de creación en contexto
        $branchModel = BranchModel::find($branch);
        if (!$branchModel) {
            return response()->json([
                'success' => false,
                'message' => 'Branch no encontrada'
            ], 404);
        }
        if (!Gate::allows('create', [ProductModel::class, $branchModel])) {
            return response()->json([
                'success' => false,
                'message' => 'No autorizado para importar productos en esta branch'
            ], 403);
        }

        try {
            $templatePath = public_path('templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx');
            
            if (!file_exists($templatePath)) {
                return response()->json([
                    'success' => false,
                    'message' => 'La plantilla ECOPC no existe'
                ], 404);
            }

            $options = [
                'update_existing' => $request->input('update_existing', true),
            ];

            $results = $this->importService->importFromExcel($templatePath, $branch, $options);

            return response()->json([
                'success' => true,
                'message' => "Plantilla ECOPC importada: {$results['successful']} productos creados, {$results['failed']} fallidos",
                'data' => $results
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al importar la plantilla ECOPC',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Valida un JSON de atributos sin crear el producto
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function validateAttributes(Request $request): JsonResponse
    {
        $request->validate([
            'attributes' => 'required',
            'product_type' => 'nullable|string|in:notebook,desktop,all-in-one,mini-pc,tablet',
        ]);

        try {
            $attributes = $request->input('attributes');
            $productType = $request->input('product_type', 'notebook');

            $validated = $this->attributesValidator->validateAndProcess($attributes, $productType);

            return response()->json([
                'success' => true,
                'message' => 'Atributos válidos',
                'data' => [
                    'original' => $attributes,
                    'validated' => $validated
                ]
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Errores de validación',
                'errors' => $e->errors()
            ], 422);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al validar atributos',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Previsualiza qué productos se importarían sin crearlos
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function previewImport(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv|max:10240',
        ]);

        try {
            $file = $request->file('file');
            
            // Guardar archivo temporalmente
            $tempPath = $file->store('temp', 'local');
            $fullPath = storage_path('app/' . $tempPath);

            // Leer el archivo
            $excelReader = app(\App\Services\ExcelReaderService::class);
            $excelData = $excelReader->readExcelFile($fullPath);

            // Limpiar archivo temporal
            Storage::disk('local')->delete($tempPath);

            $preview = [
                'total_sheets' => $excelData['total_sheets'],
                'sheets' => []
            ];

            foreach ($excelData['sheets'] as $sheet) {
                // Saltar hojas de validación
                if (in_array(strtolower($sheet['name']), ['validaciones', 'validations', 'config'])) {
                    continue;
                }

                $preview['sheets'][] = [
                    'name' => $sheet['name'],
                    'total_rows' => $sheet['total_rows'] - 1, // Excluir encabezados
                    'headers' => $sheet['headers'],
                    'sample_data' => $sheet['sample_data']
                ];
            }

            return response()->json([
                'success' => true,
                'message' => 'Previsualización generada',
                'data' => $preview
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al generar previsualización',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
