<?php

namespace App\Http\Controllers;

use App\Http\Resources\SaleItemResource;
use App\Http\Resources\SaleResource;
use App\Models\Sale;
use Illuminate\Http\Request;

class SaleController extends Controller
{
    public function index(Request $request)
    {
        $this->authorize('viewAny', Sale::class,); // fallback to permission below if no policy
        $this->middleware('can:view-sale');

        $q = Sale::query()->withCount('items');

        if ($request->filled('wc_order_id')) {
            $q->where('wc_order_id', (int) $request->query('wc_order_id'));
        }
        if ($request->filled('subsidiary_id')) {
            $q->where('subsidiary_id', (int) $request->query('subsidiary_id'));
        }
        if ($request->filled('status')) {
            $q->where('status', $request->query('status'));
        }

        $q->orderByDesc('id');

        return SaleResource::collection(
            $q->paginate($request->integer('per_page', 20))->appends($request->query())
        );
    }

    public function show(int $sale)
    {
        // Permission
        $this->middleware('can:view-sale');

        $record = Sale::with(['customer'])->findOrFail($sale);
        return SaleResource::make($record);
    }

    public function items(int $sale)
    {
        $this->middleware('can:view-sale');

        $record = Sale::findOrFail($sale);
        $items = $record->items()->with(['product','sale'])->orderBy('id')->get();

        return SaleItemResource::collection($items);
    }
}
