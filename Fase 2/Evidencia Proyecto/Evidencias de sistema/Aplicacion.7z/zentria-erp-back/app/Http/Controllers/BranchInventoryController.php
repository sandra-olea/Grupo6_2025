<?php
namespace App\Http\Controllers;

use App\Http\Resources\ProductResource;
use App\Models\Branch;
use App\Models\Product;
use Illuminate\Http\Request;

class BranchInventoryController extends Controller
{
    public function summary(Request $request, Branch $branch)
    {
        $this->authorize('viewAny', [Product::class, $branch]);

        // Allow both snake_case and camelCase for threshold
        $threshold = $request->integer('critical_threshold');
        if ($threshold === 0 && $request->has('critical_threshold') === false) {
            $threshold = (int) ($request->input('criticalThreshold', 5));
        }
        if (!$threshold) { $threshold = 5; }

        $base = Product::query()->fromBranch($branch->id);

        // Separate counts for parents/normal vs children
        $totalParentsAndNormal = (clone $base)->whereNull('parent_product_id')->count();
        $totalChildren = (clone $base)->whereNotNull('parent_product_id')->count();
        $totalProducts = $totalParentsAndNormal + $totalChildren;
        
        $activeCount     = (clone $base)->where('is_active', true)->count();
        $inactiveCount   = (clone $base)->where('is_active', false)->count();
        $withOffer       = (clone $base)->whereNotNull('offer_price')->where('offer_price', '>', 0)->count();
        $withSerial      = (clone $base)->where('serial_tracking', true)->count();
        $totalStock      = (int) (clone $base)->sum('stock');
        $avgStock        = $totalProducts > 0 ? round($totalStock / $totalProducts, 2) : 0;
        $outOfStock      = (clone $base)->where('stock', 0)->count();
        $withStock       = (clone $base)->where('stock', '>', 0)->count();
        $criticalCount   = (clone $base)->where('stock', '<=', $threshold)->count();

        // Fetch ALL critical products without pagination
        $criticalProducts = (clone $base)
            ->where('stock', '<=', $threshold)
            ->with(['brand'])
            ->orderBy('stock', 'asc')
            ->orderBy('name', 'asc')
            ->get()
            ->map(function(Product $p){
                return [
                    'id' => $p->id,
                    'name' => $p->name,
                    'sku' => $p->sku,
                    'brand_name' => optional($p->brand)->name,
                ];
            });

        return response()->json([
            'branch_id' => $branch->id,
            'params' => [
                'critical_threshold' => $threshold,
            ],
            'summary' => [
                'products_total'          => $totalParentsAndNormal, // Solo padres + normales (sin hijos)
                'total_children_products' => $totalChildren,         // Total de productos children
                'products_total_all'      => $totalProducts,         // Total incluyendo hijos
                'active'                  => $activeCount,
                'inactive'                => $inactiveCount,
                'with_offer'              => $withOffer,
                'with_serial_tracking'    => $withSerial,
                'stock_total'             => $totalStock,
                'synced_products'         => $totalProducts, // sin flag de sincronización, igual a total
                'stock_average'           => $avgStock,
                'serial_tracking_count'   => $withSerial,
                'low_stock_count'         => $criticalCount,
                'out_of_stock'            => $outOfStock,
                'with_stock_available'    => $withStock,
            ],
            'critical_products' => $criticalProducts,
        ]);
    }
}
