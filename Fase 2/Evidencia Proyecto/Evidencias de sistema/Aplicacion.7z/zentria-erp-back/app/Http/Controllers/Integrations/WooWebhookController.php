<?php

namespace App\Http\Controllers\Integrations;

use App\Http\Controllers\Controller;
use App\Models\Integration;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use App\Services\Integrations\WooOrderIngestService;
use App\Services\ReserveSaleInventoryService;
use Illuminate\Support\Facades\Http;

class WooWebhookController extends Controller
{
    public function ordersPing(Request $request, string $api_key)
    {
        $integration = $this->resolveIntegration($api_key);
        if (!$integration) {
            return response()->json(['message' => 'Invalid API key'], 401);
        }

        // Opcional: actualizar last_success_at para comprobar disponibilidad
        $integration->last_success_at = now();
        $integration->last_error_at = null;
        $integration->last_error_msg = null;
        $integration->save();

        return response()->json(['ok' => true, 'message' => 'Woo webhook endpoint alive']);
    }

    public function orders(Request $request, string $api_key, WooOrderIngestService $ingest, ReserveSaleInventoryService $reserveService)
    {
        $integration = $this->resolveIntegration($api_key);
        if (!$integration) {
            return response()->json(['message' => 'Invalid API key'])
                ->header('X-Debug-Reason', 'invalid-api-key')
                ->setStatusCode(401);
        }

        // Validate HMAC signature (or gracefully accept Woo health checks)
        $raw = $request->getContent();
        $signature = (string) $request->header('X-WC-Webhook-Signature', '');
        if ($signature === '') {
            // Try server var fallback (some proxies downcase/rename headers)
            $signature = (string) $request->server('HTTP_X_WC_WEBHOOK_SIGNATURE', '');
        }
        $secret = '';
        try {
            $secret = Crypt::decryptString((string)$integration->webhook_secret);
        } catch (\Throwable $e) {
            $this->markError($integration, 'Invalid webhook secret stored: '.$e->getMessage());
            return response()->json(['message' => 'Invalid webhook secret'], 500);
        }

        $calc = base64_encode(hash_hmac('sha256', $raw, $secret, true));

        // If signature is missing and this looks like a Woo health check (non-JSON or tiny body), accept as 204
        $contentType = (string) $request->header('Content-Type', '');
        if ($signature === '') {
            $isHealthCheck = stripos($contentType, 'application/json') === false || strlen($raw) < 20;
            if ($isHealthCheck) {
                Log::info('Woo webhook ping without signature accepted', [
                    'integration_id' => $integration->id,
                    'content_type' => $contentType,
                    'body_len' => strlen($raw),
                ]);
                $integration->last_success_at = now();
                $integration->last_error_at = null;
                $integration->last_error_msg = null;
                $integration->save();
                return response()->json(['ok' => true, 'ping' => true]);
            }
        }

        if (!hash_equals($calc, $signature)) {
            $this->markError($integration, 'Signature mismatch');

            // Detalle de diagnóstico (no revela secretos)
            $detail = [
                'topic' => (string) $request->header('X-WC-Webhook-Topic', ''),
                'delivery' => (string) $request->header('X-WC-Webhook-Delivery-ID', ''),
                'sig_received_prefix' => substr((string)$signature, 0, 12),
                'sig_calc_prefix' => substr((string)$calc, 0, 12),
                'body_len' => strlen($raw),
                'content_type' => $contentType,
            ];

            Log::warning('Woo webhook invalid signature', array_merge([
                'integration_id' => $integration->id,
                'subsidiary_id' => $integration->subsidiary_id,
            ], $detail));

            return response()->json([
                'message' => 'Invalid signature',
                'reason' => $detail,
            ])->header('X-Debug-Reason', 'invalid-signature')
              ->header('X-Debug-Sig-Received-12', $detail['sig_received_prefix'] ?? '')
              ->header('X-Debug-Sig-Calc-12', $detail['sig_calc_prefix'] ?? '')
              ->setStatusCode(401);
        }

        // Parse payload
        $topic = (string) $request->header('X-WC-Webhook-Topic', '');
        $deliveryId = (string) $request->header('X-WC-Webhook-Delivery-ID', '');

        try { $body = json_decode($raw, true); } catch (\Throwable $e) { $body = null; }

        // Log a compact snapshot of what we received (no secrets)
        try {
            Log::info('Woo webhook payload received', [
                'integration_id' => $integration->id,
                'subsidiary_id' => $integration->subsidiary_id,
                'topic' => $topic,
                'delivery' => $deliveryId,
                'content_len' => strlen($raw),
                'body_preview' => substr($raw, 0, 2000),
            ]);
        } catch (\Throwable $e) {}

        // Log minimal info for diagnostics (without secrets)
        Log::info('Woo webhook received', [
            'integration_id' => $integration->id,
            'subsidiary_id' => $integration->subsidiary_id,
            'topic' => $topic,
            'delivery' => $deliveryId,
        ]);

        // Ingest if it's an order topic and payload seems valid
        $result = null;
        if (is_array($body) && ($topic === 'order.created' || $topic === 'order.updated' || ($body['id'] ?? null))) {
            // Fallback: if the payload seems incomplete (e.g., missing line_items), try refetching from Woo REST (if credentials exist)
            if ((empty($body['line_items']) || !is_array($body['line_items'])) && !empty($body['id']) && $integration->base_url && $integration->consumer_key && $integration->consumer_secret) {
                try {
                    $url = rtrim($integration->base_url, '/').'/wp-json/wc/v3/orders/'.((int)$body['id']);
                    $resp = Http::timeout(10)->get($url, [
                        'consumer_key' => $integration->consumer_key,
                        'consumer_secret' => $integration->consumer_secret,
                    ]);
                    if ($resp->successful()) {
                        $refetched = $resp->json();
                        if (is_array($refetched) && !empty($refetched)) { $body = $refetched; }
                    }
                } catch (\Throwable $e) {
                    Log::warning('Woo refetch failed', ['error' => $e->getMessage()]);
                }
            }
            try {
                $result = $ingest->ingest((int)$integration->subsidiary_id, (string)$integration->id, $body);
                $integration->last_success_at = now();
                $integration->last_error_at = null;
                $integration->last_error_msg = null;
                $integration->save();
                try {
                    \Log::info('Woo webhook ingest success', [
                        'integration_id' => $integration->id,
                        'subsidiary_id' => $integration->subsidiary_id,
                        'wc_order_id' => $body['id'] ?? null,
                        'result' => $result,
                    ]);
                } catch (\Throwable $e) {}

                // Post-ingest stock handling based on mapped status
                try {
                    $saleId = $result['sale_id'] ?? null;
                    if ($saleId) {
                        $sale = \App\Models\Sale::find($saleId);
                        if ($sale) {
                            // Si la venta está finalizada, no alterar inventario por webhooks
                            $docMeta = (array) ($sale->documents_metadata ?? []);
                            if (!empty($docMeta['inventory_finalized']) || $sale->inventory_delivered) {
                                \Log::info('Woo post-ingest skipped: sale inventory finalized', ['sale_id' => $sale->id]);
                                return response()->json(['ok' => true, 'result' => $result, 'skipped' => 'finalized']);
                            }
                            $old = $result['old_status'] ?? null;
                            $new = $result['new_status'] ?? $sale->status;
                            // Regla:
                            // - processing (confirmed) => reservar
                            // - completed (paid) => reservar y marcar vendido (una sola vez)
                            // - pending/on-hold (draft), cancelled, refunded => liberar
                            if (in_array($new, ['confirmed','paid'], true)) {
                                $reserveService->reserve($sale);
                                if ($new === 'paid') {
                                    $reserveService->sell($sale);
                                }
                            } elseif (in_array($new, ['draft','cancelled','refunded'], true)) {
                                $reserveService->release($sale);
                            }
                        }
                    }
                } catch (\Throwable $e) {
                    \Log::warning('Woo post-ingest reservation failed', ['error' => $e->getMessage()]);
                }
            } catch (\Throwable $e) {
                $this->markError($integration, 'Ingest error: '.$e->getMessage());
                Log::error('Woo webhook ingest failed', [
                    'integration_id' => $integration->id,
                    'error' => $e->getMessage(),
                ]);
                return response()->json(['message' => 'Ingest failed'], 500);
            }
        } else {
            // Mark success timestamp even if it's a ping with JSON
            $integration->last_success_at = now();
            $integration->last_error_at = null;
            $integration->last_error_msg = null;
            $integration->save();
        }

        return response()->json(['ok' => true, 'result' => $result]);
    }

    private function resolveIntegration(string $apiKey): ?Integration
    {
        $prefix = substr($apiKey, 0, 16);
        /** @var Integration|null $integration */
        $integration = Integration::query()
            ->where('provider', 'woocommerce')
            ->where('is_active', true)
            ->where('api_key_prefix', $prefix)
            ->first();

        if (!$integration) return null;
        if (!Hash::check($apiKey, (string)$integration->api_key_hash)) return null;

        return $integration;
    }

    private function markError(Integration $integration, string $message): void
    {
        try {
            $integration->last_error_at = now();
            $integration->last_error_msg = $message;
            $integration->save();
        } catch (\Throwable $e) {}
    }
}
