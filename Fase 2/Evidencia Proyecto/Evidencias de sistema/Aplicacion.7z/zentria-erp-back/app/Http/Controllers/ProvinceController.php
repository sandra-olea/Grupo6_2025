<?php

namespace App\Http\Controllers;

use App\Models\Province;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class ProvinceController extends Controller
{
    public function index(Request $request)
    {
        $with = array_filter(explode(',', (string) $request->query('with')));
        if ($request->boolean('no_cache')) {
            $query = Province::query()->orderBy('name');
            if ($request->filled('region_id')) $query->where('region_id', (int) $request->query('region_id'));
            if (!empty($with)) $query->with($with);
            return $query->get();
        }

        $regionFilter = $request->filled('region_id') ? (int) $request->query('region_id') : 'any';
        $key = 'locations:provinces:index:region=' . $regionFilter . ':with=' . (empty($with) ? 'none' : implode(',', $with));
        return Cache::remember($key, now()->addDay(), function () use ($with, $regionFilter) {
            $q = Province::query()->orderBy('name');
            if ($regionFilter !== 'any') $q->where('region_id', (int) $regionFilter);
            if (!empty($with)) $q->with($with);
            return $q->get();
        });
    }

    public function show(Request $request, int $id)
    {
        $with = array_filter(explode(',', (string) $request->query('with')));
        if ($request->boolean('no_cache')) {
            $q = Province::query();
            if (!empty($with)) $q->with($with);
            return $q->findOrFail($id);
        }

        $key = 'locations:provinces:show:' . $id . ':with=' . (empty($with) ? 'none' : implode(',', $with));
        return Cache::remember($key, now()->addDay(), function () use ($with, $id) {
            $q = Province::query();
            if (!empty($with)) $q->with($with);
            return $q->findOrFail($id);
        });
    }
}
