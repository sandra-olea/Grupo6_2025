<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CorsMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $origin = $request->headers->get('Origin');
        $allowed = (array) config('cors.allowed_origins', []);
        $allowAll = in_array('*', $allowed, true);
        $allowOrigin = $allowAll || ($origin && in_array($origin, $allowed, true));

        // Build CORS headers
        $headers = [];
        if ($allowOrigin) {
            $headers['Access-Control-Allow-Origin'] = $allowAll ? '*' : $origin;
            if (!$allowAll) {
                // Make caches vary by Origin when not wildcard
                $headers['Vary'] = 'Origin';
            }
            if (config('cors.supports_credentials', true)) {
                $headers['Access-Control-Allow-Credentials'] = 'true';
            }
            // Echo requested headers if present to avoid preflight mismatch
            $reqHeaders = $request->headers->get('Access-Control-Request-Headers');
            $headers['Access-Control-Allow-Headers'] = $reqHeaders ?: implode(',', (array) config('cors.allowed_headers', []));

            $allowedMethods = (array) config('cors.allowed_methods', []);
            if (in_array('*', $allowedMethods, true)) {
                $reqMethod = $request->headers->get('Access-Control-Request-Method');
                $headers['Access-Control-Allow-Methods'] = $reqMethod ?: 'GET,POST,PUT,PATCH,DELETE,OPTIONS';
            } else {
                $headers['Access-Control-Allow-Methods'] = implode(',', $allowedMethods);
            }
            $headers['Access-Control-Max-Age'] = (string) config('cors.max_age', 600);
        }

        // Handle preflight early
        if ($request->isMethod('OPTIONS')) {
            return response('', 204)->withHeaders($headers);
        }

        $response = $next($request);

        foreach ($headers as $k => $v) {
            $response->headers->set($k, $v);
        }

        return $response;
    }
}
