<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class NormalizeEmptyStrings
{
    public function handle(Request $request, Closure $next)
    {
        $request->merge($this->normalize($request->all()));
        return $next($request);
    }

    private function normalize($data)
    {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = $this->normalize($value);
            }
            return $data;
        }

        if (is_string($data)) {
            // Replace common unicode spaces (NBSP and others) with regular space, then trim
            $data = preg_replace('/[\x{00A0}\x{1680}\x{2000}-\x{200B}\x{202F}\x{205F}\x{3000}]+/u', ' ', $data);
            $data = trim($data);
            if ($data === '') {
                return null;
            }
        }

        return $data;
    }
}

