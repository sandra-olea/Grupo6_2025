<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;

class Authenticate extends Middleware
{
    protected function redirectTo($request)
    {
        // Solo redirigir para rutas web, no para API
        if (! $request->is('api/*') && ! $request->expectsJson()) {
            return route('login');
        }
    }

    public function handle($request, Closure $next, ...$guards)
    {
        $token = $request->bearerToken() ?? $request->query('access_token'); 

        if (!$token) {
            if (config('app.debug')) {
                \Log::debug('AUTH MIDDLEWARE: No token provided', [
                    'url' => $request->fullUrl(),
                    'method' => $request->method(),
                ]);
            }
            throw new \Illuminate\Auth\AuthenticationException('Token no enviado.');
        }

        try {
            $user = JWTAuth::setToken($token)->authenticate();
            
            if (!$user) {
                if (config('app.debug')) {
                    \Log::debug('AUTH MIDDLEWARE: Token valid but user not found');
                }
                throw new \Illuminate\Auth\AuthenticationException('Usuario no autenticado.');
            }

            // Bloquear acceso a usuarios desactivados
            if (property_exists($user, 'is_active') && !$user->is_active) {
                if (config('app.debug')) {
                    \Log::debug('AUTH MIDDLEWARE: User account is inactive', [
                        'user_id' => $user->id,
                        'email' => $user->email,
                    ]);
                }
                return response()->json(['error' => 'ERROR NO TIENES TU CUENTA ACTIVADA'], 403);
            }

            Auth::setUser($user);

            if (config('app.debug')) {
                \Log::debug('AUTH MIDDLEWARE: User authenticated successfully', [
                    'user_id' => $user->id,
                    'email' => $user->email,
                ]);
            }

        } catch (\Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
            if (config('app.debug')) {
                \Log::debug('AUTH MIDDLEWARE: Token expired', ['token_preview' => substr($token, 0, 20) . '...']);
            }
            throw new \Illuminate\Auth\AuthenticationException('Token expirado.');
        } catch (\Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
            if (config('app.debug')) {
                \Log::debug('AUTH MIDDLEWARE: Token invalid', ['error' => $e->getMessage()]);
            }
            throw new \Illuminate\Auth\AuthenticationException('Token inválido.');
        } catch (\Tymon\JWTAuth\Exceptions\JWTException $e) {
            if (config('app.debug')) {
                \Log::debug('AUTH MIDDLEWARE: JWT exception', ['error' => $e->getMessage()]);
            }
            throw new \Illuminate\Auth\AuthenticationException('Error con el token.');
        }

        return $next($request);
    }
}
