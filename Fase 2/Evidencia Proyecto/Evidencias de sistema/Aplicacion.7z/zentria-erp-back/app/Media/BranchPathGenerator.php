<?php

namespace App\Media;

use Spatie\MediaLibrary\Support\PathGenerator\PathGenerator;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Illuminate\Support\Str;

class BranchPathGenerator implements PathGenerator
{
    protected function branchIdFrom(Media $media): string
    {
        return (string)(
            $media->branch_id
            ?? $media->getCustomProperty('branch_id')                        // <-- NUEVO
            ?? ($media->model_type === \App\Models\Branch::class ? $media->model_id : null)
            ?? ( $media->model && property_exists($media->model, 'branch_id') ? $media->model->branch_id : null )
            ?? 'public'
        );
    }

    public function getPath(Media $media): string
    {
        // Special pathing for TechnicalReviewItem: warehouse-{id}/{serial}/
        if ($media->model_type === \App\Models\TechnicalReviewItem::class && $media->model) {
            $warehouseId = $media->model->warehouse_id ?? null;
            $serialRaw   = $media->model->serial_number ?? null;

            if ($warehouseId && $serialRaw) {
                // Sanitize serial to safe folder name
                $serial = Str::slug((string)$serialRaw, '-');
                $top = "warehouse-{$warehouseId}";
                // storage/app/public/media/warehouse-{id}/{serial}/
                return "media/{$top}/{$serial}/";
            }
        }

        // Default pathing by branch/type/id
        $branchId = $media->getCustomProperty('branch_id');
        $branchFolder = $branchId ? "branch-{$branchId}" : 'global-media';

        $modelType = strtolower(class_basename($media->model_type));
        $modelId   = $media->model_id;

        return "media/{$branchFolder}/{$modelType}/{$modelId}/";
    }

    public function getPathForConversions(Media $media): string
    {
        return $this->getPath($media) . 'conversions/';
    }

    public function getPathForResponsiveImages(Media $media): string
    {
        return $this->getPath($media) . 'responsive/';
    }
}
