# Script para ejecutar tests en Docker
# Uso: .\run-tests.ps1

Write-Host "🧪 Ejecutando tests con Docker..." -ForegroundColor Cyan

# Limpiar contenedor tester anterior
Write-Host "Limpiando contenedores anteriores..." -ForegroundColor Yellow
docker compose rm -f -s -v tester 2>$null

# Reconstruir imagen del tester para asegurar código actualizado
Write-Host "Reconstruyendo imagen del tester..." -ForegroundColor Yellow
docker compose --profile test build tester

# Levantar base de datos de test
Write-Host "Levantando base de datos de test..." -ForegroundColor Yellow
docker compose --profile test up -d db_test

# Ejecutar tests
Write-Host "Ejecutando tests..." -ForegroundColor Yellow
docker compose --profile test run --rm tester

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Tests completados exitosamente!" -ForegroundColor Green
} else {
    Write-Host "❌ Tests fallaron. Revisa el output arriba." -ForegroundColor Red
    exit 1
}
