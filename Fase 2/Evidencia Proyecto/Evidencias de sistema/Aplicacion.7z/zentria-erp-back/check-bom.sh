#!/bin/sh
# Script para detectar y limpiar BOMs en archivos PHP
# Uso: ./check-bom.sh [--fix]

echo "🔍 Buscando BOMs en archivos PHP..."

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

HAS_BOM=0
FIX_MODE=0

# Verificar si se pasó --fix
if [ "$1" = "--fix" ]; then
    FIX_MODE=1
    echo "${YELLOW}⚠️  MODO FIX ACTIVADO: Se eliminarán BOMs automáticamente${NC}"
    echo ""
fi

# Buscar todos los archivos PHP (excluyendo vendor y node_modules)
find . -type f -name "*.php" \
    -not -path "./vendor/*" \
    -not -path "./node_modules/*" \
    -not -path "./.git/*" \
    -not -path "./storage/*" | while read -r file; do
    
    # Leer los primeros 3 bytes
    FIRST_BYTES=$(head -c 3 "$file" | od -An -tx1 | tr -d ' \n')
    
    # Verificar si es BOM (efbbbf)
    if [ "$FIRST_BYTES" = "efbbbf" ]; then
        echo "${RED}❌ BOM detectado en: $file${NC}"
        touch /tmp/bom_found
        
        # Si está en modo fix, limpiar el BOM
        if [ $FIX_MODE -eq 1 ]; then
            tail -c +4 "$file" > "$file.tmp" && mv "$file.tmp" "$file"
            echo "${GREEN}   ✓ BOM eliminado${NC}"
        fi
    fi
done

# Verificar si se encontró algún BOM
if [ -f /tmp/bom_found ]; then
    rm -f /tmp/bom_found
    
    if [ $FIX_MODE -eq 0 ]; then
        echo ""
        echo "${YELLOW}Para corregir automáticamente, ejecuta:${NC}"
        echo "  ./check-bom.sh --fix"
        echo ""
        exit 1
    else
        echo ""
        echo "${GREEN}✅ Todos los BOMs fueron eliminados${NC}"
        exit 0
    fi
else
    echo "${GREEN}✅ No se detectaron BOMs en archivos PHP${NC}"
    exit 0
fi
