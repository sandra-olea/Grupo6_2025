<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Notifications\NotificationController;
use App\Http\Controllers\Notifications\PreferencesController;
use App\Http\Controllers\Notifications\AdminRoleBundlesController;
use App\Http\Controllers\Notifications\EventsTestController;
use App\Http\Controllers\Notifications\StreamController;
use App\Http\Controllers\Notifications\AdminTypesController;
use App\Http\Controllers\Notifications\TestP1Controller;

Route::middleware(['auth:api'])->group(function () {
    Route::get('me/notifications', [NotificationController::class, 'index']);
    Route::post('notifications/{id}/read', [NotificationController::class, 'markRead']);
    Route::post('notifications/{id}/unread', [NotificationController::class, 'markUnread']);
    Route::post('notifications/{id}/ack', [NotificationController::class, 'ack']);
    Route::post('notifications/{id}/assign', [NotificationController::class, 'assign']);
    Route::delete('notifications/{id}', [NotificationController::class, 'destroy']);
    Route::post('me/notifications/read-all', [NotificationController::class, 'markAllRead']);
    Route::post('me/notifications/delivered', [NotificationController::class, 'markDelivered']);
    Route::post('me/notifications/delivered-all', [NotificationController::class, 'markAllDelivered']);
    Route::post('me/notifications/unread-all', [NotificationController::class, 'markAllUnread']);
    Route::delete('notifications/{id}/purge', [NotificationController::class, 'purge']);

    Route::get('me/notification-preferences', [PreferencesController::class, 'index']);
    Route::put('me/notification-preferences', [PreferencesController::class, 'update']);

    Route::get('admin/role-bundles/{roleId}', [AdminRoleBundlesController::class, 'show']);
    Route::put('admin/role-bundles/{roleId}', [AdminRoleBundlesController::class, 'update']);

    // Admin: actualizar bucket de un tipo de notificación
    Route::patch('admin/notification-types/{id}/bucket', [AdminTypesController::class, 'updateBucket']);

    Route::post('events/test', [EventsTestController::class, 'store']);
    Route::post('events/examples', [EventsTestController::class, 'examples']);
    Route::post('events/test-p1', [TestP1Controller::class, 'trigger']);

    Route::get('me/notifications/stream', [StreamController::class, 'stream']);
});
