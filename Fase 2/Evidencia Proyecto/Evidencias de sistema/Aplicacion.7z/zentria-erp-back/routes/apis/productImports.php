<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductImportController;

/*
|--------------------------------------------------------------------------
| Product Import API Routes
|--------------------------------------------------------------------------
|
| Rutas para importación masiva de productos desde archivos Excel/CSV.
| Todas estas rutas requieren autenticación y permisos Spatie.
|
| Contexto: Las rutas están bajo branches/{branch}/products/import
| Los productos se crearán en la sucursal (branch) especificada.
|
| Permisos utilizados:
| - create-product: Permite crear productos mediante importación
| - view-product: Permite previsualizar importaciones
|
*/

Route::middleware(['auth:api'])->prefix('branches/{branch}')->group(function () {
    
    // Importar productos desde archivo Excel/CSV
    Route::post('/products/import', [ProductImportController::class, 'importFromExcel'])
        ->middleware('can:create-product')
        ->name('branches.products.import');
    
    // Importar desde plantilla ECOPC predefinida
    Route::post('/products/import/ecopc', [ProductImportController::class, 'importEcopcTemplate'])
        ->middleware('can:create-product')
        ->name('branches.products.import.ecopc');
    
    // Previsualizar importación (sin crear productos realmente)
    Route::post('/products/import/preview', [ProductImportController::class, 'previewImport'])
        ->middleware('can:view-product')
        ->name('branches.products.import.preview');
    
    // Validar atributos JSON de un producto
    Route::post('/products/validate-attributes', [ProductImportController::class, 'validateAttributes'])
        ->middleware('can:view-product')
        ->name('branches.products.validate-attributes');
        
});
