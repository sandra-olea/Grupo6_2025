<?php

use App\Http\Controllers\Api\TechnicalReviewBatchController;
use App\Http\Controllers\Api\TechnicalReviewItemController;
use App\Http\Controllers\Api\EquipmentTraceabilityController;
use App\Http\Controllers\Api\TechnicalReviewValidationController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Technical Reviews API Routes
|--------------------------------------------------------------------------
|
| Rutas protegidas con autenticación Sanctum para el módulo de
| Revisiones Técnicas de equipos reacondicionados.
|
*/

Route::middleware(['auth:api'])
    ->prefix('branches/{branch}/technical-reviews')
    ->group(function () {
    
    // ===== BATCH ROUTES =====
    Route::prefix('batches')->group(function () {
        Route::get('/', [TechnicalReviewBatchController::class, 'index']);
        Route::post('/', [TechnicalReviewBatchController::class, 'store']);
        Route::get('/{batch}/items', [TechnicalReviewItemController::class, 'indexByBatch']);
        Route::get('/{batch}', [TechnicalReviewBatchController::class, 'show']);
        Route::patch('/{batch}', [TechnicalReviewBatchController::class, 'update']);
        Route::delete('/{batch}', [TechnicalReviewBatchController::class, 'destroy']);
    });

    // ===== ITEM ROUTES =====
    Route::prefix('items')->group(function () {
        Route::get('/', [TechnicalReviewItemController::class, 'index']);
        Route::post('/', [TechnicalReviewItemController::class, 'store']);
        Route::get('/{item}', [TechnicalReviewItemController::class, 'show']);
        Route::patch('/{item}', [TechnicalReviewItemController::class, 'update']);
        Route::delete('/{item}', [TechnicalReviewItemController::class, 'destroy']);
        
        // Review Actions
        Route::post('/{item}/start-review', [TechnicalReviewItemController::class, 'startReview']);
        Route::patch('/{item}/details', [TechnicalReviewItemController::class, 'updateDetails']);
        Route::post('/{item}/complete-review', [TechnicalReviewItemController::class, 'completeReview']);
        Route::post('/{item}/approve', [TechnicalReviewItemController::class, 'approve']);
        Route::post('/{item}/reopen-review', [TechnicalReviewItemController::class, 'reopenReview']);
        
        // Scoring
        Route::get('/{item}/suggested-grade', [TechnicalReviewItemController::class, 'calculateSuggestedGrade']);
    });

    // ===== TRACEABILITY ROUTES =====
    Route::prefix('traceability')->group(function () {
        // History
        Route::get('/history/{serialNumber}', [EquipmentTraceabilityController::class, 'history']);
        
        // Available for sale
        Route::get('/available-for-sale', [EquipmentTraceabilityController::class, 'availableForSale']);
        
        // Status Management
        Route::post('/{traceability}/change-status', [EquipmentTraceabilityController::class, 'changeStatus']);
        Route::post('/{traceability}/transfer', [EquipmentTraceabilityController::class, 'transfer']);
        Route::post('/bulk-transfer', [EquipmentTraceabilityController::class, 'bulkTransfer']);
        Route::post('/{traceability}/reserve', [EquipmentTraceabilityController::class, 'reserve']);
        Route::post('/{traceability}/release-reservation', [EquipmentTraceabilityController::class, 'releaseReservation']);
        Route::post('/{traceability}/mark-as-sold', [EquipmentTraceabilityController::class, 'markAsSold']);
    });

    // ===== VALIDATION ROUTES =====
    Route::prefix('validation')->group(function () {
        Route::post('/validate-field', [TechnicalReviewValidationController::class, 'validateField']);
        Route::post('/suggest-grade', [TechnicalReviewValidationController::class, 'suggestGrade']);
        Route::get('/my-common-errors', [TechnicalReviewValidationController::class, 'myCommonErrors']);
        Route::get('/rules', [TechnicalReviewValidationController::class, 'getAllValidationRules']);
        Route::get('/rules/{equipmentType}', [TechnicalReviewValidationController::class, 'getValidationRules']);
        Route::get('/error-statistics', [TechnicalReviewValidationController::class, 'errorStatistics']);
    });
});
