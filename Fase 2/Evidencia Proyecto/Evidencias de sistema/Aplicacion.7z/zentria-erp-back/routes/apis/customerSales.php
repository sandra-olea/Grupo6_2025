<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubsidiaryCustomerSalesController;

// Customer Sales (clientes para ventas) bajo una subsidiary
Route::middleware(['auth:api'])->group(function () {
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        Route::get('customer-sales', [SubsidiaryCustomerSalesController::class, 'index'])
            ->middleware('can:view-customer-sale')
            ->name('subsidiaries.customer-sales.index');

        // Resumen de clientes (lista parametrizable: id, nombre, contacto, RUT, fidelidad, total ventas, estado)
        Route::get('customer-sales/overview', [SubsidiaryCustomerSalesController::class, 'overview'])
            ->middleware('can:view-customer-sale')
            ->name('subsidiaries.customer-sales.overview');

        Route::post('customer-sales', [SubsidiaryCustomerSalesController::class, 'store'])
            ->middleware('can:create-customer-sale')
            ->name('subsidiaries.customer-sales.store');

        Route::get('customer-sales/{customer}', [SubsidiaryCustomerSalesController::class, 'show'])
            ->middleware('can:view-customer-sale')
            ->name('subsidiaries.customer-sales.show');

        Route::patch('customer-sales/{customer}', [SubsidiaryCustomerSalesController::class, 'update'])
            ->middleware('can:edit-customer-sale')
            ->name('subsidiaries.customer-sales.update');

        Route::delete('customer-sales/{customer}', [SubsidiaryCustomerSalesController::class, 'destroy'])
            ->middleware('can:delete-customer-sale')
            ->name('subsidiaries.customer-sales.destroy');
    });
});
