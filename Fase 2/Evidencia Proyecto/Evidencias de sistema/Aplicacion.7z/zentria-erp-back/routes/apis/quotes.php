<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubsidiaryQuotesController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        Route::get('quotes', [SubsidiaryQuotesController::class, 'index'])
            ->middleware('can:view-quote')
            ->name('subsidiaries.quotes.index');

        Route::get('quotes/{quote}', [SubsidiaryQuotesController::class, 'show'])
            ->middleware('can:view-quote')
            ->name('subsidiaries.quotes.show');

        Route::get('quotes/{quote}/items', [SubsidiaryQuotesController::class, 'items'])
            ->middleware('can:view-quote')
            ->name('subsidiaries.quotes.items');

        // Gestión de ítems de cotización
        Route::post('quotes/{quote}/items', [SubsidiaryQuotesController::class, 'addItem'])
            ->middleware(['can:edit-quote'])
            ->name('subsidiaries.quotes.items.add');
        Route::patch('quotes/{quote}/items/{item}', [SubsidiaryQuotesController::class, 'updateItem'])
            ->middleware(['can:edit-quote'])
            ->name('subsidiaries.quotes.items.update');
        Route::delete('quotes/{quote}/items/{item}', [SubsidiaryQuotesController::class, 'deleteItem'])
            ->middleware(['can:edit-quote'])
            ->name('subsidiaries.quotes.items.delete');

        // Descargar PDF de una cotización
        Route::get('quotes/{quote}/pdf', [SubsidiaryQuotesController::class, 'downloadPdf'])
            ->middleware('can:view-quote')
            ->name('subsidiaries.quotes.pdf');

        Route::post('quotes', [SubsidiaryQuotesController::class, 'store'])
            ->middleware(['can:create-quote'])
            ->name('subsidiaries.quotes.store');

        Route::patch('quotes/{quote}', [SubsidiaryQuotesController::class, 'update'])
            ->middleware(['can:edit-quote'])
            ->name('subsidiaries.quotes.update');

        // Convertir una cotización en una venta
        Route::post('quotes/{quote}/convert-to-sale', [SubsidiaryQuotesController::class, 'convertToSale'])
            ->middleware(['can:create-quote'])
            ->name('subsidiaries.quotes.convert-to-sale');

        Route::delete('quotes/{quote}', [SubsidiaryQuotesController::class, 'destroy'])
            ->middleware(['can:delete-quote'])
            ->name('subsidiaries.quotes.destroy');
    });
});
