<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubsidiaryDocumentsController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        Route::get('documents', [SubsidiaryDocumentsController::class, 'index'])
            ->middleware('can:view-document')
            ->name('subsidiaries.documents.index');

        Route::post('documents', [SubsidiaryDocumentsController::class, 'store'])
            ->middleware('can:create-document')
            ->name('subsidiaries.documents.store');

        Route::get('documents/{document}', [SubsidiaryDocumentsController::class, 'show'])
            ->middleware('can:view-document')
            ->name('subsidiaries.documents.show');

        Route::match(['put','patch'], 'documents/{document}', [SubsidiaryDocumentsController::class, 'update'])
            ->middleware('can:edit-document')
            ->name('subsidiaries.documents.update');

        Route::delete('documents/{document}', [SubsidiaryDocumentsController::class, 'destroy'])
            ->middleware('can:delete-document')
            ->name('subsidiaries.documents.destroy');

        // Attachments management
        Route::post('documents/{document}/attachments', [SubsidiaryDocumentsController::class, 'uploadAttachments'])
            ->middleware('can:edit-document')
            ->name('subsidiaries.documents.attachments.upload');

        Route::get('documents/{document}/attachments', [SubsidiaryDocumentsController::class, 'listAttachments'])
            ->middleware('can:view-document')
            ->name('subsidiaries.documents.attachments.index');

        Route::delete('documents/{document}/attachments/{media}', [SubsidiaryDocumentsController::class, 'deleteAttachment'])
            ->middleware('can:edit-document')
            ->name('subsidiaries.documents.attachments.destroy');
    });
});
