<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BranchTransfersController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('branches/{branch}')->group(function () {
        // List transfers
        Route::get('transfers', [BranchTransfersController::class, 'index'])
            ->middleware('can:view-transfer')
            ->name('branches.transfers.index');

        // Create transfer
        Route::post('transfers', [BranchTransfersController::class, 'store'])
            ->middleware('can:create-transfer')
            ->name('branches.transfers.store');

        // Show transfer detail
        Route::get('transfers/{transfer}', [BranchTransfersController::class, 'show'])
            ->middleware('can:view-transfer')
            ->name('branches.transfers.show');
    });
});

