<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubsidiarySalesController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        Route::get('sales', [SubsidiarySalesController::class, 'index'])
            ->middleware('can:view-sale')
            ->name('subsidiaries.sales.index');

        Route::get('sales/{sale}', [SubsidiarySalesController::class, 'show'])
            ->whereNumber('sale')
            ->middleware('can:view-sale')
            ->name('subsidiaries.sales.show');

        Route::get('sales/{sale}/items', [SubsidiarySalesController::class, 'items'])
            ->whereNumber('sale')
            ->middleware('can:view-sale')
            ->name('subsidiaries.sales.items');

        // Cerrar venta con asignación de series
        Route::post('sales/{sale}/close', [SubsidiarySalesController::class, 'close'])
            ->whereNumber('sale')
            ->middleware('can:close-sale')
            ->name('subsidiaries.sales.close');

        // Eliminar una venta
        Route::delete('sales/{sale}', [SubsidiarySalesController::class, 'destroy'])
            ->whereNumber('sale')
            ->middleware('can:delete-sale')
            ->name('subsidiaries.sales.destroy');

        // Crear cotización desde una venta (y generar PDF)
        Route::post('sales/{sale}/create-quote', [SubsidiarySalesController::class, 'createQuote'])
            ->whereNumber('sale')
            ->middleware('can:create-quote')
            ->name('subsidiaries.sales.create-quote');
    });
});
