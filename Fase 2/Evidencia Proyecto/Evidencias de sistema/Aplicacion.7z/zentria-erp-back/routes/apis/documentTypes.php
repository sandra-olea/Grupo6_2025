<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DocumentTypesController;

Route::middleware(['auth:api'])->group(function () {
    Route::get('document-types', [DocumentTypesController::class, 'index'])
        ->middleware('can:view-document-type');

    Route::post('document-types', [DocumentTypesController::class, 'store'])
        ->middleware('can:create-document-type');

    Route::get('document-types/{documentType}', [DocumentTypesController::class, 'show'])
        ->middleware('can:view-document-type');

    Route::match(['put','patch'], 'document-types/{documentType}', [DocumentTypesController::class, 'update'])
        ->middleware('can:edit-document-type');

    Route::delete('document-types/{documentType}', [DocumentTypesController::class, 'destroy'])
        ->middleware('can:delete-document-type');
});

