<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubsidiarySuppliersController;
use App\Http\Controllers\SubsidiaryCustomerSuppliersController;

/**
 * Rutas para Suppliers y CustomerSuppliers
 * Todas las rutas requieren autenticación y permisos Spatie
 */

Route::middleware(['auth:api'])->group(function () {
    
    // ====================================================================
    // SUPPLIERS - Proveedores
    // ====================================================================
    
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        
        // CRUD básico de proveedores
        Route::get('suppliers', [SubsidiarySuppliersController::class, 'index'])
            ->middleware('can:view-supplier')
            ->name('subsidiaries.suppliers.index');
            
        Route::post('suppliers', [SubsidiarySuppliersController::class, 'store'])
            ->middleware('can:create-supplier')
            ->name('subsidiaries.suppliers.store');
            
        Route::get('suppliers/{supplier}', [SubsidiarySuppliersController::class, 'show'])
            ->middleware('can:view-supplier')
            ->name('subsidiaries.suppliers.show');
            
        Route::patch('suppliers/{supplier}', [SubsidiarySuppliersController::class, 'update'])
            ->middleware('can:edit-supplier')
            ->name('subsidiaries.suppliers.update');
            
        Route::delete('suppliers/{supplier}', [SubsidiarySuppliersController::class, 'destroy'])
            ->middleware('can:delete-supplier')
            ->name('subsidiaries.suppliers.destroy');
        
        // Gestión de relaciones con clientes-proveedores
        Route::post('suppliers/{supplier}/attach-customers', [SubsidiarySuppliersController::class, 'attachCustomers'])
            ->middleware('can:manage-supplier-customers')
            ->name('subsidiaries.suppliers.attach-customers');
            
        Route::post('suppliers/{supplier}/detach-customers', [SubsidiarySuppliersController::class, 'detachCustomers'])
            ->middleware('can:manage-supplier-customers')
            ->name('subsidiaries.suppliers.detach-customers');
        
        // Listar clientes de un proveedor (paginado)
        Route::get('suppliers/{supplier}/customers', [SubsidiarySuppliersController::class, 'getCustomers'])
            ->middleware('can:view-supplier')
            ->name('subsidiaries.suppliers.customers');
    });
    
    // ====================================================================
    // CUSTOMER SUPPLIERS - Clientes-Proveedores
    // ====================================================================
    
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        
        // CRUD básico de clientes-proveedores
        Route::get('customer-suppliers', [SubsidiaryCustomerSuppliersController::class, 'index'])
            ->middleware('can:view-customer-supplier')
            ->name('subsidiaries.customer-suppliers.index');
            
        Route::post('customer-suppliers', [SubsidiaryCustomerSuppliersController::class, 'store'])
            ->middleware('can:create-customer-supplier')
            ->name('subsidiaries.customer-suppliers.store');
            
        Route::get('customer-suppliers/{customerSupplier}', [SubsidiaryCustomerSuppliersController::class, 'show'])
            ->middleware('can:view-customer-supplier')
            ->name('subsidiaries.customer-suppliers.show');
            
        Route::patch('customer-suppliers/{customerSupplier}', [SubsidiaryCustomerSuppliersController::class, 'update'])
            ->middleware('can:edit-customer-supplier')
            ->name('subsidiaries.customer-suppliers.update');
            
        Route::delete('customer-suppliers/{customerSupplier}', [SubsidiaryCustomerSuppliersController::class, 'destroy'])
            ->middleware('can:delete-customer-supplier')
            ->name('subsidiaries.customer-suppliers.destroy');
        
        // Gestión de relaciones con proveedores
        Route::post('customer-suppliers/{customerSupplier}/attach-suppliers', [SubsidiaryCustomerSuppliersController::class, 'attachSuppliers'])
            ->middleware('can:manage-customer-suppliers')
            ->name('subsidiaries.customer-suppliers.attach-suppliers');
            
        Route::post('customer-suppliers/{customerSupplier}/detach-suppliers', [SubsidiaryCustomerSuppliersController::class, 'detachSuppliers'])
            ->middleware('can:manage-customer-suppliers')
            ->name('subsidiaries.customer-suppliers.detach-suppliers');
        
        // Listar proveedores de un cliente (paginado)
        Route::get('customer-suppliers/{customerSupplier}/suppliers', [SubsidiaryCustomerSuppliersController::class, 'getSuppliers'])
            ->middleware('can:view-customer-supplier')
            ->name('subsidiaries.customer-suppliers.suppliers');
    });
});
