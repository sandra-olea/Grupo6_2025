<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ExcelTestController;

/*
|--------------------------------------------------------------------------
| Excel Test API Routes
|--------------------------------------------------------------------------
|
| Rutas de prueba para lectura y análisis de archivos Excel.
| Estas rutas son para testing y desarrollo.
|
*/

// Lee toda la plantilla ECOPC (todas las hojas con datos completos)
Route::get('/ecopc-template', [ExcelTestController::class, 'readEcopcTemplate'])
    ->name('excel-test.ecopc-template');

// Lee solo encabezados de la primera hoja
Route::get('/ecopc-headers', [ExcelTestController::class, 'readEcopcHeaders'])
    ->name('excel-test.ecopc-headers');

// Lee encabezados de TODAS las hojas
Route::get('/ecopc-all-headers', [ExcelTestController::class, 'readEcopcAllHeaders'])
    ->name('excel-test.ecopc-all-headers');

// Lista todas las hojas (sin datos, solo info)
Route::get('/ecopc-sheets-list', [ExcelTestController::class, 'getEcopcSheetsList'])
    ->name('excel-test.ecopc-sheets-list');

// Lee una hoja específica por nombre
Route::get('/ecopc-sheet-by-name', [ExcelTestController::class, 'readEcopcSheetByName'])
    ->name('excel-test.ecopc-sheet-by-name');

// Endpoints para archivos subidos
Route::post('/read-file', [ExcelTestController::class, 'readUploadedFile'])
    ->name('excel-test.read-file');

Route::post('/validate-headers', [ExcelTestController::class, 'validateFileHeaders'])
    ->name('excel-test.validate-headers');
