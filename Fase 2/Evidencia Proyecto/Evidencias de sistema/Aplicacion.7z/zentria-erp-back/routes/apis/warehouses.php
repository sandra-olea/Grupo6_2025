<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BranchWarehousesController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('branches/{branch}')->group(function () {
        Route::get('warehouses', [BranchWarehousesController::class, 'index'])
            ->name('branches.warehouses.index');

        Route::post('warehouses', [BranchWarehousesController::class, 'store'])
            ->name('branches.warehouses.store');

        Route::get('warehouses/{warehouse}', [BranchWarehousesController::class, 'show'])
            ->name('branches.warehouses.show');

        Route::patch('warehouses/{warehouse}', [BranchWarehousesController::class, 'update'])
            ->name('branches.warehouses.update');

        Route::delete('warehouses/{warehouse}', [BranchWarehousesController::class, 'destroy'])
            ->name('branches.warehouses.destroy');

        // Detalle de warehouse con productos
        Route::get('warehouses/{warehouse}/detail', [BranchWarehousesController::class, 'detail'])
            ->name('branches.warehouses.detail');

        // Asociar producto a warehouse
        Route::post('warehouses/{warehouse}/products', [BranchWarehousesController::class, 'attachProduct'])
            ->name('branches.warehouses.attach-product');

        // Desasociar producto de warehouse
        Route::delete('warehouses/{warehouse}/products', [BranchWarehousesController::class, 'detachProduct'])
            ->name('branches.warehouses.detach-product');
    });
});

