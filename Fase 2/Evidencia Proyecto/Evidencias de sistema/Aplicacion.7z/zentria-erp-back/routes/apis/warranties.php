<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubsidiaryWarrantiesController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        Route::get('warranties', [SubsidiaryWarrantiesController::class, 'index'])
            ->middleware('can:view-warranty')
            ->name('subsidiaries.warranties.index');

        Route::post('warranties', [SubsidiaryWarrantiesController::class, 'store'])
            ->middleware('can:create-warranty')
            ->name('subsidiaries.warranties.store');

        Route::get('warranties/{warranty}', [SubsidiaryWarrantiesController::class, 'show'])
            ->middleware('can:view-warranty')
            ->name('subsidiaries.warranties.show');

        Route::match(['put','patch'], 'warranties/{warranty}', [SubsidiaryWarrantiesController::class, 'update'])
            ->middleware('can:edit-warranty')
            ->name('subsidiaries.warranties.update');

        Route::delete('warranties/{warranty}', [SubsidiaryWarrantiesController::class, 'destroy'])
            ->middleware('can:delete-warranty')
            ->name('subsidiaries.warranties.destroy');
    });
});

