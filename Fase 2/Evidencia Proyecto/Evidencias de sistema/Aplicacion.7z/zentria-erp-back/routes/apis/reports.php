<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReportsController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        Route::get('reports', [ReportsController::class, 'index'])
            ->middleware('can:view-reports')
            ->name('subsidiaries.reports.index');

        Route::get('reports/{type}', [ReportsController::class, 'results'])
            ->middleware('can:view-reports')
            ->name('subsidiaries.reports.results');

        Route::get('reports/{type}/export', [ReportsController::class, 'export'])
            ->middleware('can:export-reports')
            ->name('subsidiaries.reports.export');
    });
});
