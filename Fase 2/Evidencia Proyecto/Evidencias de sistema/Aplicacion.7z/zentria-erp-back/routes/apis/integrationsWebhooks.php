<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Integrations\WooWebhookController;

// Webhooks públicos de WooCommerce
Route::get('integrations/woocommerce/webhooks/{api_key}/orders', [WooWebhookController::class, 'ordersPing'])
    ->name('integrations.woocommerce.webhooks.orders.ping');

Route::post('integrations/woocommerce/webhooks/{api_key}/orders', [WooWebhookController::class, 'orders'])
    ->name('integrations.woocommerce.webhooks.orders');
