<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\QueuesController;

// Visible para cualquier usuario autenticado
Route::middleware(['auth:api'])->group(function () {
    Route::get('queues/tasks', [QueuesController::class, 'index'])->name('queues.tasks.index');
    Route::get('queues/tasks/{id}', [QueuesController::class, 'show'])->name('queues.tasks.show');
});

