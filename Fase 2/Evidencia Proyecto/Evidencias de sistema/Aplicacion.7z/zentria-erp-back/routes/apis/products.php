<?php
use App\Http\Controllers\BranchProductsController;
use App\Http\Controllers\SubsidiaryProductsController;
use App\Http\Controllers\BranchInventoryController;

Route::middleware(['auth:api'])->group(function(){
  // Subsidiary-scoped saleable products
  Route::get('subsidiaries/{subsidiary}/products/saleables', [SubsidiaryProductsController::class, 'saleables']);

  // Branch-scoped saleable products (more efficient, recommended)
  Route::get('branches/{branch}/products/saleables', [BranchProductsController::class, 'saleables']);

  Route::get('branches/{branch}/products/summary', [BranchInventoryController::class,'summary']);
  Route::get('branches/{branch}/products/saleables', [BranchProductsController::class,'saleables']);
  Route::get('branches/{branch}/products', [BranchProductsController::class,'index']);
  Route::post('branches/{branch}/products', [BranchProductsController::class,'store'])->middleware('can:create-product');
  Route::get('branches/{branch}/products/{product}', [BranchProductsController::class,'show']);
  Route::match(['put','patch'], 'branches/{branch}/products/{product}', [BranchProductsController::class,'update'])->middleware('can:edit-product');
  Route::delete('branches/{branch}/products/{product}', [BranchProductsController::class,'destroy'])->middleware('can:delete-product');
  Route::patch('branches/{branch}/products/{product}/toggle-status', [BranchProductsController::class, 'toggleStatus'])->middleware('can:edit-product');
  
  // Remove WooCommerce synchronization (super_admin only)
  Route::delete('branches/{branch}/products/{product}/marketplace-sync/woocommerce', [BranchProductsController::class, 'removeWooCommerceSync']);
});
