<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubsidiaryIntegrationsController;
use App\Http\Controllers\Integrations\WooAdminController;
use App\Http\Controllers\UnmappedWooCommerceProductController;
use App\Http\Controllers\UnmappedWooCommerceProductAggregateController;

Route::middleware(['auth:api'])->group(function () {
    Route::prefix('subsidiaries/{subsidiary}')->group(function () {
        Route::get('integrations', [SubsidiaryIntegrationsController::class, 'index'])
            ->middleware('can:view-integration')
            ->name('subsidiaries.integrations.index');

        Route::post('integrations', [SubsidiaryIntegrationsController::class, 'store'])
            ->middleware('can:create-integration')
            ->name('subsidiaries.integrations.store');

        // Aggregated (all integrations in the subsidiary): unmapped and mapped
        Route::get('integrations/unmapped-products', [UnmappedWooCommerceProductAggregateController::class, 'unmapped'])
            ->name('subsidiaries.integrations.unmapped-products.unmapped-all');
        Route::get('integrations/unmapped-products/mapped', [UnmappedWooCommerceProductAggregateController::class, 'mapped'])
            ->name('subsidiaries.integrations.unmapped-products.mapped-all');

        Route::get('integrations/{integration}', [SubsidiaryIntegrationsController::class, 'show'])->whereUuid('integration')
            ->middleware('can:view-integration')
            ->name('subsidiaries.integrations.show');

        Route::patch('integrations/{integration}', [SubsidiaryIntegrationsController::class, 'update'])->whereUuid('integration')
            ->middleware('can:edit-integration')
            ->name('subsidiaries.integrations.update');

        Route::delete('integrations/{integration}', [SubsidiaryIntegrationsController::class, 'destroy'])->whereUuid('integration')
            ->middleware('can:delete-integration')
            ->name('subsidiaries.integrations.destroy');
        
        // Unmapped WooCommerce Products per integration (super_admin only)
        Route::group([
            'prefix' => 'integrations/{integration}/unmapped-products',
            'where' => ['integration' => '[0-9a-fA-F\-]{36}'],
        ], function () {
            Route::get('/', [UnmappedWooCommerceProductController::class, 'index'])
                ->name('subsidiaries.integrations.unmapped-products.index');
            Route::get('/mapped', [UnmappedWooCommerceProductController::class, 'mapped'])
                ->name('subsidiaries.integrations.unmapped-products.mapped');
            Route::get('/synced-products', [UnmappedWooCommerceProductController::class, 'syncedProducts'])
                ->name('subsidiaries.integrations.unmapped-products.synced-products');
            Route::get('/{unmappedProduct}', [UnmappedWooCommerceProductController::class, 'show'])
                ->name('subsidiaries.integrations.unmapped-products.show');
            Route::post('/{unmappedProduct}/map', [UnmappedWooCommerceProductController::class, 'map'])
                ->name('subsidiaries.integrations.unmapped-products.map');
            Route::post('/{unmappedProduct}/unmap', [UnmappedWooCommerceProductController::class, 'unmap'])
                ->name('subsidiaries.integrations.unmapped-products.unmap');
            Route::delete('/{unmappedProduct}', [UnmappedWooCommerceProductController::class, 'destroy'])
                ->name('subsidiaries.integrations.unmapped-products.destroy');
        });
    });

    // WooCommerce admin endpoints
    Route::prefix('subsidiaries/{subsidiary}/integrations/woocommerce')->group(function () {
        Route::get('orders/{wc_order_id}/check-or-import', [WooAdminController::class, 'checkOrImportOrder'])
            ->middleware('can:view-integration')
            ->name('subsidiaries.integrations.woocommerce.check-or-import-order');
        Route::post('import-missing-orders', [WooAdminController::class, 'importMissingOrders'])
            ->middleware('can:edit-integration')
            ->name('subsidiaries.integrations.woocommerce.import-missing-orders');
        Route::get('import-missing-orders/status', [WooAdminController::class, 'importMissingOrdersStatus'])
            ->middleware('can:view-integration')
            ->name('subsidiaries.integrations.woocommerce.import-missing-orders-status');
        Route::post('sync-stock', [WooAdminController::class, 'syncStock'])
            ->middleware('can:edit-integration')
            ->name('subsidiaries.integrations.woocommerce.sync-stock');
    });
});
