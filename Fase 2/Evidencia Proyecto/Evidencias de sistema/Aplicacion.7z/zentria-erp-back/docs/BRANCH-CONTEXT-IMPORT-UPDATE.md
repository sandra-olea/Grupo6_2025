# ✅ Actualización: Rutas de Importación con Contexto de Branch

## 📋 Cambios Realizados

### 1. **Rutas Actualizadas** ✅

Las rutas de importación ahora están bajo el contexto de una branch específica:

#### Antes:
```
POST /api/products/import
POST /api/products/import/ecopc
POST /api/products/import/preview
POST /api/products/validate-attributes
```

#### Ahora:
```
POST /api/branches/{branch}/products/import
POST /api/branches/{branch}/products/import/ecopc
POST /api/branches/{branch}/products/import/preview
POST /api/branches/{branch}/products/validate-attributes
```

### 2. **Archivos Modificados** ✅

#### `routes/apis/productImports.php`
- ✅ Agregado `prefix('branches/{branch}')` al grupo de rutas
- ✅ Cambiado `/import` a `/products/import`
- ✅ Cambiado `/import/ecopc` a `/products/import/ecopc`
- ✅ Cambiado `/import/preview` a `/products/import/preview`
- ✅ Cambiado `/validate-attributes` a `/products/validate-attributes`
- ✅ Nombres de rutas actualizados: `branches.products.import`, etc.

#### `routes/api.php`
- ✅ Removido el `Route::prefix('products')` wrapper
- ✅ Ahora incluye directamente el archivo `productImports.php`

#### `app/Http/Controllers/ProductImportController.php`
- ✅ `importFromExcel()`: Ahora recibe `int $branch` como parámetro de ruta
- ✅ `importEcopcTemplate()`: Ahora recibe `int $branch` como parámetro de ruta
- ✅ Removida validación de `branch_id` del request body
- ✅ Agregada validación de existencia de branch con código 404

#### `docs/api-endpoints-import.md`
- ✅ Todos los endpoints actualizados con `{branch}` en la URL
- ✅ Ejemplos de cURL actualizados
- ✅ Ejemplos de JavaScript/React actualizados
- ✅ Documentación de parámetros de URL agregada

### 3. **Mejoras Implementadas** 🚀

#### Mejor RESTful Design
- ✅ Los productos ahora se importan bajo el contexto explícito de una branch
- ✅ Sigue el patrón `/branches/{branch}/products/*` consistente con otras rutas

#### Validación Mejorada
- ✅ Validación de branch existence en el controller
- ✅ Respuesta 404 si la branch no existe
- ✅ Parámetro `branch_id` ya no necesario en el body

#### Mejor Experiencia de Usuario
- ✅ URL más clara y semántica
- ✅ Menos parámetros en el request body
- ✅ Branch ID visible en la URL

### 4. **Cambios en el Request** 📝

#### importFromExcel

**Antes:**
```javascript
POST /api/products/import
Body: {
  file: File,
  branch_id: 1,
  update_existing: true
}
```

**Ahora:**
```javascript
POST /api/branches/1/products/import
Body: {
  file: File,
  update_existing: true
}
```

#### importEcopcTemplate

**Antes:**
```javascript
POST /api/products/import/ecopc
Body: {
  branch_id: 1,
  update_existing: true
}
```

**Ahora:**
```javascript
POST /api/branches/1/products/import/ecopc
Body: {
  update_existing: true
}
```

#### previewImport

**Antes:**
```javascript
POST /api/products/import/preview
Body: {
  file: File
}
```

**Ahora:**
```javascript
POST /api/branches/1/products/import/preview
Body: {
  file: File
}
```

#### validateAttributes

**Antes:**
```javascript
POST /api/products/validate-attributes
Body: {
  attributes: {...}
}
```

**Ahora:**
```javascript
POST /api/branches/1/products/validate-attributes
Body: {
  attributes: {...}
}
```

### 5. **Verificación de Rutas** ✅

```bash
docker compose exec app php artisan route:list | Select-String "import"

# Resultado:
POST api/branches/{branch}/products/import branches.products.import
POST api/branches/{branch}/products/import/ecopc branches.products.import.ecopc
POST api/branches/{branch}/products/import/preview branches.products.import.preview
```

---

## 🔧 Migración para Frontend

Si ya tienes código frontend que usa los endpoints antiguos, aquí está cómo migrarlo:

### Antes:
```typescript
const response = await fetch('/api/products/import', {
  method: 'POST',
  body: formData, // Incluía branch_id
});
```

### Ahora:
```typescript
const branchId = 1; // Obtener del contexto/estado
const response = await fetch(`/api/branches/${branchId}/products/import`, {
  method: 'POST',
  body: formData, // Ya NO incluye branch_id
});
```

### Ejemplo Completo con React:
```typescript
import { useState } from 'react';
import { useCurrentBranch } from '@/hooks/useCurrentBranch';

function ProductImporter() {
  const { currentBranch } = useCurrentBranch(); // Hook para obtener branch actual
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);

  const handleImport = async () => {
    if (!file || !currentBranch) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('update_existing', 'true');

    setLoading(true);
    try {
      const response = await fetch(
        `/api/branches/${currentBranch.id}/products/import`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${getToken()}`,
          },
          body: formData,
        }
      );

      const result = await response.json();
      
      if (result.success) {
        alert(`✅ ${result.data.successful} productos importados`);
      }
    } catch (error) {
      alert('❌ Error en la importación');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <input
        type="file"
        accept=".xlsx,.xls,.csv"
        onChange={(e) => setFile(e.target.files?.[0] || null)}
        disabled={loading}
      />
      <button onClick={handleImport} disabled={!file || loading}>
        {loading ? 'Importando...' : 'Importar Productos'}
      </button>
    </div>
  );
}
```

---

## 🚀 Beneficios

1. **RESTful Compliance**: Sigue mejor el estándar REST con recursos anidados
2. **Claridad**: La URL indica claramente a qué branch pertenecen los productos
3. **Consistencia**: Alineado con otras rutas como `branches/{branch}/products`
4. **Menos Parámetros**: Body del request más limpio
5. **Mejor Validación**: Validación de branch en controller con respuesta 404

---

## 📚 Referencias

- **Rutas:** `routes/apis/productImports.php`
- **Controller:** `app/Http/Controllers/ProductImportController.php`
- **Documentación:** `docs/api-endpoints-import.md`
- **Tests:** `tests/Feature/Http/Controllers/ProductImportControllerTest.php` (requiere actualización)

---

## ⚠️ Nota Importante

Los tests en `tests/Feature/Http/Controllers/ProductImportControllerTest.php` necesitarán ser actualizados para usar las nuevas URLs con `{branch}` en la ruta.
