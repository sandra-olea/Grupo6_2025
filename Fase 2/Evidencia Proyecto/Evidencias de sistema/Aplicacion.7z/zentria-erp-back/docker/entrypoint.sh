#!/bin/sh
set -e

cd /var/www/html

# Establece permisos correctos PRIMERO
echo "Configurando permisos de directorios..."
chown -R www-data:www-data storage bootstrap/cache || true
chmod -R 775 storage bootstrap/cache || true

# Si no hay .env, lo crea desde el ejemplo
if [ ! -f .env ] && [ -f .env.example ]; then
  cp .env.example .env
fi

# Espera a PostgreSQL si hay config
if [ -n "${DB_HOST}" ]; then
  echo "Esperando a PostgreSQL en ${DB_HOST}:${DB_PORT:-5432}..."
  until pg_isready -h "${DB_HOST}" -p "${DB_PORT:-5432}" -U "${DB_USERNAME}" >/dev/null 2>&1; do
    sleep 1
  done
  echo "PostgreSQL disponible."
fi

# Instala dependencias si falta vendor
if [ ! -d vendor ]; then
  composer install --no-interaction --prefer-dist --no-progress || true
fi

if [ ! -f vendor/autoload.php ]; then
  composer install --no-interaction --prefer-dist --optimize-autoloader || true
fi
php artisan package:discover --ansi || true
php artisan optimize:clear || true

# Claves de la app y JWT
if ! grep -q "^APP_KEY=base64:" .env 2>/dev/null; then
  php artisan key:generate --force || true
fi
if ! grep -q "^JWT_SECRET=" .env 2>/dev/null; then
  php artisan jwt:secret --force || true
fi

# Limpia/optimiza y migra
php artisan optimize:clear || true
if [ "${RUN_MIGRATIONS:-true}" = "true" ]; then
  php artisan migrate --force || true
fi
if [ "${RUN_SEED:-false}" = "true" ]; then
  php artisan db:seed --force || true
fi

# Auto-seed if notifications are empty (dev-friendly). Disable with AUTO_SEED_IF_EMPTY=false
if [ "${AUTO_SEED_IF_EMPTY:-true}" = "true" ]; then
  php artisan db:seed-if-empty --ansi || true
fi

# imagenes spatie
mkdir -p storage/app/public
php artisan storage:link || true

# Asegura permisos finales
echo "Verificando permisos finales..."
chown -R www-data:www-data storage bootstrap/cache || true
chmod -R 775 storage bootstrap/cache || true

# Ejecuta el comando pasado o por defecto php-fpm en primer plano
if [ "$#" -gt 0 ]; then
  exec "$@"
else
  exec php-fpm -F
fi
