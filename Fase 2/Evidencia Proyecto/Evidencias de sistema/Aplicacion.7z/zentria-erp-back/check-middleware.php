<?php

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';

echo "=== Middleware Groups ===\n";
$groups = $app->make('router')->getMiddlewareGroups();
echo "API group middlewares:\n";
print_r($groups['api'] ?? ['No api group']);

echo "\n=== Global Middleware ===\n";
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
// En Laravel 12 no hay getGlobalMiddleware(), los globales se definen en bootstrap/app.php

echo "\n=== Verificando respuesta JSON con status 401 ===\n";
$response = new \Illuminate\Http\JsonResponse(['error' => 'Test'], 401);
echo "Status Code: " . $response->getStatusCode() . "\n";
echo "Content: " . $response->getContent() . "\n";
echo "Headers: \n";
foreach ($response->headers->all() as $key => $values) {
    echo "  $key: " . implode(', ', $values) . "\n";
}

echo "\n=== Simulando prepare() ===\n";
$request = \Illuminate\Http\Request::create('http://localhost/api/test', 'GET');
$preparedResponse = $response->prepare($request);
echo "Status después de prepare(): " . $preparedResponse->getStatusCode() . "\n";
