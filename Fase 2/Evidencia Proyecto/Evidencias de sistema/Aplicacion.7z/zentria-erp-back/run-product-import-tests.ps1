#!/usr/bin/env pwsh

# Script para ejecutar tests del módulo de importación de productos

Write-Host "🧪 Tests del Módulo de Importación de Productos" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

# Verificar que estamos en el directorio correcto
if (-not (Test-Path "artisan")) {
    Write-Host "❌ Error: Este script debe ejecutarse desde la raíz del proyecto Laravel" -ForegroundColor Red
    exit 1
}

# Menú de opciones
Write-Host "Selecciona qué tests ejecutar:" -ForegroundColor Yellow
Write-Host "1. Todos los tests del módulo" -ForegroundColor White
Write-Host "2. Solo ProductAttributesValidatorTest (validaciones)" -ForegroundColor White
Write-Host "3. Solo ProductImportServiceTest (lógica de importación)" -ForegroundColor White
Write-Host "4. Solo ProductImportControllerTest (endpoints API)" -ForegroundColor White
Write-Host "5. Todos los tests unitarios" -ForegroundColor White
Write-Host "6. Todos los tests de funcionalidad" -ForegroundColor White
Write-Host "7. Todos los tests del proyecto" -ForegroundColor White
Write-Host "0. Salir" -ForegroundColor White
Write-Host ""

$opcion = Read-Host "Opción"

switch ($opcion) {
    "1" {
        Write-Host ""
        Write-Host "🧪 Ejecutando todos los tests del módulo..." -ForegroundColor Yellow
        Write-Host ""
        docker compose exec app php artisan test tests/Unit/Services/ProductAttributesValidatorTest.php tests/Unit/Services/ProductImportServiceTest.php tests/Feature/Http/Controllers/ProductImportControllerTest.php
    }
    
    "2" {
        Write-Host ""
        Write-Host "🧪 Ejecutando ProductAttributesValidatorTest..." -ForegroundColor Yellow
        Write-Host ""
        docker compose exec app php artisan test tests/Unit/Services/ProductAttributesValidatorTest.php
    }
    
    "3" {
        Write-Host ""
        Write-Host "🧪 Ejecutando ProductImportServiceTest..." -ForegroundColor Yellow
        Write-Host ""
        docker compose exec app php artisan test tests/Unit/Services/ProductImportServiceTest.php
    }
    
    "4" {
        Write-Host ""
        Write-Host "🧪 Ejecutando ProductImportControllerTest..." -ForegroundColor Yellow
        Write-Host ""
        docker compose exec app php artisan test tests/Feature/Http/Controllers/ProductImportControllerTest.php
    }
    
    "5" {
        Write-Host ""
        Write-Host "🧪 Ejecutando todos los tests unitarios..." -ForegroundColor Yellow
        Write-Host ""
        docker compose exec app php artisan test --testsuite=Unit
    }
    
    "6" {
        Write-Host ""
        Write-Host "🧪 Ejecutando todos los tests de funcionalidad..." -ForegroundColor Yellow
        Write-Host ""
        docker compose exec app php artisan test --testsuite=Feature
    }
    
    "7" {
        Write-Host ""
        Write-Host "🧪 Ejecutando TODOS los tests del proyecto..." -ForegroundColor Yellow
        Write-Host ""
        docker compose exec app php artisan test
    }
    
    "0" {
        Write-Host ""
        Write-Host "👋 ¡Hasta luego!" -ForegroundColor Cyan
        exit 0
    }
    
    default {
        Write-Host ""
        Write-Host "❌ Opción no válida" -ForegroundColor Red
        exit 1
    }
}

Write-Host ""
Write-Host "✅ Ejecución completada" -ForegroundColor Green
Write-Host ""
Write-Host "📚 Para más información: tests/README-PRODUCT-IMPORT-TESTS.md" -ForegroundColor Cyan
