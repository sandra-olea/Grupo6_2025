<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        api: __DIR__.'/../routes/api.php',
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withCommands([
        \App\Console\Commands\CreatePermissionGroupsConfig::class,
        \App\Console\Commands\SeedPermissions::class,
        \App\Console\Commands\DbSeedIfEmpty::class,
    ])
    ->withMiddleware(function (Middleware $middleware) {
        // CORS global usando el middleware nativo de Laravel
        $middleware->append(\Illuminate\Http\Middleware\HandleCors::class);
        // Normaliza strings vacíos o con solo espacios a null
        $middleware->append(\App\Http\Middleware\NormalizeEmptyStrings::class);
        
        $middleware->alias([
            'auth'                  => \App\Http\Middleware\Authenticate::class,
            'rol'                   => \App\Http\Middleware\CheckRol::class,
            'verificar.activacion'  => \App\Http\Middleware\VerificarActivacion::class,
            'verificar.empresa'     => \App\Http\Middleware\VerificarAccesoEmpresa::class,
            // Autorizaciones
            'can'                   => \Illuminate\Auth\Middleware\Authorize::class,
            'role'                  => \Spatie\Permission\Middlewares\RoleMiddleware::class,
            'permission'            => \Spatie\Permission\Middlewares\PermissionMiddleware::class,
            'role_or_permission'    => \Spatie\Permission\Middlewares\RoleOrPermissionMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // Handler GLOBAL para todas las HttpExceptions en rutas API
        $exceptions->render(function (\Symfony\Component\HttpKernel\Exception\HttpException $e, $request) {
            // SIEMPRE devolver JSON para rutas /api/*
            if ($request->is('api/*') || $request->expectsJson()) {
                $statusCode = $e->getStatusCode();
                
                // Personalizar mensajes de autorización
                if ($statusCode === 403) {
                    $message = 'No tienes permiso para realizar esta acción.';
                } else {
                    $message = $e->getMessage() ?: \Symfony\Component\HttpFoundation\Response::$statusTexts[$statusCode] ?? 'Error';
                }
                
                return response()->json(['message' => $message], $statusCode);
            }
        });

        // Manejo específico de autorización
        $exceptions->render(function (\Illuminate\Auth\Access\AuthorizationException $e, $request) {
            // SIEMPRE devolver JSON para rutas /api/*
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'message' => 'No tienes permiso para realizar esta acción.',
                ], 403, ['Content-Type' => 'application/json']);
            }
        });

        $exceptions->render(function (\Spatie\Permission\Exceptions\UnauthorizedException $e, $request) {
            // SIEMPRE devolver JSON para rutas /api/*
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'message' => 'No tienes permiso para realizar esta acción.',
                ], 403, ['Content-Type' => 'application/json']);
            }
        });

        $exceptions->render(function (\Illuminate\Auth\AuthenticationException $e, $request) {
            // SIEMPRE devolver JSON para rutas /api/*
            if ($request->is('api/*') || $request->expectsJson()) {
                return response()->json([
                    'message' => 'No autenticado.',
                ], 401, ['Content-Type' => 'application/json']);
            }
        });
    })->create();

