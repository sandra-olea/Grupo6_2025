#!/usr/bin/env pwsh

# Script para probar el importador de productos

Write-Host "🧪 Prueba del Importador de Productos" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

# Verificar que estamos en el directorio correcto
if (-not (Test-Path "artisan")) {
    Write-Host "❌ Error: Este script debe ejecutarse desde la raíz del proyecto Laravel" -ForegroundColor Red
    exit 1
}

# Verificar que existe el CSV de ejemplo
$csvPath = "public/templates/CSV/ejemplo-importacion-productos.csv"
if (-not (Test-Path $csvPath)) {
    Write-Host "❌ Error: No se encontró el archivo $csvPath" -ForegroundColor Red
    exit 1
}

# Verificar que existe el XLSX (si existe)
$xlsxPath = "public/templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx"
$hasXlsx = Test-Path $xlsxPath

Write-Host "📁 Archivos disponibles:" -ForegroundColor Yellow
Write-Host "   ✓ CSV: $csvPath" -ForegroundColor Green
if ($hasXlsx) {
    Write-Host "   ✓ XLSX: $xlsxPath" -ForegroundColor Green
} else {
    Write-Host "   ✗ XLSX: No encontrado (opcional)" -ForegroundColor Gray
}
Write-Host ""

# Menú de opciones
Write-Host "Selecciona una opción:" -ForegroundColor Cyan
Write-Host "1. Vista previa del CSV de ejemplo" -ForegroundColor White
Write-Host "2. Importar CSV de ejemplo (necesita branch_id)" -ForegroundColor White
if ($hasXlsx) {
    Write-Host "3. Vista previa del XLSX de ECOPC" -ForegroundColor White
    Write-Host "4. Importar XLSX de ECOPC (necesita branch_id)" -ForegroundColor White
}
Write-Host "5. Probar con archivo personalizado" -ForegroundColor White
Write-Host "0. Salir" -ForegroundColor White
Write-Host ""

$opcion = Read-Host "Opción"

switch ($opcion) {
    "1" {
        Write-Host ""
        Write-Host "📊 Generando vista previa del CSV..." -ForegroundColor Yellow
        Write-Host ""
        
        # Convertir CSV a un formato temporal que el comando pueda leer
        # Nota: El comando espera Excel, así que mostramos el contenido del CSV
        Write-Host "Contenido del archivo CSV:" -ForegroundColor Cyan
        Get-Content $csvPath | Select-Object -First 20
        Write-Host ""
        Write-Host "✅ Mostrando primeras 20 líneas del CSV" -ForegroundColor Green
    }
    
    "2" {
        Write-Host ""
        $branchId = Read-Host "Ingresa el ID de la sucursal"
        
        if ([string]::IsNullOrWhiteSpace($branchId) -or -not ($branchId -match '^\d+$')) {
            Write-Host "❌ Error: Debes ingresar un ID de sucursal válido (número)" -ForegroundColor Red
            exit 1
        }
        
        Write-Host ""
        Write-Host "⚠️  IMPORTANTE: El comando espera archivos Excel (.xlsx), no CSV" -ForegroundColor Yellow
        Write-Host "   Por favor, convierte el CSV a Excel o usa un archivo .xlsx" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "   Comando para ejecutar con Excel:" -ForegroundColor Cyan
        Write-Host "   docker compose exec app php artisan products:import public/templates/XLSX/tu-archivo.xlsx $branchId --update-existing" -ForegroundColor White
    }
    
    "3" {
        if (-not $hasXlsx) {
            Write-Host "❌ El archivo XLSX no está disponible" -ForegroundColor Red
            exit 1
        }
        
        Write-Host ""
        Write-Host "📊 Generando vista previa del XLSX..." -ForegroundColor Yellow
        Write-Host ""
        
        docker compose exec app php artisan products:import $xlsxPath 1 --preview
    }
    
    "4" {
        if (-not $hasXlsx) {
            Write-Host "❌ El archivo XLSX no está disponible" -ForegroundColor Red
            exit 1
        }
        
        Write-Host ""
        $branchId = Read-Host "Ingresa el ID de la sucursal"
        
        if ([string]::IsNullOrWhiteSpace($branchId) -or -not ($branchId -match '^\d+$')) {
            Write-Host "❌ Error: Debes ingresar un ID de sucursal válido (número)" -ForegroundColor Red
            exit 1
        }
        
        Write-Host ""
        Write-Host "🚀 Importando productos..." -ForegroundColor Yellow
        Write-Host ""
        
        docker compose exec app php artisan products:import $xlsxPath $branchId --update-existing
    }
    
    "5" {
        Write-Host ""
        $customFile = Read-Host "Ingresa la ruta del archivo Excel (desde la raíz del proyecto)"
        
        if (-not (Test-Path $customFile)) {
            Write-Host "❌ Error: El archivo no existe: $customFile" -ForegroundColor Red
            exit 1
        }
        
        $branchId = Read-Host "Ingresa el ID de la sucursal"
        
        if ([string]::IsNullOrWhiteSpace($branchId) -or -not ($branchId -match '^\d+$')) {
            Write-Host "❌ Error: Debes ingresar un ID de sucursal válido (número)" -ForegroundColor Red
            exit 1
        }
        
        $preview = Read-Host "¿Solo vista previa? (s/n)"
        
        Write-Host ""
        if ($preview -eq "s" -or $preview -eq "S") {
            Write-Host "📊 Generando vista previa..." -ForegroundColor Yellow
            docker compose exec app php artisan products:import $customFile $branchId --preview
        } else {
            Write-Host "🚀 Importando productos..." -ForegroundColor Yellow
            docker compose exec app php artisan products:import $customFile $branchId --update-existing
        }
    }
    
    "0" {
        Write-Host ""
        Write-Host "👋 ¡Hasta luego!" -ForegroundColor Cyan
        exit 0
    }
    
    default {
        Write-Host ""
        Write-Host "❌ Opción no válida" -ForegroundColor Red
        exit 1
    }
}

Write-Host ""
Write-Host "✅ Proceso completado" -ForegroundColor Green
Write-Host ""
Write-Host "📚 Para más información, consulta: docs/product-import-guide.md" -ForegroundColor Cyan
