# Script PowerShell para detectar BOMs en archivos PHP
# Uso: .\check-bom.ps1 [-Fix]

param(
    [switch]$Fix
)

Write-Host "[*] Buscando BOMs en archivos PHP..." -ForegroundColor Cyan

$hasBom = $false
$fixedCount = 0

# Buscar todos los archivos PHP (excluyendo vendor, node_modules, storage)
Get-ChildItem -Path . -Filter "*.php" -Recurse -File | Where-Object {
    $_.FullName -notmatch '\\vendor\\' -and
    $_.FullName -notmatch '\\node_modules\\' -and
    $_.FullName -notmatch '\\.git\\' -and
    $_.FullName -notmatch '\\storage\\'
} | ForEach-Object {
    $file = $_
    
    # Leer los primeros 3 bytes
    $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
    
    if ($bytes.Length -ge 3) {
        $firstThree = $bytes[0..2]
        
        # Verificar si es BOM UTF-8 (ef bb bf)
        if ($firstThree[0] -eq 0xEF -and $firstThree[1] -eq 0xBB -and $firstThree[2] -eq 0xBF) {
            Write-Host "[X] BOM detectado en: $($file.FullName)" -ForegroundColor Red
            $hasBom = $true
            
            if ($Fix) {
                # Eliminar el BOM (saltar los primeros 3 bytes)
                $content = $bytes[3..($bytes.Length - 1)]
                [System.IO.File]::WriteAllBytes($file.FullName, $content)
                Write-Host "    [OK] BOM eliminado" -ForegroundColor Green
                $fixedCount++
            }
        }
    }
}

Write-Host ""

if (-not $hasBom) {
    Write-Host "[OK] No se detectaron BOMs en archivos PHP" -ForegroundColor Green
    exit 0
} else {
    if (-not $Fix) {
        Write-Host "[!] Para corregir automaticamente, ejecuta:" -ForegroundColor Yellow
        Write-Host "    .\check-bom.ps1 -Fix" -ForegroundColor Yellow
        Write-Host ""
        exit 1
    } else {
        Write-Host "[OK] Se corrigieron $fixedCount archivo(s)" -ForegroundColor Green
        exit 0
    }
}
