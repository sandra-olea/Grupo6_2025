<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Cotización #{{ $quote_number_display }}</title>
    <style>
        @page { size: letter; margin: 24mm 18mm; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #1f2937; }
        h1 { font-size: 18px; margin: 0 0 8px 0; }
        h2 { font-size: 14px; margin: 12px 0 6px 0; }
        .muted { color: #6b7280; }
        .box { border: 1px solid #d1d5db; padding: 8px; }
        table { width: 100%; border-spacing: 0; border: 1px solid #e5e7eb; border-left: 0; border-top: 0; }
        th, td { padding: 6px; border-right: 1px solid #e5e7eb; border-top: 1px solid #e5e7eb; text-align: left; vertical-align: top; }
        th { background: #f3f4f6; font-weight: bold; }
        .right { text-align: right; }
        .small { font-size: 11px; }
        .totals { margin-top: 10px; width: 50%; margin-left: auto; }
        .label { color: #374151; }
    </style>
</head>
<body>
    <table style="width:100%; margin-bottom: 10px">
        <tr>
            <td style="width:65%">
                <h1>Cotización #{{ $quote_number_display }}</h1>
                <div class="muted small">Generada desde Venta #{{ $sale->id }} ({{ $sale->sale_number }})</div>
            </td>
            <td style="width:35%">
                <div class="box small">
                    <div><span class="label">Fecha:</span> {{ $date_display }}</div>
                    <div><span class="label">Método de pago:</span> {{ $payment_title }}</div>
                    <div><span class="label">Documento:</span> {{ $document_type ?: 'boleta' }}</div>
                    @if(!empty($po_number))
                        <div><span class="label">N° orden de C.:</span> {{ $po_number }}</div>
                    @endif
                </div>
            </td>
        </tr>
    </table>

    <table style="width:100%; margin-bottom: 8px">
        <tr>
            <td style="width:100%">
                <div class="box">
                    <h2>Cliente</h2>
                    <div><span class="label">Empresa / Comprador:</span> {{ $buyer_name }}</div>
                    <div><span class="label">RUT:</span> {{ $rut }}</div>
                    <div><span class="label">Giro:</span> {{ $giro }}</div>
                    <div><span class="label">Dirección:</span> {{ $address }}</div>
                    <div><span class="label">Contacto:</span> {{ $contact_name }}</div>
                    <div><span class="label">Correo:</span> {{ $email }}</div>
                </div>
            </td>
        </tr>
    </table>

    <h2>Detalle</h2>
    <table>
        <thead>
            <tr>
                <th style="width: 80px">Cantidad</th>
                <th style="width: 140px">SKU</th>
                <th>Producto</th>
                <th class="right" style="width: 140px">Precio Neto</th>
                <th class="right" style="width: 140px">Total Neto</th>
            </tr>
        </thead>
        <tbody>
        @php $hasItems = is_countable($items) ? count($items) > 0 : !empty($items); @endphp
        @if($hasItems)
        @foreach($items as $it)
            <tr>
                <td>{{ $it['quantity'] }}</td>
                <td>{{ $it['sku'] }}</td>
                <td>
                    <div style="font-weight:bold;">{{ $it['name'] }}</div>
                    @if(!empty($it['addons']))
                        <div class="small" style="color:#6b7280; font-style:italic; margin-top:2px;">{{ $it['addons'] }}</div>
                    @endif
                    @if($it['has_discount'])
                        <div class="muted small">Desc: $ {{ number_format($it['discount_amount'], 0, ',', '.') }}</div>
                    @endif
                </td>
                <td class="right">$ {{ number_format($it['unit_net'], 0, ',', '.') }}</td>
                <td class="right">$ {{ number_format($it['total_net'], 0, ',', '.') }}</td>
            </tr>
        @endforeach
        @else
            <tr>
                <td colspan="5" class="small muted">Sin ítems</td>
            </tr>
        @endif
        </tbody>
    </table>

    <table class="totals">
        <tbody>
            @if($totals['shipping_net'] > 0)
            <tr>
                <td class="label">Envío (Neto)</td>
                <td class="right">$ {{ number_format($totals['shipping_net'], 0, ',', '.') }}</td>
            </tr>
            @endif
            <tr>
                <td class="label" style="font-weight: normal;">TOTAL NETO</td>
                <td class="right" style="font-weight: normal;">$ {{ number_format($totals['total_net'], 0, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="label">IVA (19%)</td>
                <td class="right">$ {{ number_format($totals['iva'], 0, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="label" style="font-weight: normal;">TOTAL</td>
                <td class="right" style="font-weight: normal;">$ {{ number_format($totals['grand_total'], 0, ',', '.') }}</td>
            </tr>
        </tbody>
    </table>

    <div class="small muted" style="margin-top: 18px">Los montos están expresados en CLP e incluyen desglose de IVA. La suma de IVA + Total Neto cuadra con el total del pedido.</div>
</body>
</html>
