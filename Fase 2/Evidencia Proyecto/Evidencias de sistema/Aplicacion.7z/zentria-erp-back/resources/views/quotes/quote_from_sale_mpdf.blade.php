<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Cotización #{{ $quote_number_display }}</title>
</head>
<body style="font-family: DejaVu Sans; font-size: 11px; color: #1f2937;">
    <table style="width:100%; border-spacing:0; margin-bottom:8px;">
        <tr>
            <td style="width:65%;">
                <div style="font-size:16px; font-weight:bold; margin-bottom:4px;">Cotización #{{ $quote_number_display }}</div>
                <div style="color:#6b7280; font-size:10px;">Generada desde Venta #{{ $sale->id }} ({{ $sale->sale_number }})</div>
            </td>
            <td style="width:35%;">
                <div style="border:1px solid #d1d5db; padding:6px; font-size:10px;">
                    <div><span style="color:#374151;">Fecha:</span> {{ $date_display }}</div>
                    <div><span style="color:#374151;">Método de pago:</span> {{ $payment_title }}</div>
                    <div><span style="color:#374151;">Documento:</span> {{ $document_type ?: 'boleta' }}</div>
                    @if(!empty($po_number))
                        <div><span style="color:#374151;">N° orden de C.:</span> {{ $po_number }}</div>
                    @endif
                </div>
            </td>
        </tr>
    </table>

    <table style="width:100%; border-spacing:0; margin-bottom:8px;">
        <tr>
            <td>
                <div style="border:1px solid #d1d5db; padding:6px;">
                    <div style="font-size:12px; font-weight:bold; margin-bottom:4px;">Cliente</div>
                    <div><span style="color:#374151;">Empresa / Comprador:</span> {{ $buyer_name }}</div>
                    <div><span style="color:#374151;">RUT:</span> {{ $rut }}</div>
                    <div><span style="color:#374151;">Giro:</span> {{ $giro }}</div>
                    <div><span style="color:#374151;">Dirección:</span> {{ $address }}</div>
                    <div><span style="color:#374151;">Contacto:</span> {{ $contact_name }}</div>
                    <div><span style="color:#374151;">Correo:</span> {{ $email }}</div>
                </div>
            </td>
        </tr>
    </table>

    <div style="font-size:12px; font-weight:bold; margin:6px 0;">Detalle</div>
    <table style="width:100%; border-spacing:0; border:1px solid #e5e7eb; border-left:0; border-top:0;">
        <thead>
            <tr>
                <th style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; background:#f3f4f6; text-align:left; width:80px;">Cantidad</th>
                <th style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; background:#f3f4f6; text-align:left; width:140px;">SKU</th>
                <th style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; background:#f3f4f6; text-align:left;">Producto</th>
                <th style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; background:#f3f4f6; text-align:right; width:140px;">Precio Neto</th>
                <th style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; background:#f3f4f6; text-align:right; width:140px;">Total Neto</th>
            </tr>
        </thead>
        <tbody>
            @php $hasItems = is_countable($items) ? count($items) > 0 : !empty($items); @endphp
            @if($hasItems)
                @foreach($items as $it)
                    <tr>
                        <td style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb;">{{ $it['quantity'] }}</td>
                        <td style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb;">{{ $it['sku'] }}</td>
                        <td style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb;">
                            <div style="font-weight:bold;">{{ $it['name'] }}</div>
                            @if(!empty($it['addons']))
                                <div style="color:#6b7280; font-size:10px; font-style:italic; margin-top:2px;">{{ $it['addons'] }}</div>
                            @endif
                            @if($it['has_discount'])
                                <div style="color:#6b7280; font-size:10px;">Desc: $ {{ number_format($it['discount_amount'], 0, ',', '.') }}</div>
                            @endif
                        </td>
                        <td style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; text-align:right;">$ {{ number_format($it['unit_net'], 0, ',', '.') }}</td>
                        <td style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; text-align:right;">$ {{ number_format($it['total_net'], 0, ',', '.') }}</td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="5" style="padding:6px; border-right:1px solid #e5e7eb; border-top:1px solid #e5e7eb; color:#6b7280; font-size:10px;">Sin ítems</td>
                </tr>
            @endif
        </tbody>
    </table>

    <table style="width:100%; border-spacing:0; margin-top:8px;">
        <tr>
            <td style="width:50%"></td>
            <td style="width:50%">
                <table style="width:100%; border-spacing:0;">
                    @if($totals['shipping_net'] > 0)
                    <tr>
                        <td style="padding:6px;">Envío (Neto)</td>
                        <td style="padding:6px; text-align:right;">$ {{ number_format($totals['shipping_net'], 0, ',', '.') }}</td>
                    </tr>
                    @endif
                    <tr>
                        <td style="padding:6px; font-weight:normal;">TOTAL NETO</td>
                        <td style="padding:6px; text-align:right; font-weight:normal;">$ {{ number_format($totals['total_net'], 0, ',', '.') }}</td>
                    </tr>
                    <tr>
                        <td style="padding:6px;">IVA (19%)</td>
                        <td style="padding:6px; text-align:right;">$ {{ number_format($totals['iva'], 0, ',', '.') }}</td>
                    </tr>
                    <tr>
                        <td style="padding:6px; font-weight:normal;">TOTAL</td>
                        <td style="padding:6px; text-align:right; font-weight:normal;">$ {{ number_format($totals['grand_total'], 0, ',', '.') }}</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

    <div style="margin-top:10px; color:#6b7280; font-size:10px;">Los montos están expresados en CLP e incluyen desglose de IVA.</div>
</body>
</html>
