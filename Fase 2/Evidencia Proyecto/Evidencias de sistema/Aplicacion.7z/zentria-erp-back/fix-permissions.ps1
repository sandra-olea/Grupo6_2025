#!/usr/bin/env pwsh

# Script para solucionar problemas de permisos en contenedores Docker

Write-Host "🔧 Solucionando permisos de Laravel en Docker..." -ForegroundColor Cyan

# Detiene los contenedores
Write-Host "`n📦 Deteniendo contenedores..." -ForegroundColor Yellow
docker-compose down

# Limpia directorios de caché y logs
Write-Host "`n🧹 Limpiando directorios de caché..." -ForegroundColor Yellow
if (Test-Path "storage\framework\cache\data") {
    Remove-Item -Path "storage\framework\cache\data\*" -Recurse -Force -ErrorAction SilentlyContinue
}
if (Test-Path "storage\framework\views") {
    Remove-Item -Path "storage\framework\views\*" -Force -ErrorAction SilentlyContinue
}
if (Test-Path "storage\logs") {
    Remove-Item -Path "storage\logs\*" -Force -ErrorAction SilentlyContinue
}

# Reconstruye las imágenes
Write-Host "`n🔨 Reconstruyendo imágenes Docker..." -ForegroundColor Yellow
docker-compose build --no-cache app

# Inicia los contenedores
Write-Host "`n🚀 Iniciando contenedores..." -ForegroundColor Yellow
docker-compose up -d

# Espera a que los contenedores estén listos
Write-Host "`n⏳ Esperando a que los contenedores estén listos..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

# Configura permisos dentro del contenedor
Write-Host "`n🔐 Configurando permisos dentro del contenedor..." -ForegroundColor Yellow
docker-compose exec app sh -c "chown -R www-data:www-data /var/www/html/storage /var/www/html/bootstrap/cache"
docker-compose exec app sh -c "chmod -R 775 /var/www/html/storage /var/www/html/bootstrap/cache"

# Limpia caché de Laravel
Write-Host "`n🧹 Limpiando caché de Laravel..." -ForegroundColor Yellow
docker-compose exec app php artisan optimize:clear

Write-Host "`n[OK] Permisos configurados correctamente!" -ForegroundColor Green
Write-Host "[INFO] Los logs estan disponibles en: docker-compose logs -f app" -ForegroundColor Cyan
