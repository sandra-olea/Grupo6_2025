<?php

require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use App\Models\Notifications\NotificationSubscription;
use App\Models\Notifications\NotificationEvent;
use App\Models\Notifications\NotificationType;

echo "=== VERIFICANDO NOTIFICACIONES DE ATTACH/DETACH ===\n\n";

// 1. Verificar tipos en BD
$types = NotificationType::whereIn('key', [
    'supplier.customers-attached',
    'supplier.customers-detached',
    'customer-supplier.suppliers-attached',
    'customer-supplier.suppliers-detached',
])->get();

echo "✓ Tipos en BD: " . $types->count() . "\n";
foreach ($types as $type) {
    echo "  - {$type->key} (ID: {$type->id})\n";
}

// 2. Verificar eventos creados
$events = NotificationEvent::whereIn('type_id', $types->pluck('id'))
    ->orderBy('created_at', 'desc')
    ->limit(10)
    ->get();

echo "\n✓ Eventos creados (últimos 10): " . $events->count() . "\n";
foreach ($events as $event) {
    echo "  - {$event->type->key} (ID: {$event->id}) - " . $event->created_at . "\n";
}

echo "\n=== FIN ===\n";
