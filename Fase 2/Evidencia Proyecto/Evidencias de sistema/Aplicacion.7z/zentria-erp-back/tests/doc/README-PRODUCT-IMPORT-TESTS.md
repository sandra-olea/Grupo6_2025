# Tests del Módulo de Importación de Productos

Este directorio contiene los tests automatizados para el sistema de importación masiva de productos.

## Estructura de Tests

```
tests/
├── Unit/
│   └── Services/
│       ├── ProductAttributesValidatorTest.php    # Tests del validador de atributos
│       └── ProductImportServiceTest.php          # Tests del servicio de importación
└── Feature/
    └── Http/
        └── Controllers/
            └── ProductImportControllerTest.php   # Tests del controlador API
```

## Tipos de Tests

### Tests Unitarios (Unit)

#### ProductAttributesValidatorTest
Valida que los atributos de productos cumplan con las reglas del frontend:
- ✅ Validación de CPU brands (Intel, AMD)
- ✅ Validación de RAM types (DDR3, DDR3L, DDR4, DDR5)
- ✅ Validación de RAM capacities (4, 8, 16, 24, 32, 40, 48, 56, 64 GB)
- ✅ Validación de grades (A, B, C, M)
- ✅ Validación de display resolutions
- ✅ Validación de storage types (NVMe, SSD SATA, HDD)
- ✅ Validación de storage capacities
- ✅ Validación de connectivity (WiFi, Ethernet, Bluetooth)
- ✅ Validación de product kinds (notebook, desktop_pc, aio, monitor)
- ✅ Normalización de valores legacy (CPU, RAM)
- ✅ Sanitización de booleanos
- ✅ Parseo de JSON strings

**Total de tests:** 30+

#### ProductImportServiceTest
Valida la lógica de importación de productos:
- ✅ Mapeo de columnas básicas (SKU, Name, Brand, etc.)
- ✅ Mapeo de columnas con notación de punto (cpu.brand)
- ✅ Mapeo de columnas con guión bajo (cpu_brand)
- ✅ Parseo de columnas legacy (CPU, RAM)
- ✅ Extracción de datos con attributes_json
- ✅ Normalización de valores numéricos
- ✅ Normalización de valores booleanos
- ✅ Parseo de capacidades de RAM desde strings
- ✅ Establecimiento de valores anidados
- ✅ Validación de datos básicos
- ✅ Identificación de filas vacías
- ✅ Identificación de hojas de validación
- ✅ Creación y búsqueda de marcas
- ✅ Creación y búsqueda de categorías
- ✅ Creación de productos con datos completos
- ✅ Actualización de productos existentes
- ✅ Manejo de múltiples categorías

**Total de tests:** 25+

### Tests de Funcionalidad (Feature)

#### ProductImportControllerTest
Valida los endpoints de la API:
- ✅ Autenticación requerida
- ✅ Validación de campos obligatorios
- ✅ Validación de tipo de archivo
- ✅ Validación de tamaño de archivo
- ✅ Validación de existencia de sucursal
- ✅ Validación de atributos completos
- ✅ Rechazo de atributos inválidos
- ✅ Rechazo de valores fuera de rango
- ✅ Aceptación de todos los grades válidos
- ✅ Aceptación de todos los product kinds válidos

**Total de tests:** 20+

## Ejecutar los Tests

### Ejecutar todos los tests
```bash
docker compose exec app php artisan test
```

### Ejecutar solo tests unitarios
```bash
docker compose exec app php artisan test --testsuite=Unit
```

### Ejecutar solo tests de funcionalidad
```bash
docker compose exec app php artisan test --testsuite=Feature
```

### Ejecutar tests específicos

#### Solo validador de atributos
```bash
docker compose exec app php artisan test tests/Unit/Services/ProductAttributesValidatorTest.php
```

#### Solo servicio de importación
```bash
docker compose exec app php artisan test tests/Unit/Services/ProductImportServiceTest.php
```

#### Solo controlador
```bash
docker compose exec app php artisan test tests/Feature/Http/Controllers/ProductImportControllerTest.php
```

### Ejecutar un test individual
```bash
docker compose exec app php artisan test --filter it_validates_complete_notebook_attributes
```

### Ver cobertura de código
```bash
docker compose exec app php artisan test --coverage
```

### Ejecutar tests con salida detallada
```bash
docker compose exec app php artisan test --verbose
```

## Estructura de un Test

```php
/** @test */
public function it_validates_complete_notebook_attributes()
{
    // Arrange - Preparar datos
    $attributes = [
        'cpu' => ['brand' => 'Intel', 'model' => 'I7 14700'],
        'ram' => ['capacity_gb' => 16, 'type' => 'DDR4'],
        'grade' => 'B',
        'product_kind' => 'notebook',
    ];

    // Act - Ejecutar acción
    $validated = $this->validator->validateNotebookAttributes($attributes);

    // Assert - Verificar resultado
    $this->assertIsArray($validated);
    $this->assertEquals('Intel', $validated['cpu']['brand']);
    $this->assertEquals(16, $validated['ram']['capacity_gb']);
}
```

## Valores Permitidos (según Frontend)

### CPU
- **Brands:** Intel, AMD
- **Families:** 
  - Intel: Celeron, Pentium, Core, Xeon
  - AMD: Athlon, Ryzen, Ryzen PRO, EPYC

### RAM
- **Types:** DDR3, DDR3L, DDR4, DDR5
- **Capacities:** 4, 8, 16, 24, 32, 40, 48, 56, 64 GB
- **Channels:** single, dual, quad
- **Modules:** 1, 2, 3, 4

### Storage
- **Types:** NVMe, SSD SATA, HDD, SSD_SATA
- **Capacities:** 64, 128, 240, 256, 500, 512, 1000, 2000, 4000 GB
- **Configs:** single, hybrid

### Display
- **Panels:** TN, VA, IPS, OLED
- **Resolutions:** 1366x768, 1600x900, 1920x1080, 2560x1440, 3840x2160
- **Sizes (Notebook):** 12.5", 13.3", 14.0", 15.6", 17.3"
- **Refresh Rates:** 60, 75, 120, 144 Hz
- **Aspect Ratios:** 16:9, 16:10, 21:9

### Connectivity
- **WiFi:** 802.11n, 802.11ac, 802.11ax, USB/PCIe opcional, N/A
- **Ethernet:** 100 Mbps, 1GbE, 2.5GbE
- **Bluetooth:** 4.0, 4.2, 5.0, 5.1, N/A

### Otros
- **Grades:** A, B, C, M
- **Product Kinds:** notebook, desktop_pc, aio, monitor
- **OS Names:** Windows, Ubuntu, Linux, No OS
- **License Types:** digital, OEM, sticker, none, sin licencia
- **Charger Types:** original, genérico, no aplica
- **Keyboard Layouts:** ES-LA, EN-US, FR, DE
- **Camera Resolutions:** 0.9, 1.0, 1.3, 2.0 MP

## Troubleshooting

### Error: "Class not found"
```bash
docker compose exec app composer dump-autoload
```

### Error: "Database connection"
Verificar que la base de datos de tests esté configurada en `.env.testing` o `phpunit.xml`

### Tests lentos
```bash
# Ejecutar tests en paralelo (requiere paratest)
docker compose exec app php artisan test --parallel
```

### Limpiar base de datos de tests
```bash
docker compose exec app php artisan migrate:fresh --env=testing
```

## Integración Continua (CI)

Estos tests están diseñados para ejecutarse en pipelines de CI/CD. Ejemplo para GitHub Actions:

```yaml
- name: Run Tests
  run: |
    docker compose exec -T app php artisan test --coverage --min=80
```

## Contribuir

Al agregar nuevas funcionalidades:

1. ✅ Escribir tests PRIMERO (TDD)
2. ✅ Asegurar cobertura > 80%
3. ✅ Seguir nomenclatura: `it_does_something_specific`
4. ✅ Un assert por concepto
5. ✅ Tests independientes (sin dependencias entre ellos)
6. ✅ Usar factories para datos de prueba

## Referencias

- [PHPUnit Documentation](https://phpunit.de/documentation.html)
- [Laravel Testing](https://laravel.com/docs/testing)
- [Product Import Guide](../docs/product-import-guide.md)
