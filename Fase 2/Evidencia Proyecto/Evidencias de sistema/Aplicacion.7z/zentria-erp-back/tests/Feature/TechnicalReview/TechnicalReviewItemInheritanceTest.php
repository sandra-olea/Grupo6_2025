<?php

namespace Tests\Feature\TechnicalReview;

use App\Enums\EquipmentType;
use App\Models\Branch;
use App\Models\Brand;
use App\Models\Company;
use App\Models\CustomerSupplier;
use App\Models\Product;
use App\Models\TechnicalReviewBatch;
use App\Models\TechnicalReviewItem;
use App\Models\Subsidiary;
use App\Models\User;
use App\Models\Warehouse;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Seeders\TestBaselineSeeder;
use Tests\TestCase;
use Tymon\JWTAuth\Facades\JWTAuth;

class TechnicalReviewItemInheritanceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->artisan('migrate');
        $this->seed(TestBaselineSeeder::class);
    }

    public function test_items_inherit_batch_context_when_created(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $structure = $this->createBranchStructure();
        $batch = $this->makeBatch($structure['branch'], $structure['warehouse'], $structure['customer'], $user);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson("/api/branches/{$structure['branch']->id}/technical-reviews/items", [
                'batch_id' => $batch->id,
                'serial_number' => 'SN-001',
                'equipment_type' => EquipmentType::DESKTOP->value,
            ]);

        $response->assertStatus(201)
            ->assertJsonPath('success', true)
            ->assertJsonPath('data.batch.id', $batch->id)
            ->assertJsonPath('data.branch.id', $structure['branch']->id)
            ->assertJsonPath('data.customer_supplier.id', $structure['customer']->id);

        $item = TechnicalReviewItem::firstOrFail();
        $this->assertSame($structure['branch']->id, $item->branch_id);
        $this->assertSame($structure['warehouse']->id, $item->warehouse_id);
        $this->assertSame($structure['customer']->id, $item->customer_supplier_id);
    }

    public function test_can_create_item_without_equipment_type(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $structure = $this->createBranchStructure();
        $batch = $this->makeBatch($structure['branch'], $structure['warehouse'], $structure['customer'], $user);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson("/api/branches/{$structure['branch']->id}/technical-reviews/items", [
                'batch_id' => $batch->id,
                'serial_number' => 'SN-NULL-TYPE',
            ]);

        $response->assertStatus(201)
            ->assertJsonPath('success', true)
            ->assertJsonPath('data.equipment_type.value', null);

        $item = TechnicalReviewItem::where('serial_number', 'SN-NULL-TYPE')->firstOrFail();
        $this->assertNull($item->equipment_type);
    }

    public function test_cannot_associate_product_without_serial_tracking(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $structure = $this->createBranchStructure();
        $batch = $this->makeBatch($structure['branch'], $structure['warehouse'], $structure['customer'], $user);
        $product = $this->makeProduct($structure['branch'], serialTracking: false, productKind: 'notebook');

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson("/api/branches/{$structure['branch']->id}/technical-reviews/items", [
                'batch_id' => $batch->id,
                'serial_number' => 'SN-NO-SERIAL',
                'product_id' => $product->id,
            ]);

        $response->assertStatus(422)
            ->assertJsonPath('errors.product_id.0', 'El producto seleccionado no permite seguimiento por serie y no puede asociarse a una revisión técnica.');
    }

    public function test_assigns_equipment_type_from_product_kind(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $structure = $this->createBranchStructure();
        $batch = $this->makeBatch($structure['branch'], $structure['warehouse'], $structure['customer'], $user);
        $product = $this->makeProduct($structure['branch'], serialTracking: true, productKind: 'notebook');

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson("/api/branches/{$structure['branch']->id}/technical-reviews/items", [
                'batch_id' => $batch->id,
                'serial_number' => 'SN-AUTO-TYPE',
                'product_id' => $product->id,
            ]);

        $response->assertStatus(201)
            ->assertJsonPath('data.equipment_type.value', EquipmentType::NOTEBOOK->value);

        $item = TechnicalReviewItem::where('serial_number', 'SN-AUTO-TYPE')->firstOrFail();
        $this->assertTrue($item->equipment_type instanceof EquipmentType);
        $this->assertEquals(EquipmentType::NOTEBOOK, $item->equipment_type);
    }

    public function test_can_list_items_filtered_by_batch(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $structure = $this->createBranchStructure();
        $firstBatch = $this->makeBatch($structure['branch'], $structure['warehouse'], $structure['customer'], $user);
        $secondCustomer = $this->makeCustomer($structure['subsidiary'], 'Second Customer');
        $secondBatch = $this->makeBatch($structure['branch'], $structure['warehouse'], $secondCustomer, $user);

        $this->createItemForBatch($token, $structure['branch'], $firstBatch, 'SN-100', EquipmentType::DESKTOP);
        $this->createItemForBatch($token, $structure['branch'], $firstBatch, 'SN-101', EquipmentType::DESKTOP);
        $this->createItemForBatch($token, $structure['branch'], $secondBatch, 'SN-200', EquipmentType::DESKTOP);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->getJson("/api/branches/{$structure['branch']->id}/technical-reviews/batches/{$firstBatch->id}/items");

        $response->assertStatus(200)
            ->assertJsonPath('success', true);

        $this->assertCount(2, $response->json('data'));
        $this->assertEquals($firstBatch->id, $response->json('data.0.batch.id'));
        $this->assertEquals($structure['customer']->id, $response->json('data.0.customer_supplier.id'));

        $ids = collect($response->json('data'))->pluck('serial_number');
        $this->assertTrue($ids->contains('SN-100'));
        $this->assertTrue($ids->contains('SN-101'));
        $this->assertFalse($ids->contains('SN-200'));
    }

    public function test_batch_metrics_update_when_items_are_associated(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $structure = $this->createBranchStructure();
        $batch = $this->makeBatch($structure['branch'], $structure['warehouse'], $structure['customer'], $user, 2);

        $baseResponse = $this->withHeader('Authorization', 'Bearer '.$token)
            ->getJson("/api/branches/{$structure['branch']->id}/technical-reviews/batches/{$batch->id}");

        $baseResponse->assertStatus(200)
            ->assertJsonPath('data.expected_quantity', 2)
            ->assertJsonPath('data.received_quantity', 0)
            ->assertJsonPath('data.pending_count', 2)
            ->assertJsonPath('data.progress', 0);

        $this->createItemForBatch($token, $structure['branch'], $batch, 'SN-A', EquipmentType::DESKTOP);

        $afterFirst = $this->withHeader('Authorization', 'Bearer '.$token)
            ->getJson("/api/branches/{$structure['branch']->id}/technical-reviews/batches/{$batch->id}");

        $afterFirst->assertStatus(200)
            ->assertJsonPath('data.received_quantity', 1)
            ->assertJsonPath('data.pending_count', 1);
        $this->assertEqualsWithDelta(50, $afterFirst->json('data.progress'), 0.01);

        $this->createItemForBatch($token, $structure['branch'], $batch, 'SN-B', EquipmentType::DESKTOP);

        $afterSecond = $this->withHeader('Authorization', 'Bearer '.$token)
            ->getJson("/api/branches/{$structure['branch']->id}/technical-reviews/batches/{$batch->id}");

        $afterSecond->assertStatus(200)
            ->assertJsonPath('data.received_quantity', 2)
            ->assertJsonPath('data.pending_count', 0);
        $this->assertEqualsWithDelta(100, $afterSecond->json('data.progress'), 0.01);
    }

    public function test_serial_number_must_be_unique_across_batches(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $structure = $this->createBranchStructure();
        $firstBatch = $this->makeBatch($structure['branch'], $structure['warehouse'], $structure['customer'], $user);
        $secondCustomer = $this->makeCustomer($structure['subsidiary'], 'Unique Customer');
        $secondBatch = $this->makeBatch($structure['branch'], $structure['warehouse'], $secondCustomer, $user);

        $this->createItemForBatch($token, $structure['branch'], $firstBatch, 'SN-GLOBAL', EquipmentType::DESKTOP);

        $responseSameBatch = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson("/api/branches/{$structure['branch']->id}/technical-reviews/items", [
                'batch_id' => $firstBatch->id,
                'serial_number' => 'SN-GLOBAL',
            ]);

        $responseSameBatch->assertStatus(422)
            ->assertJsonPath('errors.serial_number.0', 'Este número de serie ya está registrado en otra revisión técnica');

        $responseDifferentBatch = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson("/api/branches/{$structure['branch']->id}/technical-reviews/items", [
                'batch_id' => $secondBatch->id,
                'serial_number' => 'SN-GLOBAL',
            ]);

        $responseDifferentBatch->assertStatus(422)
            ->assertJsonPath('errors.serial_number.0', 'Este número de serie ya está registrado en otra revisión técnica');
    }

    private function makeUserWithToken(): array
    {
        $user = User::create([
            'first_name' => 'Test',
            'last_name' => 'User',
            'email' => 'tech-reviewer-'.uniqid().'@example.test',
            'rut' => '1'.random_int(1000000, 9999999).'-K',
            'password' => bcrypt('password'),
            'is_active' => true,
            'email_verified_at' => now(),
        ]);

        $user->assignRole('super-admin');

        return [$user, JWTAuth::fromUser($user)];
    }

    private function createBranchStructure(): array
    {
        $company = Company::create([
            'company_name' => 'Test Company',
            'company_rut' => '76'.random_int(1000000, 9999999),
            'contact_email' => 'company-'.uniqid().'@example.test',
            'company_phone' => '+56912345678',
            'company_address' => 'Calle Falsa 123',
            'is_active' => true,
        ]);

        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Subsidiary '.$company->id,
            'subsidiary_rut' => '96'.random_int(1000000, 9999999),
            'subsidiary_email' => 'subsidiary-'.uniqid().'@example.test',
            'subsidiary_phone' => '+56987654321',
            'subsidiary_status' => true,
        ]);

        $branch = Branch::create([
            'subsidiary_id' => $subsidiary->id,
            'branch_name' => 'Main Branch',
            'branch_address' => 'Av. Principal 456',
            'branch_phone' => '+5622345678',
            'branch_email' => 'branch-'.uniqid().'@example.test',
            'branch_status' => true,
        ]);

        $warehouse = Warehouse::create([
            'branch_id' => $branch->id,
            'name' => 'Main Warehouse',
            'code' => 'WH-'.uniqid(),
            'warehouse_type' => 'technical-review',
            'is_active' => true,
        ]);

        $customer = $this->makeCustomer($subsidiary, 'Primary Customer');

        return compact('company', 'subsidiary', 'branch', 'warehouse', 'customer');
    }

    private function makeCustomer(Subsidiary $subsidiary, string $name): CustomerSupplier
    {
        return CustomerSupplier::create([
            'subsidiary_id' => $subsidiary->id,
            'name' => $name,
        ]);
    }

    private function makeBatch(Branch $branch, Warehouse $warehouse, CustomerSupplier $customer, User $creator, int $expectedQuantity = 10): TechnicalReviewBatch
    {
        return TechnicalReviewBatch::create([
            'code' => 'BATCH-'.uniqid(),
            'branch_id' => $branch->id,
            'warehouse_id' => $warehouse->id,
            'customer_supplier_id' => $customer->id,
            'entry_date' => now()->format('Y-m-d'),
            'expected_quantity' => $expectedQuantity,
            'completed_quantity' => 0,
            'status' => 'draft',
            'created_by' => $creator->id,
        ]);
    }

    private function createItemForBatch(string $token, Branch $branch, TechnicalReviewBatch $batch, string $serial, ?EquipmentType $equipmentType = null): void
    {
        $payload = [
            'batch_id' => $batch->id,
            'serial_number' => $serial,
        ];

        if ($equipmentType instanceof EquipmentType) {
            $payload['equipment_type'] = $equipmentType->value;
        }

        $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson("/api/branches/{$branch->id}/technical-reviews/items", $payload)
            ->assertStatus(201);
    }

    private function makeProduct(Branch $branch, bool $serialTracking, string $productKind): Product
    {
        $brand = Brand::create([
            'branch_id' => $branch->id,
            'name' => 'Brand '.uniqid(),
        ]);

        return Product::create([
            'branch_id' => $branch->id,
            'sku' => 'SKU-'.uniqid(),
            'name' => 'Product '.uniqid(),
            'brand_id' => $brand->id,
            'serial_tracking' => $serialTracking,
            'attributes_json' => ['product_kind' => $productKind],
            'product_type' => 'device',
            'warranty_months' => 0,
            'cost' => 0,
            'price' => 0,
            'stock' => 0,
        ]);
    }
}
