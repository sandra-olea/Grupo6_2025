<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\User;
use App\Models\Branch;
use App\Models\Warehouse;
use Tymon\JWTAuth\Facades\JWTAuth;

class WarehousesTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->artisan('migrate');
        // Seeders necesarios para el contexto
        $this->seed(\Database\Seeders\RegionSeeder::class);
        $this->seed(\Database\Seeders\ProvinceSeeder::class);
        $this->seed(\Database\Seeders\CommuneSeeder::class);
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);
        $this->seed(\Database\Seeders\EmpresaSeeder::class);
    }

    protected function makeUser(array $overrides = []): User
    {
        $defaults = [
            'first_name' => 'Test',
            'last_name'  => 'User',
            'email'      => 'user'.uniqid().'@example.com',
            'password'   => 'password',
            'rut'        => '1'.random_int(1000000, 9999999).'-K',
        ];
        $payload = array_merge($defaults, $overrides);
        if (isset($payload['password']) && !str_starts_with($payload['password'], '$2y$')) {
            $payload['password'] = \Illuminate\Support\Facades\Hash::make($payload['password']);
        }
        return User::create($payload);
    }

    protected function tokenFor(User $user): string
    {
        return JWTAuth::fromUser($user);
    }

    public function test_guest_cannot_access(): void
    {
        $branch = Branch::first();
        $resp = $this->getJson('/api/branches/'.($branch?->id ?? 1).'/warehouses');
        $resp->assertStatus(401);
    }

    public function test_user_without_permission_gets_forbidden(): void
    {
        $user = $this->makeUser();
        $token = $this->tokenFor($user);
        
        $branch = Branch::first();
        if (!$branch) { $this->markTestSkipped('No branch available'); }
        
        $resp = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson('/api/branches/'.$branch->id.'/warehouses', [
                'name' => 'Bodega X', 
                'code' => 'X1', 
                'warehouse_type' => 'secondary'
            ]);
        
        $resp->assertStatus(403);
    }
}

