<?php

namespace Tests\Feature\Notifications;

use App\Models\Notifications\NotificationEvent;
use App\Models\Notifications\NotificationType;
use App\Models\Notifications\UserNotification;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tymon\JWTAuth\Facades\JWTAuth;

class DeliverNotificationsTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->artisan('migrate');
        $this->seed(\Tests\Seeders\TestBaselineSeeder::class);
    }

    public function test_user_can_mark_single_notification_as_delivered(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $notification = $this->makeNotificationForUser($user);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson('/api/me/notifications/delivered', [
                'notification_id' => $notification->id,
            ]);

        $response->assertStatus(200)
            ->assertJson(['ok' => true, 'updated' => 1]);

        $this->assertTrue($notification->fresh()->delivered_to_user);
    }

    public function test_user_can_mark_multiple_notifications_as_delivered(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $first = $this->makeNotificationForUser($user);
        $second = $this->makeNotificationForUser($user);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson('/api/me/notifications/delivered', [
                'notification_ids' => [$first->id, $second->id],
            ]);

        $response->assertStatus(200)
            ->assertJson(['ok' => true, 'updated' => 2]);

        $this->assertTrue($first->fresh()->delivered_to_user);
        $this->assertTrue($second->fresh()->delivered_to_user);
    }

    public function test_cannot_mark_notification_from_other_user(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        [$otherUser] = $this->makeUserWithToken('other@example.test');
        $otherNotification = $this->makeNotificationForUser($otherUser);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson('/api/me/notifications/delivered', [
                'notification_id' => $otherNotification->id,
            ]);

        $response->assertStatus(403);
        $this->assertFalse($otherNotification->fresh()->delivered_to_user);
    }

    public function test_user_can_mark_all_notifications_as_delivered(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $pending = $this->makeNotificationForUser($user);
        $alreadyDelivered = $this->makeNotificationForUser($user, ['delivered_to_user' => true]);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->postJson('/api/me/notifications/delivered-all');

        $response->assertStatus(200)
            ->assertJson(['ok' => true, 'updated' => 1]);

        $this->assertTrue($pending->fresh()->delivered_to_user);
        $this->assertTrue($alreadyDelivered->fresh()->delivered_to_user);
    }

    public function test_delivered_flag_is_present_in_index_response(): void
    {
        [$user, $token] = $this->makeUserWithToken();
        $this->makeNotificationForUser($user, ['delivered_to_user' => true]);

        $response = $this->withHeader('Authorization', 'Bearer '.$token)
            ->getJson('/api/me/notifications');

        $response->assertStatus(200);
        $this->assertTrue($response->json('data.0.delivered_to_user'));
    }

    protected function makeUserWithToken(?string $email = null): array
    {
        $user = User::create([
            'first_name' => 'Test',
            'last_name' => 'User',
            'email' => $email ?? ('user'.uniqid().'@example.test'),
            'rut' => '1'.random_int(1000000, 9999999).'-K',
            'password' => bcrypt('password'),
            'is_active' => true,
            'email_verified_at' => now(),
        ]);
        $user->assignRole('super-admin');

        return [$user, JWTAuth::fromUser($user)];
    }

    protected function makeNotificationForUser(User $user, array $overrides = []): UserNotification
    {
        $type = NotificationType::firstOrCreate([
            'key' => 'test.notification',
        ], [
            'module' => 'system',
            'description' => 'Test notification',
            'default_priority' => 'P3',
            'default_channels' => ['inapp'],
            'critical' => false,
            'enabled_global' => true,
            'bucket' => 'Important',
        ]);

        $event = NotificationEvent::create([
            'type_id' => $type->id,
            'entity_type' => 'test',
            'entity_id' => 1,
            'company_id' => null,
            'subsidiary_id' => null,
            'branch_id' => null,
            'priority' => 'P3',
            'payload' => ['foo' => 'bar'],
            'dedup_key' => 'test-'.uniqid(),
            'occurred_at' => now(),
        ]);

        return UserNotification::create(array_merge([
            'user_id' => $user->id,
            'event_id' => $event->id,
            'status' => 'unread',
            'delivered_channels' => ['inapp'],
            'delivered_to_user' => $overrides['delivered_to_user'] ?? false,
            'aggregate_count' => 1,
            'last_occurred_at' => now(),
        ], $overrides));
    }
}
