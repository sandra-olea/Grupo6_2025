<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Company;
use App\Models\ScopeRole;
use App\Models\Subsidiary;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;
use Spatie\Permission\Models\Role;

class ManagerAutoAssignmentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->artisan('migrate');
        
        // Crear roles necesarios
        Role::findOrCreate('subsidiary-admin', 'api');
        Role::findOrCreate('subsidiary-member', 'api');
        Role::findOrCreate('branch-admin', 'api');
    }

    protected function createUser(array $overrides = []): User
    {
        $defaults = [
            'first_name' => 'Test',
            'last_name' => 'User',
            'email' => 'user'.uniqid().'@test.com',
            'password' => bcrypt('password'),
            'rut' => '1'.random_int(1000000,9999999).'-K'
        ];
        return User::create(array_merge($defaults, $overrides));
    }

    protected function createCompany(): Company
    {
        return Company::create([
            'company_name' => 'Test Company',
            'company_rut' => '76'.random_int(1000000,9999999).'-K',
            'contact_email' => 'company'.uniqid().'@test.com',
        ]);
    }

    public function test_assigning_manager_to_new_subsidiary_grants_admin_role(): void
    {
        // Arrange: Crear usuario y empresa
        $user = $this->createUser();
        $company = $this->createCompany();

        // Act: Crear subsidiary con manager
        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_manager_id' => $user->id,
            'subsidiary_status' => true,
        ]);

        // Assert: Verificar que se asignó el rol subsidiary-admin
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        // Verificar que tiene el rol subsidiary-admin específicamente
        $adminRole = Role::where('name', 'subsidiary-admin')->first();
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);
    }

    public function test_assigning_manager_to_new_subsidiary_grants_member_access(): void
    {
        // Arrange
        $user = $this->createUser();
        $company = $this->createCompany();

        // Act: Crear subsidiary con manager
        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_manager_id' => $user->id,
            'subsidiary_status' => true,
        ]);

        // Assert: Verificar que se asignó el rol subsidiary-member para acceso/visibilidad
        $memberRole = Role::where('name', 'subsidiary-member')->first();
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $memberRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        // Verificar que la subsidiary es visible para el usuario
        $visibleSubsidiaries = Subsidiary::visibleTo($user)->pluck('id')->toArray();
        $this->assertContains($subsidiary->id, $visibleSubsidiaries);
    }

    public function test_updating_subsidiary_manager_removes_old_manager_roles(): void
    {
        // Arrange: Crear usuarios y subsidiary
        $oldManager = $this->createUser(['email' => 'old'.uniqid().'@test.com']);
        $newManager = $this->createUser(['email' => 'new'.uniqid().'@test.com']);
        $company = $this->createCompany();

        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_manager_id' => $oldManager->id,
            'subsidiary_status' => true,
        ]);

        // Verificar que el old manager tiene los roles
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $oldManager->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        // Act: Cambiar el manager
        $subsidiary->update(['subsidiary_manager_id' => $newManager->id]);

        // Assert: El old manager ya NO debe tener los roles
        $adminRole = Role::where('name', 'subsidiary-admin')->first();
        $memberRole = Role::where('name', 'subsidiary-member')->first();

        $this->assertDatabaseMissing('scope_roles', [
            'user_id' => $oldManager->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        $this->assertDatabaseMissing('scope_roles', [
            'user_id' => $oldManager->id,
            'role_id' => $memberRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        // El nuevo manager SÍ debe tener los roles
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $newManager->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $newManager->id,
            'role_id' => $memberRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);
    }

    public function test_assigning_manager_to_new_branch_grants_admin_role(): void
    {
        // Arrange
        $user = $this->createUser();
        $company = $this->createCompany();
        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_status' => true,
        ]);

        // Act: Crear branch con manager
        $branch = Branch::create([
            'subsidiary_id' => $subsidiary->id,
            'branch_name' => 'Test Branch',
            'branch_address' => 'Test Address',
            'branch_phone' => '123456789',
            'branch_email' => 'branch'.uniqid().'@test.com',
            'branch_status' => true,
            'manager_id' => $user->id,
        ]);

        // Assert: Verificar que se asignó el rol branch-admin
        $adminRole = Role::where('name', 'branch-admin')->first();
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'branch',
            'scope_id' => $branch->id,
        ]);
    }

    public function test_assigning_manager_to_new_branch_grants_branch_user_access(): void
    {
        // Arrange
        $user = $this->createUser();
        $company = $this->createCompany();
        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_status' => true,
        ]);

        // Act: Crear branch con manager
        $branch = Branch::create([
            'subsidiary_id' => $subsidiary->id,
            'branch_name' => 'Test Branch',
            'branch_address' => 'Test Address',
            'branch_phone' => '123456789',
            'branch_email' => 'branch'.uniqid().'@test.com',
            'branch_status' => true,
            'manager_id' => $user->id,
        ]);

        // Assert: Verificar que se creó el registro en branch_user
        $this->assertDatabaseHas('branch_user', [
            'user_id' => $user->id,
            'branch_id' => $branch->id,
        ]);

        // Verificar que tiene position = 'Manager'
        $pivot = DB::table('branch_user')
            ->where('user_id', $user->id)
            ->where('branch_id', $branch->id)
            ->first();

        $this->assertEquals('Manager', $pivot->position);

        // Verificar que la branch es visible para el usuario
        $visibleBranches = Branch::visibleTo($user)->pluck('id')->toArray();
        $this->assertContains($branch->id, $visibleBranches);
    }

    public function test_updating_branch_manager_removes_old_manager_access(): void
    {
        // Arrange
        $oldManager = $this->createUser(['email' => 'old'.uniqid().'@test.com']);
        $newManager = $this->createUser(['email' => 'new'.uniqid().'@test.com']);
        $company = $this->createCompany();
        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_status' => true,
        ]);

        $branch = Branch::create([
            'subsidiary_id' => $subsidiary->id,
            'branch_name' => 'Test Branch',
            'branch_address' => 'Test Address',
            'branch_phone' => '123456789',
            'branch_email' => 'branch'.uniqid().'@test.com',
            'branch_status' => true,
            'manager_id' => $oldManager->id,
        ]);

        $adminRole = Role::where('name', 'branch-admin')->first();

        // Verificar que el old manager tiene acceso y roles ANTES del cambio
        $this->assertDatabaseHas('branch_user', [
            'user_id' => $oldManager->id,
            'branch_id' => $branch->id,
        ]);

        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $oldManager->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'branch',
            'scope_id' => $branch->id,
        ]);

        // Act: Cambiar el manager
        $branch->update(['manager_id' => $newManager->id]);

        // Assert 1: El OLD manager ya NO debe tener el rol branch-admin
        $this->assertDatabaseMissing('scope_roles', [
            'user_id' => $oldManager->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'branch',
            'scope_id' => $branch->id,
        ]);

        // Assert 2: El OLD manager ya NO debe tener acceso via branch_user
        // (porque no es su primary_branch y is_primary = false)
        $this->assertDatabaseMissing('branch_user', [
            'user_id' => $oldManager->id,
            'branch_id' => $branch->id,
            'is_primary' => false,
        ]);

        // Assert 3: El NEW manager SÍ debe tener acceso via branch_user
        $this->assertDatabaseHas('branch_user', [
            'user_id' => $newManager->id,
            'branch_id' => $branch->id,
        ]);

        // Assert 4: El NEW manager SÍ debe tener el rol branch-admin
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $newManager->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'branch',
            'scope_id' => $branch->id,
        ]);

        // Assert 5: Verificar visibilidad - oldManager NO ve, newManager SÍ ve
        $oldManagerVisibleBranches = Branch::visibleTo($oldManager)->pluck('id')->toArray();
        $this->assertNotContains($branch->id, $oldManagerVisibleBranches);

        $newManagerVisibleBranches = Branch::visibleTo($newManager)->pluck('id')->toArray();
        $this->assertContains($branch->id, $newManagerVisibleBranches);
    }

    public function test_user_can_be_manager_of_multiple_subsidiaries(): void
    {
        // Arrange
        $user = $this->createUser();
        $company = $this->createCompany();

        // Act: Crear múltiples subsidiaries con el mismo manager
        $sub1 = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Subsidiary 1',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub1'.uniqid().'@test.com',
            'subsidiary_manager_id' => $user->id,
            'subsidiary_status' => true,
        ]);

        $sub2 = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Subsidiary 2',
            'subsidiary_rut' => '78'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub2'.uniqid().'@test.com',
            'subsidiary_manager_id' => $user->id,
            'subsidiary_status' => true,
        ]);

        // Assert: Verificar que tiene roles en ambas subsidiaries
        $adminRole = Role::where('name', 'subsidiary-admin')->first();
        $memberRole = Role::where('name', 'subsidiary-member')->first();

        // Subsidiary 1
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $sub1->id,
        ]);

        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $memberRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $sub1->id,
        ]);

        // Subsidiary 2
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $sub2->id,
        ]);

        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $memberRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $sub2->id,
        ]);

        // Verificar que puede ver ambas subsidiaries
        $visibleSubsidiaries = Subsidiary::visibleTo($user)->pluck('id')->toArray();
        $this->assertContains($sub1->id, $visibleSubsidiaries);
        $this->assertContains($sub2->id, $visibleSubsidiaries);
    }

    public function test_user_can_be_manager_of_multiple_branches(): void
    {
        // Arrange
        $user = $this->createUser();
        $company = $this->createCompany();
        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_status' => true,
        ]);

        // Act: Crear múltiples branches con el mismo manager
        $branch1 = Branch::create([
            'subsidiary_id' => $subsidiary->id,
            'branch_name' => 'Branch 1',
            'branch_address' => 'Address 1',
            'branch_phone' => '111111111',
            'branch_email' => 'branch1'.uniqid().'@test.com',
            'branch_status' => true,
            'manager_id' => $user->id,
        ]);

        $branch2 = Branch::create([
            'subsidiary_id' => $subsidiary->id,
            'branch_name' => 'Branch 2',
            'branch_address' => 'Address 2',
            'branch_phone' => '222222222',
            'branch_email' => 'branch2'.uniqid().'@test.com',
            'branch_status' => true,
            'manager_id' => $user->id,
        ]);

        // Assert: Verificar que tiene acceso a ambas branches
        $this->assertDatabaseHas('branch_user', [
            'user_id' => $user->id,
            'branch_id' => $branch1->id,
        ]);

        $this->assertDatabaseHas('branch_user', [
            'user_id' => $user->id,
            'branch_id' => $branch2->id,
        ]);

        // Verificar que tiene rol de admin en ambas
        $adminRole = Role::where('name', 'branch-admin')->first();

        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'branch',
            'scope_id' => $branch1->id,
        ]);

        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'branch',
            'scope_id' => $branch2->id,
        ]);

        // Verificar que puede ver ambas branches
        $visibleBranches = Branch::visibleTo($user)->pluck('id')->toArray();
        $this->assertContains($branch1->id, $visibleBranches);
        $this->assertContains($branch2->id, $visibleBranches);
    }

    public function test_removing_manager_removes_roles_and_access(): void
    {
        // Arrange
        $user = $this->createUser();
        $company = $this->createCompany();
        $subsidiary = Subsidiary::create([
            'company_id' => $company->id,
            'subsidiary_name' => 'Test Subsidiary',
            'subsidiary_rut' => '77'.random_int(1000000,9999999).'-K',
            'subsidiary_email' => 'sub'.uniqid().'@test.com',
            'subsidiary_manager_id' => $user->id,
            'subsidiary_status' => true,
        ]);

        // Verificar que tiene los roles
        $this->assertDatabaseHas('scope_roles', [
            'user_id' => $user->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        // Act: Remover el manager
        $subsidiary->update(['subsidiary_manager_id' => null]);

        // Assert: Ya no debe tener los roles
        $adminRole = Role::where('name', 'subsidiary-admin')->first();
        $memberRole = Role::where('name', 'subsidiary-member')->first();

        $this->assertDatabaseMissing('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $adminRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);

        $this->assertDatabaseMissing('scope_roles', [
            'user_id' => $user->id,
            'role_id' => $memberRole->id,
            'scope_type' => 'subsidiary',
            'scope_id' => $subsidiary->id,
        ]);
    }
}
