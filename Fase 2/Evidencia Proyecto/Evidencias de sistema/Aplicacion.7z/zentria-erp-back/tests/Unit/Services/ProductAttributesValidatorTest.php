<?php

namespace Tests\Unit\Services;

use App\Services\ProductAttributesValidator;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class ProductAttributesValidatorTest extends TestCase
{
    protected ProductAttributesValidator $validator;

    protected function setUp(): void
    {
        parent::setUp();
        $this->validator = new ProductAttributesValidator();
    }

    /** @test */
    public function it_validates_complete_notebook_attributes()
    {
        $attributes = [
            'packaging' => [
                'charger_included' => true,
                'charger_type' => 'original',
            ],
            'os' => [
                'name' => 'Windows',
                'version' => '11 Home',
                'license_type' => 'digital',
            ],
            'cpu' => [
                'brand' => 'Intel',
                'model' => 'I7 14700',
                'family' => 'Core',
                'generation' => '13th Gen (Raptor Lake)',
            ],
            'gpu' => [
                'type' => 'integrated',
                'model' => 'Intel UHD Graphics',
            ],
            'ram' => [
                'type' => 'DDR4',
                'channel' => 'dual',
                'modules' => 2,
                'upgradable' => true,
                'capacity_gb' => 16,
                'max_supported_gb' => 32,
            ],
            'grade' => 'B',
            'category_grade' => 'A',
            'display' => [
                'panel' => 'IPS',
                'touch' => false,
                'resolution' => '1920x1080',
                'size_inches' => 15.6,
                'refresh_rate' => 60,
                'aspect_ratio' => '16:9',
            ],
            'storage' => [
                'config' => 'single',
                'primary' => [
                    'type' => 'NVMe',
                    'capacity_gb' => 512,
                ],
                'upgradable' => true,
            ],
            'connectivity' => [
                'wifi' => '802.11ax',
                'ethernet' => '1GbE',
                'bluetooth' => '5.0',
            ],
            'product_kind' => 'notebook',
            'keyboard' => [
                'layout' => 'ES-LA',
                'backlit' => true,
            ],
            'camera' => [
                'available' => true,
                'resolution_mp' => 1.0,
            ],
        ];

        $validated = $this->validator->validateNotebookAttributes($attributes);

        $this->assertIsArray($validated);
        $this->assertEquals('Intel', $validated['cpu']['brand']);
        $this->assertEquals(16, $validated['ram']['capacity_gb']);
    }

    /** @test */
    public function it_validates_minimal_notebook_attributes()
    {
        $attributes = [
            'product_kind' => 'notebook',
        ];

        $validated = $this->validator->validateNotebookAttributes($attributes);

        $this->assertIsArray($validated);
        $this->assertEquals('notebook', $validated['product_kind']);
    }

    /** @test */
    public function it_rejects_invalid_cpu_brand()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'cpu' => [
                'brand' => 'InvalidBrand', // Solo Intel o AMD permitidos
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_rejects_invalid_ram_type()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'ram' => [
                'type' => 'DDR2', // No está en los valores permitidos
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_rejects_invalid_ram_capacity()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'ram' => [
                'capacity_gb' => 12, // No está en los valores permitidos (4,8,16,24,32,40,48,56,64)
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_ram_capacities()
    {
        $validCapacities = [4, 8, 16, 24, 32, 40, 48, 56, 64];

        foreach ($validCapacities as $capacity) {
            $attributes = [
                'ram' => ['capacity_gb' => $capacity],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($capacity, $validated['ram']['capacity_gb']);
        }
    }

    /** @test */
    public function it_rejects_invalid_grade()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'grade' => 'F', // Solo A, B, C, M permitidos
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_grades()
    {
        $validGrades = ['A', 'B', 'C', 'M'];

        foreach ($validGrades as $grade) {
            $attributes = [
                'grade' => $grade,
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($grade, $validated['grade']);
        }
    }

    /** @test */
    public function it_rejects_invalid_display_resolution()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'display' => [
                'resolution' => '1280x720', // No está en los valores permitidos
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_display_resolutions()
    {
        $validResolutions = ['1366x768', '1600x900', '1920x1080', '2560x1440', '3840x2160'];

        foreach ($validResolutions as $resolution) {
            $attributes = [
                'display' => ['resolution' => $resolution],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($resolution, $validated['display']['resolution']);
        }
    }

    /** @test */
    public function it_rejects_invalid_display_size()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'display' => [
                'size_inches' => 18.5, // No está en los valores permitidos para notebook
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_display_sizes_for_notebook()
    {
        $validSizes = [12.5, 13.3, 14.0, 15.6, 17.3];

        foreach ($validSizes as $size) {
            $attributes = [
                'display' => ['size_inches' => $size],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($size, $validated['display']['size_inches']);
        }
    }

    /** @test */
    public function it_rejects_invalid_storage_type()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'storage' => [
                'primary' => [
                    'type' => 'eMMC', // No está en los valores permitidos
                ],
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_storage_types()
    {
        $validTypes = ['NVMe', 'SSD SATA', 'HDD', 'SSD_SATA'];

        foreach ($validTypes as $type) {
            $attributes = [
                'storage' => [
                    'primary' => ['type' => $type],
                ],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($type, $validated['storage']['primary']['type']);
        }
    }

    /** @test */
    public function it_rejects_invalid_storage_capacity()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'storage' => [
                'primary' => [
                    'capacity_gb' => 750, // No está en los valores permitidos
                ],
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_storage_capacities()
    {
        $validCapacities = [64, 128, 240, 256, 500, 512, 1000, 2000, 4000];

        foreach ($validCapacities as $capacity) {
            $attributes = [
                'storage' => [
                    'primary' => ['capacity_gb' => $capacity],
                ],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($capacity, $validated['storage']['primary']['capacity_gb']);
        }
    }

    /** @test */
    public function it_rejects_invalid_wifi_standard()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'connectivity' => [
                'wifi' => '802.11g', // No está en los valores permitidos
            ],
            'product_kind' => 'notebook',
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_wifi_standards()
    {
        $validStandards = ['802.11n', '802.11ac', '802.11ax', 'USB/PCIe opcional', 'N/A'];

        foreach ($validStandards as $standard) {
            $attributes = [
                'connectivity' => ['wifi' => $standard],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($standard, $validated['connectivity']['wifi']);
        }
    }

    /** @test */
    public function it_rejects_invalid_product_kind()
    {
        $this->expectException(ValidationException::class);

        $attributes = [
            'product_kind' => 'smartphone', // No está en los valores permitidos
        ];

        $this->validator->validateNotebookAttributes($attributes);
    }

    /** @test */
    public function it_accepts_valid_product_kinds()
    {
        $validKinds = ['notebook', 'desktop_pc', 'aio', 'monitor'];

        foreach ($validKinds as $kind) {
            $attributes = [
                'product_kind' => $kind,
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($kind, $validated['product_kind']);
        }
    }

    /** @test */
    public function it_sanitizes_string_booleans()
    {
        $attributes = [
            'ram' => [
                'upgradable' => 'true', // String que debe convertirse a boolean
            ],
            'display' => [
                'touch' => 'false',
            ],
            'product_kind' => 'notebook',
        ];

        $sanitized = $this->validator->sanitizeAttributes($attributes);

        $this->assertTrue($sanitized['ram']['upgradable']);
        $this->assertFalse($sanitized['display']['touch']);
    }

    /** @test */
    public function it_normalizes_legacy_cpu_format()
    {
        $attributes = [
            'CPU' => 'I7 14700',
        ];

        $normalized = $this->validator->normalizeAttributes($attributes);

        $this->assertArrayHasKey('cpu', $normalized);
        $this->assertEquals('I7 14700', $normalized['cpu']['model']);
    }

    /** @test */
    public function it_normalizes_legacy_ram_format()
    {
        $attributes = [
            'RAM' => '16 GB',
        ];

        $normalized = $this->validator->normalizeAttributes($attributes);

        $this->assertArrayHasKey('ram', $normalized);
        $this->assertEquals(16, $normalized['ram']['capacity_gb']);
    }

    /** @test */
    public function it_validates_and_processes_complete_flow()
    {
        $attributes = [
            'CPU' => 'I7 10710U', // Legacy format
            'RAM' => '16 GB', // Legacy format
            'ram' => [
                'upgradable' => 'true', // String boolean
            ],
            'grade' => 'B',
            'product_kind' => 'notebook',
        ];

        $result = $this->validator->validateAndProcess($attributes, 'notebook');

        // Verificar normalización
        $this->assertArrayHasKey('cpu', $result);
        $this->assertEquals('I7 10710U', $result['cpu']['model']);

        // Verificar sanitización
        $this->assertTrue($result['ram']['upgradable']);

        // Verificar valores validados
        $this->assertEquals('B', $result['grade']);
    }

    /** @test */
    public function it_parses_json_string_attributes()
    {
        $jsonString = json_encode([
            'cpu' => ['brand' => 'Intel', 'model' => 'I7 14700'],
            'ram' => ['capacity_gb' => 16],
            'product_kind' => 'notebook',
        ]);

        $validated = $this->validator->validateNotebookAttributes($jsonString);

        $this->assertEquals('Intel', $validated['cpu']['brand']);
        $this->assertEquals(16, $validated['ram']['capacity_gb']);
    }

    /** @test */
    public function it_rejects_invalid_json_string()
    {
        $this->expectException(ValidationException::class);

        $invalidJson = '{"cpu": {"brand": "Intel"'; // JSON inválido

        $this->validator->validateNotebookAttributes($invalidJson);
    }

    /** @test */
    public function it_accepts_valid_keyboard_layouts()
    {
        $validLayouts = ['ES-LA', 'EN-US', 'FR', 'DE'];

        foreach ($validLayouts as $layout) {
            $attributes = [
                'keyboard' => ['layout' => $layout],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($layout, $validated['keyboard']['layout']);
        }
    }

    /** @test */
    public function it_accepts_valid_camera_resolutions()
    {
        $validResolutions = [0.9, 1.0, 1.3, 2.0];

        foreach ($validResolutions as $resolution) {
            $attributes = [
                'camera' => ['resolution_mp' => $resolution],
                'product_kind' => 'notebook',
            ];

            $validated = $this->validator->validateNotebookAttributes($attributes);
            $this->assertEquals($resolution, $validated['camera']['resolution_mp']);
        }
    }

    /** @test */
    public function it_accepts_hybrid_storage_config()
    {
        $attributes = [
            'storage' => [
                'config' => 'hybrid',
                'primary' => [
                    'type' => 'NVMe',
                    'capacity_gb' => 256,
                ],
                'secondary' => [
                    'type' => 'HDD',
                    'capacity_gb' => 1000,
                ],
            ],
            'product_kind' => 'notebook',
        ];

        $validated = $this->validator->validateNotebookAttributes($attributes);

        $this->assertEquals('hybrid', $validated['storage']['config']);
        $this->assertEquals('NVMe', $validated['storage']['primary']['type']);
        $this->assertEquals('HDD', $validated['storage']['secondary']['type']);
    }
}
