# Comandos Útiles - Importación de Productos

## 🚀 Quick Start

```bash
# 1. Reconstruir contenedores con permisos
.\fix-permissions.ps1

# 2. Verificar permisos en BD
docker compose exec app php artisan db:seed --class=CheckSuppliersProductImportsPermissionsSeeder

# 3. Ejecutar tests
.\run-product-import-tests.ps1

# 4. Probar importación
.\test-product-import.ps1
```

## 🧪 Tests

```bash
# Todos los tests del módulo
docker compose exec app php artisan test tests/Unit/Services/ProductAttributesValidatorTest.php tests/Unit/Services/ProductImportServiceTest.php tests/Feature/Http/Controllers/ProductImportControllerTest.php

# Solo validador
docker compose exec app php artisan test tests/Unit/Services/ProductAttributesValidatorTest.php

# Solo servicio
docker compose exec app php artisan test tests/Unit/Services/ProductImportServiceTest.php

# Solo controlador
docker compose exec app php artisan test tests/Feature/Http/Controllers/ProductImportControllerTest.php

# Test específico
docker compose exec app php artisan test --filter it_validates_complete_notebook_attributes

# Con cobertura
docker compose exec app php artisan test --coverage

# Verbose
docker compose exec app php artisan test --verbose
```

## 📦 Importación

```bash
# Vista previa de un archivo
docker compose exec app php artisan products:import /path/to/file.xlsx 1 --preview

# Importar con actualización
docker compose exec app php artisan products:import /path/to/file.xlsx 1 --update-existing

# Importar plantilla ECOPC
docker compose exec app php artisan products:import public/templates/XLSX/plantilla_ecopc_validada_con_conectividad.xlsx 1 --update-existing
```

## 🔍 Debugging

```bash
# Ver logs en tiempo real
docker compose logs -f app

# Limpiar caché
docker compose exec app php artisan optimize:clear

# Regenerar autoload
docker compose exec app composer dump-autoload

# Entrar al contenedor
docker compose exec app sh

# Ver productos creados
docker compose exec app php artisan tinker
>>> Product::count()
>>> Product::latest()->take(5)->get(['sku', 'name', 'attributes_json'])
```

## 🗄️ Base de Datos

```bash
# Resetear base de datos
docker compose exec app php artisan migrate:fresh --seed

# Solo migraciones
docker compose exec app php artisan migrate

# Rollback
docker compose exec app php artisan migrate:rollback

# Ver estado de migraciones
docker compose exec app php artisan migrate:status

# Entrar a PostgreSQL
docker compose exec db psql -U postgres -d zentriaback
```

## 🧹 Limpieza

```bash
# Limpiar storage/framework/cache
Remove-Item -Path "storage\framework\cache\data\*" -Recurse -Force

# Limpiar logs
Remove-Item -Path "storage\logs\*" -Force

# Limpiar vendor y reinstalar
Remove-Item -Path "vendor" -Recurse -Force
docker compose exec app composer install
```

## 📊 Verificación de Datos

```bash
# Contar productos por sucursal
docker compose exec app php artisan tinker
>>> DB::table('products')->select('branch_id', DB::raw('count(*) as total'))->groupBy('branch_id')->get()

# Ver productos con atributos
>>> Product::whereNotNull('attributes_json')->count()
>>> Product::whereNotNull('attributes_json')->first()->attributes_json

# Ver marcas creadas
>>> Brand::all(['id', 'name', 'branch_id'])

# Ver categorías
>>> Category::all(['id', 'name', 'slug'])
```

## 🎨 Validación de Atributos

```bash
# Probar validación de atributos directamente
docker compose exec app php artisan tinker

>>> $validator = app(\App\Services\ProductAttributesValidator::class);
>>> $attributes = ['cpu' => ['brand' => 'Intel'], 'grade' => 'B', 'product_kind' => 'notebook'];
>>> $result = $validator->validateAndProcess($attributes, 'notebook');
>>> print_r($result);
```

## 🔧 Desarrollo

```bash
# Crear un nuevo test
docker compose exec app php artisan make:test Services/MiNuevoTest --unit

# Crear un factory
docker compose exec app php artisan make:factory ProductFactory

# Crear un seeder
docker compose exec app php artisan make:seeder ProductsSeeder

# Listar rutas
docker compose exec app php artisan route:list --path=products

# Ver info del sistema
docker compose exec app php artisan about
```

## 📝 Git

```bash
# Ver archivos modificados
git status

# Ver cambios en validador
git diff app/Services/ProductAttributesValidator.php

# Commit de tests
git add tests/
git commit -m "feat: add comprehensive product import tests"

# Commit de documentación
git add docs/ PRODUCT-IMPORT-IMPLEMENTATION.md
git commit -m "docs: add product import documentation"
```

## 🐛 Troubleshooting

```bash
# Si los tests fallan por permisos
.\fix-permissions.ps1

# Si fallan por base de datos
docker compose exec app php artisan migrate:fresh --env=testing

# Si fallan por autoload
docker compose exec app composer dump-autoload

# Si fallan por caché
docker compose exec app php artisan config:clear
docker compose exec app php artisan cache:clear
docker compose exec app php artisan route:clear

# Ver errores de Laravel
docker compose exec app tail -f storage/logs/laravel.log

# Reiniciar servicios
docker compose down
docker compose up -d
```

## 📈 Performance

```bash
# Optimizar para producción
docker compose exec app php artisan config:cache
docker compose exec app php artisan route:cache
docker compose exec app php artisan view:cache

# Ver tiempo de ejecución de tests
docker compose exec app php artisan test --profile

# Analizar memoria
docker compose exec app php artisan test --memory-limit=512M
```

## 🌐 API Testing con cURL

```bash
# Obtener token (ajustar según tu auth)
$token = "tu-token-aqui"

# Vista previa
curl -X POST http://localhost:8000/api/products/import/preview \
  -H "Authorization: Bearer $token" \
  -F "file=@public/templates/CSV/ejemplo-importacion-productos.csv"

# Validar atributos
curl -X POST http://localhost:8000/api/products/validate-attributes \
  -H "Authorization: Bearer $token" \
  -H "Content-Type: application/json" \
  -d '{
    "attributes": {
      "cpu": {"brand": "Intel", "model": "I7 14700"},
      "ram": {"capacity_gb": 16, "type": "DDR4"},
      "grade": "B",
      "product_kind": "notebook"
    }
  }'
```

## � Permisos y Roles

```bash
# Verificar permisos de suppliers y product imports
docker compose exec app php artisan db:seed --class=CheckSuppliersProductImportsPermissionsSeeder

# Re-sincronizar roles y permisos
docker compose exec app php artisan db:seed --class=RolesAndPermissionsSeeder

# Limpiar cache de permisos
docker compose exec app php artisan permission:cache-reset

# Ver rutas de suppliers
docker compose exec app php artisan route:list --path=subsidiaries

# Ver rutas de product imports
docker compose exec app php artisan route:list --path=products/import

# Ver rutas de excel tests
docker compose exec app php artisan route:list --path=excel-test

# Ejecutar tests de permisos
docker compose exec app php artisan test tests/Feature/SuppliersProductImportsPermissionsTest.php
```

## �📚 Documentación

```bash
# Generar documentación de API (si usas herramientas)
docker compose exec app php artisan l5-swagger:generate

# Ver todas las rutas de productos
docker compose exec app php artisan route:list | Select-String "products"

# Ver documentación de permisos
# Ver: docs/permissions-suppliers-product-imports.md
# Ver: docs/api-endpoints-import.md
# Ver: docs/RESUMEN-PERMISOS-IMPLEMENTATION.md
```

## 🎯 Producción

```bash
# Antes de deploy
docker compose exec app php artisan test
docker compose exec app php artisan config:cache
docker compose exec app php artisan route:cache
docker compose exec app php artisan view:cache
docker compose exec app composer install --no-dev --optimize-autoloader

# Backup de base de datos
docker compose exec db pg_dump -U postgres zentriaback > backup.sql

# Restaurar backup
cat backup.sql | docker compose exec -T db psql -U postgres zentriaback
```
